# Engage Admin

Web back office for Engage. Front end only: every read and write goes to the Engage Gateway.

## Stack

React 19.3 + TypeScript 6.0 + Vite 8, MUI 9 (emotion), React Router 8 (`BrowserRouter` + `Routes`, no data router), MSAL browser 5 for Entra sign-in, msw 3 for mocks, Vitest 5 + Testing Library (jsdom), Playwright 1.64, ESLint 10 + typescript-eslint, Prettier.

## Scripts

`npm run dev` (port 5174), `build`, `lint`, `typecheck`, `test`, `test:e2e`, `format`, `format:check`, `verify` (build, lint, format check, unit tests, Playwright). Every task ends with `npm run verify` green.

## Layout

- `src/ds`: design system (tokens, theme, fonts, `Panel`). Copy the DS from `src/ds`; never restyle with ad-hoc colours.
- `src/data`: gateway client. The gateway contract is `docs/api/gateway-swagger.json` (Pradeep's C# gateway); the page and mock follow it exactly.
- `src/auth`: `AuthProvider` and `useAuth()`.
- `src/mocks`: msw handlers and fixtures, shared by the browser worker and the test server.
- `src/screens`: one folder per screen.
- `src/app`: app root, routes and shell.
- `src/test`: test setup and helpers.
- `e2e`: Playwright specs.

## Rules

- English only.
- Mock mode is the default: with `VITE_GATEWAY_URL` unset, `main.tsx` starts the msw worker and the app signs in as "Local Admin".
- Stand-in mode: `VITE_ENTRA_MOCK=1` (`npm run dev:entra-mock`, port 5175) replaces MSAL with `src/auth/fakeMsal.ts` and a stand-in page at `/mock-entra-sign-in`; accounts live in `sessionStorage`. It takes precedence over the real `VITE_ENTRA_*` settings.
- msw 3 names the unhandled-request option `onUnhandledFrame`, not `onUnhandledRequest`.
- Direct commits on `dev`; no feature branches or PRs.

## Hosting

- The app is served under the base path `/engage-admin/`.
- `src/config.ts` is the only place settings are read: window config (`config.js`, written at container start) first, then `VITE_` env.
- `.env.example` names stay for local development.
