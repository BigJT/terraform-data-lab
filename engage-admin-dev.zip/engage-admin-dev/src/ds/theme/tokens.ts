export const colors = {
  canvas: '#EBEDF1',
  panel: '#FFFFFF',
  rule: '#D2D7DF',
  textPrimary: '#1C355E',
  textSecondary: '#706E6C',
  textMuted: '#949291',
  chrome: '#495D7E',
  onChrome: '#F8F9FA',
  green: '#34C759',
  amber: '#EDA100',
  red: '#FF383C',
  strip: '#F8F9FA',
} as const

export const badgeColors = {
  'Broker portal': '#495D7E',
  Bloomberg: '#2E3E80',
  Email: '#992E63',
  Network: '#50A1A1',
  Market: '#1C355E',
} as const

export const fontFamily = "'Source Sans 3', sans-serif"
