import { createTheme } from '@mui/material/styles'
import { frFR } from '@mui/material/locale'
import { frFR as pickersFrFR } from '@mui/x-date-pickers/locales'
import { colors, fontFamily } from './tokens'
import { fontFaceCss } from './fonts'

export const theme = createTheme({
  palette: {
    primary: { main: colors.chrome },
    text: { primary: colors.textPrimary, secondary: colors.textSecondary },
    background: { default: colors.canvas, paper: colors.panel },
  },
  typography: { fontFamily },
  shape: { borderRadius: 2 },
  shadows: Array.from({ length: 25 }, () => 'none') as never,
  components: {
    MuiCssBaseline: {
      styleOverrides: `${fontFaceCss}\nbody { font-variant-numeric: tabular-nums; }`,
    },
    MuiButton: {
      defaultProps: { disableElevation: true, disableRipple: true },
      styleOverrides: {
        root: {
          textTransform: 'none',
          minHeight: 28,
          padding: '0 12px',
          fontSize: 13,
          fontWeight: 600,
        },
      },
    },
  },
})

// MUI's own French for its built-in text (pagination, autocomplete, date picker).
export const frenchTheme = createTheme(theme, frFR, pickersFrFR)
