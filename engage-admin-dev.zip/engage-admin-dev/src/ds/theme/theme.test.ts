import { describe, expect, it } from 'vitest'
import { theme } from './theme'

describe('theme', () => {
  it('uses the Engage chrome colour as the primary', () => {
    expect(theme.palette.primary.main).toBe('#495D7E')
  })

  it('paints the canvas in the Engage background grey', () => {
    expect(theme.palette.background.default).toBe('#EBEDF1')
  })

  it('sets Source Sans 3 as the font family', () => {
    expect(theme.typography.fontFamily).toContain('Source Sans 3')
  })
})
