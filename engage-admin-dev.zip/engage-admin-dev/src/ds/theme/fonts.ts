import SourceSansLight from '@/ds/fonts/SourceSans3-Light.otf'
import SourceSansRegular from '@/ds/fonts/SourceSans3-Regular.otf'
import SourceSansMedium from '@/ds/fonts/SourceSans3-Medium.otf'
import SourceSansSemibold from '@/ds/fonts/SourceSans3-Semibold.otf'
import SourceSansBold from '@/ds/fonts/SourceSans3-Bold.otf'

interface FontFace {
  url: string
  weight: 300 | 400 | 500 | 600 | 700
}

const faces: FontFace[] = [
  { url: SourceSansLight, weight: 300 },
  { url: SourceSansRegular, weight: 400 },
  { url: SourceSansMedium, weight: 500 },
  { url: SourceSansSemibold, weight: 600 },
  { url: SourceSansBold, weight: 700 },
]

/** Self-hosted @font-face declarations for CssBaseline's global styles. */
export const fontFaceCss = faces
  .map(
    (face) => `
@font-face {
  font-family: 'Source Sans 3';
  src: url('${face.url}') format('opentype');
  font-weight: ${String(face.weight)};
  font-style: normal;
  font-display: swap;
}`,
  )
  .join('\n')
