import DOMPurify from 'dompurify'

/** The only place stored HTML is rendered: sanitised first. */
export function SafeHtml({ html }: { html: string }) {
  return (
    <div
      dangerouslySetInnerHTML={{
        __html: DOMPurify.sanitize(html, { USE_PROFILES: { html: true } }),
      }}
    />
  )
}
