import { useState } from 'react'
import { describe, expect, it } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AttachmentPicker } from './AttachmentPicker'

const mb = 1024 * 1024

function file(name: string, size: number) {
  return new File([new Uint8Array(size)], name)
}

function Harness() {
  const [files, setFiles] = useState<File[]>([])
  return <AttachmentPicker label="Attachment" files={files} onChange={setFiles} />
}

async function choose(user: ReturnType<typeof userEvent.setup>, ...chosen: File[]) {
  await user.upload(screen.getByLabelText('Add an attachment input'), chosen)
}

describe('AttachmentPicker', () => {
  it('refuses an empty file', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('empty.txt', 0))
    expect(await screen.findByText('Attachment empty.txt is empty.')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Remove' })).not.toBeInTheDocument()
  })

  it('refuses a file over 10 MB', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('big.bin', 10 * mb + 1))
    expect(await screen.findByText('Attachment big.bin is larger than 10 MB.')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Remove' })).not.toBeInTheDocument()
  })

  it('accepts exactly 10 MB', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('ten.bin', 10 * mb))
    expect(await screen.findByText('ten.bin')).toBeInTheDocument()
  })

  it('refuses a file that takes the total over 15 MB', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('part1.bin', 8 * mb))
    await choose(user, file('part2.bin', 8 * mb))
    expect(await screen.findByText('Attachments must total 15 MB or less.')).toBeInTheDocument()
    expect(screen.getByText('part1.bin')).toBeInTheDocument()
    expect(screen.queryByText('part2.bin')).not.toBeInTheDocument()
  })

  it('lists a valid file with its size in KB and removes it', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('notes.txt', 2048))
    expect(await screen.findByText('notes.txt')).toBeInTheDocument()
    expect(screen.getByText('2 KB')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Remove' }))
    expect(screen.queryByText('notes.txt')).not.toBeInTheDocument()
  })

  it('rounds a part-kilobyte size up', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('notes.txt', 12))
    expect(await screen.findByText('1 KB')).toBeInTheDocument()
  })

  it('clears the error when a file is removed', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('empty.txt', 0), file('notes.txt', 12))
    expect(await screen.findByText('Attachment empty.txt is empty.')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Remove' }))
    expect(screen.queryByText('Attachment empty.txt is empty.')).not.toBeInTheDocument()
  })

  it('keeps valid files and reports the refused one from the same choice', async () => {
    const user = userEvent.setup()
    renderWithTheme(<Harness />)
    await choose(user, file('empty.txt', 0), file('notes.txt', 12))
    expect(await screen.findByText('Attachment empty.txt is empty.')).toBeInTheDocument()
    expect(screen.getByText('notes.txt')).toBeInTheDocument()
  })
})
