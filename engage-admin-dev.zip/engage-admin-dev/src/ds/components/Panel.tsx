import { Box, type BoxProps, type Theme } from '@mui/material'
import type { SystemStyleObject } from '@mui/system'
import type { ReactNode } from 'react'
import { colors } from '@/ds/theme'

interface PanelProps extends Omit<BoxProps, 'sx'> {
  heading?: ReactNode
  sx?: SystemStyleObject<Theme>
  children?: ReactNode
}

/** A white area on the canvas, headed in small capitals. */
export function Panel({ heading, children, sx, ...rest }: PanelProps) {
  return (
    <Box
      sx={{
        backgroundColor: colors.panel,
        border: `1px solid ${colors.rule}`,
        display: 'flex',
        flexDirection: 'column',
        minHeight: 0,
        ...sx,
      }}
      {...rest}
    >
      {heading !== undefined && (
        <Box
          component="h2"
          sx={{
            m: 0,
            px: 2,
            py: 1.25,
            fontSize: 14,
            fontWeight: 600,
            letterSpacing: '0.05em',
            textTransform: 'uppercase',
            color: colors.textPrimary,
            borderBottom: `1px solid ${colors.rule}`,
          }}
        >
          {heading}
        </Box>
      )}
      <Box sx={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>{children}</Box>
    </Box>
  )
}
