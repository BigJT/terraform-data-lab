import { Box, Button, IconButton, Popover, TextField } from '@mui/material'
import { EditorContent, useEditor, useEditorState, type Editor } from '@tiptap/react'
import type { EditorView } from '@tiptap/pm/view'
import StarterKit from '@tiptap/starter-kit'
import { TableKit } from '@tiptap/extension-table'
import Image from '@tiptap/extension-image'
import { useEffect, useRef, useState, type ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'

export interface RichTextEditorProps {
  label: string
  value: string
  onChange: (html: string) => void
  toolbar: 'basic' | 'full'
  error?: string
  readOnly?: boolean
  placeholder?: string
  onBlur?: () => void
  /** Keeps the label for assistive tech only, with no visible heading. */
  hideLabel?: boolean
}

/** True when the HTML has no visible text and no image. */
// eslint-disable-next-line react-refresh/only-export-components -- helper shared with the editor's users
export function isRichTextEmpty(html: string): boolean {
  const body = new DOMParser().parseFromString(html, 'text/html').body
  return body.textContent.trim() === '' && body.querySelector('img') === null
}

function imageFiles(files: FileList | File[] | undefined | null): File[] {
  return Array.from(files ?? []).filter((file) => file.type.startsWith('image/'))
}

/** A failed clipboard or file read inserts nothing. */
const ignore = () => undefined

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      resolve(reader.result as string)
    }
    reader.onerror = () => {
      reject(reader.error ?? new Error('Could not read the image'))
    }
    reader.readAsDataURL(file)
  })
}

/** Reads each image file to a data URL and inserts it at `at` (or the selection). */
function insertImages(view: EditorView, files: File[], at?: number) {
  for (const file of files) {
    void readAsDataUrl(file).then((src) => {
      const image = view.state.schema.nodes.image
      if (view.isDestroyed || !image) return
      const node = image.create({ src })
      const tr =
        at === undefined
          ? view.state.tr.replaceSelectionWith(node)
          : view.state.tr.insert(Math.min(at, view.state.doc.content.size), node)
      view.dispatch(tr)
    }, ignore)
  }
}

const basicExtensions = [StarterKit]

const fullExtensions = [
  StarterKit.configure({ link: { openOnClick: false } }),
  TableKit,
  Image.configure({ allowBase64: true, inline: true }),
]

function ToolButton({
  label,
  pressed,
  onClick,
  children,
}: {
  label: string
  pressed?: boolean
  onClick: (event: React.MouseEvent<HTMLButtonElement>) => void
  children: ReactNode
}) {
  return (
    <IconButton
      size="small"
      aria-label={label}
      aria-pressed={pressed ?? false}
      onMouseDown={(event) => {
        event.preventDefault()
      }}
      onClick={onClick}
      sx={{
        borderRadius: 1,
        minWidth: 32,
        fontSize: 13,
        fontWeight: 600,
        color: colors.textPrimary,
        bgcolor: pressed ? colors.rule : 'transparent',
      }}
    >
      {children}
    </IconButton>
  )
}

function Toolbar({ editor, kind }: { editor: Editor; kind: 'basic' | 'full' }) {
  const active = useEditorState({
    editor,
    selector: ({ editor: current }) => ({
      h2: current.isActive('heading', { level: 2 }),
      h3: current.isActive('heading', { level: 3 }),
      bold: current.isActive('bold'),
      italic: current.isActive('italic'),
      underline: current.isActive('underline'),
      bullet: current.isActive('bulletList'),
      ordered: current.isActive('orderedList'),
      link: current.isActive('link'),
    }),
  })
  const [linkAnchor, setLinkAnchor] = useState<HTMLElement | null>(null)
  const [url, setUrl] = useState('')
  const fileInput = useRef<HTMLInputElement>(null)
  const chain = () => editor.chain().focus()
  const { t } = useTranslation()

  const bold = (
    <ToolButton
      label={t('editor.bold')}
      pressed={active.bold}
      onClick={() => chain().toggleBold().run()}
    >
      B
    </ToolButton>
  )
  const italic = (
    <ToolButton
      label={t('editor.italic')}
      pressed={active.italic}
      onClick={() => chain().toggleItalic().run()}
    >
      <i>I</i>
    </ToolButton>
  )
  if (kind === 'basic') {
    return (
      <>
        {bold}
        {italic}
      </>
    )
  }

  const applyLink = () => {
    const href = url.trim()
    if (href === '') chain().extendMarkRange('link').unsetLink().run()
    else chain().extendMarkRange('link').setLink({ href }).run()
    setLinkAnchor(null)
  }

  const pastePlainText = () => {
    void navigator.clipboard.readText().then((text) => {
      const content = text
        .split(/\r?\n/)
        .flatMap((line, index) => [
          ...(index > 0 ? [{ type: 'hardBreak' }] : []),
          ...(line === '' ? [] : [{ type: 'text', text: line }]),
        ])
      chain().insertContent(content).run()
    }, ignore)
  }

  return (
    <>
      <ToolButton
        label={t('editor.heading2')}
        pressed={active.h2}
        onClick={() => chain().toggleHeading({ level: 2 }).run()}
      >
        H2
      </ToolButton>
      <ToolButton
        label={t('editor.heading3')}
        pressed={active.h3}
        onClick={() => chain().toggleHeading({ level: 3 }).run()}
      >
        H3
      </ToolButton>
      {bold}
      {italic}
      <ToolButton
        label={t('editor.underline')}
        pressed={active.underline}
        onClick={() => chain().toggleUnderline().run()}
      >
        <u>U</u>
      </ToolButton>
      <ToolButton
        label={t('editor.bulletList')}
        pressed={active.bullet}
        onClick={() => chain().toggleBulletList().run()}
      >
        •
      </ToolButton>
      <ToolButton
        label={t('editor.numberedList')}
        pressed={active.ordered}
        onClick={() => chain().toggleOrderedList().run()}
      >
        1.
      </ToolButton>
      <ToolButton
        label={t('editor.link')}
        pressed={active.link}
        onClick={(event) => {
          setUrl(String(editor.getAttributes('link').href ?? ''))
          setLinkAnchor(event.currentTarget)
        }}
      >
        🔗
      </ToolButton>
      <ToolButton
        label={t('editor.insertTable')}
        onClick={() => chain().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()}
      >
        ▦
      </ToolButton>
      <ToolButton label={t('editor.image')} onClick={() => fileInput.current?.click()}>
        🖼
      </ToolButton>
      <ToolButton label={t('editor.pastePlain')} onClick={pastePlainText}>
        T
      </ToolButton>
      <input
        ref={fileInput}
        type="file"
        accept="image/*"
        hidden
        onChange={(event) => {
          const file = imageFiles(event.target.files)[0]
          event.target.value = ''
          if (file) {
            void readAsDataUrl(file).then((src) => chain().setImage({ src }).run(), ignore)
          }
        }}
      />
      <Popover
        open={linkAnchor !== null}
        anchorEl={linkAnchor}
        onClose={() => {
          setLinkAnchor(null)
        }}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Box sx={{ p: 2, display: 'flex', gap: 1, alignItems: 'center' }}>
          <TextField
            label={t('editor.url')}
            size="small"
            autoFocus
            value={url}
            onChange={(event) => {
              setUrl(event.target.value)
            }}
          />
          <Button
            onClick={() => {
              setLinkAnchor(null)
            }}
          >
            {t('common.cancel')}
          </Button>
          <Button variant="contained" onClick={applyLink}>
            {t('editor.apply')}
          </Button>
        </Box>
      </Popover>
    </>
  )
}

/** TipTap editor with a basic (Bold, Italic) or full toolbar; value and onChange are HTML. */
export function RichTextEditor({
  label,
  value,
  onChange,
  toolbar,
  error,
  readOnly = false,
  placeholder,
  onBlur,
  hideLabel = false,
}: RichTextEditorProps) {
  const onChangeRef = useRef(onChange)
  const onBlurRef = useRef(onBlur)
  useEffect(() => {
    onChangeRef.current = onChange
    onBlurRef.current = onBlur
  }, [onChange, onBlur])

  const full = toolbar === 'full'
  const editor = useEditor(
    {
      extensions: full ? fullExtensions : basicExtensions,
      content: value,
      editable: !readOnly,
      editorProps: {
        attributes: { 'aria-label': label, 'aria-multiline': 'true', role: 'textbox' },
        handlePaste: full
          ? (view, event) => {
              const files = imageFiles(event.clipboardData?.files)
              if (files.length === 0) return false
              insertImages(view, files)
              return true
            }
          : undefined,
        handleDrop: full
          ? (view, event, _slice, moved) => {
              const files = imageFiles(event.dataTransfer?.files)
              if (moved || files.length === 0) return false
              const at = view.posAtCoords({ left: event.clientX, top: event.clientY })?.pos
              insertImages(view, files, at)
              return true
            }
          : undefined,
      },
      onUpdate: ({ editor: current }) => {
        onChangeRef.current(current.getHTML())
      },
      onBlur: () => {
        onBlurRef.current?.()
      },
    },
    [toolbar, label],
  )

  useEffect(() => {
    if (editor.getHTML() !== value) editor.commands.setContent(value, { emitUpdate: false })
  }, [editor, value])

  useEffect(() => {
    if (editor.isEditable === readOnly) editor.setEditable(!readOnly, false)
  }, [editor, readOnly])

  const empty = useEditorState({
    editor,
    selector: ({ editor: current }) => current.isEmpty,
  })

  return (
    <Box role="group" aria-label={label} sx={{ mb: 3 }}>
      {hideLabel ? null : (
        <Box sx={{ fontSize: 12, fontWeight: 600, color: colors.textSecondary, mb: 0.5 }}>
          {label}
        </Box>
      )}
      <Box
        sx={{
          border: `1px solid ${error ? colors.red : colors.rule}`,
          borderRadius: 1,
          bgcolor: colors.panel,
        }}
      >
        {readOnly ? null : (
          <Box
            sx={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: 0.5,
              p: 0.5,
              borderBottom: `1px solid ${colors.rule}`,
            }}
          >
            <Toolbar editor={editor} kind={toolbar} />
          </Box>
        )}
        <Box
          sx={{
            position: 'relative',
            fontSize: 14,
            color: colors.textPrimary,
            '& .tiptap': { minHeight: 80, p: 1.5, outline: 'none' },
            '& .tiptap p': { m: 0 },
            '& .tiptap img': { maxWidth: '100%' },
            '& .tiptap table': { borderCollapse: 'collapse', width: '100%' },
            '& .tiptap th, & .tiptap td': { border: `1px solid ${colors.rule}`, p: 0.5 },
          }}
        >
          {placeholder && empty ? (
            <Box
              aria-hidden
              sx={{
                position: 'absolute',
                top: 12,
                left: 12,
                color: colors.textSecondary,
                pointerEvents: 'none',
              }}
            >
              {placeholder}
            </Box>
          ) : null}
          <EditorContent editor={editor} />
        </Box>
      </Box>
      {error ? <Box sx={{ mt: 0.5, fontSize: 12, color: colors.red }}>{error}</Box> : null}
    </Box>
  )
}
