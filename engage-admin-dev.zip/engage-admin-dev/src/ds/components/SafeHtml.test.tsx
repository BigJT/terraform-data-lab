import { describe, expect, it } from 'vitest'
import { render } from '@testing-library/react'
import { SafeHtml } from './SafeHtml'

function html(input: string) {
  return render(<SafeHtml html={input} />).container
}

describe('SafeHtml', () => {
  it('removes script elements', () => {
    expect(html('<p>a</p><script>window.__xss = 1</script>').querySelector('script')).toBeNull()
  })

  it('removes event handler attributes', () => {
    const img = html('<img src="x" onerror="window.__xss = 2">').querySelector('img')
    expect(img?.hasAttribute('onerror')).toBe(false)
  })

  it('keeps strong, tables and data: images', () => {
    const container = html(
      '<strong>b</strong><table><tbody><tr><td>c</td></tr></tbody></table><img src="data:image/png;base64,AAAA">',
    )
    expect(container.querySelector('strong')?.textContent).toBe('b')
    expect(container.querySelector('td')?.textContent).toBe('c')
    expect(container.querySelector('img')?.getAttribute('src')).toBe('data:image/png;base64,AAAA')
  })
})
