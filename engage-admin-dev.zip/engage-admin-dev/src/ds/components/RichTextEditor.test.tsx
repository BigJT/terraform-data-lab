import { describe, expect, it, vi } from 'vitest'
import { fireEvent, screen, waitFor } from '@testing-library/react'
import { renderWithTheme } from '@/test/renderWithTheme'
import { RichTextEditor, isRichTextEmpty } from './RichTextEditor'

const fullNames = [
  'Heading 2',
  'Heading 3',
  'Bold',
  'Italic',
  'Underline',
  'Bullet list',
  'Numbered list',
  'Link',
  'Insert table',
  'Image',
  'Paste as plain text',
]

describe('isRichTextEmpty', () => {
  it.each([
    ['', true],
    ['<p></p>', true],
    ['<p>  </p><p>&nbsp;</p>', true],
    ['<p>Hi</p>', false],
    ['<p><img src="data:image/png;base64,AAAA"></p>', false],
  ])('%s is empty: %s', (html, empty) => {
    expect(isRichTextEmpty(html)).toBe(empty)
  })
})

describe('RichTextEditor', () => {
  it('offers only Bold and Italic on the basic toolbar', async () => {
    renderWithTheme(<RichTextEditor label="COMPANY" value="" onChange={vi.fn()} toolbar="basic" />)
    expect(await screen.findByRole('button', { name: 'Bold' })).toBeVisible()
    expect(
      screen.getAllByRole('button').map((button) => button.getAttribute('aria-label')),
    ).toEqual(['Bold', 'Italic'])
  })

  it('offers the full toolbar and shows the error text', async () => {
    renderWithTheme(
      <RichTextEditor label="BODY" value="" onChange={vi.fn()} toolbar="full" error="Required" />,
    )
    expect(await screen.findByRole('button', { name: 'Bold' })).toBeVisible()
    expect(
      screen.getAllByRole('button').map((button) => button.getAttribute('aria-label')),
    ).toEqual(fullNames)
    expect(screen.getByText('Required')).toBeVisible()
  })

  it('inserts a pasted PNG file as an inline data-URL image', async () => {
    const onChange = vi.fn()
    renderWithTheme(<RichTextEditor label="BODY" value="" onChange={onChange} toolbar="full" />)
    const box = await screen.findByRole('textbox', { name: 'BODY' })
    const file = new File([new Uint8Array([137, 80, 78, 71])], 'shot.png', { type: 'image/png' })
    const event = new Event('paste', { bubbles: true, cancelable: true })
    Object.defineProperty(event, 'clipboardData', {
      value: { files: [file], types: ['Files'], getData: () => '' },
    })
    fireEvent(box, event)
    await waitFor(() => {
      expect(box.querySelector('img[src]')?.getAttribute('src')).toMatch(/^data:image\/png;base64,/)
    })
    expect(onChange).toHaveBeenLastCalledWith(expect.stringContaining('data:image/png;base64,'))
  })
})
