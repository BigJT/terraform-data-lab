import { Alert, Box, Button } from '@mui/material'
import { useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'

const maxFileBytes = 10 * 1024 * 1024
const maxTotalBytes = 15 * 1024 * 1024

interface Props {
  files: File[]
  onChange: (files: File[]) => void
  label: string
}

export function AttachmentPicker({ files, onChange, label }: Props) {
  const { t } = useTranslation()
  const input = useRef<HTMLInputElement>(null)
  const [errors, setErrors] = useState<string[]>([])

  function choose(chosen: File[]) {
    const found: string[] = []
    const accepted = [...files]
    let total = files.reduce((sum, file) => sum + file.size, 0)
    for (const file of chosen) {
      if (file.size === 0) {
        found.push(t('attachments.empty', { name: file.name }))
      } else if (file.size > maxFileBytes) {
        found.push(t('attachments.tooLarge', { name: file.name }))
      } else if (total + file.size > maxTotalBytes) {
        found.push(t('attachments.totalTooLarge'))
      } else {
        accepted.push(file)
        total += file.size
      }
    }
    setErrors(found)
    onChange(accepted)
  }

  return (
    <Box>
      <Box sx={{ mt: 2, mb: 1, fontSize: 12, fontWeight: 600, color: colors.textSecondary }}>
        {label}
      </Box>
      <input
        ref={input}
        type="file"
        multiple
        hidden
        aria-label={t('attachments.inputLabel')}
        onChange={(event) => {
          choose(Array.from(event.target.files ?? []))
          event.target.value = ''
        }}
      />
      <Button
        variant="outlined"
        onClick={() => {
          input.current?.click()
        }}
      >
        {t('attachments.add')}
      </Button>
      {files.map((file, index) => (
        <Box
          key={`${file.name}-${String(index)}`}
          sx={{ display: 'flex', alignItems: 'center', gap: 2, mt: 1 }}
        >
          <span>{file.name}</span>
          <span>{t('attachments.size', { kb: Math.ceil(file.size / 1024) })}</span>
          <Button
            size="small"
            onClick={() => {
              setErrors([])
              onChange(files.filter((_, position) => position !== index))
            }}
          >
            {t('common.remove')}
          </Button>
        </Box>
      ))}
      {errors.length > 0 && (
        <Alert severity="error" sx={{ mt: 1 }}>
          {errors.map((error) => (
            <div key={error}>{error}</div>
          ))}
        </Alert>
      )}
    </Box>
  )
}
