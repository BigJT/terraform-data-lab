import type {
  AccountDto,
  AppVersion,
  Attachment,
  FactsetMultiple,
  FactsetPeer,
  DisconnectionLog,
  BrokerNoteDetail,
  CompanyRef,
  FlashDetail,
  ImportType,
  IndexInfo,
  Market,
  RicName,
  ReportValidation,
  RicQuote,
  Ticker,
  TickerList,
  WorkStatus,
} from '@/data/types'

export interface FixtureCompany {
  id: string
  name: string
  ric: string
  languageCode: 'fr-FR' | 'en-EN'
  marketCode: string
  sector: string
  subSector: string
  indices: [string | null, string | null, string | null, string | null]
  archived: boolean
}

export interface FixtureUser extends Omit<AccountDto, 'emitter'> {
  companyId: string
}

export const markets: Market[] = [
  { name: 'EPA', fullName: 'Euronext Paris', code: 'EPA', devise: 'EUR' },
  { name: 'LSE', fullName: 'London Stock Exchange', code: 'LSE', devise: 'GBp' },
]

export const sectors = [
  'Luxury',
  'Luxury/Fashion',
  'Food',
  'Food/Dairy',
  'Hospitality',
  'Beverages',
  'Payments',
  'Industrials',
  'Industrials/Capital Goods',
]

export const indices: IndexInfo[] = [
  { codeRIC: '.FCHI', name: 'CAC 40', type: 'national' },
  { codeRIC: '.FTSE', name: 'FTSE 100', type: 'national' },
  { codeRIC: '.STOXX50E', name: 'Euro Stoxx 50', type: 'national' },
  { codeRIC: '.SXNP', name: 'Stoxx Europe 600 Industrials', type: 'sector' },
  { codeRIC: '.SXQP', name: 'Stoxx Europe 600 Personal & Household Goods', type: 'sector' },
  { codeRIC: '.SX3P', name: 'Stoxx Europe 600 Food & Beverage', type: 'sector' },
]

const pairNames: RicName[] = [
  { ric: 'LVMH.PA', name: 'LVMH Moet Hennessy Louis Vuitton' },
  { ric: 'DANO.PA', name: 'Danone' },
  { ric: 'PRTP.PA', name: 'Kering' },
  { ric: 'ACCP.PA', name: 'Accor' },
  { ric: 'DGE.L', name: 'Diageo' },
  { ric: 'WLN.PA', name: 'Worldline' },
  { ric: 'OREP.PA', name: "L'Oreal" },
  { ric: 'HRMS.PA', name: 'Hermes International' },
  { ric: 'CDI.PA', name: 'Christian Dior' },
  { ric: 'NESN.S', name: 'Nestle' },
  { ric: 'ULVR.L', name: 'Unilever' },
  { ric: 'PERP.PA', name: 'Pernod Ricard' },
  { ric: 'ABI.BR', name: 'Anheuser-Busch InBev' },
  { ric: 'IHG.L', name: 'InterContinental Hotels Group' },
  { ric: 'WTB.L', name: 'Whitbread' },
  { ric: 'ADYEN.AS', name: 'Adyen' },
  { ric: 'NEXI.MI', name: 'Nexi' },
  { ric: 'SIEGn.DE', name: 'Siemens' },
  { ric: 'SGEF.PA', name: 'Vinci' },
  { ric: 'AIR.PA', name: 'Airbus' },
]

export const pairs: RicQuote[] = pairNames.map((pair) => ({
  ...pair,
  isin: `ISIN${pair.ric}`,
  currency: 'EUR',
}))

function seedCompanies(): FixtureCompany[] {
  const base = { languageCode: 'fr-FR', marketCode: 'EPA', subSector: '', archived: false } as const
  return [
    {
      ...base,
      id: 'c1',
      name: 'LVMH',
      ric: 'LVMH.PA',
      sector: 'Luxury',
      subSector: 'Luxury/Fashion',
      indices: ['.FCHI', '.SXQP', '.STOXX50E', null],
    },
    {
      ...base,
      id: 'c2',
      name: 'Danone',
      ric: 'DANO.PA',
      sector: 'Food',
      subSector: 'Food/Dairy',
      indices: ['.FCHI', '.SX3P', null, null],
    },
    {
      ...base,
      id: 'c3',
      name: 'Kering',
      ric: 'PRTP.PA',
      sector: 'Luxury',
      indices: ['.FCHI', '.SXQP', null, null],
    },
    {
      ...base,
      id: 'c4',
      name: 'Accor',
      ric: 'ACCP.PA',
      sector: 'Hospitality',
      indices: ['.FCHI', null, null, null],
    },
    {
      ...base,
      id: 'c5',
      name: 'Diageo',
      ric: 'DGE.L',
      languageCode: 'en-EN',
      marketCode: 'LSE',
      sector: 'Beverages',
      indices: ['.FTSE', '.SX3P', null, null],
    },
    {
      ...base,
      id: 'c6',
      name: 'Worldline',
      ric: 'WLN.PA',
      sector: 'Payments',
      indices: [null, null, null, null],
      archived: true,
    },
  ]
}

const reads = {
  passwordChangeRequired: false,
  lastDailyDate: '2026-10-09T06:00:00Z',
  lastDailyReadDate: '2026-10-09T08:00:00Z',
  lastFlashDate: '2026-10-08T14:00:00Z',
  lastFlashReadDate: '2026-10-08T14:30:00Z',
}

function user(
  id: string,
  companyId: string,
  firstname: string,
  lastname: string,
  jobFunction: string,
  email: string,
  phone: string | undefined,
  role: string,
  cgu: string | undefined,
): FixtureUser {
  return {
    ...reads,
    id,
    companyId,
    firstname,
    lastname,
    jobFunction,
    email,
    phone,
    authorities: [role],
    cgu,
  }
}

function seedUsers(): FixtureUser[] {
  const standard = 'ROLE_EMITTER'
  const limited = 'ROLE_EMITTER_LIMITED'
  const julien = user(
    'u2',
    'c1',
    'Julien',
    'Bernard',
    'Investor Relations Analyst',
    'julien.bernard@lvmh.example',
    undefined,
    limited,
    undefined,
  )
  delete julien.lastDailyReadDate
  delete julien.lastFlashReadDate
  return [
    user(
      'u1',
      'c1',
      'Claire',
      'Martin',
      'Head of Investor Relations',
      'claire.martin@lvmh.example',
      '+33 1 44 13 22 22',
      standard,
      '2025-03-14T09:00:00Z',
    ),
    julien,
    user(
      'u3',
      'c2',
      'Sophie',
      'Laurent',
      'Investor Relations Director',
      'sophie.laurent@danone.example',
      '+33 1 44 35 20 20',
      standard,
      '2024-11-02T10:00:00Z',
    ),
    user(
      'u4',
      'c2',
      'Marc',
      'Dubois',
      'Finance Manager',
      'marc.dubois@danone.example',
      undefined,
      limited,
      '2025-06-20T10:00:00Z',
    ),
    user(
      'u5',
      'c3',
      'Elodie',
      'Petit',
      'Investor Relations Manager',
      'elodie.petit@kering.example',
      '+33 1 45 64 61 00',
      standard,
      '2025-01-10T10:00:00Z',
    ),
    user(
      'u6',
      'c3',
      'Thomas',
      'Moreau',
      'Head of Communications',
      'thomas.moreau@kering.example',
      undefined,
      standard,
      '2025-09-01T10:00:00Z',
    ),
    user(
      'u7',
      'c4',
      'Camille',
      'Roux',
      'Investor Relations Director',
      'camille.roux@accor.example',
      '+33 1 45 38 86 00',
      standard,
      '2025-02-18T10:00:00Z',
    ),
    user(
      'u8',
      'c4',
      'Hugo',
      'Lefevre',
      'Treasury Analyst',
      'hugo.lefevre@accor.example',
      undefined,
      limited,
      '2025-05-05T10:00:00Z',
    ),
    user(
      'u9',
      'c5',
      'James',
      'Walker',
      'Head of Investor Relations',
      'james.walker@diageo.example',
      '+44 20 8978 6000',
      standard,
      '2024-12-12T10:00:00Z',
    ),
    user(
      'u10',
      'c5',
      'Emma',
      'Clarke',
      'Investor Relations Manager',
      'emma.clarke@diageo.example',
      undefined,
      limited,
      '2025-07-07T10:00:00Z',
    ),
    user(
      'u11',
      'c5',
      'Oliver',
      'Hughes',
      'Company Secretary',
      'oliver.hughes@diageo.example',
      undefined,
      standard,
      '2025-08-19T10:00:00Z',
    ),
    user(
      'u12',
      'c6',
      'Nicolas',
      'Garnier',
      'Investor Relations Manager',
      'nicolas.garnier@worldline.example',
      '+33 1 34 34 95 95',
      standard,
      '2024-10-01T10:00:00Z',
    ),
  ]
}

export interface FixtureReportState {
  id: string
  date: string
  languageCode: 'fr-FR' | 'en-EN'
  writingStatus: WorkStatus
  validation: ReportValidation
  sent: boolean
  sentAt?: string
  lockedBy: string | null
  updatedAt: string
}

export interface FixtureReport extends FixtureReportState {
  companyId: string
  sector: string
  value: string
  customContent1: string
  customContent2: string
  graphPosition: Attachment | null
}

export type FixtureMarketReport = FixtureReportState & { content: string }

export const marketLanguages = {
  'fr-FR': { languageId: '6f1c2a1e-0000-4000-8000-000000000001', languageName: 'French' },
  'en-EN': { languageId: '6f1c2a1e-0000-4000-8000-000000000002', languageName: 'English' },
} as const

export const localAdmin = 'Local Admin'

export function localDate(date: Date): string {
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${String(date.getFullYear())}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

/** ISO instant for a local `YYYY-MM-DD` date at local `HH:mm`. */
export function localInstant(date: string, time = '00:00'): string {
  const [year, month, day] = date.split('-').map(Number)
  const [hours, minutes] = time.split(':').map(Number)
  return new Date(year ?? 0, (month ?? 1) - 1, day ?? 1, hours ?? 0, minutes ?? 0).toISOString()
}

export function emptyReport(companyId: string, language: 'fr-FR' | 'en-EN', date: string) {
  const state: FixtureReport = {
    id: `r-${companyId}-${date}`,
    companyId,
    date,
    languageCode: language,
    sector: '',
    value: '',
    customContent1: '',
    customContent2: '',
    graphPosition: null,
    writingStatus: 'todo',
    validation: { writing: 'todo', content: 'todo', status: 'todo' },
    sent: false,
    lockedBy: null,
    updatedAt: localInstant(date),
  }
  return state
}

export function emptyMarketReport(language: 'fr-FR' | 'en-EN', date: string) {
  const state: FixtureMarketReport = {
    id: `m-${language}-${date}`,
    date,
    languageCode: language,
    content: '',
    writingStatus: 'todo',
    validation: { writing: 'todo', content: 'todo', status: 'todo' },
    sent: false,
    lockedBy: null,
    updatedAt: localInstant(date),
  }
  return state
}

function seedReports(): FixtureReport[] {
  const today = localDate(new Date())
  const at = (time: string) => localInstant(today, time)
  const report = (
    companyId: string,
    language: 'fr-FR' | 'en-EN',
    time: string,
    fields: Partial<FixtureReport>,
  ): FixtureReport => ({
    ...emptyReport(companyId, language, today),
    updatedAt: at(time),
    ...fields,
  })
  return [
    report('c1', 'fr-FR', '07:45', {
      value: '<p><strong>LVMH</strong> shares rose 1.2% after the Q3 update.</p>',
      sector: '<p>Luxury names traded higher across Europe.</p>',
      customContent1:
        '<p><strong>Desk note</strong></p><script>window.__xss = 1</script><img src="x" onerror="window.__xss = 2">',
      writingStatus: 'done',
      validation: { writing: 'done', content: 'done', status: 'done' },
      sent: true,
      sentAt: at('07:45'),
    }),
    report('c2', 'fr-FR', '07:30', {
      value: '<p>Danone was flat in a quiet session.</p>',
      sector: '<p>Food producers lagged the index.</p>',
      writingStatus: 'done',
      validation: { writing: 'doing', content: 'doing', status: 'doing' },
    }),
    report('c3', 'fr-FR', '07:20', {
      value: '<p>Kering slipped 0.8%.</p>',
      lockedBy: 'jean.martin@rothschildandco.com',
    }),
    report('c4', 'fr-FR', '07:00', {}),
    report('c5', 'en-EN', '07:10', { value: '<p>Diageo gained 0.5% in London.</p>' }),
  ]
}

function seedMarketReports(): FixtureMarketReport[] {
  const today = localDate(new Date())
  return [
    {
      ...emptyMarketReport('fr-FR', today),
      content: '<p>European markets closed higher, led by luxury stocks.</p>',
      writingStatus: 'done',
      validation: { writing: 'done', content: 'done', status: 'done' },
      updatedAt: localInstant(today, '06:50'),
    },
    { ...emptyMarketReport('en-EN', today), updatedAt: localInstant(today, '06:40') },
  ]
}

export const flashTypes = [
  'Price movement',
  'Pre-opening',
  'Breaking News',
  'Reco / TP',
  "Sales traders' comments",
  'Brokers Interests',
  'Brokers Comments',
  'Peer report',
]

export const brokers = [
  'Barclays',
  'BofA',
  'CIC Market Solutions',
  'Citi',
  'IDMidcaps',
  'Oddo BHF',
  'RBC Capital',
  'Redburn Atlantic',
  'Seaport Global',
  'Zacks',
]

export const recommendations = [
  'BUY',
  'NEUTRAL',
  'OUTPERFORM',
  'OVERWEIGHT',
  'HOLD',
  'UNDERWEIGHT',
  'SELL',
  'EQUALWEIGHT',
]

const noteEmitters: Record<string, CompanyRef> = {
  c1: { id: 'c1', name: 'LVMH', ric: 'LVMH.PA' },
  c2: { id: 'c2', name: 'Danone', ric: 'DANO.PA' },
  c3: { id: 'c3', name: 'Kering', ric: 'PRTP.PA' },
  c4: { id: 'c4', name: 'Accor', ric: 'ACCP.PA' },
  c5: { id: 'c5', name: 'Diageo', ric: 'DGE.L' },
}

function seedBrokerNote(
  fields: Partial<BrokerNoteDetail> &
    Pick<
      BrokerNoteDetail,
      | 'id'
      | 'broker'
      | 'title'
      | 'currency'
      | 'currentObjective'
      | 'currentRecommendation'
      | 'createdAt'
    > & { emitterId: string },
): BrokerNoteDetail {
  const { emitterId, ...rest } = fields
  return {
    company: noteEmitters[emitterId] ?? { id: emitterId, name: emitterId, ric: '' },
    sectorNote: false,
    initiationNote: false,
    recommendationChange: false,
    previousObjective: null,
    previousRecommendation: null,
    monitoringOfficer: null,
    sendByMail: false,
    attachments: [],
    ...rest,
  }
}

function seedBrokerNotes(): BrokerNoteDetail[] {
  return [
    seedBrokerNote({
      id: 'bn1',
      emitterId: 'c1',
      broker: 'Barclays',
      title: 'Target price raised after Q3',
      currency: '€',
      currentObjective: 720,
      currentRecommendation: 'OVERWEIGHT',
      recommendationChange: true,
      previousObjective: 680,
      previousRecommendation: 'NEUTRAL',
      createdAt: '2026-10-09T07:45:00Z',
    }),
    seedBrokerNote({
      id: 'bn2',
      emitterId: 'c5',
      broker: 'Citi',
      title: 'Initiating coverage',
      currency: 'p',
      currentObjective: 3100,
      currentRecommendation: 'BUY',
      initiationNote: true,
      createdAt: '2026-10-08T08:10:00Z',
    }),
    seedBrokerNote({
      id: 'bn3',
      emitterId: 'c2',
      broker: 'Oddo BHF',
      title: null,
      currency: '€',
      currentObjective: 64,
      currentRecommendation: 'HOLD',
      sectorNote: true,
      createdAt: '2026-10-07T09:30:00Z',
    }),
    seedBrokerNote({
      id: 'bn4',
      emitterId: 'c3',
      broker: 'BofA',
      title: 'Downgrade on China demand',
      currency: '€',
      currentObjective: 290,
      currentRecommendation: 'UNDERWEIGHT',
      recommendationChange: true,
      previousObjective: 340,
      previousRecommendation: 'NEUTRAL',
      createdAt: '2026-10-06T06:55:00Z',
    }),
    seedBrokerNote({
      id: 'bn5',
      emitterId: 'c4',
      broker: 'RBC Capital',
      title: 'Hotels upcycle intact',
      currency: '€',
      currentObjective: 48,
      currentRecommendation: 'OUTPERFORM',
      attachments: [
        { id: 'att-bn5', fileName: 'accor-rbc.pdf', contentType: 'application/pdf', size: 245760 },
      ],
      createdAt: '2026-10-05T07:00:00Z',
    }),
  ]
}

export type FixtureFlash = FlashDetail

function seedFlash(
  fields: Omit<FlashDetail, 'relatedCompanies'> & { emitterIds: string[] },
): FlashDetail {
  const { emitterIds, ...rest } = fields
  return {
    ...rest,
    relatedCompanies: emitterIds.map((id) => noteEmitters[id] ?? { id, name: id, ric: '' }),
  }
}

function seedFlashes(): FlashDetail[] {
  return [
    seedFlash({
      id: 'f1',
      createdAt: '2026-10-12T07:45:00Z',
      title: 'LVMH Q3 revenue ahead of consensus',
      company: 'LVMH',
      type: 'Breaking News',
      emitterIds: ['c1'],
      links: ['https://www.lvmh.com/investors'],
      sendByEmail: true,
      attachments: [],
      description:
        '<p>LVMH reported Q3 organic revenue growth of 3%, ahead of the 1% consensus.</p>',
    }),
    seedFlash({
      id: 'f2',
      createdAt: '2026-10-11T15:20:00Z',
      title: 'Danone shares up 2.4% in early trade',
      company: 'Danone',
      type: 'Price movement',
      emitterIds: ['c2'],
      links: [],
      sendByEmail: false,
      attachments: [],
      description: '<p>Danone is trading up 2.4% after a broker upgrade.</p>',
    }),
    seedFlash({
      id: 'f3',
      createdAt: '2026-10-10T06:55:00Z',
      title: 'Pre-opening: European luxury sector',
      company: 'Kering',
      type: 'Pre-opening',
      emitterIds: ['c1', 'c3'],
      links: [],
      sendByEmail: false,
      attachments: [
        { id: 'a1', fileName: 'luxury-preopen.pdf', contentType: 'application/pdf', size: 2048 },
      ],
      description: '<p>Futures point to a firmer open for luxury names.</p>',
    }),
    seedFlash({
      id: 'f4',
      createdAt: '2026-10-09T12:10:00Z',
      title: "Diageo: brokers' comments after trading update",
      company: 'Diageo',
      type: 'Brokers Comments',
      emitterIds: ['c5'],
      links: ['https://www.diageo.com/en/investors', 'https://www.londonstockexchange.com'],
      sendByEmail: true,
      attachments: [],
      description: '<p>Brokers broadly positive on the trading update.</p>',
    }),
    seedFlash({
      id: 'f5',
      createdAt: '2026-10-08T09:30:00Z',
      title: 'Peer report: hospitality',
      company: 'Accor',
      type: 'Peer report',
      emitterIds: ['c1', 'c2', 'c3', 'c4', 'c5'],
      links: [],
      sendByEmail: false,
      attachments: [],
      description: '<p>Weekly hospitality peer comparison.</p>',
    }),
  ]
}

function seedAttachmentBytes(): Map<string, { contentType: string; bytes: Uint8Array }> {
  const bytes = new Uint8Array(2048).fill(0x20)
  bytes.set(new TextEncoder().encode('%PDF-1.4'))
  return new Map([['a1', { contentType: 'application/pdf', bytes }]])
}

export interface MockTickerList extends TickerList {
  emitterId: string
}

function seedTickerLists(): MockTickerList[] {
  const ticker = (id: string, ric: string) => ({
    id,
    ricCode: ric,
    name: pairs.find((pair) => pair.ric === ric)?.name ?? ric,
  })
  const list = (id: string, emitterId: string, name: string, tickers: Ticker[]) => ({
    id,
    emitterId,
    name,
    comments: '',
    tickers,
    createdAt: '2026-09-01T09:00:00Z',
    updatedAt: '2026-09-01T09:00:00Z',
  })
  return [
    list('l1', 'c1', 'Luxury peers', [
      ticker('t1', 'HRMS.PA'),
      ticker('t2', 'CDI.PA'),
      ticker('t3', 'PRTP.PA'),
    ]),
    list('l2', 'c1', 'European consumer', [ticker('t4', 'OREP.PA')]),
    list('l3', 'c2', 'Food peers', [ticker('t5', 'NESN.S'), ticker('t6', 'ULVR.L')]),
  ]
}

export const availableMultiples: FactsetMultiple[] = [
  { id: 1, key: 'PE', label: 'P/E' },
  { id: 2, key: 'EV_EBITDA', label: 'EV/EBITDA' },
  { id: 3, key: 'EV_SALES', label: 'EV/Sales' },
  { id: 4, key: 'PB', label: 'P/B' },
  { id: 5, key: 'DIV_YIELD', label: 'Dividend yield' },
  { id: 6, key: 'FCF_YIELD', label: 'FCF yield' },
]

export interface FactsetState {
  peers: FactsetPeer[]
  multipleKeys: string[]
}

function seedFactsets(): Record<string, FactsetState> {
  return {
    c1: {
      peers: [
        { id: 1, factsetName: 'Hermes International', factsetId: 'HRMS-FR' },
        { id: 2, factsetName: 'Kering', factsetId: 'PRTP-FR' },
      ],
      multipleKeys: ['PE', 'EV_EBITDA'],
    },
  }
}

export const importTypes: ImportType[] = [
  { kind: 'stock', label: 'Short BlackApp (file 10)' },
  { kind: 'consensus', label: 'Consensus' },
  { kind: 'stock-lending', label: 'Short Markit (file 9)' },
  { kind: 'reco-tp', label: 'Reco TP' },
]

function seedAppVersions(): AppVersion[] {
  return [{ version: '3.4.0', forceUpdate: false }]
}

export const disconnectionReasons = [
  'TOKEN_EXPIRED',
  'TOKEN_INVALID_SIGNATURE',
  'TOKEN_REVOKED',
  'USER_NOT_FOUND',
  'SESSION_CORRUPTED',
  'TOKEN_REPLACED_BY_NEW_LOGIN',
  'TOKEN_MALFORMED',
  'TOKEN_INVALID',
  'USER_DEACTIVATED',
  'INSUFFICIENT_ROLES',
  'MANUAL_LOGOUT',
]

const disconnectionEmails = [
  'claire.martin@lvmh.example',
  'sophie.laurent@danone.example',
  'james.walker@diageo.example',
  'camille.roux@accor.example',
  'elodie.petit@kering.example',
]

function seedDisconnections(): DisconnectionLog[] {
  const now = Date.now()
  return Array.from({ length: 45 }, (_, i) => {
    const desktop = i % 2 === 0
    return {
      id: `d${String(i + 1)}`,
      createdAt: new Date(now - (i * 48 + 1) * 3_600_000).toISOString(),
      userEmail: disconnectionEmails[i % 5] ?? '',
      platform: desktop ? 'DESKTOP' : 'MOBILE',
      reason: disconnectionReasons[i % 11] ?? '',
      ipAddress: `10.0.0.${String(i + 1)}`,
      userAgent: desktop
        ? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Engage Desktop/2.3.0'
        : 'Engage/3.4.0 (iPhone; iOS 26.5)',
      details: `Mock disconnection ${String(i + 1)}`,
    }
  })
}

// Module state: writes persist until the page reloads (or resetFixtures in tests).
export const db = {
  companies: seedCompanies(),
  users: seedUsers(),
  reports: seedReports(),
  marketReports: seedMarketReports(),
  flashes: seedFlashes(),
  brokerNotes: seedBrokerNotes(),
  tickerLists: seedTickerLists(),
  attachmentBytes: seedAttachmentBytes(),
  appVersions: seedAppVersions(),
  disconnections: seedDisconnections(),
  factsets: seedFactsets(),
}

export function resetFixtures() {
  db.companies = seedCompanies()
  db.users = seedUsers()
  db.reports = seedReports()
  db.marketReports = seedMarketReports()
  db.flashes = seedFlashes()
  db.brokerNotes = seedBrokerNotes()
  db.tickerLists = seedTickerLists()
  db.attachmentBytes = seedAttachmentBytes()
  db.appVersions = seedAppVersions()
  db.disconnections = seedDisconnections()
  db.factsets = seedFactsets()
}
