import dayjs from 'dayjs'
import { http, HttpResponse, type RequestHandler } from 'msw'
import type {
  BrokerNoteDetail,
  BrokerNoteSummary,
  BrokerNoteRequest,
  CompanyDetail,
  CompanySummary,
  CreateCompanyFailure,
  CreateCompanyRequest,
  CreateFlashRequest,
  CreateTickerListRequest,
  AccountDto,
  CreateUserRequest,
  EconomicStatistic,
  FactsetPeer,
  FlashDetail,
  FlashPage,
  FlashSummary,
  MarketReportContent,
  MarketReportDetail,
  MarketReportSummary,
  Page,
  PublishAppVersionRequest,
  ReportContent,
  ReportDetail,
  ReportSummary,
  IndexInfo,
  UpdateIndicesRequest,
  UpdateUserRequest,
} from '@/data/types'
import {
  brokers,
  db,
  emptyMarketReport,
  emptyReport,
  flashTypes,
  availableMultiples,
  type MockTickerList,
  importTypes,
  indices,
  localAdmin,
  localDate,
  localInstant,
  marketLanguages,
  markets,
  pairs,
  recommendations,
  sectors,
  type FixtureCompany,
  type FixtureMarketReport,
  type FixtureReport,
  type FixtureReportState,
  type FixtureUser,
} from './fixtures'

const emitters = '*/api-admin/emitters-management/emitter'
const accounts = '*/api-admin/accounts-management'
const referential = '*/api-admin/referential'
const reports = '*/api-admin/reports'

const notFound = () => HttpResponse.json({ message: 'Not found' }, { status: 404 })
const bad = (message: string) => HttpResponse.json({ message }, { status: 400 })

function summary(company: FixtureCompany): CompanySummary {
  return {
    id: company.id,
    name: company.name,
    ric: company.ric,
    isArchived: company.archived,
    devise: marketOf(company).devise,
    sectors: [{ name: company.subSector || company.sector }],
    associatedAccountsCount: db.users.filter((user) => user.companyId === company.id).length,
  }
}

function indexRef(ric: string | null): IndexInfo | null {
  return indices.find((index) => index.codeRIC === ric) ?? null
}

function marketOf(company: FixtureCompany) {
  const market = markets.find((candidate) => candidate.code === company.marketCode)
  if (!market) throw new Error(`Unknown fixture market ${company.marketCode}`)
  return market
}

function detail(company: FixtureCompany): CompanyDetail {
  const [national1, sector1, national2, sector2] = company.indices
  return {
    id: company.id,
    name: company.name,
    ric: company.ric,
    sector: company.subSector || company.sector,
    isArchived: company.archived,
    market: marketOf(company),
    primaryIndice1: indexRef(national1),
    primaryIndice2: indexRef(sector1),
    primaryIndice3: indexRef(national2),
    primaryIndice4: indexRef(sector2),
    languageCode: company.languageCode,
  }
}

const sameText = (a: string, b: string) => a.toLowerCase() === b.toLowerCase()

function toUser(fixture: FixtureUser): AccountDto {
  const { companyId, ...account } = fixture
  const company = db.companies.find((candidate) => candidate.id === companyId)
  if (!company) throw new Error(`Unknown fixture company ${companyId}`)
  return { ...account, emitter: detail(company) }
}

type NewUserFields = Omit<CreateUserRequest, 'emitterId' | 'roles'> & { roles?: string[] }

function newUser(companyId: string, fields: NewUserFields): FixtureUser {
  const { firstName, lastName, roles, ...rest } = fields
  return {
    ...rest,
    firstname: firstName,
    lastname: lastName,
    authorities: roles ?? ['ROLE_EMITTER'],
    id: crypto.randomUUID(),
    companyId,
    passwordChangeRequired: true,
  }
}

function setArchived(archived: boolean) {
  return ({ params }: { params: Record<string, string | readonly string[] | undefined> }) => {
    const company = db.companies.find((candidate) => candidate.id === params.emitterId)
    if (!company) return notFound()
    company.archived = archived
    return new HttpResponse(null, { status: 200 })
  }
}

// Shared by the browser worker (dev) and the node server (tests).

const languages = ['fr-FR', 'en-EN'] as const

/** `dd-MM-yyyy` path date to `YYYY-MM-DD`, or today when absent. */
function dayOf(param: string | readonly string[] | undefined): string {
  if (typeof param !== 'string') return localDate(new Date())
  const [day = '', month = '', year = ''] = param.split('-')
  return `${year}-${month}-${day}`
}

function ensureReports(date: string): FixtureReport[] {
  for (const company of db.companies.filter((candidate) => !candidate.archived)) {
    if (!db.reports.some((row) => row.companyId === company.id && row.date === date)) {
      db.reports.push(emptyReport(company.id, company.languageCode, date))
    }
  }
  return db.reports.filter((row) => row.date === date && !companyOf(row).archived)
}

function ensureMarketReports(date: string): FixtureMarketReport[] {
  for (const language of languages) {
    if (!db.marketReports.some((row) => row.languageCode === language && row.date === date)) {
      db.marketReports.push(emptyMarketReport(language, date))
    }
  }
  return languages.flatMap((language) =>
    db.marketReports.filter((row) => row.languageCode === language && row.date === date),
  )
}

function companyOf(row: FixtureReport): FixtureCompany {
  const company = db.companies.find((candidate) => candidate.id === row.companyId)
  if (!company) throw new Error(`Unknown fixture company ${row.companyId}`)
  return company
}

function stateOf(row: FixtureReportState) {
  return {
    id: row.id,
    languageCode: row.languageCode,
    writingStatus: row.writingStatus,
    validation: { ...row.validation },
    sent: row.sent,
    lockedBy: row.lockedBy,
    lockedByCaller: row.lockedBy === localAdmin,
    createdAt: localInstant(row.date, '05:00'),
    updatedAt: row.updatedAt,
  }
}

function reportSummary(row: FixtureReport): ReportSummary {
  const company = companyOf(row)
  const linked = ensureMarketReports(row.date).find((m) => m.languageCode === row.languageCode)
  return {
    ...stateOf(row),
    emitterId: company.id,
    companyName: company.name,
    ric: company.ric,
    sentAt: row.sentAt ?? null,
    marketReportId: linked?.id ?? null,
  }
}

function marketSummary(row: FixtureMarketReport): MarketReportSummary {
  return { ...stateOf(row), ...marketLanguages[row.languageCode] }
}

function economicStatistics(): EconomicStatistic[] {
  const stamp = dayjs().hour(6).minute(0).second(0).millisecond(0).toISOString()
  const row = (
    zone: string,
    country: string,
    object: string,
    period: string,
    actual: string,
    expected: string,
    previous: string,
    released: string,
  ) => ({
    zone,
    country,
    object,
    period,
    actual,
    expected,
    previous,
    released,
    createdAt: stamp,
    updated_at: stamp,
  })
  return [
    row('Europe', 'France', 'CPI (YoY)', 'Sep', '1.2%', '1.3%', '1.4%', '08:45'),
    row('Europe', 'Germany', 'ZEW Economic Sentiment', 'Oct', '12.5', '10.0', '9.8', '11:00'),
    row('Americas', 'United States', 'Retail Sales (MoM)', 'Sep', '0.4%', '0.3%', '0.1%', '14:30'),
  ]
}

function reportDetail(row: FixtureReport): ReportDetail {
  const linked = ensureMarketReports(row.date).find((m) => m.languageCode === row.languageCode)
  return {
    ...reportSummary(row),
    sector: row.sector,
    value: row.value,
    customContent1: row.customContent1,
    customContent2: row.customContent2,
    graphPosition: row.graphPosition,
    marketContent: linked?.content ?? null,
  }
}

function marketDetail(row: FixtureMarketReport): MarketReportDetail {
  return { ...marketSummary(row), content: row.content }
}

type Edit<Row extends FixtureReportState> = (row: Row, request: Request) => Promise<void> | void

function write<Row extends FixtureReportState>(
  rows: () => Row[],
  out: (row: Row) => ReportDetail | MarketReportDetail,
  edit: Edit<Row>,
) {
  return async ({ params, request }: { params: Record<string, unknown>; request: Request }) => {
    const row = rows().find((candidate) => candidate.id === params.id)
    if (!row) return notFound()
    await edit(row, request)
    row.updatedAt = new Date().toISOString()
    return HttpResponse.json(out(row))
  }
}

const signOffs = {
  writing_status: (row: FixtureReportState) => {
    row.writingStatus = 'done'
    row.validation = { writing: 'doing', content: 'doing', status: 'doing' }
  },
  'validation/analysis': (row: FixtureReportState) => {
    row.validation.writing = 'done'
    if (row.validation.content === 'done') row.validation.status = 'done'
  },
  'validation/content': (row: FixtureReportState) => {
    row.validation.content = 'done'
    if (row.validation.writing === 'done') row.validation.status = 'done'
  },
  sent: (row: FixtureReportState) => {
    row.sent = true
    row.sentAt = new Date().toISOString()
  },
  lock: (row: FixtureReportState) => {
    row.lockedBy = localAdmin
  },
  unlock: (row: FixtureReportState) => {
    row.lockedBy = null
  },
}

function reportHandlers(): RequestHandler[] {
  const company = () => db.reports
  const market = () => db.marketReports
  const handlers: RequestHandler[] = []
  for (const [name, apply] of Object.entries(signOffs)) {
    if (name === 'validation/content') continue
    handlers.push(
      http.put(`${reports}/market/:id/${name}`, write(market, marketDetail, apply)),
      http.put(`${reports}/:id/${name}`, write(company, reportDetail, apply)),
    )
  }
  return [
    http.put(
      `${reports}/market/:id/validation/content`,
      write(market, marketDetail, async (row, request) => {
        row.content = ((await request.json()) as MarketReportContent).content
        signOffs['validation/content'](row)
      }),
    ),
    http.put(
      `${reports}/:id/validation/content`,
      write(company, reportDetail, signOffs['validation/content']),
    ),
    http.get(`${reports}/market/byId/:id`, ({ params }) => {
      const row = db.marketReports.find((candidate) => candidate.id === params.id)
      return row ? HttpResponse.json(marketDetail(row)) : notFound()
    }),
    http.get(`${reports}/market/:date`, ({ params }) =>
      HttpResponse.json(ensureMarketReports(dayOf(params.date)).map(marketSummary)),
    ),
    http.get(`${reports}/market`, () =>
      HttpResponse.json(ensureMarketReports(dayOf(undefined)).map(marketSummary)),
    ),
    http.get(`${reports}/byId/:id`, ({ params }) => {
      const row = db.reports.find((candidate) => candidate.id === params.id)
      return row ? HttpResponse.json(reportDetail(row)) : notFound()
    }),
    http.get(`${reports}/:date`, ({ params }) =>
      HttpResponse.json(ensureReports(dayOf(params.date)).map(reportSummary)),
    ),
    http.get(reports, () => HttpResponse.json(ensureReports(dayOf(undefined)).map(reportSummary))),
    http.put(
      `${reports}/market/:id/content`,
      write(market, marketDetail, async (row, request) => {
        row.content = ((await request.json()) as MarketReportContent).content
      }),
    ),
    http.get(`${reports}/statistics/economic`, ({ request }) => {
      const date = new URL(request.url).searchParams.get('date')
      return HttpResponse.json(date === dayjs().format('YYYY-MM-DD') ? economicStatistics() : [])
    }),
    http.post(
      `${reports}/:id/graph-position`,
      write(company, reportDetail, async (row, request) => {
        const file = (await request.formData()).get('graph-position')
        if (file === null || typeof file === 'string')
          throw new Error('Missing graph-position part')
        row.graphPosition = {
          id: crypto.randomUUID(),
          fileName: file.name,
          contentType: file.type,
          size: file.size,
        }
      }),
    ),
    http.delete(
      `${reports}/:id/graph-position`,
      write(company, reportDetail, (row) => {
        row.graphPosition = null
      }),
    ),
    http.put(
      `${reports}/:id/content`,
      write(company, reportDetail, async (row, request) => {
        const { sector, value, customContent1, customContent2 } =
          (await request.json()) as ReportContent
        Object.assign(row, { sector, value, customContent1, customContent2 })
      }),
    ),
    ...handlers,
  ]
}

export const handlers: RequestHandler[] = [
  http.get(emitters, () => HttpResponse.json(db.companies.map(summary))),
  http.put(emitters, async ({ request }) => {
    const body = (await request.json()) as CreateCompanyRequest
    if (db.companies.some((company) => sameText(company.ric, body.ric))) {
      return bad('An emitter with same RIC code already exists')
    }
    const company: FixtureCompany = {
      id: crypto.randomUUID(),
      name: body.name,
      ric: body.ric,
      languageCode: body.languageCode,
      marketCode: body.marketCode,
      sector: body.sector,
      subSector: body.subSector ?? '',
      indices: [
        body.primaryIndiceRic1 ?? null,
        body.primaryIndiceRic2 ?? null,
        body.primaryIndiceRic3 ?? null,
        body.primaryIndiceRic4 ?? null,
      ],
      archived: false,
    }
    db.companies.push(company)
    const failures: CreateCompanyFailure[] = []
    for (const collaborator of body.collaborators) {
      if (db.users.some((existing) => sameText(existing.email, collaborator.email))) {
        failures.push({
          collaborator: collaborator.email,
          message: `Email ${collaborator.email} is already used.`,
        })
      } else {
        db.users.push(newUser(company.id, collaborator))
      }
    }
    return HttpResponse.json({ emitter: detail(company), failures })
  }),
  http.put(`${emitters}/indice/:emitterId`, async ({ params, request }) => {
    const company = db.companies.find((candidate) => candidate.id === params.emitterId)
    if (!company) return notFound()
    const body = (await request.json()) as UpdateIndicesRequest
    company.indices = [
      body.primaryIndiceRic1,
      body.primaryIndiceRic2,
      body.primaryIndiceRic3,
      body.primaryIndiceRic4,
    ]
    return new HttpResponse(null, { status: 200 })
  }),
  http.put(`${emitters}/:emitterId/archive`, setArchived(true)),
  http.put(`${emitters}/:emitterId/unarchive`, setArchived(false)),
  http.get(`${emitters}/:emitterId`, ({ params }) => {
    const company = db.companies.find((candidate) => candidate.id === params.emitterId)
    return company ? HttpResponse.json(detail(company)) : notFound()
  }),
  http.get('*/api-admin/pairs-management/pairs/ric/:search', ({ params }) => {
    const found = pairs.find((pair) => sameText(pair.ric, String(params.search)))
    return found ? HttpResponse.json(found) : notFound()
  }),
  http.get(`${referential}/market`, () => HttpResponse.json(markets)),
  http.get(`${referential}/sectors`, () => HttpResponse.json(sectors)),
  http.get(`${referential}/indices`, () => HttpResponse.json(indices)),
  http.get(`${accounts}/emitter/:emitterId`, ({ params }) =>
    HttpResponse.json(db.users.filter((user) => user.companyId === params.emitterId).map(toUser)),
  ),
  http.put(`${accounts}/account`, async ({ request }) => {
    const body = (await request.json()) as CreateUserRequest
    if (db.users.some((user) => sameText(user.email, body.email))) {
      return bad(`Email ${body.email} is already used.`)
    }
    const { emitterId, ...fields } = body
    const created = newUser(emitterId, fields)
    db.users.push(created)
    return HttpResponse.json(toUser(created))
  }),
  http.post(`${accounts}/account/:accountId`, async ({ params, request }) => {
    const existing = db.users.find((user) => user.id === params.accountId)
    if (!existing) return notFound()
    const body = (await request.json()) as UpdateUserRequest
    if (db.users.some((user) => user.id !== existing.id && sameText(user.email, body.email))) {
      return bad(`Email ${body.email} is already used.`)
    }
    const { firstName, lastName, roles, emitterId, ...rest } = body
    Object.assign(existing, {
      ...rest,
      firstname: firstName,
      lastname: lastName,
      authorities: roles,
      companyId: emitterId,
    })
    return HttpResponse.json(toUser(existing))
  }),
  http.delete(`${accounts}/account/delete/:accountId`, ({ params }) => {
    const at = db.users.findIndex((user) => user.id === params.accountId)
    if (at < 0) return bad(`No account with UUID: ${String(params.accountId)}`)
    db.users.splice(at, 1)
    return new HttpResponse(null, { status: 200 })
  }),
  http.get(`${accounts}/roles`, () => HttpResponse.json(['ROLE_EMITTER', 'ROLE_EMITTER_LIMITED'])),
  ...reportHandlers(),
  ...flashHandlers(),
  ...brokerNoteHandlers(),
  ...tickerListHandlers(),
  ...importHandlers(),
  ...factsetHandlers(),
  ...appVersionHandlers(),
  ...disconnectionHandlers(),
]

function flashSummary(flash: FlashDetail): FlashSummary {
  return {
    id: flash.id,
    title: flash.title,
    company: flash.company,
    type: flash.type,
    description: flash.description,
    sendByEmail: flash.sendByEmail,
    attachmentCount: flash.attachments.length,
    relatedCompanyCount: flash.relatedCompanies.length,
    createdAt: flash.createdAt,
  }
}

function brokerNoteSummary(note: BrokerNoteDetail): BrokerNoteSummary {
  const summary: Partial<BrokerNoteDetail> = { ...note }
  delete summary.sendByMail
  delete summary.attachments
  return {
    ...(summary as Omit<BrokerNoteSummary, 'attachmentCount'>),
    attachmentCount: note.attachments.length,
  }
}

function flashHandlers(): RequestHandler[] {
  const flashes = '*/api-admin/flashs'
  return [
    http.get(flashes, ({ request }) => {
      const params = new URL(request.url).searchParams
      const needle = (params.get('q') ?? '').trim().toLowerCase()
      const page = Number(params.get('page') ?? 0)
      const size = Number(params.get('size') ?? 20)
      const matching = db.flashes
        .filter((flash) =>
          `${flash.title}\n${flash.company}\n${flash.type}\n${flash.description}`
            .toLowerCase()
            .includes(needle),
        )
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      const body: FlashPage = {
        content: matching.slice(page * size, (page + 1) * size).map(flashSummary),
        totalElements: matching.length,
        totalPages: Math.ceil(matching.length / size),
        number: page,
        size,
      }
      return HttpResponse.json(body)
    }),
    http.get(`${flashes}/:id`, ({ params }) => {
      const found = db.flashes.find((flash) => flash.id === params.id)
      return found ? HttpResponse.json(found) : notFound()
    }),
    http.delete(`${flashes}/:id`, ({ params }) => {
      const at = db.flashes.findIndex((flash) => flash.id === params.id)
      if (at < 0) return notFound()
      db.flashes.splice(at, 1)
      return new HttpResponse(null, { status: 200 })
    }),
    http.post(flashes, async ({ request }) => {
      const data = await request.formData()
      const part = data.get('flash')
      const text = typeof part === 'string' ? part : await (part as Blob).text()
      const body = JSON.parse(text) as CreateFlashRequest
      if (body.title === 'Mock server error') {
        return HttpResponse.json({ message: 'Mock failure' }, { status: 500 })
      }
      const recipients = body.sendToAll
        ? db.companies.filter((company) => !company.archived).map((company) => company.id)
        : body.emittersUUID
      const attachments: FlashDetail['attachments'] = []
      for (const file of data.getAll('attachments')) {
        if (typeof file === 'string') continue
        const attachmentId = crypto.randomUUID()
        db.attachmentBytes.set(attachmentId, {
          contentType: file.type,
          bytes: new Uint8Array(await file.arrayBuffer()),
        })
        attachments.push({
          id: attachmentId,
          fileName: file.name,
          contentType: file.type,
          size: file.size,
        })
      }
      const now = new Date().toISOString()
      const created: FlashDetail = {
        id: crypto.randomUUID(),
        title: body.title,
        company: body.value,
        description: body.description,
        type: body.type,
        links: body.links,
        sendByEmail: body.sendByEmail,
        relatedCompanies: recipients.map((recipient) => {
          const found = db.companies.find((company) => company.id === recipient)
          return { id: recipient, name: found?.name ?? recipient, ric: found?.ric ?? '' }
        }),
        attachments,
        createdAt: now,
      }
      db.flashes.push(created)
      return HttpResponse.json(created)
    }),
    http.get('*/api-admin/referential/types/flash', () => HttpResponse.json(flashTypes)),
    http.get('*/api/attachment/:id/content', ({ params }) => {
      const stored = db.attachmentBytes.get(String(params.id))
      if (!stored) return notFound()
      return new HttpResponse(stored.bytes, { headers: { 'Content-Type': stored.contentType } })
    }),
  ]
}

function brokerNoteHandlers(): RequestHandler[] {
  const notes = '*/api-admin/broker-note'
  return [
    http.get(notes, ({ request }) => {
      const params = new URL(request.url).searchParams
      const needle = (params.get('q') ?? '').trim().toLowerCase()
      const page = Number(params.get('page') ?? 0)
      const size = Number(params.get('size') ?? 20)
      const matching = db.brokerNotes
        .filter((note) =>
          `${note.company.name}\n${note.broker}\n${note.title ?? ''}\n${note.currentRecommendation}`
            .toLowerCase()
            .includes(needle),
        )
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      const body: Page<BrokerNoteSummary> = {
        content: matching.slice(page * size, (page + 1) * size).map(brokerNoteSummary),
        totalElements: matching.length,
        totalPages: Math.ceil(matching.length / size),
        number: page,
        size,
      }
      return HttpResponse.json(body)
    }),
    http.post(notes, async ({ request }) => {
      const data = await request.formData()
      const part = data.get('note')
      const body = JSON.parse(
        typeof part === 'string' ? part : await (part as Blob).text(),
      ) as BrokerNoteRequest
      const company = db.companies.find((candidate) => candidate.id === body.emitterId)
      if (!company) return HttpResponse.json({ message: 'Unknown company' }, { status: 400 })
      const id = crypto.randomUUID()
      const created: BrokerNoteDetail = {
        id,
        company: { id: company.id, name: company.name, ric: company.ric },
        title: body.title ?? null,
        broker: body.broker,
        currency: body.currency,
        currentObjective: Number(body.currentObjective),
        currentRecommendation: body.currentRecommendation,
        sectorNote: body.sectorNote,
        initiationNote: body.initiationNote,
        recommendationChange: body.recoChange,
        previousObjective: body.previousObjective ? Number(body.previousObjective) : null,
        previousRecommendation: body.previousRecommendation ?? null,
        monitoringOfficer: null,
        sendByMail: body.sendByEmail,
        attachments: data
          .getAll('attachments')
          .filter((file) => typeof file !== 'string')
          .map((file) => ({
            id: crypto.randomUUID(),
            fileName: file.name,
            contentType: file.type || 'application/octet-stream',
            size: file.size,
          })),
        createdAt: new Date().toISOString(),
      }
      db.brokerNotes.push(created)
      return HttpResponse.json(created)
    }),
    http.get(`${notes}/lastOfEmitter/:emitterId`, ({ params }) => {
      const newest = db.brokerNotes
        .filter((note) => note.company.id === params.emitterId)
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0]
      return newest ? HttpResponse.json(newest) : new HttpResponse(null, { status: 204 })
    }),
    http.get(`${notes}/:id`, ({ params }) => {
      const found = db.brokerNotes.find((note) => note.id === params.id)
      return found ? HttpResponse.json(found) : notFound()
    }),
    http.delete(`${notes}/:id`, ({ params }) => {
      const at = db.brokerNotes.findIndex((note) => note.id === params.id)
      if (at < 0) return notFound()
      db.brokerNotes.splice(at, 1)
      return new HttpResponse(null, { status: 200 })
    }),
    http.get('*/api-admin/referential/broker', () => HttpResponse.json(brokers)),
    http.get('*/api-admin/referential/types/broker-note', () => HttpResponse.json(recommendations)),
  ]
}

function tickerListHandlers(): RequestHandler[] {
  const lists = '*/api-admin/tickers'
  const duplicate = (name: string) =>
    bad(`A list with name [${name}] already exists for the emitter.`)
  const taken = (emitterId: string, name: string, exceptId?: string) =>
    db.tickerLists.some(
      (list) => list.emitterId === emitterId && list.id !== exceptId && sameText(list.name, name),
    )
  const toTicker = (ric: string, name: string) => {
    const pair = pairs.find((candidate) => sameText(candidate.ric, ric))
    return pair ? { id: crypto.randomUUID(), ricCode: pair.ric, name } : null
  }
  const noPair = (ric: string) =>
    HttpResponse.json({ message: `No pair with RIC [${ric}]` }, { status: 404 })
  const publicList = (list: MockTickerList) => ({
    id: list.id,
    name: list.name,
    comments: list.comments,
    tickers: list.tickers,
    createdAt: list.createdAt,
    updatedAt: list.updatedAt,
  })
  return [
    http.get(`${lists}/by-emitter/:emitterId`, ({ params, request }) => {
      const search = new URL(request.url).searchParams
      const page = Number(search.get('page') ?? 0)
      const size = Number(search.get('size') ?? 100)
      const matching = db.tickerLists.filter((list) => list.emitterId === params.emitterId)
      return HttpResponse.json({
        criteria: null,
        emitterId: params.emitterId,
        resultPage: {
          content: matching.slice(page * size, (page + 1) * size).map(publicList),
          totalElements: matching.length,
          totalPages: Math.ceil(matching.length / size),
          number: page,
          size,
        },
      })
    }),
    http.put(lists, async ({ request }) => {
      const body = (await request.json()) as CreateTickerListRequest
      if (taken(body.emitterId, body.name)) return duplicate(body.name)
      const created = []
      for (const { ric, name } of body.tickers) {
        const ticker = toTicker(ric, name)
        if (!ticker) return noPair(ric)
        created.push(ticker)
      }
      const now = new Date().toISOString()
      const list = {
        id: crypto.randomUUID(),
        emitterId: body.emitterId,
        name: body.name,
        comments: body.comments,
        tickers: created,
        createdAt: now,
        updatedAt: now,
      }
      db.tickerLists.push(list)
      return HttpResponse.json(publicList(list))
    }),
    http.put(`${lists}/:listId/ticker`, async ({ params, request }) => {
      const list = db.tickerLists.find((candidate) => candidate.id === params.listId)
      if (!list) return notFound()
      const { ric, name } = (await request.json()) as { ric: string; name: string }
      const ticker = toTicker(ric, name)
      if (!ticker) return noPair(ric)
      list.tickers.push(ticker)
      return HttpResponse.json(publicList(list))
    }),
    http.post(`${lists}/:listId`, async ({ params, request }) => {
      const list = db.tickerLists.find((candidate) => candidate.id === params.listId)
      if (!list) return notFound()
      const { name, comments } = (await request.json()) as { name: string; comments: string }
      if (taken(list.emitterId, name, list.id)) return duplicate(name)
      list.name = name
      list.comments = comments
      return HttpResponse.json(publicList(list))
    }),
    http.delete(`${lists}/ticker/:tickerId`, ({ params }) => {
      for (const list of db.tickerLists) {
        const at = list.tickers.findIndex((ticker) => ticker.id === params.tickerId)
        if (at >= 0) {
          list.tickers.splice(at, 1)
          return new HttpResponse(null, { status: 200 })
        }
      }
      return notFound()
    }),
    http.delete(`${lists}/:listId`, ({ params }) => {
      const at = db.tickerLists.findIndex((list) => list.id === params.listId)
      if (at < 0) return notFound()
      db.tickerLists.splice(at, 1)
      return new HttpResponse(null, { status: 200 })
    }),
  ]
}

function factsetHandlers(): RequestHandler[] {
  const factset = '*/api-admin/factset/emitter/:emitterId'
  const stateFor = (emitterId: string) =>
    (db.factsets[emitterId] ??= { peers: [], multipleKeys: [] })
  return [
    http.get(factset, ({ params }) => {
      const company = db.companies.find((candidate) => candidate.id === params.emitterId)
      if (!company) return notFound()
      const state = stateFor(company.id)
      return HttpResponse.json({
        peersBloomIds: state.peers,
        multiples: availableMultiples.filter((multiple) =>
          state.multipleKeys.includes(multiple.key),
        ),
        availableMultiples,
      })
    }),
    http.post(`${factset}/peers`, async ({ params, request }) => {
      const body = (await request.json()) as { emitterBloomIds: FactsetPeer[] }
      stateFor(String(params.emitterId)).peers = body.emitterBloomIds.map((peer, index) => ({
        ...peer,
        id: index + 1,
      }))
      return new HttpResponse(null, { status: 200 })
    }),
    http.put(`${factset}/multiples`, async ({ params, request }) => {
      stateFor(String(params.emitterId)).multipleKeys = (await request.json()) as string[]
      return new HttpResponse(null, { status: 200 })
    }),
  ]
}

function importHandlers(): RequestHandler[] {
  return [
    http.get('*/api-admin/import/excel-types', () => HttpResponse.json(importTypes)),
    http.post('*/api-admin/emitter/:emitterId/import/:kind', async ({ params, request }) => {
      const company = db.companies.find((candidate) => candidate.id === params.emitterId)
      if (!company) return notFound()
      const kind = String(params.kind)
      if (!importTypes.some((type) => type.kind === kind)) return bad(`Invalid type [${kind}]`)
      const file = (await request.formData()).get('file') as File | null
      const name = (file?.name ?? '').toLowerCase()
      if (name.includes('invalid')) return bad('Invalid Excel file')
      if (name.includes('no-brute')) return bad('Tab [Brute] not found in Excel file')
      if (name.includes('errors')) {
        return HttpResponse.json({
          totalRows: 150,
          okRows: 148,
          rowErrors: {
            '101': ["Field [Value] shouldn't be empty"],
            '117': [`Value [${company.ric}] was expected for field [RIC].`],
          },
        })
      }
      return HttpResponse.json({ totalRows: 20, okRows: 20, rowErrors: {} })
    }),
  ]
}

function appVersionHandlers(): RequestHandler[] {
  const path = '*/api-admin/app-version'
  return [
    http.get(path, () => {
      const latest = db.appVersions[db.appVersions.length - 1]
      return HttpResponse.json(latest ?? { version: null, forceUpdate: false })
    }),
    http.post(path, async ({ request }) => {
      const { version, forceUpdate } = (await request.json()) as PublishAppVersionRequest
      if (db.appVersions.some((existing) => existing.version === version)) {
        return bad(`A version ${version} already exists.`)
      }
      const created = { version, forceUpdate }
      db.appVersions.push(created)
      return HttpResponse.json(created)
    }),
  ]
}

function disconnectionHandlers(): RequestHandler[] {
  const day = 86_400_000
  return [
    http.get('*/api-admin/disconnections/stats', ({ request }) => {
      const days = Number(new URL(request.url).searchParams.get('days') ?? '7')
      const since = Date.now() - days * day
      const within = db.disconnections.filter((log) => Date.parse(log.createdAt) >= since)
      const tally = (key: 'reason' | 'platform') => {
        const counts = new Map<string, number>()
        for (const log of within) counts.set(log[key], (counts.get(log[key]) ?? 0) + 1)
        return [...counts]
      }
      return HttpResponse.json({
        days,
        from: new Date(since).toISOString(),
        to: new Date().toISOString(),
        totalDisconnections: within.length,
        last24hDisconnections: 3,
        reasonBreakdown: tally('reason').map(([reason, count]) => ({ reason, count })),
        platformBreakdown: tally('platform').map(([platform, count]) => ({ platform, count })),
        topDisconnectedUsers: [{ userEmail: 'claire.martin@lvmh.example', disconnectionCount: 4 }],
      })
    }),
    http.get('*/api-admin/disconnections', ({ request }) => {
      const params = new URL(request.url).searchParams
      const page = Number(params.get('page') ?? '0')
      const size = Number(params.get('size') ?? '20')
      const email = params.get('userEmail')?.toLowerCase()
      const start = params.get('startDate')
      const end = params.get('endDate')
      const platform = params.get('platform')
      const reason = params.get('reason')
      const matches = db.disconnections
        .filter(
          (log) =>
            (!email || log.userEmail.toLowerCase().includes(email)) &&
            (!start || log.createdAt.slice(0, 10) >= start) &&
            (!end || log.createdAt.slice(0, 10) <= end) &&
            (!platform || log.platform === platform) &&
            (!reason || log.reason === reason),
        )
        .sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt))
      return HttpResponse.json({
        content: matches.slice(page * size, (page + 1) * size),
        totalElements: matches.length,
        totalPages: Math.ceil(matches.length / size),
        number: page,
        size,
      })
    }),
  ]
}
