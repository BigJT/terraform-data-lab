import { createContext, useContext } from 'react'
import type { GatewayClient } from './gatewayClient'

export const GatewayContext = createContext<GatewayClient | null>(null)

export function useGateway(): GatewayClient {
  const client = useContext(GatewayContext)
  if (!client) throw new Error('useGateway must be used inside a GatewayProvider')
  return client
}
