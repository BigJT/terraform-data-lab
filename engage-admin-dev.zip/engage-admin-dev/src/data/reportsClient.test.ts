import { describe, expect, it } from 'vitest'
import dayjs from 'dayjs'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient } from './gatewayClient'

const client = createGatewayClient({
  baseUrl: 'http://gateway.test',
  getToken: () => Promise.resolve('tok'),
  onAuthError: () => undefined,
})

interface Seen {
  method: string
  path: string
  body: unknown
}

function capture(): Seen[] {
  const seen: Seen[] = []
  server.use(
    http.all('*/api-admin/reports/*', async ({ request }) => {
      const text = await request.text()
      seen.push({
        method: request.method,
        path: new URL(request.url).pathname,
        body: text ? (JSON.parse(text) as unknown) : undefined,
      })
      return HttpResponse.json([])
    }),
    http.get('*/api-admin/reports', ({ request }) => {
      seen.push({ method: 'GET', path: new URL(request.url).pathname, body: undefined })
      return HttpResponse.json([])
    }),
    http.get('*/api-admin/reports/market', ({ request }) => {
      seen.push({ method: 'GET', path: new URL(request.url).pathname, body: undefined })
      return HttpResponse.json([])
    }),
  )
  return seen
}

describe('reports client URLs', () => {
  it('lists today with no date and other days as dd-MM-yyyy', async () => {
    const seen = capture()
    await client.listReports(null)
    await client.listReports('2026-10-05')
    await client.listMarketReports(null)
    await client.listMarketReports('2026-10-05')
    expect(seen.map((call) => call.path)).toEqual([
      '/api-admin/reports',
      '/api-admin/reports/05-10-2026',
      '/api-admin/reports/market',
      '/api-admin/reports/market/05-10-2026',
    ])
  })

  it('addresses company report reads and writes', async () => {
    const seen = capture()
    const content = { sector: 's', value: 'v', customContent1: '1', customContent2: '2' }
    await client.getReport('r1')
    await client.saveReportContent('r1', content)
    await client.requestReportValidation('r1')
    await client.validateReportAnalysis('r1')
    await client.validateReportContent('r1')
    await client.sendReport('r1')
    await client.lockReport('r1')
    await client.unlockReport('r1')
    expect(seen.map((call) => `${call.method} ${call.path}`)).toEqual([
      'GET /api-admin/reports/byId/r1',
      'PUT /api-admin/reports/r1/content',
      'PUT /api-admin/reports/r1/writing_status',
      'PUT /api-admin/reports/r1/validation/analysis',
      'PUT /api-admin/reports/r1/validation/content',
      'PUT /api-admin/reports/r1/sent',
      'PUT /api-admin/reports/r1/lock',
      'PUT /api-admin/reports/r1/unlock',
    ])
    expect(seen[1]?.body).toEqual(content)
    expect(seen[2]?.body).toBeUndefined()
  })

  it('addresses market report reads and writes', async () => {
    const seen = capture()
    await client.getMarketReport('m1')
    await client.saveMarketReportContent('m1', { content: 'x' })
    await client.requestMarketReportValidation('m1')
    await client.validateMarketReportAnalysis('m1')
    await client.validateMarketReportContent('m1', { content: 'y' })
    await client.sendMarketReport('m1')
    await client.lockMarketReport('m1')
    await client.unlockMarketReport('m1')
    expect(seen.map((call) => `${call.method} ${call.path}`)).toEqual([
      'GET /api-admin/reports/market/byId/m1',
      'PUT /api-admin/reports/market/m1/content',
      'PUT /api-admin/reports/market/m1/writing_status',
      'PUT /api-admin/reports/market/m1/validation/analysis',
      'PUT /api-admin/reports/market/m1/validation/content',
      'PUT /api-admin/reports/market/m1/sent',
      'PUT /api-admin/reports/market/m1/lock',
      'PUT /api-admin/reports/market/m1/unlock',
    ])
    expect(seen[1]?.body).toEqual({ content: 'x' })
    expect(seen[3]?.body).toBeUndefined()
    expect(seen[4]?.body).toEqual({ content: 'y' })
  })
})

describe('reports mock handlers', () => {
  it('lists today as five company rows, never the archived company', async () => {
    const rows = await client.listReports(null)
    expect(rows.map((row) => row.companyName).sort()).toEqual([
      'Accor',
      'Danone',
      'Diageo',
      'Kering',
      'LVMH',
    ])
    const lvmh = rows.find((row) => row.companyName === 'LVMH')
    expect(lvmh).toMatchObject({ ric: 'LVMH.PA', validation: { status: 'done' }, sent: true })
    expect(lvmh?.sentAt).toBeDefined()
    expect(lvmh?.emitterId).toBe('c1')
    expect(lvmh?.marketReportId).toMatch(/^m-fr-FR-/)
    expect(dayjs(lvmh?.createdAt).format('HH:mm')).toBe('05:00')
  })

  it('creates empty rows on the fly for other dates, still without the archived company', async () => {
    const rows = await client.listReports('2026-10-05')
    expect(rows).toHaveLength(5)
    expect(rows.every((row) => row.validation.status === 'todo' && !row.sent)).toBe(true)
    expect(
      rows.every((row) => dayjs(row.createdAt).format('YYYY-MM-DD HH:mm') === '2026-10-05 05:00'),
    ).toBe(true)
    const markets = await client.listMarketReports('2026-10-05')
    expect(markets.map((row) => row.languageCode)).toEqual(['fr-FR', 'en-EN'])
  })

  it('lists today as two market rows', async () => {
    const rows = await client.listMarketReports(null)
    expect(
      rows.map((row) => [
        row.languageCode,
        row.languageName,
        row.languageId,
        row.validation.status,
      ]),
    ).toEqual([
      ['fr-FR', 'French', '6f1c2a1e-0000-4000-8000-000000000001', 'done'],
      ['en-EN', 'English', '6f1c2a1e-0000-4000-8000-000000000002', 'todo'],
    ])
    expect(rows.every((row) => !('sentAt' in row))).toBe(true)
  })

  it('reports who holds the lock by name, and whether it is the caller', async () => {
    const [accor] = (await client.listReports(null)).filter((row) => row.companyName === 'Accor')
    const kering = (await client.listReports(null)).find((row) => row.companyName === 'Kering')
    expect(await client.getReport(kering?.id ?? '')).toMatchObject({
      lockedBy: 'jean.martin@rothschildandco.com',
      lockedByCaller: false,
    })
    const locked = await client.lockReport(accor?.id ?? '')
    expect(locked).toMatchObject({ lockedBy: 'Local Admin', lockedByCaller: true })
    const unlocked = await client.unlockReport(accor?.id ?? '')
    expect(unlocked).toMatchObject({ lockedBy: null, lockedByCaller: false })
  })

  it('applies the sign-off rules and stamps updatedAt on every write', async () => {
    const accor = (await client.listReports(null)).find((row) => row.companyName === 'Accor')
    const reportId = accor?.id ?? ''
    const saved = await client.saveReportContent(reportId, {
      sector: '<p>s</p>',
      value: '<p>x</p>',
      customContent1: '',
      customContent2: '',
    })
    expect(saved).toMatchObject({ sector: '<p>s</p>', value: '<p>x</p>' })
    expect(Math.abs(Date.now() - new Date(saved.updatedAt).getTime())).toBeLessThan(5000)
    const requested = await client.requestReportValidation(reportId)
    expect(requested).toMatchObject({
      writingStatus: 'done',
      validation: { writing: 'doing', content: 'doing', status: 'doing' },
    })
    expect((await client.validateReportAnalysis(reportId)).validation).toEqual({
      writing: 'done',
      content: 'doing',
      status: 'doing',
    })
    const both = await client.validateReportContent(reportId)
    expect(both.validation).toEqual({ writing: 'done', content: 'done', status: 'done' })
    const sent = await client.sendReport(reportId)
    expect(sent.sent).toBe(true)
    expect(sent.sentAt).toBeDefined()
  })

  it('answers 404 for an unknown report', async () => {
    await expect(client.getReport('nope')).rejects.toMatchObject({ status: 404 })
    await expect(client.getMarketReport('nope')).rejects.toMatchObject({ status: 404 })
  })

  it('stores the market content sent with validation/content', async () => {
    const [english] = (await client.listMarketReports(null)).filter(
      (row) => row.languageCode === 'en-EN',
    )
    const marketId = english?.id ?? ''
    const validated = await client.validateMarketReportContent(marketId, { content: '<p>m</p>' })
    expect(validated).toMatchObject({ content: '<p>m</p>', validation: { content: 'done' } })
    expect((await client.getMarketReport(marketId)).content).toBe('<p>m</p>')
  })

  it('links a company report to the same-language market report', async () => {
    const diageo = (await client.listReports(null)).find((row) => row.companyName === 'Diageo')
    const detail = await client.getReport(diageo?.id ?? '')
    const market = await client.getMarketReport(detail.marketReportId ?? '')
    expect(market.languageCode).toBe('en-EN')
    expect(detail.marketContent).toBe(market.content)
  })
})

describe('report chart', () => {
  async function reportId() {
    return (await client.listReports(null))[0]?.id ?? ''
  }

  it('posts the file in the graph-position part and returns the detail', async () => {
    let seen: { url: string; file: FormDataEntryValue | null } = { url: '', file: null }
    server.use(
      http.post('*/api-admin/reports/:id/graph-position', async ({ request }) => {
        seen = { url: request.url, file: (await request.clone().formData()).get('graph-position') }
        return undefined
      }),
    )
    const file = new File(['x'], 'chart.png', { type: 'image/png' })
    const detail = await client.attachReportChart(await reportId(), file)
    expect(seen.url).toMatch(
      /^http:\/\/gateway\.test\/api-admin\/reports\/r-[^/]+\/graph-position$/,
    )
    expect((seen.file as File).size).toBe(1)
    expect(detail.graphPosition).toMatchObject({ contentType: 'image/png', size: 1 })
    expect(detail.graphPosition?.fileName).toEqual(expect.any(String))
  })

  it('deletes the chart and returns the detail', async () => {
    let seen = ''
    server.use(
      http.delete('*/api-admin/reports/:id/graph-position', ({ request }) => {
        seen = `${request.method} ${new URL(request.url).pathname}`
        return undefined
      }),
    )
    const detail = await client.removeReportChart(await reportId())
    expect(seen).toMatch(/^DELETE \/api-admin\/reports\/r-[^/]+\/graph-position$/)
    expect(detail.graphPosition).toBeNull()
  })
})

describe('economic statistics', () => {
  it('gets the statistics for the given date', async () => {
    let seen = ''
    server.use(
      http.get('*/api-admin/reports/statistics/economic', ({ request }) => {
        seen = new URL(request.url).pathname + new URL(request.url).search
        return HttpResponse.json([])
      }),
    )
    expect(await client.listEconomicStatistics('2026-10-12')).toEqual([])
    expect(seen).toBe('/api-admin/reports/statistics/economic?date=2026-10-12')
  })

  it('mocks three rows for today and none for another day', async () => {
    const today = new Date().toLocaleDateString('en-CA')
    const rows = await client.listEconomicStatistics(today)
    expect(rows.map((row) => row.object)).toEqual([
      'CPI (YoY)',
      'ZEW Economic Sentiment',
      'Retail Sales (MoM)',
    ])
    expect(await client.listEconomicStatistics('2000-01-01')).toEqual([])
  })
})
