import { describe, expect, it, vi } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient, GatewayError } from './gatewayClient'

const baseUrl = 'http://gateway.test'

function makeClient() {
  const onAuthError = vi.fn()
  const client = createGatewayClient({
    baseUrl,
    getToken: () => Promise.resolve('tok-1'),
    onAuthError,
  })
  return { client, onAuthError }
}

describe('gateway client', () => {
  it('sends the bearer token and returns the list', async () => {
    let header: string | null = null
    server.use(
      http.get('*/api-admin/emitters-management/emitter', ({ request }) => {
        header = request.headers.get('Authorization')
        return HttpResponse.json([])
      }),
    )
    const { client } = makeClient()
    expect(await client.listCompanies()).toEqual([])
    expect(header).toBe('Bearer tok-1')
  })

  it('returns the seeded companies with joined sectors and user counts', async () => {
    const companies = await makeClient().client.listCompanies()
    expect(companies).toHaveLength(6)
    expect(companies.find((company) => company.id === 'c1')).toEqual({
      id: 'c1',
      name: 'LVMH',
      isArchived: false,
      ric: 'LVMH.PA',
      devise: 'EUR',
      sectors: [{ name: 'Luxury/Fashion' }],
      associatedAccountsCount: 2,
    })
    expect(companies.find((company) => company.id === 'c4')?.sectors).toEqual([
      { name: 'Hospitality' },
    ])
  })

  it.each([401, 403] as const)('reports a %s to onAuthError and throws', async (status) => {
    server.use(
      http.get('*/api-admin/emitters-management/emitter', () =>
        HttpResponse.json({ error: 'unauthorized' }, { status }),
      ),
    )
    const { client, onAuthError } = makeClient()
    await expect(client.listCompanies()).rejects.toMatchObject({ status, fromServer: false })
    expect(onAuthError).toHaveBeenCalledExactlyOnceWith(status)
  })

  it('throws a typed error carrying the message and field errors of a 400', async () => {
    const fieldErrors = [
      { objectName: 'user', field: 'email', code: 'Email', message: 'bad email' },
    ]
    server.use(
      http.put('*/api-admin/accounts-management/account', () =>
        HttpResponse.json({ message: 'Invalid', fieldErrors }, { status: 400 }),
      ),
    )
    const { client, onAuthError } = makeClient()
    const error = await client
      .createUser({
        email: 'x',
        firstName: 'a',
        lastName: 'b',
        jobFunction: 'c',
        emitterId: 'c1',
        roles: [],
      })
      .catch((caught: unknown) => caught)
    expect(error).toBeInstanceOf(GatewayError)
    expect(error).toMatchObject({ status: 400, message: 'Invalid', fieldErrors, fromServer: true })
    expect(onAuthError).not.toHaveBeenCalled()
  })

  it('falls back to a generic message when an error body is not JSON', async () => {
    server.use(
      http.get('*/api-admin/referential/market', () => new HttpResponse('boom', { status: 500 })),
    )
    await expect(makeClient().client.listMarkets()).rejects.toMatchObject({
      status: 500,
      fromServer: false,
    })
  })

  it('treats an empty gateway message as no message', async () => {
    server.use(
      http.get('*/api-admin/referential/market', () =>
        HttpResponse.json({ message: '' }, { status: 500, statusText: 'Internal Server Error' }),
      ),
    )
    await expect(makeClient().client.listMarkets()).rejects.toMatchObject({
      message: 'Internal Server Error',
      fromServer: false,
    })
  })

  it('surfaces the mock duplicate-RIC rejection, case-insensitively', async () => {
    const { client } = makeClient()
    await expect(
      client.createCompany({
        name: 'Dup',
        ric: 'lvmh.pa',
        marketCode: 'EPA',
        languageCode: 'fr-FR',
        sector: 'Luxury',
        otherIndicesRic: [],
        collaborators: [],
      }),
    ).rejects.toMatchObject({
      status: 400,
      message: 'An emitter with same RIC code already exists',
    })
  })

  it('creates a company with its users', async () => {
    const { client } = makeClient()
    const created = await client.createCompany({
      name: "L'Oreal",
      ric: 'OREP.PA',
      marketCode: 'EPA',
      languageCode: 'fr-FR',
      sector: 'Luxury',
      otherIndicesRic: [],
      collaborators: [
        {
          email: 'a@b.example',
          firstName: 'A',
          lastName: 'B',
          jobFunction: 'CFO',
          roles: ['ROLE_EMITTER'],
        },
      ],
    })
    expect(created.failures).toEqual([])
    expect(created.emitter.name).toBe("L'Oreal")
    expect(
      (await client.listCompanies()).find((company) => company.id === created.emitter.id)
        ?.associatedAccountsCount,
    ).toBe(1)
  })

  it('creates the company but reports a collaborator whose email is already used', async () => {
    const { client } = makeClient()
    const collaborator = {
      firstName: 'A',
      lastName: 'B',
      jobFunction: 'CFO',
      roles: ['ROLE_EMITTER'],
    }
    const created = await client.createCompany({
      name: "L'Oreal",
      ric: 'OREP.PA',
      marketCode: 'EPA',
      languageCode: 'fr-FR',
      sector: 'Luxury',
      otherIndicesRic: [],
      collaborators: [
        { ...collaborator, email: 'new@x.example' },
        { ...collaborator, email: 'claire.martin@lvmh.example' },
      ],
    })
    expect(created.failures).toEqual([
      {
        collaborator: 'claire.martin@lvmh.example',
        message: 'Email claire.martin@lvmh.example is already used.',
      },
    ])
    expect(
      (await client.listCompanies()).find((company) => company.id === created.emitter.id)
        ?.associatedAccountsCount,
    ).toBe(1)
  })

  it('sends the gateway field names and answers 200 to a create', async () => {
    let body: unknown
    server.use(
      http.put('*/api-admin/emitters-management/emitter', async ({ request }) => {
        body = await request.json()
        return HttpResponse.json({ emitter: {}, failures: [] })
      }),
    )
    await makeClient().client.createCompany({
      name: 'N',
      ric: 'R',
      marketCode: 'EPA',
      languageCode: 'fr-FR',
      sector: 'Luxury',
      subSector: 'Luxury/Fashion',
      primaryIndiceRic1: '.FCHI',
      otherIndicesRic: [],
      collaborators: [],
    })
    expect(body).toEqual({
      name: 'N',
      ric: 'R',
      marketCode: 'EPA',
      languageCode: 'fr-FR',
      sector: 'Luxury',
      subSector: 'Luxury/Fashion',
      primaryIndiceRic1: '.FCHI',
      otherIndicesRic: [],
      collaborators: [],
    })
  })

  it('archives and unarchives, and 404s an unknown id', async () => {
    const { client } = makeClient()
    await client.archiveCompany('c1')
    expect((await client.getCompany('c1')).isArchived).toBe(true)
    await client.unarchiveCompany('c1')
    expect((await client.getCompany('c1')).isArchived).toBe(false)
    await expect(client.archiveCompany('nope')).rejects.toMatchObject({ status: 404 })
    await expect(client.getCompany('nope')).rejects.toMatchObject({ status: 404 })
  })

  it('looks up a RIC case-insensitively and 404s an unknown one', async () => {
    const { client } = makeClient()
    expect(await client.lookupRic('danO.pa')).toMatchObject({ ric: 'DANO.PA', name: 'Danone' })
    await expect(client.lookupRic('NOPE.PA')).rejects.toMatchObject({ status: 404 })
  })

  it('updates indices', async () => {
    const { client } = makeClient()
    await client.updateCompanyIndices('c4', {
      primaryIndiceRic1: '.FTSE',
      primaryIndiceRic2: null,
      primaryIndiceRic3: null,
      primaryIndiceRic4: '.SXNP',
    })
    const detail = await client.getCompany('c4')
    expect(detail.primaryIndice1?.codeRIC).toBe('.FTSE')
    expect(detail.primaryIndice2).toBeNull()
    expect(detail.primaryIndice4?.codeRIC).toBe('.SXNP')
  })

  it('manages users: create returns the account, duplicate email, update, delete, unknown delete', async () => {
    const { client } = makeClient()
    const request = {
      email: 'new@x.example',
      firstName: 'N',
      lastName: 'U',
      jobFunction: 'CFO',
      emitterId: 'c2',
      roles: ['ROLE_EMITTER'],
    }
    const created = await client.createUser(request)
    expect(created).toMatchObject({
      email: 'new@x.example',
      firstname: 'N',
      lastname: 'U',
      authorities: ['ROLE_EMITTER'],
      passwordChangeRequired: true,
    })
    expect(created.emitter.id).toBe('c2')
    await expect(client.createUser({ ...request, email: 'NEW@x.example' })).rejects.toMatchObject({
      status: 400,
      message: 'Email NEW@x.example is already used.',
    })
    const users = await client.listCompanyUsers('c2')
    expect(users).toHaveLength(3)
    const added = users.find((user) => user.email === 'new@x.example')
    if (!added) throw new Error('user not created')
    const updated = await client.updateUser(added.id, {
      email: 'new@x.example',
      firstName: 'Z',
      lastName: 'U',
      jobFunction: 'CFO',
      emitterId: 'c2',
      roles: ['ROLE_EMITTER_LIMITED'],
      passwordChangeRequired: false,
    })
    expect(updated).toMatchObject({
      firstname: 'Z',
      authorities: ['ROLE_EMITTER_LIMITED'],
      passwordChangeRequired: false,
    })
    await expect(
      client.updateUser(added.id, {
        email: 'sophie.laurent@danone.example',
        firstName: 'Z',
        lastName: 'U',
        jobFunction: 'CFO',
        emitterId: 'c2',
        roles: [],
        passwordChangeRequired: false,
      }),
    ).rejects.toMatchObject({ status: 400 })
    await client.deleteUser(added.id)
    expect(await client.listCompanyUsers('c2')).toHaveLength(2)
    await expect(client.deleteUser('ghost')).rejects.toMatchObject({
      status: 400,
      message: 'No account with UUID: ghost',
    })
  })

  it('serves the referential data and roles', async () => {
    const { client } = makeClient()
    expect((await client.listMarkets()).map((market) => market.code)).toEqual(['EPA', 'LSE'])
    expect(await client.listSectors()).toContain('Luxury/Fashion')
    expect(await client.listIndices()).toHaveLength(6)
    expect(await client.listRoles()).toEqual(['ROLE_EMITTER', 'ROLE_EMITTER_LIMITED'])
  })
})
