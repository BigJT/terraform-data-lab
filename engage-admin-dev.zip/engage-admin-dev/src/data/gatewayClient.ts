import type {
  AppVersion,
  BrokerNoteDetail,
  BrokerNoteSummary,
  BrokerNoteRequest,
  CompanyDetail,
  CompanySummary,
  CreateCompanyRequest,
  CreateCompanyResult,
  CreateFlashRequest,
  CreateTickerListRequest,
  AccountDto,
  CreateUserRequest,
  DisconnectionLog,
  DisconnectionQuery,
  DisconnectionStats,
  FieldError,
  FlashDetail,
  FlashPage,
  EconomicStatistic,
  Factset,
  FactsetPeer,
  ImportResult,
  ImportType,
  IndexInfo,
  Market,
  MarketReportContent,
  MarketReportDetail,
  MarketReportSummary,
  Page,
  PublishAppVersionRequest,
  ReportContent,
  ReportDetail,
  ReportSummary,
  RicQuote,
  TickerList,
  TickerListsPage,
  UpdateIndicesRequest,
  UpdateUserRequest,
} from './types'

/** A non-2xx gateway answer. `fromServer` is false when the message is a status text, not one the gateway wrote. */
export class GatewayError extends Error {
  readonly status: number
  readonly fieldErrors?: FieldError[]
  readonly fromServer: boolean

  constructor(status: number, message: string, fieldErrors?: FieldError[], fromServer = false) {
    super(message)
    this.name = 'GatewayError'
    this.status = status
    this.fieldErrors = fieldErrors
    this.fromServer = fromServer
  }
}

/** The gateway's own message, or `fallback` for status texts, network failures and anything else. */
export function gatewayMessage(failure: unknown, fallback: string): string {
  return failure instanceof GatewayError && failure.fromServer ? failure.message : fallback
}

export interface GatewayClientOptions {
  baseUrl: string
  getToken: () => Promise<string>
  onAuthError: (status: 401 | 403) => void
}

const emitters = '/api-admin/emitters-management/emitter'
const accounts = '/api-admin/accounts-management'
const referential = '/api-admin/referential'
const reports = '/api-admin/reports'
const flashes = '/api-admin/flashs'
const brokerNotes = '/api-admin/broker-note'
const tickers = '/api-admin/tickers'
const appVersion = '/api-admin/app-version'
const disconnections = '/api-admin/disconnections'

/** `YYYY-MM-DD` to the `dd-MM-yyyy` the reports paths use. */
function pathDate(date: string): string {
  const [year = '', month = '', day = ''] = date.split('-')
  return `${day}-${month}-${year}`
}

export function createGatewayClient({ baseUrl, getToken, onAuthError }: GatewayClientOptions) {
  async function send(method: string, path: string, body?: unknown): Promise<Response> {
    const headers: Record<string, string> = { Authorization: `Bearer ${await getToken()}` }
    if (body !== undefined) headers['Content-Type'] = 'application/json'
    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    if (response.status === 401 || response.status === 403) {
      onAuthError(response.status)
      throw new GatewayError(response.status, response.statusText)
    }
    if (!response.ok) throw await toError(response)
    return response
  }

  async function toError(response: Response): Promise<GatewayError> {
    let parsed: { message?: string; fieldErrors?: FieldError[] } = {}
    try {
      parsed = (await response.json()) as typeof parsed
    } catch {
      // Body is empty or not JSON; fall back to the status text.
    }
    const message = typeof parsed.message === 'string' ? parsed.message : ''
    return new GatewayError(
      response.status,
      message || response.statusText || `Request failed (${String(response.status)})`,
      parsed.fieldErrors,
      message !== '',
    )
  }

  async function json<T>(method: string, path: string, body?: unknown): Promise<T> {
    return (await (await send(method, path, body)).json()) as T
  }

  async function empty(method: string, path: string, body?: unknown): Promise<void> {
    await send(method, path, body)
  }

  async function form<T>(method: string, path: string, body: FormData): Promise<T> {
    const response = await fetch(`${baseUrl}${path}`, {
      method,
      headers: { Authorization: `Bearer ${await getToken()}` },
      body,
    })
    if (response.status === 401 || response.status === 403) {
      onAuthError(response.status)
      throw new GatewayError(response.status, response.statusText)
    }
    if (!response.ok) throw await toError(response)
    return (await response.json()) as T
  }

  const id = encodeURIComponent
  return {
    listCompanies: () => json<CompanySummary[]>('GET', emitters),
    createCompany: (request: CreateCompanyRequest) =>
      json<CreateCompanyResult>('PUT', emitters, request),
    getCompany: (emitterId: string) => json<CompanyDetail>('GET', `${emitters}/${id(emitterId)}`),
    archiveCompany: (emitterId: string) => empty('PUT', `${emitters}/${id(emitterId)}/archive`),
    unarchiveCompany: (emitterId: string) => empty('PUT', `${emitters}/${id(emitterId)}/unarchive`),
    updateCompanyIndices: (emitterId: string, request: UpdateIndicesRequest) =>
      empty('PUT', `${emitters}/indice/${id(emitterId)}`, request),
    lookupRic: (search: string) =>
      json<RicQuote>('GET', `/api-admin/pairs-management/pairs/ric/${id(search)}`),
    listMarkets: () => json<Market[]>('GET', `${referential}/market`),
    listSectors: () => json<string[]>('GET', `${referential}/sectors`),
    listIndices: () => json<IndexInfo[]>('GET', `${referential}/indices`),
    listCompanyUsers: (emitterId: string) =>
      json<AccountDto[]>('GET', `${accounts}/emitter/${id(emitterId)}`),
    createUser: (request: CreateUserRequest) =>
      json<AccountDto>('PUT', `${accounts}/account`, request),
    updateUser: (accountId: string, request: UpdateUserRequest) =>
      json<AccountDto>('POST', `${accounts}/account/${id(accountId)}`, request),
    deleteUser: (accountId: string) =>
      empty('DELETE', `${accounts}/account/delete/${id(accountId)}`),
    async listTickerLists(emitterId: string): Promise<TickerList[]> {
      const page = await json<TickerListsPage>(
        'GET',
        `${tickers}/by-emitter/${id(emitterId)}?page=0&size=100`,
      )
      return page.resultPage.content
    },
    createTickerList: (request: CreateTickerListRequest) =>
      json<TickerList>('PUT', tickers, request),
    addTicker: (listId: string, ric: string, name: string) =>
      json<TickerList>('PUT', `${tickers}/${id(listId)}/ticker`, { ric, name }),
    renameTickerList: (listId: string, name: string, comments: string) =>
      json<TickerList>('POST', `${tickers}/${id(listId)}`, { name, comments }),
    deleteTickerList: (listId: string) => empty('DELETE', `${tickers}/${id(listId)}`),
    deleteTicker: (tickerId: string) => empty('DELETE', `${tickers}/ticker/${id(tickerId)}`),
    listImportTypes: () => json<ImportType[]>('GET', '/api-admin/import/excel-types'),
    importFile(emitterId: string, kind: string, file: File) {
      const body = new FormData()
      body.append('file', file, file.name)
      return form<ImportResult>(
        'POST',
        `/api-admin/emitter/${id(emitterId)}/import/${id(kind)}?purge=true`,
        body,
      )
    },
    getFactset: (emitterId: string) =>
      json<Factset>('GET', `/api-admin/factset/emitter/${id(emitterId)}`),
    saveFactsetPeers: (emitterId: string, peers: FactsetPeer[]) =>
      empty('POST', `/api-admin/factset/emitter/${id(emitterId)}/peers`, {
        emitterBloomIds: peers.map(({ factsetName, factsetId }) => ({ factsetName, factsetId })),
      }),
    saveFactsetMultiples: (emitterId: string, keys: string[]) =>
      empty('PUT', `/api-admin/factset/emitter/${id(emitterId)}/multiples`, keys),
    listRoles: () => json<string[]>('GET', `${accounts}/roles`),
    listReports: (date: string | null) =>
      json<ReportSummary[]>('GET', date === null ? reports : `${reports}/${pathDate(date)}`),
    getReport: (analysisId: string) =>
      json<ReportDetail>('GET', `${reports}/byId/${id(analysisId)}`),
    saveReportContent: (analysisId: string, content: ReportContent) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/content`, content),
    requestReportValidation: (analysisId: string) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/writing_status`),
    validateReportAnalysis: (analysisId: string) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/validation/analysis`),
    validateReportContent: (analysisId: string) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/validation/content`),
    sendReport: (analysisId: string) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/sent`),
    attachReportChart(analysisId: string, file: File) {
      const body = new FormData()
      body.append('graph-position', file, file.name)
      return form<ReportDetail>('POST', `${reports}/${id(analysisId)}/graph-position`, body)
    },
    removeReportChart: (analysisId: string) =>
      json<ReportDetail>('DELETE', `${reports}/${id(analysisId)}/graph-position`),
    listEconomicStatistics: (date: string) =>
      json<EconomicStatistic[]>(
        'GET',
        `${reports}/statistics/economic?date=${encodeURIComponent(date)}`,
      ),
    lockReport: (analysisId: string) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/lock`),
    unlockReport: (analysisId: string) =>
      json<ReportDetail>('PUT', `${reports}/${id(analysisId)}/unlock`),
    listMarketReports: (date: string | null) =>
      json<MarketReportSummary[]>(
        'GET',
        date === null ? `${reports}/market` : `${reports}/market/${pathDate(date)}`,
      ),
    getMarketReport: (marketReportId: string) =>
      json<MarketReportDetail>('GET', `${reports}/market/byId/${id(marketReportId)}`),
    saveMarketReportContent: (marketReportId: string, content: MarketReportContent) =>
      json<MarketReportDetail>('PUT', `${reports}/market/${id(marketReportId)}/content`, content),
    requestMarketReportValidation: (marketReportId: string) =>
      json<MarketReportDetail>('PUT', `${reports}/market/${id(marketReportId)}/writing_status`),
    validateMarketReportAnalysis: (marketReportId: string) =>
      json<MarketReportDetail>(
        'PUT',
        `${reports}/market/${id(marketReportId)}/validation/analysis`,
      ),
    validateMarketReportContent: (marketReportId: string, content: MarketReportContent) =>
      json<MarketReportDetail>(
        'PUT',
        `${reports}/market/${id(marketReportId)}/validation/content`,
        content,
      ),
    sendMarketReport: (marketReportId: string) =>
      json<MarketReportDetail>('PUT', `${reports}/market/${id(marketReportId)}/sent`),
    lockMarketReport: (marketReportId: string) =>
      json<MarketReportDetail>('PUT', `${reports}/market/${id(marketReportId)}/lock`),
    unlockMarketReport: (marketReportId: string) =>
      json<MarketReportDetail>('PUT', `${reports}/market/${id(marketReportId)}/unlock`),
    listFlashes: ({ q, page, size }: { q?: string; page: number; size: number }) => {
      const query = new URLSearchParams({ page: String(page), size: String(size) })
      if (q) query.set('q', q)
      return json<FlashPage>('GET', `${flashes}?${query.toString()}`)
    },
    getFlash: (flashId: string) => json<FlashDetail>('GET', `${flashes}/${id(flashId)}`),
    deleteFlash: (flashId: string) => empty('DELETE', `${flashes}/${id(flashId)}`),
    listFlashTypes: () => json<string[]>('GET', `${referential}/types/flash`),
    async getAttachmentContent(attachmentId: string): Promise<Blob> {
      return (await send('GET', `/api/attachment/${id(attachmentId)}/content`)).blob()
    },
    createFlash(request: CreateFlashRequest, files: File[]) {
      const body = new FormData()
      body.append('flash', new Blob([JSON.stringify(request)], { type: 'application/json' }))
      for (const file of files) body.append('attachments', file)
      return form<FlashDetail>('POST', flashes, body)
    },
    listBrokerNotes: ({ q, page, size }: { q?: string; page: number; size: number }) => {
      const query = new URLSearchParams({ page: String(page), size: String(size) })
      if (q) query.set('q', q)
      return json<Page<BrokerNoteSummary>>('GET', `${brokerNotes}?${query.toString()}`)
    },
    getBrokerNote: (noteId: string) =>
      json<BrokerNoteDetail>('GET', `${brokerNotes}/${id(noteId)}`),
    async getLastBrokerNote(emitterId: string): Promise<BrokerNoteDetail | null> {
      const response = await send('GET', `${brokerNotes}/lastOfEmitter/${id(emitterId)}`)
      return response.status === 204 ? null : ((await response.json()) as BrokerNoteDetail)
    },
    createBrokerNote(request: BrokerNoteRequest, files: File[]) {
      const body = new FormData()
      body.append('note', new Blob([JSON.stringify(request)], { type: 'application/json' }))
      for (const file of files) body.append('attachments', file)
      return form<BrokerNoteDetail>('POST', brokerNotes, body)
    },
    deleteBrokerNote: (noteId: string) => empty('DELETE', `${brokerNotes}/${id(noteId)}`),
    listBrokers: () => json<string[]>('GET', `${referential}/broker`),
    listRecommendations: () => json<string[]>('GET', `${referential}/types/broker-note`),
    getAppVersion: () => json<AppVersion>('GET', appVersion),
    publishAppVersion: (request: PublishAppVersionRequest) =>
      json<AppVersion>('POST', appVersion, request),
    getDisconnectionStats: (days: number) =>
      json<DisconnectionStats>('GET', `${disconnections}/stats?days=${String(days)}`),
    listDisconnections({ page, size, ...filters }: DisconnectionQuery) {
      const query = new URLSearchParams({ page: String(page), size: String(size) })
      query.set('sort', 'createdAt,desc')
      for (const [name, value] of Object.entries(filters)) if (value) query.set(name, value)
      return json<Page<DisconnectionLog>>('GET', `${disconnections}?${query.toString()}`)
    },
  }
}

export type GatewayClient = ReturnType<typeof createGatewayClient>
