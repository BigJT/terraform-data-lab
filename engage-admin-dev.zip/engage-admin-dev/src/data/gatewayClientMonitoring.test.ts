import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient } from './gatewayClient'

function makeClient() {
  return createGatewayClient({
    baseUrl: 'http://gateway.test',
    getToken: () => Promise.resolve('tok-1'),
    onAuthError: () => undefined,
  })
}

describe('gateway client disconnections', () => {
  it('requests stats for the chosen period', async () => {
    const stats = await makeClient().getDisconnectionStats(30)
    expect(stats).toMatchObject({
      days: 30,
      totalDisconnections: 15,
      last24hDisconnections: 3,
      topDisconnectedUsers: [{ userEmail: 'claire.martin@lvmh.example', disconnectionCount: 4 }],
    })
    expect(stats.reasonBreakdown.length).toBeGreaterThan(0)
    expect(stats.platformBreakdown.length).toBeGreaterThan(0)
  })

  it('sends only the filled filters, always sorted newest first', async () => {
    let url = ''
    server.use(
      http.get('*/api-admin/disconnections', ({ request }) => {
        url = request.url
        return HttpResponse.json({
          content: [],
          totalElements: 0,
          totalPages: 0,
          number: 0,
          size: 20,
        })
      }),
    )
    await makeClient().listDisconnections({ page: 2, size: 20, platform: 'MOBILE', userEmail: '' })
    const params = new URL(url).searchParams
    expect(Object.fromEntries(params)).toEqual({
      page: '2',
      size: '20',
      sort: 'createdAt,desc',
      platform: 'MOBILE',
    })
  })

  it('pages the mock logs', async () => {
    const page = await makeClient().listDisconnections({ page: 2, size: 20 })
    expect(page).toMatchObject({ totalElements: 45, totalPages: 3, number: 2 })
    expect(page.content).toHaveLength(5)
  })

  it('filters the mock logs by date range, inclusive on the UTC date', async () => {
    const all = await makeClient().listDisconnections({ page: 0, size: 100 })
    const day = all.content[3]?.createdAt.slice(0, 10) ?? ''
    const one = await makeClient().listDisconnections({
      page: 0,
      size: 100,
      startDate: day,
      endDate: day,
    })
    expect(one.content.length).toBeGreaterThan(0)
    expect(one.content.every((log) => log.createdAt.startsWith(day))).toBe(true)
    const none = await makeClient().listDisconnections({
      page: 0,
      size: 100,
      startDate: '2999-01-01',
    })
    expect(none.totalElements).toBe(0)
  })

  it('matches the email case-insensitively as a substring', async () => {
    const result = await makeClient().listDisconnections({ page: 0, size: 100, userEmail: 'LVMH' })
    expect(result.totalElements).toBe(9)
  })
})
