import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient } from './gatewayClient'

function makeClient() {
  return createGatewayClient({
    baseUrl: 'http://gateway.test',
    getToken: () => Promise.resolve('tok-1'),
    onAuthError: () => undefined,
  })
}

describe('gateway client factset', () => {
  it('reads the peers, multiples and available multiples for an emitter', async () => {
    const factset = await makeClient().getFactset('c1')
    expect(factset.peersBloomIds).toEqual([
      { id: 1, factsetName: 'Hermes International', factsetId: 'HRMS-FR' },
      { id: 2, factsetName: 'Kering', factsetId: 'PRTP-FR' },
    ])
    expect(factset.multiples).toEqual([
      { id: 1, key: 'PE', label: 'P/E' },
      { id: 2, key: 'EV_EBITDA', label: 'EV/EBITDA' },
    ])
    expect(factset.availableMultiples.map((multiple) => multiple.id)).toEqual([1, 2, 3, 4, 5, 6])
  })

  it('posts the peers wrapped in emitterBloomIds', async () => {
    let seen: { url: string; body: unknown } = { url: '', body: null }
    server.use(
      http.post('*/api-admin/factset/emitter/:emitterId/peers', async ({ request }) => {
        seen = { url: request.url, body: await request.json() }
        return new HttpResponse(null, { status: 200 })
      }),
    )
    const peers = [{ factsetName: 'Kering', factsetId: 'PRTP-FR' }]
    await makeClient().saveFactsetPeers('c1', peers)
    expect(seen.url).toBe('http://gateway.test/api-admin/factset/emitter/c1/peers')
    expect(seen.body).toEqual({ emitterBloomIds: peers })
  })

  it('reads saved peers back with an id each, as FactsetPeerDto requires', async () => {
    const client = makeClient()
    await client.saveFactsetPeers('c2', [
      { factsetName: 'Nestle', factsetId: 'NESN-CH' },
      { factsetName: 'Unilever', factsetId: 'ULVR-GB' },
    ])
    const { peersBloomIds } = await client.getFactset('c2')
    expect(peersBloomIds.map((peer) => peer.factsetId)).toEqual(['NESN-CH', 'ULVR-GB'])
    expect(peersBloomIds.every((peer) => Number.isInteger(peer.id))).toBe(true)
  })

  it('puts the multiple keys as the bare array', async () => {
    let seen: { url: string; body: unknown } = { url: '', body: null }
    server.use(
      http.put('*/api-admin/factset/emitter/:emitterId/multiples', async ({ request }) => {
        seen = { url: request.url, body: await request.json() }
        return new HttpResponse(null, { status: 200 })
      }),
    )
    await makeClient().saveFactsetMultiples('c1', ['PE', 'PB'])
    expect(seen.url).toBe('http://gateway.test/api-admin/factset/emitter/c1/multiples')
    expect(seen.body).toEqual(['PE', 'PB'])
  })

  it('throws the gateway message on failure', async () => {
    server.use(
      http.get('*/api-admin/factset/emitter/:emitterId', () =>
        HttpResponse.json({ message: 'Factset down' }, { status: 500 }),
      ),
    )
    await expect(makeClient().getFactset('c1')).rejects.toThrow('Factset down')
  })
})
