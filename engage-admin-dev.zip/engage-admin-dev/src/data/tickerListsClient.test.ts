import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient, GatewayError } from './gatewayClient'

const client = createGatewayClient({
  baseUrl: 'http://gateway.test',
  getToken: () => Promise.resolve('tok'),
  onAuthError: () => undefined,
})

describe('ticker lists client', () => {
  it('asks for page 0, size 100 of the company and returns the content', async () => {
    const urls: URL[] = []
    server.use(
      http.get('*/api-admin/tickers/by-emitter/:emitterId', ({ request }) => {
        urls.push(new URL(request.url))
        return HttpResponse.json({
          criteria: null,
          emitterId: 'c1',
          resultPage: {
            content: [{ id: 'x', name: 'One', comments: '', tickers: [] }],
            totalElements: 1,
            totalPages: 1,
            number: 0,
            size: 100,
          },
        })
      }),
    )
    const lists = await client.listTickerLists('c1')
    expect(lists.map((list) => list.name)).toEqual(['One'])
    expect(urls[0]?.pathname).toBe('/api-admin/tickers/by-emitter/c1')
    expect(urls[0]?.searchParams.get('page')).toBe('0')
    expect(urls[0]?.searchParams.get('size')).toBe('100')
  })

  it('lists the seeded lists of LVMH from the mock', async () => {
    const lists = await client.listTickerLists('c1')
    expect(lists.map((list) => list.name)).toEqual(['Luxury peers', 'European consumer'])
    expect(lists[0]?.tickers.map((ticker) => ticker.ricCode)).toEqual([
      'HRMS.PA',
      'CDI.PA',
      'PRTP.PA',
    ])
  })

  it('creates a list with PUT, sending ric and name per ticker, and returns it', async () => {
    const created = await client.createTickerList({
      emitterId: 'c4',
      name: 'Watchlist',
      comments: '',
      tickers: [{ ric: 'AIR.PA', name: 'Airbus' }],
    })
    expect(created.name).toBe('Watchlist')
    expect(created.tickers).toEqual([
      expect.objectContaining({ ricCode: 'AIR.PA', name: 'Airbus' }),
    ])
    expect((await client.listTickerLists('c4')).map((list) => list.name)).toEqual(['Watchlist'])
  })

  it('surfaces the 400 duplicate message as a GatewayError, ignoring case', async () => {
    const failure: unknown = await client
      .createTickerList({
        emitterId: 'c1',
        name: 'luxury PEERS',
        comments: '',
        tickers: [{ ric: 'AIR.PA', name: 'Airbus' }],
      })
      .catch((error: unknown) => error)
    expect(failure).toBeInstanceOf(GatewayError)
    expect((failure as GatewayError).status).toBe(400)
    expect((failure as GatewayError).message).toBe(
      'A list with name [luxury PEERS] already exists for the emitter.',
    )
  })

  it('allows the same name on another company', async () => {
    const created = await client.createTickerList({
      emitterId: 'c4',
      name: 'Luxury peers',
      comments: '',
      tickers: [{ ric: 'AIR.PA', name: 'Airbus' }],
    })
    expect(created.name).toBe('Luxury peers')
    expect((await client.listTickerLists('c4')).map((list) => list.name)).toEqual(['Luxury peers'])
  })

  it('answers 404 for a RIC with no pair', async () => {
    const failure: unknown = await client
      .createTickerList({
        emitterId: 'c4',
        name: 'Bad',
        comments: '',
        tickers: [{ ric: 'ZZZZ.PA', name: 'Z' }],
      })
      .catch((error: unknown) => error)
    expect((failure as GatewayError).status).toBe(404)
    expect((failure as GatewayError).message).toBe('No pair with RIC [ZZZZ.PA]')
  })

  it('adds a ticker to a list', async () => {
    const list = await client.addTicker('l2', 'HRMS.PA', 'Hermes International')
    expect(list.id).toBe('l2')
    expect(list.tickers.map((item) => item.ricCode)).toEqual(['OREP.PA', 'HRMS.PA'])
    const lists = await client.listTickerLists('c1')
    expect(lists[1]?.tickers.map((item) => item.ricCode)).toEqual(['OREP.PA', 'HRMS.PA'])
  })

  it('answers 404 when adding an unknown RIC or to an unknown list', async () => {
    const noPair: unknown = await client.addTicker('l2', 'ZZZZ.PA', 'Z').catch((e: unknown) => e)
    expect((noPair as GatewayError).status).toBe(404)
    expect((noPair as GatewayError).message).toBe('No pair with RIC [ZZZZ.PA]')
    const noList: unknown = await client
      .addTicker('nope', 'AIR.PA', 'Airbus')
      .catch((e: unknown) => e)
    expect((noList as GatewayError).status).toBe(404)
  })

  it('renames a list with POST to the list path', async () => {
    const seen: string[] = []
    server.use(
      http.all('*/api-admin/tickers/:listId', ({ request }) => {
        seen.push(`${request.method} ${new URL(request.url).pathname}`)
        return HttpResponse.json({ id: 'l2', name: 'X', comments: 'note', tickers: [] })
      }),
    )
    await client.renameTickerList('l2', 'X', 'note')
    expect(seen).toEqual(['POST /api-admin/tickers/l2'])
  })

  it('renames a list, rejecting a duplicate name with the server message', async () => {
    const renamed = await client.renameTickerList('l2', 'EU consumer', '')
    expect(renamed.name).toBe('EU consumer')
    const failure: unknown = await client
      .renameTickerList('l2', 'luxury peers', '')
      .catch((e: unknown) => e)
    expect((failure as GatewayError).status).toBe(400)
    expect((failure as GatewayError).message).toBe(
      'A list with name [luxury peers] already exists for the emitter.',
    )
  })

  it('answers 404 when renaming an unknown list', async () => {
    const failure: unknown = await client.renameTickerList('nope', 'X', '').catch((e: unknown) => e)
    expect((failure as GatewayError).status).toBe(404)
  })

  it('sends name and the current comments when renaming, and keeps the comments', async () => {
    let body: unknown
    server.use(
      http.post('*/api-admin/tickers/:listId', async ({ request }) => {
        body = await request.json()
        return HttpResponse.json({ id: 'l2', name: 'X', comments: 'keep me', tickers: [] })
      }),
    )
    await client.renameTickerList('l2', 'X', 'keep me')
    expect(body).toEqual({ name: 'X', comments: 'keep me' })
  })

  it('sends emitterId, empty comments and ric/name tickers on create', async () => {
    let body: unknown
    server.use(
      http.put('*/api-admin/tickers', async ({ request }) => {
        body = await request.json()
        return HttpResponse.json({ id: 'n', name: 'W', comments: '', tickers: [] })
      }),
    )
    await client.createTickerList({
      emitterId: 'c4',
      name: 'W',
      comments: '',
      tickers: [{ ric: 'AIR.PA', name: 'Airbus' }],
    })
    expect(body).toEqual({
      emitterId: 'c4',
      name: 'W',
      comments: '',
      tickers: [{ ric: 'AIR.PA', name: 'Airbus' }],
    })
  })

  it('deletes a ticker and a list, and answers 404 for unknown ids', async () => {
    await client.deleteTicker('t3')
    expect((await client.listTickerLists('c1'))[0]?.tickers).toHaveLength(2)
    await client.deleteTickerList('l1')
    expect((await client.listTickerLists('c1')).map((list) => list.name)).toEqual([
      'European consumer',
    ])
    const noTicker: unknown = await client.deleteTicker('nope').catch((e: unknown) => e)
    expect((noTicker as GatewayError).status).toBe(404)
    const noList: unknown = await client.deleteTickerList('nope').catch((e: unknown) => e)
    expect((noList as GatewayError).status).toBe(404)
  })
})
