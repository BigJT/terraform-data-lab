import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient, GatewayError } from './gatewayClient'

const unauthorised: number[] = []
const client = createGatewayClient({
  baseUrl: 'http://gateway.test',
  getToken: () => Promise.resolve('tok'),
  onAuthError: (status) => unauthorised.push(status),
})

describe('broker notes client', () => {
  it('sends q, page and size to the list and omits an empty q', async () => {
    const urls: URL[] = []
    server.use(
      http.get('*/api-admin/broker-note', ({ request }) => {
        urls.push(new URL(request.url))
        return HttpResponse.json({
          content: [],
          totalElements: 0,
          totalPages: 0,
          number: 0,
          size: 20,
        })
      }),
    )
    await client.listBrokerNotes({ q: 'citi', page: 2, size: 20 })
    await client.listBrokerNotes({ q: '', page: 0, size: 20 })
    expect(urls[0]?.searchParams.get('q')).toBe('citi')
    expect(urls[0]?.searchParams.get('page')).toBe('2')
    expect(urls[0]?.searchParams.get('size')).toBe('20')
    expect(urls[1]?.searchParams.has('q')).toBe(false)
  })

  it('addresses get, delete and both referential lists', async () => {
    const seen: string[] = []
    server.use(
      http.all('*/api-admin/*', ({ request }) => {
        seen.push(`${request.method} ${new URL(request.url).pathname}`)
        return HttpResponse.json([])
      }),
    )
    await client.getBrokerNote('bn1')
    await client.deleteBrokerNote('bn1')
    await client.listBrokers()
    await client.listRecommendations()
    expect(seen).toEqual([
      'GET /api-admin/broker-note/bn1',
      'DELETE /api-admin/broker-note/bn1',
      'GET /api-admin/referential/broker',
      'GET /api-admin/referential/types/broker-note',
    ])
  })

  it('reads the summary and detail shapes of the gateway contract', async () => {
    const page = await client.listBrokerNotes({ page: 0, size: 20 })
    expect(page.content[0]).toMatchObject({
      id: 'bn1',
      company: { id: 'c1', name: 'LVMH', ric: 'LVMH.PA' },
      currentObjective: 720,
      previousObjective: 680,
      recommendationChange: true,
      monitoringOfficer: null,
      attachmentCount: 0,
    })
    const detail = await client.getBrokerNote('bn5')
    expect(detail.attachments).toHaveLength(1)
    expect(detail).toMatchObject({ sendByMail: false, recommendationChange: false })
    expect(detail).not.toHaveProperty('emitter')
  })

  it('creates and deletes against the contract mock', async () => {
    const created = await client.createBrokerNote(
      {
        emitterId: 'c1',
        broker: 'Citi',
        currency: '€',
        currentObjective: '70.00',
        currentRecommendation: 'BUY',
        sectorNote: false,
        initiationNote: false,
        recoChange: false,
        sendByEmail: true,
      },
      [],
    )
    expect(created).toMatchObject({ company: { id: 'c1' }, currentObjective: 70, sendByMail: true })
    await expect(client.deleteBrokerNote(created.id)).resolves.toBeUndefined()
  })

  it('returns the last note of a company, or null on 204', async () => {
    expect((await client.getLastBrokerNote('c1'))?.id).toBe('bn1')
    server.use(
      http.get(
        '*/api-admin/broker-note/lastOfEmitter/:id',
        () => new HttpResponse(null, { status: 204 }),
      ),
    )
    expect(await client.getLastBrokerNote('c9')).toBeNull()
  })

  it('turns a 404 into GatewayError', async () => {
    await expect(client.getBrokerNote('nope')).rejects.toMatchObject({ status: 404 })
    await expect(client.deleteBrokerNote('nope')).rejects.toBeInstanceOf(GatewayError)
  })

  it('reports 401 and 403 through onAuthError', async () => {
    server.use(
      http.get('*/api-admin/broker-note', () => new HttpResponse(null, { status: 401 })),
      http.get('*/api-admin/referential/broker', () => new HttpResponse(null, { status: 403 })),
    )
    await expect(client.listBrokerNotes({ page: 0, size: 20 })).rejects.toMatchObject({
      status: 401,
    })
    await expect(client.listBrokers()).rejects.toMatchObject({ status: 403 })
    expect(unauthorised).toEqual([401, 403])
  })

  it('posts create as multipart with a json note part and no client Content-Type', async () => {
    let seen: { note: unknown; count: number; contentType: string | null } | null = null
    server.use(
      http.post('*/api-admin/broker-note', async ({ request }) => {
        const data = await request.formData()
        const note = data.get('note')
        seen = {
          note: JSON.parse(
            typeof note === 'string' ? note : await (note as Blob).text(),
          ) as unknown,
          count: data.getAll('attachments').length,
          contentType: request.headers.get('Content-Type'),
        }
        return HttpResponse.json({ id: 'new' }, { status: 201 })
      }),
    )
    const note = {
      emitterId: 'c1',
      broker: 'Citi',
      currency: '€',
      currentObjective: '70.00',
      currentRecommendation: 'BUY',
      sectorNote: false,
      initiationNote: false,
      recoChange: false,
      sendByEmail: false,
    }
    const created = await client.createBrokerNote(note, [new File(['x'], 'a.txt')])
    expect(created).toMatchObject({ id: 'new' })
    const result = seen as unknown as { note: unknown; count: number; contentType: string }
    expect(result.note).toEqual(note)
    expect(result.count).toBe(1)
    expect(result.contentType).toMatch(/^multipart\/form-data; boundary=/)
  })

  it('turns a 400 on create into GatewayError', async () => {
    server.use(
      http.post('*/api-admin/broker-note', () =>
        HttpResponse.json({ message: 'Bad note' }, { status: 400 }),
      ),
    )
    await expect(client.createBrokerNote({} as never, [])).rejects.toMatchObject({
      status: 400,
      message: 'Bad note',
    })
  })
})
