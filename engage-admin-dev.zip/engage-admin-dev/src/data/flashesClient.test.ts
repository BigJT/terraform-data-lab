import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient, GatewayError } from './gatewayClient'

const client = createGatewayClient({
  baseUrl: 'http://gateway.test',
  getToken: () => Promise.resolve('tok'),
  onAuthError: () => undefined,
})

describe('flashes client', () => {
  it('sends q, page and size to the list', async () => {
    const urls: URL[] = []
    server.use(
      http.get('*/api-admin/flashs', ({ request }) => {
        urls.push(new URL(request.url))
        return HttpResponse.json({
          content: [],
          totalElements: 0,
          totalPages: 0,
          number: 0,
          size: 20,
        })
      }),
    )
    await client.listFlashes({ q: 'lux', page: 2, size: 20 })
    await client.listFlashes({ page: 0, size: 20 })
    expect(urls[0]?.searchParams.get('q')).toBe('lux')
    expect(urls[0]?.searchParams.get('page')).toBe('2')
    expect(urls[0]?.searchParams.get('size')).toBe('20')
    expect(urls[1]?.searchParams.has('q')).toBe(false)
  })

  it('reads the summary and detail shapes of the gateway contract', async () => {
    const page = await client.listFlashes({ page: 0, size: 20 })
    expect(page.content[0]).toMatchObject({
      id: 'f1',
      company: 'LVMH',
      relatedCompanyCount: 1,
      attachmentCount: 0,
    })
    expect(page.content[0]).not.toHaveProperty('emitters')
    const detail = await client.getFlash('f3')
    expect(detail.company).toBe('Kering')
    expect(detail.relatedCompanies.map((company) => company.name)).toEqual(['LVMH', 'Kering'])
  })

  it('creates and deletes against the contract mock', async () => {
    const created = await client.createFlash(
      {
        title: 't',
        value: 'v',
        description: '<p>d</p>',
        type: 'Breaking News',
        links: [],
        emittersUUID: ['c1'],
        sendByEmail: false,
        sendToAll: false,
      },
      [],
    )
    expect(created.company).toBe('v')
    expect(created.relatedCompanies.map((company) => company.id)).toEqual(['c1'])
    await expect(client.deleteFlash(created.id)).resolves.toBeUndefined()
  })

  it('addresses get, delete and types', async () => {
    const seen: string[] = []
    server.use(
      http.all('*/api-admin/*', ({ request }) => {
        seen.push(`${request.method} ${new URL(request.url).pathname}`)
        return HttpResponse.json([])
      }),
    )
    await client.getFlash('f1')
    await client.deleteFlash('f1')
    await client.listFlashTypes()
    expect(seen).toEqual([
      'GET /api-admin/flashs/f1',
      'DELETE /api-admin/flashs/f1',
      'GET /api-admin/referential/types/flash',
    ])
  })

  it('fetches attachment bytes with the bearer header', async () => {
    let auth: string | null = null
    server.use(
      http.get('*/api/attachment/a1/content', ({ request }) => {
        auth = request.headers.get('Authorization')
        return new HttpResponse('abc', { headers: { 'Content-Type': 'text/plain' } })
      }),
    )
    const blob = await client.getAttachmentContent('a1')
    expect(await blob.text()).toBe('abc')
    expect(auth).toBe('Bearer tok')
  })

  it('posts create as multipart with a json flash part and attachments', async () => {
    let seen: { flash: unknown; count: number; contentType: string | null } | null = null
    server.use(
      http.post('*/api-admin/flashs', async ({ request }) => {
        const data = await request.formData()
        const flash = data.get('flash')
        seen = {
          flash: JSON.parse(
            typeof flash === 'string' ? flash : await (flash as Blob).text(),
          ) as unknown,
          count: data.getAll('attachments').length,
          contentType: request.headers.get('Content-Type'),
        }
        return HttpResponse.json({ id: 'new' }, { status: 201 })
      }),
    )
    const request = {
      title: 't',
      value: 'v',
      description: '<p>d</p>',
      type: 'Breaking News',
      links: [],
      emittersUUID: ['c1'],
      sendByEmail: false,
      sendToAll: false,
    }
    await client.createFlash(request, [new File(['x'], 'a.txt'), new File(['y'], 'b.txt')])
    expect(seen).not.toBeNull()
    const result = seen as unknown as { flash: unknown; count: number; contentType: string }
    expect(result.flash).toEqual(request)
    expect(result.count).toBe(2)
    expect(result.contentType).toMatch(/^multipart\/form-data; boundary=/)
  })

  it('turns 404 and a 400 body into GatewayError', async () => {
    server.use(
      http.get('*/api-admin/flashs/nope', () =>
        HttpResponse.json({ message: 'Not found' }, { status: 404 }),
      ),
      http.post('*/api-admin/flashs', () =>
        HttpResponse.json({ message: 'Bad flash' }, { status: 400 }),
      ),
    )
    await expect(client.getFlash('nope')).rejects.toMatchObject({ status: 404 })
    await expect(client.getFlash('nope')).rejects.toBeInstanceOf(GatewayError)
    await expect(client.createFlash({} as never, [])).rejects.toMatchObject({
      status: 400,
      message: 'Bad flash',
    })
  })
})
