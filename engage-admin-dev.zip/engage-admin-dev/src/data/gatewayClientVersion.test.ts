import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient } from './gatewayClient'

function makeClient() {
  return createGatewayClient({
    baseUrl: 'http://gateway.test',
    getToken: () => Promise.resolve('tok-1'),
    onAuthError: () => undefined,
  })
}

describe('gateway client app version', () => {
  it('returns the latest version on 200', async () => {
    const version = await makeClient().getAppVersion()
    expect(version).toMatchObject({ version: '3.4.0', forceUpdate: false })
  })

  it('returns a null version on 200 when nothing is published', async () => {
    server.use(
      http.get('*/api-admin/app-version', () =>
        HttpResponse.json({ version: null, forceUpdate: false }),
      ),
    )
    expect(await makeClient().getAppVersion()).toEqual({ version: null, forceUpdate: false })
  })

  it('answers 200 with a null version from the mock when none is published', async () => {
    const { db } = await import('@/mocks/fixtures')
    db.appVersions.length = 0
    expect(await makeClient().getAppVersion()).toEqual({ version: null, forceUpdate: false })
  })

  it('posts the version and force flag and returns the created version', async () => {
    let body: unknown
    server.use(
      http.post('*/api-admin/app-version', async ({ request }) => {
        body = await request.json()
        return HttpResponse.json({ version: '3.5.0', forceUpdate: true })
      }),
    )
    const created = await makeClient().publishAppVersion({ version: '3.5.0', forceUpdate: true })
    expect(body).toEqual({ version: '3.5.0', forceUpdate: true })
    expect(created.version).toBe('3.5.0')
  })

  it('surfaces the duplicate message on 400', async () => {
    await expect(
      makeClient().publishAppVersion({ version: '3.4.0', forceUpdate: false }),
    ).rejects.toMatchObject({ status: 400, message: 'A version 3.4.0 already exists.' })
  })
})
