import { useMemo, type ReactNode } from 'react'
import { useAuth } from '@/auth/authContext'
import { appConfig } from '@/config'
import { createGatewayClient } from './gatewayClient'
import { GatewayContext } from './gatewayContext'

export function GatewayProvider({ children }: { children: ReactNode }) {
  const { getToken, onAuthError } = useAuth()
  const client = useMemo(
    () =>
      createGatewayClient({
        baseUrl: appConfig().gatewayUrl,
        getToken,
        onAuthError,
      }),
    [getToken, onAuthError],
  )
  return <GatewayContext value={client}>{children}</GatewayContext>
}
