export interface RicName {
  ric: string
  name: string
}

export interface RicQuote extends RicName {
  isin: string
  currency: string
}

export interface Market {
  name: string
  fullName: string
  code: string
  devise: string
  createdAt?: string
  updated_at?: string
}

export interface IndexInfo {
  name: string
  codeRIC: string
  type: string
  createdAt?: string
  updated_at?: string
}

export interface CompanySummary {
  id: string
  name: string
  isArchived: boolean
  ric: string
  devise: string
  sectors: { name: string; createdAt?: string; updated_at?: string }[]
  associatedAccountsCount: number
}

export interface CompanyDetail {
  id: string
  name: string
  ric: string
  sector: string
  isArchived: boolean
  market: Market
  pairs?: unknown[]
  importedPairs?: unknown[]
  primaryIndice1: IndexInfo | null
  primaryIndice2: IndexInfo | null
  primaryIndice3: IndexInfo | null
  primaryIndice4: IndexInfo | null
  otherIndices?: IndexInfo[]
  languageCode: 'fr-FR' | 'en-EN'
  tickers?: unknown[]
}

export interface AccountDto {
  id: string
  email: string
  phone?: string
  firstname: string
  lastname: string
  jobFunction: string
  cgu?: string
  deactivationDate?: string
  emitter: CompanyDetail
  authorities: string[]
  passwordChangeRequired: boolean
  lastFlashReadDate?: string
  lastFlashDate?: string
  lastDailyReadDate?: string
  lastDailyDate?: string
}

export interface Collaborator {
  email: string
  firstName: string
  lastName: string
  jobFunction: string
  phone?: string
  roles: string[]
}

export interface CreateCompanyRequest {
  name: string
  ric: string
  marketCode: string
  languageCode: 'fr-FR' | 'en-EN'
  sector: string
  subSector?: string
  primaryIndiceRic1?: string
  primaryIndiceRic2?: string
  primaryIndiceRic3?: string
  primaryIndiceRic4?: string
  otherIndicesRic: string[]
  collaborators: Collaborator[]
}

export interface CreateCompanyFailure {
  collaborator: string
  message: string
}

export interface CreateCompanyResult {
  emitter: CompanyDetail
  failures: CreateCompanyFailure[]
}

export interface UpdateIndicesRequest {
  primaryIndiceRic1: string | null
  primaryIndiceRic2: string | null
  primaryIndiceRic3: string | null
  primaryIndiceRic4: string | null
}

export interface CreateUserRequest {
  email: string
  firstName: string
  lastName: string
  phone?: string
  jobFunction: string
  emitterId: string
  roles: string[]
}

export interface UpdateUserRequest {
  email: string
  firstName: string
  lastName: string
  phone?: string
  jobFunction: string
  emitterId: string
  roles: string[]
  passwordChangeRequired: boolean
}

export interface FieldError {
  objectName: string
  field: string
  code: string
  message: string
}

export type WorkStatus = 'todo' | 'doing' | 'done'

export interface ReportValidation {
  writing: WorkStatus
  content: WorkStatus
  status: WorkStatus
}

interface ReportState {
  id: string
  languageCode: 'fr-FR' | 'en-EN'
  writingStatus: WorkStatus
  validation: ReportValidation
  sent: boolean
  lockedBy: string | null
  lockedByCaller: boolean
  createdAt: string
  updatedAt: string
}

export interface ReportSummary extends ReportState {
  emitterId: string
  companyName: string
  ric: string
  sentAt?: string | null
  marketReportId: string | null
}

export interface MarketReportSummary extends ReportState {
  languageId: string
  languageName: string
}

export interface ReportContent {
  sector: string
  value: string
  customContent1: string
  customContent2: string
}

export interface MarketReportContent {
  content: string
}

export interface ReportDetail extends ReportSummary, ReportContent {
  marketContent: string | null
  graphPosition: Attachment | null
}

export interface EconomicStatistic {
  zone: string
  country: string
  object: string
  period: string
  actual: string
  expected: string
  previous: string
  released: string
  createdAt: string
  updated_at: string
}

export interface MarketReportDetail extends MarketReportSummary, MarketReportContent {}

export interface Attachment {
  id: string
  fileName: string
  contentType: string
  size: number
}

export interface CompanyRef {
  id: string
  name: string
  ric: string
}

export interface FlashSummary {
  id: string
  title: string
  company: string
  type: string
  description: string
  sendByEmail: boolean
  attachmentCount: number
  relatedCompanyCount: number
  createdAt: string
}

export interface FlashDetail {
  id: string
  title: string
  company: string
  type: string
  description: string
  links: string[]
  sendByEmail: boolean
  attachments: Attachment[]
  relatedCompanies: CompanyRef[]
  createdAt: string
}

export interface FlashPage {
  content: FlashSummary[]
  totalElements: number
  totalPages: number
  number: number
  size: number
}

export interface CreateFlashRequest {
  title: string
  value: string
  description: string
  type: string
  links: string[]
  emittersUUID: string[]
  sendByEmail: boolean
  sendToAll: boolean
}

export interface Page<T> {
  content: T[]
  totalElements: number
  totalPages: number
  number: number
  size: number
}

export interface BrokerNoteSummary {
  id: string
  title: string | null
  broker: string
  company: CompanyRef
  currency: string
  currentObjective: number | null
  currentRecommendation: string
  previousObjective: number | null
  previousRecommendation: string | null
  recommendationChange: boolean
  sectorNote: boolean
  initiationNote: boolean
  monitoringOfficer: string | null
  attachmentCount: number
  createdAt: string
}

export interface BrokerNoteDetail extends Omit<BrokerNoteSummary, 'attachmentCount'> {
  sendByMail: boolean
  attachments: Attachment[]
}

export interface BrokerNoteRequest {
  emitterId: string
  title?: string
  broker: string
  currency: string
  currentObjective: string
  currentRecommendation: string
  sectorNote: boolean
  initiationNote: boolean
  recoChange: boolean
  previousObjective?: string
  previousRecommendation?: string
  sendByEmail: boolean
}

export interface Ticker {
  id: string
  ricCode: string
  name: string
}

export interface TickerList {
  id: string
  name: string
  comments: string | null
  tickers: Ticker[]
  createdAt?: string | null
  updatedAt?: string | null
}

export interface TickerListsPage {
  criteria: string | null
  emitterId: string
  resultPage: {
    content: TickerList[]
    totalElements: number
    totalPages: number
    number: number
    size: number
  }
}

export interface CreateTickerListRequest {
  emitterId: string
  name: string
  comments: string
  tickers: { ric: string; name: string }[]
}

export interface ImportType {
  kind: string
  label: string
}

export interface ImportResult {
  totalRows: number
  okRows: number
  rowErrors: Record<string, string[]>
}

export interface AppVersion {
  version: string | null
  forceUpdate: boolean
}

export interface PublishAppVersionRequest {
  version: string
  forceUpdate: boolean
}

export type DisconnectionPlatform = 'DESKTOP' | 'MOBILE'

export interface DisconnectionStats {
  days: number
  from: string
  to: string
  totalDisconnections: number
  last24hDisconnections: number
  reasonBreakdown: { reason: string; count: number }[]
  platformBreakdown: { platform: string; count: number }[]
  topDisconnectedUsers: { userEmail: string; disconnectionCount: number }[]
}

export interface DisconnectionLog {
  id: string
  createdAt: string
  userEmail: string
  platform: DisconnectionPlatform
  reason: string
  ipAddress: string
  userAgent: string
  details: string
}

export interface DisconnectionQuery {
  page: number
  size: number
  userEmail?: string
  startDate?: string
  endDate?: string
  platform?: string
  reason?: string
}

export interface FactsetPeer {
  id?: number
  factsetName: string
  factsetId: string
}

export interface FactsetMultiple {
  id: number
  key: string
  label: string
}

export interface Factset {
  peersBloomIds: FactsetPeer[]
  multiples: FactsetMultiple[]
  availableMultiples: FactsetMultiple[]
}
