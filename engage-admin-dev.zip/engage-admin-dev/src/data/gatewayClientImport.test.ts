// @vitest-environment node
// Node's own FormData keeps file names through fetch; jsdom's loses them.
import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { createGatewayClient } from './gatewayClient'

function makeClient() {
  return createGatewayClient({
    baseUrl: 'http://gateway.test',
    getToken: () => Promise.resolve('tok-1'),
    onAuthError: () => undefined,
  })
}

describe('gateway client imports', () => {
  it('lists the import types in order', async () => {
    const types = await makeClient().listImportTypes()
    expect(types.map((type) => type.label)).toEqual([
      'Short BlackApp (file 10)',
      'Consensus',
      'Short Markit (file 9)',
      'Reco TP',
    ])
  })

  it('uploads a file as a multipart part named file with purge=true and no hand-set content type', async () => {
    let seen = { url: '', contentType: '', name: '' }
    server.use(
      http.post('*/api-admin/emitter/:emitterId/import/:kind', async ({ request }) => {
        const file = (await request.clone().formData()).get('file')
        seen = {
          url: request.url,
          contentType: request.headers.get('Content-Type') ?? '',
          name: file instanceof File ? file.name : '',
        }
        return HttpResponse.json({ totalRows: 1, okRows: 1, rowErrors: {} })
      }),
    )
    const file = new File(['x'], 'consensus.xlsx')
    expect(await makeClient().importFile('c1', 'consensus', file)).toEqual({
      totalRows: 1,
      okRows: 1,
      rowErrors: {},
    })
    expect(seen.name).toBe('consensus.xlsx')
    expect(seen.url).toContain('/api-admin/emitter/c1/import/consensus?purge=true')
    expect(seen.contentType).toMatch(/^multipart\/form-data; boundary=/)
  })

  it('returns row errors, surfaces 400 messages, and rejects an unknown kind or company', async () => {
    const client = makeClient()
    const result = await client.importFile('c1', 'stock', new File(['x'], 'stock-errors.xlsx'))
    expect(result.rowErrors['117']).toEqual(['Value [LVMH.PA] was expected for field [RIC].'])
    await expect(client.importFile('c1', 'stock', new File(['x'], 'invalid.xlsx'))).rejects.toThrow(
      'Invalid Excel file',
    )
    await expect(
      client.importFile('c1', 'stock', new File(['x'], 'no-brute.xlsx')),
    ).rejects.toThrow('Tab [Brute] not found in Excel file')
    await expect(client.importFile('c1', 'nope', new File(['x'], 'a.xlsx'))).rejects.toThrow(
      'Invalid type [nope]',
    )
    await expect(client.importFile('zz', 'stock', new File(['x'], 'a.xlsx'))).rejects.toMatchObject(
      { status: 404 },
    )
  })
})
