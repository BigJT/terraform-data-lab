import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@/i18n'
import { App } from '@/app/App'
import { appConfig } from '@/config'

async function startMocks() {
  if (appConfig().gatewayUrl !== '') return
  const { worker } = await import('@/mocks/browser')
  await worker.start({
    onUnhandledFrame: 'bypass',
    serviceWorker: { url: `${import.meta.env.BASE_URL}mockServiceWorker.js` },
  })
}

const rootElement = document.getElementById('root')
if (!rootElement) throw new Error('Root element #root not found')

await startMocks()

createRoot(rootElement).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
