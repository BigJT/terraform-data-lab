import { afterEach, describe, expect, it, vi } from 'vitest'
import { appConfig } from '@/config'

function clearEnv() {
  vi.stubEnv('VITE_GATEWAY_URL', '')
  vi.stubEnv('VITE_ENTRA_TENANT_ID', '')
  vi.stubEnv('VITE_ENTRA_CLIENT_ID', '')
  vi.stubEnv('VITE_API_SCOPE', '')
  vi.stubEnv('VITE_ENTRA_MOCK', '')
}

describe('appConfig', () => {
  afterEach(() => {
    delete window.__ENGAGE_ADMIN_CONFIG__
    vi.unstubAllEnvs()
  })

  it('prefers the start-up config over the build settings', () => {
    clearEnv()
    vi.stubEnv('VITE_GATEWAY_URL', 'https://env.example')
    vi.stubEnv('VITE_ENTRA_TENANT_ID', 'env-tenant')
    vi.stubEnv('VITE_ENTRA_CLIENT_ID', 'env-client')
    vi.stubEnv('VITE_API_SCOPE', 'env-scope')
    window.__ENGAGE_ADMIN_CONFIG__ = {
      gatewayUrl: 'https://window.example',
      entraTenantId: 'window-tenant',
      entraClientId: 'window-client',
      apiScope: 'window-scope',
    }
    expect(appConfig()).toEqual({
      gatewayUrl: 'https://window.example',
      entraTenantId: 'window-tenant',
      entraClientId: 'window-client',
      apiScope: 'window-scope',
      entraMock: false,
    })
  })

  it('falls back to the build settings when a start-up key is missing or empty', () => {
    clearEnv()
    vi.stubEnv('VITE_GATEWAY_URL', 'https://env.example')
    vi.stubEnv('VITE_ENTRA_TENANT_ID', 'env-tenant')
    vi.stubEnv('VITE_ENTRA_CLIENT_ID', 'env-client')
    vi.stubEnv('VITE_API_SCOPE', 'env-scope')
    window.__ENGAGE_ADMIN_CONFIG__ = { gatewayUrl: '', apiScope: 'window-scope' }
    expect(appConfig()).toEqual({
      gatewayUrl: 'https://env.example',
      entraTenantId: 'env-tenant',
      entraClientId: 'env-client',
      apiScope: 'window-scope',
      entraMock: false,
    })
  })

  it('uses the build settings when there is no start-up config', () => {
    clearEnv()
    vi.stubEnv('VITE_GATEWAY_URL', 'https://env.example')
    expect(appConfig().gatewayUrl).toBe('https://env.example')
  })

  it('gives empty strings when nothing is set', () => {
    clearEnv()
    window.__ENGAGE_ADMIN_CONFIG__ = {}
    expect(appConfig()).toEqual({
      gatewayUrl: '',
      entraTenantId: '',
      entraClientId: '',
      apiScope: '',
      entraMock: false,
    })
  })

  it('turns the stand-in on from the start-up config', () => {
    clearEnv()
    window.__ENGAGE_ADMIN_CONFIG__ = { entraMock: '1' }
    expect(appConfig().entraMock).toBe(true)
  })

  it('turns the stand-in on from the build settings', () => {
    clearEnv()
    vi.stubEnv('VITE_ENTRA_MOCK', '1')
    expect(appConfig().entraMock).toBe(true)
  })

  it('leaves the stand-in off for any other value', () => {
    clearEnv()
    vi.stubEnv('VITE_ENTRA_MOCK', 'yes')
    window.__ENGAGE_ADMIN_CONFIG__ = { entraMock: '0' }
    expect(appConfig().entraMock).toBe(false)
  })
})
