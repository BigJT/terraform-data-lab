import ts from 'typescript'
import { describe, expect, it } from 'vitest'
import en from './en.json'
import fr from './fr.json'
import review from '../../docs/i18n-review.md?raw'

interface Tree {
  [key: string]: string | Tree
}

function leaves(tree: Tree, prefix = ''): [string, string][] {
  return Object.entries(tree).flatMap(([key, value]) =>
    typeof value === 'string'
      ? [[prefix + key, value] as [string, string]]
      : leaves(value, `${prefix}${key}.`),
  )
}

const sources = import.meta.glob<string>(
  ['/src/**/*.tsx', '!/src/**/*.test.tsx', '!/src/mocks/**', '!/src/test/**'],
  { query: '?raw', import: 'default', eager: true },
)

const allowed = [
  'Engage Admin',
  'EN',
  'FR',
  'B',
  'I',
  'U',
  'H2',
  'H3',
  'T',
  'CUSTOM CONTENT 1',
  'CUSTOM CONTENT 2',
]

describe('translations', () => {
  it('en and fr have the same keys and no empty values', () => {
    const english = leaves(en)
    const french = leaves(fr)
    expect(french.map(([key]) => key)).toEqual(english.map(([key]) => key))
    expect(
      [...english, ...french].filter(([, value]) => value.trim() === '').map(([key]) => key),
    ).toEqual([])
  })

  it('no screen carries a literal JSX text node', () => {
    const found: string[] = []
    for (const [file, source] of Object.entries(sources)) {
      const visit = (node: ts.Node) => {
        if (ts.isJsxText(node)) {
          const text = node.text.replace(/\s+/g, ' ').trim()
          if (/[A-Za-zÀ-ÿ]/.test(text) && !allowed.includes(text)) found.push(`${file}: ${text}`)
        }
        ts.forEachChild(node, visit)
      }
      visit(ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX))
    }
    expect(found).toEqual([])
  })

  it('every en key has a row in docs/i18n-review.md', () => {
    const rows = new Set([...review.matchAll(/^\| (\S+) \|/gm)].map((match) => match[1]))
    expect(
      leaves(en as Tree)
        .map(([key]) => key)
        .filter((key) => !rows.has(key)),
    ).toEqual([])
  })
})
