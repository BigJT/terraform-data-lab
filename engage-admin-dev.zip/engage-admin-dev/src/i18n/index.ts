import i18next from 'i18next'
import { initReactI18next } from 'react-i18next'
import dayjs from 'dayjs'
import 'dayjs/locale/fr'
import en from './en.json'
import fr from './fr.json'

export type Language = 'en' | 'fr'

export const languageKey = 'engage-admin.language'

function storedLanguage(): Language | null {
  try {
    const stored = localStorage.getItem(languageKey)
    return stored === 'en' || stored === 'fr' ? stored : null
  } catch {
    return null
  }
}

/** The stored choice, else French for a French browser, else English. */
export function detectLanguage(): Language {
  return storedLanguage() ?? (navigator.language.toLowerCase().startsWith('fr') ? 'fr' : 'en')
}

function applyLanguage(lng: Language) {
  // Tests in the node environment have no document.
  if (typeof document !== 'undefined') document.documentElement.lang = lng
  dayjs.locale(lng)
}

export function setLanguage(lng: Language) {
  void i18next.changeLanguage(lng)
  try {
    localStorage.setItem(languageKey, lng)
  } catch {
    // Storage blocked: the choice lasts until reload.
  }
  applyLanguage(lng)
}

const initialLanguage = detectLanguage()

void i18next.use(initReactI18next).init({
  resources: { en: { translation: en }, fr: { translation: fr } },
  lng: initialLanguage,
  fallbackLng: 'en',
  interpolation: { escapeValue: false },
})
applyLanguage(initialLanguage)
