import { afterEach, describe, expect, it, vi } from 'vitest'
import dayjs from 'dayjs'
import i18next from 'i18next'
import { detectLanguage, languageKey, setLanguage } from '@/i18n'

function browserLanguage(language: string) {
  vi.spyOn(navigator, 'language', 'get').mockReturnValue(language)
}

afterEach(() => {
  localStorage.removeItem(languageKey)
})

describe('detectLanguage', () => {
  it('picks French for a French browser', () => {
    browserLanguage('fr-FR')
    expect(detectLanguage()).toBe('fr')
  })

  it('picks English for any other browser', () => {
    browserLanguage('en-GB')
    expect(detectLanguage()).toBe('en')
  })

  it('prefers the stored choice over the browser', () => {
    browserLanguage('fr-FR')
    localStorage.setItem(languageKey, 'en')
    expect(detectLanguage()).toBe('en')
  })

  it('ignores a stored value that is not a language', () => {
    browserLanguage('fr-FR')
    localStorage.setItem(languageKey, 'de')
    expect(detectLanguage()).toBe('fr')
  })

  it('falls back to the browser when storage throws', () => {
    browserLanguage('fr-CA')
    vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
      throw new Error('blocked')
    })
    expect(detectLanguage()).toBe('fr')
  })
})

describe('setLanguage', () => {
  it('switches i18next, stores the choice, and sets <html lang> and the dayjs locale', () => {
    setLanguage('fr')
    expect(i18next.language).toBe('fr')
    expect(localStorage.getItem(languageKey)).toBe('fr')
    expect(document.documentElement.lang).toBe('fr')
    expect(dayjs.locale()).toBe('fr')
    expect(dayjs('2026-10-12').format('dddd D MMMM YYYY')).toBe('lundi 12 octobre 2026')

    setLanguage('en')
    expect(i18next.language).toBe('en')
    expect(localStorage.getItem(languageKey)).toBe('en')
    expect(document.documentElement.lang).toBe('en')
    expect(dayjs.locale()).toBe('en')
  })

  it('still switches when storage throws', () => {
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('blocked')
    })
    setLanguage('fr')
    expect(i18next.language).toBe('fr')
    expect(document.documentElement.lang).toBe('fr')
    expect(dayjs.locale()).toBe('fr')
  })
})
