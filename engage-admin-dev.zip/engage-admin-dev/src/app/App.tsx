import { ThemeProvider } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'
import { BrowserRouter } from 'react-router'
import { useTranslation } from 'react-i18next'
import { frenchTheme, theme } from '@/ds/theme'
import { AuthProvider } from '@/auth/AuthProvider'
import { AuthGate } from '@/auth/AuthGate'
import { GatewayProvider } from '@/data/GatewayProvider'
import { entraSettingsFromEnv } from '@/auth/entraAuth'
import { AppRoutes } from '@/app/AppRoutes'
import { mockSignInPath } from '@/auth/fakeMsal'
import { appConfig } from '@/config'
import { MockEntraSignInScreen } from '@/screens/MockEntraSignIn/MockEntraSignInScreen'

const entra = entraSettingsFromEnv()

const standIn = appConfig().entraMock && window.location.pathname === mockSignInPath

export function App() {
  const { i18n } = useTranslation()
  const activeTheme = i18n.resolvedLanguage === 'fr' ? frenchTheme : theme
  if (standIn) {
    return (
      <ThemeProvider theme={activeTheme}>
        <CssBaseline />
        <MockEntraSignInScreen />
      </ThemeProvider>
    )
  }
  return (
    <ThemeProvider theme={activeTheme}>
      <CssBaseline />
      <AuthProvider entra={entra}>
        <AuthGate>
          <GatewayProvider>
            <BrowserRouter basename="/engage-admin">
              <AppRoutes />
            </BrowserRouter>
          </GatewayProvider>
        </AuthGate>
      </AuthProvider>
    </ThemeProvider>
  )
}
