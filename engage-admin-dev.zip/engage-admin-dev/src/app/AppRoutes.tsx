import { Navigate, Route, Routes } from 'react-router'
import { AppShell } from '@/app/AppShell'
import { AddCompanyScreen } from '@/screens/AddCompany/AddCompanyScreen'
import { CompaniesScreen } from '@/screens/Companies/CompaniesScreen'
import { CompanyDetailScreen } from '@/screens/CompanyDetail/CompanyDetailScreen'
import { SendBrokerNoteScreen } from '@/screens/BrokerNotes/SendBrokerNoteScreen'
import { BrokerNotesScreen } from '@/screens/BrokerNotes/BrokerNotesScreen'
import { FlashDetailScreen } from '@/screens/Flashes/FlashDetailScreen'
import { FlashesScreen } from '@/screens/Flashes/FlashesScreen'
import { SendFlashScreen } from '@/screens/Flashes/SendFlashScreen'
import { MarketReportScreen } from '@/screens/Reports/MarketReportScreen'
import { ReportScreen } from '@/screens/Reports/ReportScreen'
import { ReportsScreen } from '@/screens/Reports/ReportsScreen'
import { VersionScreen } from '@/screens/Version/VersionScreen'
import { MonitoringScreen } from '@/screens/Monitoring/MonitoringScreen'

export function AppRoutes() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route index element={<Navigate to="/companies" replace />} />
        <Route path="reports" element={<ReportsScreen />} />
        <Route path="reports/market/:id" element={<MarketReportScreen />} />
        <Route path="reports/:id" element={<ReportScreen />} />
        <Route path="flashes" element={<FlashesScreen />} />
        <Route path="flashes/new" element={<SendFlashScreen />} />
        <Route path="flashes/:id" element={<FlashDetailScreen />} />
        <Route path="broker-notes" element={<BrokerNotesScreen />} />
        <Route path="broker-notes/new" element={<SendBrokerNoteScreen />} />
        <Route path="companies" element={<CompaniesScreen />} />
        <Route path="companies/new" element={<AddCompanyScreen />} />
        <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
        <Route path="version" element={<VersionScreen />} />
        <Route path="monitoring" element={<MonitoringScreen />} />
      </Route>
    </Routes>
  )
}
