import { Box, Link } from '@mui/material'
import { NavLink, Outlet } from 'react-router'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { useAuth } from '@/auth/authContext'
import { setLanguage } from '@/i18n'

const navEntries = [
  { labelKey: 'shell.reports', path: '/reports' },
  { labelKey: 'shell.flashes', path: '/flashes' },
  { labelKey: 'shell.brokerNotes', path: '/broker-notes' },
  { labelKey: 'shell.companies', path: '/companies' },
  { labelKey: 'shell.version', path: '/version' },
  { labelKey: 'shell.monitoring', path: '/monitoring' },
] as const

const languages = [
  { lng: 'en', label: 'EN' },
  { lng: 'fr', label: 'FR' },
] as const

function LanguageSwitch() {
  const { t, i18n } = useTranslation()
  return (
    <Box role="group" aria-label={t('shell.language')} sx={{ display: 'flex', gap: 0.5, mb: 1 }}>
      {languages.map(({ lng, label }) => {
        const pressed = i18n.resolvedLanguage === lng
        return (
          <Box
            key={lng}
            component="button"
            type="button"
            lang={lng}
            aria-pressed={pressed}
            onClick={() => {
              setLanguage(lng)
            }}
            sx={{
              height: 24,
              px: 1,
              fontSize: 12,
              fontWeight: 600,
              fontFamily: 'inherit',
              borderRadius: 1,
              cursor: 'pointer',
              border: `1px solid ${pressed ? colors.panel : colors.onChrome}`,
              backgroundColor: pressed ? colors.panel : 'transparent',
              color: pressed ? colors.textPrimary : colors.onChrome,
              '&:focus-visible': { outline: `2px solid ${colors.onChrome}`, outlineOffset: 2 },
            }}
          >
            {label}
          </Box>
        )
      })}
    </Box>
  )
}

export function AppShell() {
  const { name, signOut } = useAuth()
  const { t } = useTranslation()
  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Box
        component="aside"
        sx={{
          width: 220,
          flexShrink: 0,
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: colors.chrome,
          color: colors.onChrome,
        }}
      >
        <Box sx={{ px: 2, py: 2.5, fontSize: 18, fontWeight: 700 }}>Engage Admin</Box>
        <Box component="nav" sx={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
          {navEntries.map((entry) => (
            <Box
              key={entry.path}
              component={NavLink}
              to={entry.path}
              sx={{
                px: 2,
                py: 1,
                fontSize: 14,
                fontWeight: 600,
                color: colors.onChrome,
                textDecoration: 'none',
                '&:hover': { textDecoration: 'underline' },
                '&:focus-visible': { outline: `2px solid ${colors.onChrome}`, outlineOffset: -2 },
                '&.active': { backgroundColor: colors.panel, color: colors.textPrimary },
              }}
            >
              {t(entry.labelKey)}
            </Box>
          ))}
        </Box>
        <Box sx={{ px: 2, py: 2, display: 'flex', flexDirection: 'column', gap: 0.5 }}>
          <LanguageSwitch />
          <Box sx={{ fontSize: 14 }}>{name}</Box>
          <Link
            component="button"
            onClick={signOut}
            sx={{ alignSelf: 'flex-start', fontSize: 13, color: colors.onChrome }}
          >
            {t('shell.signOut')}
          </Link>
        </Box>
      </Box>
      <Box component="main" sx={{ flex: 1, minWidth: 0, p: 3, backgroundColor: colors.canvas }}>
        <Outlet />
      </Box>
    </Box>
  )
}
