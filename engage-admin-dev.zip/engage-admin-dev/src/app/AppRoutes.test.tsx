import { describe, expect, it, vi } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, useLocation } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { browserLocation } from '@/auth/browserLocation'
import { AppRoutes } from '@/app/AppRoutes'
import { languageKey } from '@/i18n'

function LocationProbe() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderApp(initialPath = '/') {
  return renderWithTheme(
    <AuthProvider>
      <MemoryRouter initialEntries={[initialPath]}>
        <GatewayProvider>
          <AppRoutes />
        </GatewayProvider>
        <LocationProbe />
      </MemoryRouter>
    </AuthProvider>,
  )
}

const entries = [
  { label: 'Reports', path: '/reports' },
  { label: 'Flashes', path: '/flashes' },
  { label: 'Broker notes', path: '/broker-notes' },
  { label: 'Companies', path: '/companies' },
  { label: 'Version', path: '/version' },
  { label: 'Monitoring', path: '/monitoring' },
]

describe('AppRoutes', () => {
  it('shows the six sidebar entries in order with their routes', () => {
    renderApp()
    const links = within(screen.getByRole('navigation')).getAllByRole('link')
    expect(links.map((link) => link.textContent)).toEqual(entries.map((entry) => entry.label))
    expect(links.map((link) => link.getAttribute('href'))).toEqual(
      entries.map((entry) => entry.path),
    )
  })

  it('shows the wordmark, the signed-in name and a Sign out link', () => {
    renderApp()
    expect(screen.getByText('Engage Admin')).toBeInTheDocument()
    expect(screen.getByText('Local Admin')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Sign out' })).toBeInTheDocument()
  })

  it('redirects / to Companies', () => {
    renderApp('/')
    expect(screen.getByTestId('location')).toHaveTextContent('/companies')
    expect(screen.getByRole('heading', { level: 1, name: 'Companies' })).toBeInTheDocument()
    expect(screen.queryByText('Coming soon')).not.toBeInTheDocument()
  })

  it('marks the current entry as selected', async () => {
    const user = userEvent.setup()
    renderApp()
    await user.click(screen.getByRole('link', { name: 'Version' }))
    expect(screen.getByRole('link', { name: 'Version' })).toHaveAttribute('aria-current', 'page')
    expect(screen.getByRole('link', { name: 'Companies' })).not.toHaveAttribute('aria-current')
  })

  it('signs out by replacing the location with the app root', async () => {
    const user = userEvent.setup()
    const replace = vi.spyOn(browserLocation, 'replace').mockImplementation(() => undefined)
    renderApp()
    await user.click(screen.getByRole('button', { name: 'Sign out' }))
    expect(replace).toHaveBeenCalledWith('/engage-admin/')
  })

  it('shows the EN | FR switch with EN pressed', () => {
    renderApp()
    const group = screen.getByRole('group', { name: 'Language' })
    expect(within(group).getByRole('button', { name: 'EN' })).toHaveAttribute(
      'aria-pressed',
      'true',
    )
    expect(within(group).getByRole('button', { name: 'FR' })).toHaveAttribute(
      'aria-pressed',
      'false',
    )
  })

  it('turns the shell French at once when FR is clicked, and back with EN', async () => {
    const user = userEvent.setup()
    renderApp()
    await user.click(screen.getByRole('button', { name: 'FR' }))
    const links = within(screen.getByRole('navigation')).getAllByRole('link')
    expect(links.map((link) => link.textContent)).toEqual([
      'Rapports',
      'Flashs',
      'N. de brokers',
      'Émetteurs',
      'Version',
      'Monitoring',
    ])
    expect(screen.getByRole('button', { name: 'Se déconnecter' })).toBeInTheDocument()
    const group = screen.getByRole('group', { name: 'Langue' })
    expect(within(group).getByRole('button', { name: 'FR' })).toHaveAttribute(
      'aria-pressed',
      'true',
    )
    expect(localStorage.getItem(languageKey)).toBe('fr')

    await user.click(screen.getByRole('button', { name: 'EN' }))
    expect(screen.getByRole('link', { name: 'Reports' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Sign out' })).toBeInTheDocument()
  })
})
