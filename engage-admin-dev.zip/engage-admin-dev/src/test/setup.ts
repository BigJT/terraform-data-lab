import { afterAll, afterEach, beforeAll, beforeEach, vi } from 'vitest'
import { cleanup } from '@testing-library/react'
import '@testing-library/jest-dom/vitest'
import { server } from '@/mocks/server'
import { resetFixtures } from '@/mocks/fixtures'
import { languageKey, setLanguage } from '@/i18n'

beforeAll(() => {
  server.listen({ onUnhandledFrame: 'error' })
})

afterAll(() => {
  server.close()
})

// Fail any test that logs a console.error (React key warnings, jsdom not-implemented, act() warnings),
// so noise can't hide behind a green suite. A test that genuinely expects one spies on it itself.
const consoleErrors: string[] = []
beforeEach(() => {
  resetFixtures()
  if (typeof window !== 'undefined') {
    setLanguage('en')
    localStorage.removeItem(languageKey)
  }
  consoleErrors.length = 0
  const original = console.error
  vi.spyOn(console, 'error').mockImplementation((...args: unknown[]) => {
    consoleErrors.push(args.map((arg) => String(arg)).join(' '))
    original(...args)
  })
})

afterEach(() => {
  cleanup()
  server.resetHandlers()
  vi.restoreAllMocks()
  if (consoleErrors.length > 0) {
    const joined = consoleErrors.join('\n')
    consoleErrors.length = 0
    throw new Error(`Unexpected console.error during test:\n${joined}`)
  }
})
