import type { ReactElement, ReactNode } from 'react'
import { render } from '@testing-library/react'
import { ThemeProvider } from '@mui/material/styles'
import { theme } from '@/ds/theme'

// eslint-disable-next-line react-refresh/only-export-components -- test helper, never hot-reloaded
function Wrapper({ children }: { children: ReactNode }) {
  return <ThemeProvider theme={theme}>{children}</ThemeProvider>
}

export function renderWithTheme(ui: ReactElement) {
  return render(ui, { wrapper: Wrapper })
}
