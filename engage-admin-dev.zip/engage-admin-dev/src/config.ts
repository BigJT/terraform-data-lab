export interface AppConfig {
  gatewayUrl: string
  entraTenantId: string
  entraClientId: string
  apiScope: string
  entraMock: boolean
}

type ConfigKey = keyof NonNullable<Window['__ENGAGE_ADMIN_CONFIG__']>

// The container writes window.__ENGAGE_ADMIN_CONFIG__ into config.js at start-up; local runs use the VITE_ settings.
function setting(key: ConfigKey, fallback: string | undefined): string {
  const value = window.__ENGAGE_ADMIN_CONFIG__?.[key]
  if (typeof value === 'string' && value !== '') return value
  return fallback ?? ''
}

/** The only place the app reads its settings. */
export function appConfig(): AppConfig {
  return {
    gatewayUrl: setting('gatewayUrl', import.meta.env.VITE_GATEWAY_URL),
    entraTenantId: setting('entraTenantId', import.meta.env.VITE_ENTRA_TENANT_ID),
    entraClientId: setting('entraClientId', import.meta.env.VITE_ENTRA_CLIENT_ID),
    apiScope: setting('apiScope', import.meta.env.VITE_API_SCOPE),
    entraMock: setting('entraMock', import.meta.env.VITE_ENTRA_MOCK) === '1',
  }
}
