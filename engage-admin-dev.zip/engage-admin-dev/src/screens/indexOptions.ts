import type { IndexInfo } from '@/data/types'

/** Indices a slot may pick: everything except what the other slots already chose. */
export function availableIndices(
  all: IndexInfo[],
  chosen: (string | null)[],
  slot: number,
): IndexInfo[] {
  const taken = chosen.filter((ric, position): ric is string => ric !== null && position !== slot)
  return all.filter((index) => !taken.includes(index.codeRIC))
}
