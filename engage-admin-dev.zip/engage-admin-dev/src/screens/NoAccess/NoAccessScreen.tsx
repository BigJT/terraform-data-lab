import { Box, Button } from '@mui/material'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { useAuth } from '@/auth/authContext'

export function NoAccessScreen() {
  const { signOut } = useAuth()
  const { t } = useTranslation()
  return (
    <Box
      component="main"
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 3,
        backgroundColor: colors.canvas,
      }}
    >
      <Box sx={{ fontSize: 18, fontWeight: 600, color: colors.textPrimary }}>
        {t('noAccess.message')}
      </Box>
      <Button variant="contained" onClick={signOut}>
        {t('shell.signOut')}
      </Button>
    </Box>
  )
}
