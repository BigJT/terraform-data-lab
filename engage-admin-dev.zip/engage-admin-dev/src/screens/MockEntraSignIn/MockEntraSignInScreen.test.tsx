import { afterEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithTheme } from '@/test/renderWithTheme'
import { browserLocation } from '@/auth/browserLocation'
import { mockAccountKey, mockRedirectKey } from '@/auth/fakeMsal'
import { MockEntraSignInScreen } from './MockEntraSignInScreen'

describe('MockEntraSignInScreen', () => {
  afterEach(() => {
    sessionStorage.clear()
    vi.restoreAllMocks()
  })

  it('stores the picked account and returns to the app root', async () => {
    const user = userEvent.setup()
    const replace = vi.spyOn(browserLocation, 'replace').mockImplementation(() => undefined)
    renderWithTheme(<MockEntraSignInScreen />)
    await user.click(screen.getByRole('button', { name: 'Standard User' }))
    expect(sessionStorage.getItem(mockAccountKey)).toBe('mock-standard')
    expect(sessionStorage.getItem(mockRedirectKey)).toBe('1')
    expect(replace).toHaveBeenCalledWith('/engage-admin/')
  })
})
