import { Box, Button } from '@mui/material'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { Panel } from '@/ds/components'
import { browserLocation } from '@/auth/browserLocation'
import { mockAccountKey, mockAccounts, mockRedirectKey } from '@/auth/fakeMsal'

function pick(homeAccountId: string) {
  sessionStorage.setItem(mockAccountKey, homeAccountId)
  sessionStorage.setItem(mockRedirectKey, '1')
  browserLocation.replace(import.meta.env.BASE_URL)
}

export function MockEntraSignInScreen() {
  const { t } = useTranslation()
  return (
    <Box
      component="main"
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.canvas,
      }}
    >
      <Panel>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 3,
            px: 6,
            py: 5,
          }}
        >
          <Box
            component="h1"
            sx={{ m: 0, fontSize: 24, fontWeight: 700, color: colors.textPrimary }}
          >
            {t('mockSignIn.title')}
          </Box>
          <Box sx={{ color: colors.textPrimary }}>{t('mockSignIn.intro')}</Box>
          <Box sx={{ display: 'flex', gap: 2 }}>
            {mockAccounts.map((account) => (
              <Button
                key={account.homeAccountId}
                variant="contained"
                onClick={() => {
                  pick(account.homeAccountId)
                }}
              >
                {account.name}
              </Button>
            ))}
          </Box>
        </Box>
      </Panel>
    </Box>
  )
}
