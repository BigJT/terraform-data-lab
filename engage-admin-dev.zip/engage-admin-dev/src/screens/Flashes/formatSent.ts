const pad = (value: number) => String(value).padStart(2, '0')

export function formatSent(iso: string): string {
  const date = new Date(iso)
  const day = `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${String(date.getFullYear())}`
  return `${day} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}
