import { describe, expect, it, vi } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import type { CreateFlashRequest } from '@/data/types'
import { SendFlashScreen } from './SendFlashScreen'

// The real Tiptap editor cannot be typed into under jsdom; a textarea stands in.
// Playwright drives the real editor (MTP-FLS-008).
vi.mock('@/ds/components', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/ds/components')>()
  return {
    ...actual,
    RichTextEditor: ({
      label,
      value,
      onChange,
      error,
    }: {
      label: string
      value: string
      onChange: (html: string) => void
      error?: string
    }) => (
      <div>
        <textarea
          aria-label={label}
          value={value}
          onChange={(event) => {
            onChange(event.target.value)
          }}
        />
        {error && <span>{error}</span>}
      </div>
    ),
  }
})

const errors = [
  'Please choose a recipient',
  'Subject is required',
  'Company is required',
  'Type is required',
  'Message is required',
]

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen() {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/flashes/new']}>
          <Routes>
            <Route path="flashes/new" element={<SendFlashScreen />} />
            <Route path="*" element={<Location />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

/** Records each posted `flash` part and answers 200 with id `new1`. */
function capturePosts() {
  const posted: CreateFlashRequest[] = []
  server.use(
    http.post('*/api-admin/flashs', async ({ request }) => {
      const part = (await request.formData()).get('flash') as Blob
      posted.push(JSON.parse(await part.text()) as CreateFlashRequest)
      return HttpResponse.json({ id: 'new1' }, { status: 200 })
    }),
  )
  return posted
}

async function chooseCompany(user: ReturnType<typeof userEvent.setup>, name: string) {
  await user.click(screen.getByRole('combobox', { name: 'Companies' }))
  await user.click(await screen.findByRole('option', { name }))
}

async function fillContent(user: ReturnType<typeof userEvent.setup>, subject: string) {
  await user.type(screen.getByRole('textbox', { name: 'Subject' }), subject)
  await user.type(screen.getByRole('textbox', { name: 'Company' }), 'Danone')
  await user.click(screen.getByRole('combobox', { name: 'Type' }))
  await user.click(await screen.findByRole('option', { name: 'Breaking News' }))
  await user.type(screen.getByRole('textbox', { name: 'Message' }), '<p><strong>Big</strong></p>')
}

describe('SendFlashScreen', () => {
  it('shows every error on an empty Send and sends nothing', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    expect(await screen.findByRole('heading', { name: 'Send a flash' })).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Send' }))
    for (const error of errors) expect(await screen.findByText(error)).toBeInTheDocument()
    expect(posted).toEqual([])
  })

  it('offers the eight flash types', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(await screen.findByRole('combobox', { name: 'Type' }))
    const options = within(await screen.findByRole('listbox')).getAllByRole('option')
    expect(options.map((option) => option.textContent)).toEqual([
      'Price movement',
      'Pre-opening',
      'Breaking News',
      'Reco / TP',
      "Sales traders' comments",
      'Brokers Interests',
      'Brokers Comments',
      'Peer report',
    ])
  })

  it('never offers archived companies', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(await screen.findByRole('combobox', { name: 'Companies' }))
    const options = within(await screen.findByRole('listbox')).getAllByRole('option')
    expect(options.map((option) => option.textContent)).toEqual([
      'LVMH',
      'Danone',
      'Kering',
      'Accor',
      'Diageo',
    ])
  })

  it('disables the picker and clears the recipient error when sending to all', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByRole('heading', { name: 'Send a flash' })
    await user.click(screen.getByRole('button', { name: 'Send' }))
    expect(await screen.findByText('Please choose a recipient')).toBeInTheDocument()
    await user.click(screen.getByRole('checkbox', { name: 'Send to all companies' }))
    expect(screen.getByRole('combobox', { name: 'Companies' })).toBeDisabled()
    expect(screen.queryByText('Please choose a recipient')).not.toBeInTheDocument()
  })

  it('posts the flash with trimmed links and opens the new detail', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await screen.findByRole('heading', { name: 'Send a flash' })
    await chooseCompany(user, 'Danone')
    await fillContent(user, 'Danone upgrade')
    await user.type(
      screen.getByRole('textbox', { name: 'Related links' }),
      '  https://a.example  {Enter}{Enter}https://b.example',
    )
    await user.click(screen.getByRole('checkbox', { name: 'Also send by email' }))
    await user.click(screen.getByRole('button', { name: 'Send' }))
    expect(await screen.findByTestId('location')).toHaveTextContent('/flashes/new1')
    expect(posted).toEqual([
      {
        title: 'Danone upgrade',
        value: 'Danone',
        description: '<p><strong>Big</strong></p>',
        type: 'Breaking News',
        links: ['https://a.example', 'https://b.example'],
        emittersUUID: ['c2'],
        sendByEmail: true,
        sendToAll: false,
      },
    ])
  })

  it('sends the chosen files as attachments parts', async () => {
    let sizes: number[] = []
    server.use(
      http.post('*/api-admin/flashs', async ({ request }) => {
        const files = (await request.formData()).getAll('attachments') as File[]
        sizes = files.map((file) => file.size)
        return HttpResponse.json({ id: 'new1' }, { status: 200 })
      }),
    )
    const user = userEvent.setup()
    renderScreen()
    await screen.findByRole('heading', { name: 'Send a flash' })
    await chooseCompany(user, 'Danone')
    await fillContent(user, 'With a file')
    await user.upload(
      screen.getByLabelText('Add an attachment input'),
      new File(['hello'], 'notes.txt', { type: 'text/plain' }),
    )
    await user.click(screen.getByRole('button', { name: 'Send' }))
    await screen.findByTestId('location')
    // jsdom's File loses its name through the msw round trip; Playwright checks the name.
    expect(sizes).toEqual([5])
  })

  it('sends to all companies with no chosen ids', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await screen.findByRole('heading', { name: 'Send a flash' })
    await chooseCompany(user, 'Danone')
    await user.click(screen.getByRole('checkbox', { name: 'Send to all companies' }))
    await fillContent(user, 'To everyone')
    await user.click(screen.getByRole('button', { name: 'Send' }))
    await screen.findByTestId('location')
    expect(posted[0]).toMatchObject({ emittersUUID: [], sendToAll: true, links: [] })
  })

  it('shows the alert and keeps every value when the server fails', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByRole('heading', { name: 'Send a flash' })
    await chooseCompany(user, 'Danone')
    await fillContent(user, 'Mock server error')
    await user.type(screen.getByRole('textbox', { name: 'Related links' }), 'https://a.example')
    await user.click(screen.getByRole('checkbox', { name: 'Also send by email' }))
    await user.click(screen.getByRole('button', { name: 'Send' }))
    expect(
      await screen.findByText('Unable to create a flash right now. Please try again later.'),
    ).toBeInTheDocument()
    expect(screen.getByRole('textbox', { name: 'Subject' })).toHaveValue('Mock server error')
    expect(screen.getByRole('textbox', { name: 'Company' })).toHaveValue('Danone')
    expect(screen.getByRole('combobox', { name: 'Type' })).toHaveTextContent('Breaking News')
    expect(screen.getByRole('textbox', { name: 'Message' })).toHaveValue(
      '<p><strong>Big</strong></p>',
    )
    expect(screen.getByRole('textbox', { name: 'Related links' })).toHaveValue('https://a.example')
    expect(screen.getByRole('checkbox', { name: 'Also send by email' })).toBeChecked()
    expect(screen.getByRole('button', { name: 'Danone' })).toBeInTheDocument()
    expect(screen.queryByTestId('location')).not.toBeInTheDocument()
  })
})
