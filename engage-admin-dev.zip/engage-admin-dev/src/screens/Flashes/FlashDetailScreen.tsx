import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Link,
} from '@mui/material'
import { useEffect, useState } from 'react'
import { Link as RouterLink, useNavigate, useParams } from 'react-router'
import { useTranslation } from 'react-i18next'
import { Panel, SafeHtml } from '@/ds/components'
import { colors } from '@/ds/theme'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { Attachment, FlashDetail } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { formatSent } from './formatSent'

function SectionHeading({ children }: { children: string }) {
  return (
    <Box sx={{ mt: 2, mb: 0.5, fontSize: 12, fontWeight: 600, color: colors.textSecondary }}>
      {children}
    </Box>
  )
}

export function FlashDetailScreen() {
  const { t } = useTranslation()
  const { id = '' } = useParams()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [flash, setFlash] = useState<FlashDetail | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [confirming, setConfirming] = useState(false)
  const [deleteError, setDeleteError] = useState<string | null>(null)
  const [downloadError, setDownloadError] = useState(false)

  useEffect(() => {
    let current = true
    gateway.getFlash(id).then(
      (loaded) => {
        if (current) setFlash(loaded)
      },
      (failure: unknown) => {
        if (!current) return
        setError(
          failure instanceof GatewayError && failure.status === 404
            ? t('flashes.notFound')
            : gatewayMessage(failure, t('flashes.loadOneFailed')),
        )
      },
    )
    return () => {
      current = false
    }
  }, [gateway, id, t])

  async function download(attachment: Attachment) {
    setDownloadError(false)
    let content: Blob
    try {
      content = await gateway.getAttachmentContent(attachment.id)
    } catch {
      setDownloadError(true)
      return
    }
    const url = URL.createObjectURL(content)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = attachment.fileName
    anchor.click()
    URL.revokeObjectURL(url)
  }

  async function remove() {
    try {
      await gateway.deleteFlash(id)
      void navigate('/flashes')
    } catch (failure) {
      setDeleteError(gatewayMessage(failure, t('flashes.deleteFailed')))
    }
  }

  if (error !== null) {
    return (
      <>
        <ScreenTitle>{error}</ScreenTitle>
        <Link component={RouterLink} to="/flashes">
          {t('flashes.back')}
        </Link>
      </>
    )
  }
  if (flash === null) return null

  return (
    <>
      <ScreenTitle>{flash.title}</ScreenTitle>
      <Box sx={{ mb: 2, color: colors.textSecondary, fontSize: 14 }}>
        {t('flashes.sentOn', { date: formatSent(flash.createdAt) })}
      </Box>
      <Link component={RouterLink} to="/flashes" sx={{ display: 'inline-block', mb: 2 }}>
        {t('flashes.back')}
      </Link>
      <Panel>
        <Box sx={{ p: 2 }}>
          <SectionHeading>{t('flashes.recipientsHeading')}</SectionHeading>
          {flash.relatedCompanies.map((company) => (
            <Box key={company.id}>{company.name}</Box>
          ))}
          <SectionHeading>{t('flashes.contentHeading')}</SectionHeading>
          <Box>{t('flashes.type', { type: flash.type })}</Box>
          <Box>{t('flashes.company', { company: flash.company })}</Box>
          <SafeHtml html={flash.description} />
          {flash.links.length > 0 && (
            <>
              <SectionHeading>{t('flashes.linksHeading')}</SectionHeading>
              {flash.links.map((href) => (
                <Box key={href}>
                  <Link href={href} target="_blank" rel="noopener noreferrer">
                    {href}
                  </Link>
                </Box>
              ))}
            </>
          )}
          {flash.attachments.length > 0 && (
            <>
              <SectionHeading>{t('flashes.attachmentHeading')}</SectionHeading>
              {downloadError && (
                <Alert severity="error" sx={{ mb: 1 }}>
                  {t('flashes.downloadFailed')}
                </Alert>
              )}
              {flash.attachments.map((attachment) => (
                <Box key={attachment.id}>
                  <Button
                    onClick={() => {
                      void download(attachment)
                    }}
                  >
                    {attachment.fileName}
                  </Button>
                </Box>
              ))}
            </>
          )}
          {flash.sendByEmail && <Box sx={{ mt: 2 }}>{t('flashes.emailCopy')}</Box>}
          <Box sx={{ mt: 2 }}>
            <Button
              variant="outlined"
              color="error"
              onClick={() => {
                setDeleteError(null)
                setConfirming(true)
              }}
            >
              {t('common.delete')}
            </Button>
          </Box>
        </Box>
      </Panel>
      <Dialog
        open={confirming}
        onClose={() => {
          setConfirming(false)
        }}
      >
        <DialogTitle>{t('flashes.deleteTitle')}</DialogTitle>
        <DialogContent>
          {deleteError !== null && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {deleteError}
            </Alert>
          )}
          <Box>{t('flashes.deleteQuestion')}</Box>
          <Box sx={{ fontWeight: 700 }}>{t('flashes.deleteWarning')}</Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setConfirming(false)
            }}
          >
            {t('common.cancel')}
          </Button>
          <Button
            onClick={() => {
              void remove()
            }}
          >
            {t('common.yes')}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}
