import { describe, expect, it } from 'vitest'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { FlashesScreen } from './FlashesScreen'

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen() {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/flashes']}>
          <Routes>
            <Route path="flashes" element={<FlashesScreen />} />
            <Route path="*" element={<Location />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

function bodyRows() {
  return screen.getAllByRole('row').slice(1)
}

function rowCells(index: number) {
  const row = bodyRows()[index]
  if (!row) throw new Error(`No row ${String(index)}`)
  return cells(row)
}

function cells(row: HTMLElement) {
  return within(row)
    .getAllByRole('cell')
    .map((cell) => cell.textContent)
}

describe('FlashesScreen', () => {
  it('shows the heading, controls, columns and rows newest first', async () => {
    renderScreen()
    expect(screen.getByRole('heading', { name: 'Flashes' })).toBeInTheDocument()
    expect(screen.getByPlaceholderText('Search flashes')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Send a flash' })).toBeInTheDocument()
    await screen.findByText('LVMH Q3 revenue ahead of consensus')
    expect(screen.getAllByRole('columnheader').map((header) => header.textContent)).toEqual([
      'Sent',
      'Recipients',
      'Company',
      'Title',
      'Type',
    ])
    const rows = bodyRows()
    expect(rows).toHaveLength(5)
    const first = rowCells(0)
    expect(first[0]).toMatch(/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)
    expect(first.slice(1)).toEqual([
      '1 company',
      'LVMH',
      'LVMH Q3 revenue ahead of consensus',
      'Breaking News',
    ])
    const third = rowCells(2)
    expect(third[1]).toBe('2 companies')
    expect(third[2]).toBe('Kering')
    expect(rowCells(4)[3]).toBe('Peer report: hospitality')
  })

  it('searches after the debounce, and clearing shows all again', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH Q3 revenue ahead of consensus')
    await user.type(screen.getByPlaceholderText('Search flashes'), 'luxury')
    await waitFor(() => {
      expect(bodyRows()).toHaveLength(1)
    })
    expect(screen.getByText('Pre-opening: European luxury sector')).toBeInTheDocument()
    await user.clear(screen.getByPlaceholderText('Search flashes'))
    await waitFor(() => {
      expect(bodyRows()).toHaveLength(5)
    })
  })

  it('shows the empty state', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH Q3 revenue ahead of consensus')
    await user.type(screen.getByPlaceholderText('Search flashes'), 'zzzz')
    expect(await screen.findByText('No flashes found.')).toBeInTheDocument()
  })

  it('pages 20 at a time and requests the next page', async () => {
    const pages: string[] = []
    server.use(
      http.get('*/api-admin/flashs', ({ request }) => {
        const page = new URL(request.url).searchParams.get('page') ?? ''
        pages.push(page)
        return HttpResponse.json({
          content: [],
          totalElements: 45,
          totalPages: 3,
          number: Number(page),
          size: 20,
        })
      }),
    )
    const user = userEvent.setup()
    renderScreen()
    expect(await screen.findByText('1–20 of 45')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /next page/i }))
    await waitFor(() => {
      expect(pages).toEqual(['0', '1'])
    })
  })

  it('opens the detail on a row click and compose on the button', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(await screen.findByText('Danone shares up 2.4% in early trade'))
    expect(screen.getByTestId('location')).toHaveTextContent('/flashes/f2')
  })

  it('goes to compose from the button', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(screen.getByRole('button', { name: 'Send a flash' }))
    expect(screen.getByTestId('location')).toHaveTextContent('/flashes/new')
  })
})
