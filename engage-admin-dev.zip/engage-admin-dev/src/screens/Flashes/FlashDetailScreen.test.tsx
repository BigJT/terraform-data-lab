import { describe, expect, it, vi } from 'vitest'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { FlashDetailScreen } from './FlashDetailScreen'

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen(id: string) {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/flashes/${id}`]}>
          <Routes>
            <Route path="flashes/:id" element={<FlashDetailScreen />} />
            <Route path="*" element={<Location />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

describe('FlashDetailScreen', () => {
  it('shows the sections for a flash with links and an email note', async () => {
    renderScreen('f1')
    expect(
      await screen.findByRole('heading', { name: 'LVMH Q3 revenue ahead of consensus' }),
    ).toBeInTheDocument()
    expect(screen.getByText(/^Sent \d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Back to flashes' })).toHaveAttribute(
      'href',
      '/flashes',
    )
    for (const heading of ['RECIPIENTS', 'CONTENT', 'RELATED LINKS:']) {
      expect(screen.getByText(heading)).toBeInTheDocument()
    }
    expect(screen.queryByText('ATTACHMENT')).not.toBeInTheDocument()
    expect(screen.getByText('Type: Breaking News')).toBeInTheDocument()
    expect(screen.getByText('Company: LVMH')).toBeInTheDocument()
    expect(screen.getByText(/ahead of the 1% consensus/)).toBeInTheDocument()
    const link = screen.getByRole('link', { name: 'https://www.lvmh.com/investors' })
    expect(link).toHaveAttribute('target', '_blank')
    expect(link).toHaveAttribute('rel', 'noopener noreferrer')
    expect(screen.getByText('Duplicate sent by email')).toBeInTheDocument()
  })

  it('lists every recipient and an attachment, and hides empty sections', async () => {
    renderScreen('f3')
    await screen.findByRole('heading', { name: 'Pre-opening: European luxury sector' })
    expect(screen.getByText('LVMH')).toBeInTheDocument()
    expect(screen.getByText('Kering')).toBeInTheDocument()
    expect(screen.queryByText('RELATED LINKS:')).not.toBeInTheDocument()
    expect(screen.getByText('ATTACHMENT')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'luxury-preopen.pdf' })).toBeInTheDocument()
    expect(screen.queryByText('Duplicate sent by email')).not.toBeInTheDocument()
  })

  it('shows "Flash not found" on a 404', async () => {
    renderScreen('missing')
    expect(await screen.findByText('Flash not found')).toBeInTheDocument()
  })

  it('downloads an attachment through an object URL and revokes it', async () => {
    const create = vi.fn(() => 'blob:test')
    const revoke = vi.fn()
    Object.assign(URL, { createObjectURL: create, revokeObjectURL: revoke })
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => undefined)
    renderScreen('f3')
    await userEvent.click(await screen.findByRole('button', { name: 'luxury-preopen.pdf' }))
    await waitFor(() => {
      expect(revoke).toHaveBeenCalledWith('blob:test')
    })
    expect(create).toHaveBeenCalledOnce()
    expect(click).toHaveBeenCalledOnce()
    click.mockRestore()
  })

  it.each([404, 500])(
    'shows an error when the attachment download fails with %i',
    async (status) => {
      server.use(http.get('*/api/attachment/:id/content', () => new HttpResponse(null, { status })))
      renderScreen('f3')
      await userEvent.click(await screen.findByRole('button', { name: 'luxury-preopen.pdf' }))
      expect(await screen.findByRole('alert')).toHaveTextContent(
        'The attachment could not be downloaded. Try again later.',
      )
    },
  )

  it('removes scripts and event attributes from the message but keeps formatting', async () => {
    server.use(
      http.get('*/api-admin/flashs/f2', () =>
        HttpResponse.json({
          id: 'f2',
          title: 'Unsafe',
          company: 'Danone',
          type: 'Price movement',
          description:
            '<p><strong>Bold</strong><script>window.hacked=1</script><img src="x" onerror="window.hacked=1"></p>',
          links: [],
          sendByEmail: false,
          relatedCompanies: [],
          attachments: [],
          createdAt: '2026-10-11T15:20:00Z',
        }),
      ),
    )
    const { container } = renderScreen('f2')
    await screen.findByRole('heading', { name: 'Unsafe' })
    expect(screen.getByText('Bold').tagName).toBe('STRONG')
    expect(container.querySelector('script')).toBeNull()
    expect(container.querySelector('img')?.hasAttribute('onerror')).toBe(false)
  })

  it('Cancel closes the delete dialog and keeps the flash', async () => {
    renderScreen('f1')
    await userEvent.click(await screen.findByRole('button', { name: 'Delete' }))
    expect(screen.getByRole('dialog', { name: 'Delete flash' })).toBeInTheDocument()
    expect(screen.getByText('Are you sure you want to delete?')).toBeInTheDocument()
    expect(screen.getByText('This action cannot be undone')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(screen.queryByTestId('location')).not.toBeInTheDocument()
  })

  it('Yes deletes the flash and returns to the list', async () => {
    let deleted = false
    server.use(
      http.delete('*/api-admin/flashs/f1', () => {
        deleted = true
        return new HttpResponse(null, { status: 200 })
      }),
    )
    renderScreen('f1')
    await userEvent.click(await screen.findByRole('button', { name: 'Delete' }))
    await userEvent.click(screen.getByRole('button', { name: 'Yes' }))
    expect(await screen.findByTestId('location')).toHaveTextContent('/flashes')
    expect(deleted).toBe(true)
  })

  it('shows the error inside the dialog when delete fails', async () => {
    server.use(
      http.delete('*/api-admin/flashs/f1', () =>
        HttpResponse.json({ message: 'Cannot delete right now' }, { status: 500 }),
      ),
    )
    renderScreen('f1')
    await userEvent.click(await screen.findByRole('button', { name: 'Delete' }))
    await userEvent.click(screen.getByRole('button', { name: 'Yes' }))
    expect(await screen.findByRole('alert')).toHaveTextContent('Cannot delete right now')
    expect(screen.getByRole('dialog', { name: 'Delete flash' })).toBeInTheDocument()
  })
})
