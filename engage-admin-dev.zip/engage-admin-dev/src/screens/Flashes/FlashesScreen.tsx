import {
  Alert,
  Box,
  Button,
  InputBase,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TablePagination,
} from '@mui/material'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { FlashPage } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { formatSent } from './formatSent'

const columns = ['sent', 'recipients', 'company', 'title', 'type']
const pageSize = 20
export function FlashesScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [search, setSearch] = useState('')
  const [query, setQuery] = useState('')
  const [page, setPage] = useState(0)
  const [result, setResult] = useState<FlashPage | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (search === query) return
    const timer = setTimeout(() => {
      setQuery(search)
      setPage(0)
    }, 300)
    return () => {
      clearTimeout(timer)
    }
  }, [search, query])

  useEffect(() => {
    let current = true
    gateway.listFlashes({ q: query, page, size: pageSize }).then(
      (loaded) => {
        if (!current) return
        setResult(loaded)
        setError(null)
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, t('flashes.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, query, page, t])

  const rows = result?.content ?? []

  return (
    <>
      <ScreenTitle>{t('shell.flashes')}</ScreenTitle>
      <Panel>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2 }}>
          <InputBase
            placeholder={t('flashes.search')}
            value={search}
            onChange={(event) => {
              setSearch(event.target.value)
            }}
            inputProps={{ 'aria-label': t('flashes.search') }}
            sx={{ flex: 1, px: 1.5, height: 32, border: `1px solid ${colors.rule}`, fontSize: 14 }}
          />
          <Button
            variant="contained"
            onClick={() => {
              void navigate('/flashes/new')
            }}
          >
            {t('flashes.send')}
          </Button>
        </Box>
        {error !== null && (
          <Alert severity="error" sx={{ mx: 2, mb: 2 }}>
            {error}
          </Alert>
        )}
        <Table size="small">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column} sx={{ fontWeight: 600 }}>
                  {t(`flashes.columns.${column}`)}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((flash) => (
              <TableRow
                key={flash.id}
                hover
                onClick={() => {
                  void navigate(`/flashes/${flash.id}`)
                }}
                sx={{ cursor: 'pointer' }}
              >
                <TableCell>{formatSent(flash.createdAt)}</TableCell>
                <TableCell>
                  {t('flashes.recipientCount', { count: flash.relatedCompanyCount })}
                </TableCell>
                <TableCell>{flash.company}</TableCell>
                <TableCell>{flash.title}</TableCell>
                <TableCell>{flash.type}</TableCell>
              </TableRow>
            ))}
            {result !== null && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={columns.length} sx={{ color: colors.textSecondary }}>
                  {t('flashes.empty')}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={result?.totalElements ?? 0}
          page={page}
          rowsPerPage={pageSize}
          rowsPerPageOptions={[]}
          onPageChange={(_event, next) => {
            setPage(next)
          }}
        />
      </Panel>
    </>
  )
}
