import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  MenuItem,
  TextField,
} from '@mui/material'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { useTranslation } from 'react-i18next'
import { AttachmentPicker, Panel, RichTextEditor, isRichTextEmpty } from '@/ds/components'
import { colors } from '@/ds/theme'
import { useGateway } from '@/data/gatewayContext'
import type { CompanySummary } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'

type Field = 'recipients' | 'title' | 'value' | 'type' | 'description'
type Errors = Partial<Record<Field, string>>

function SectionHeading({ children }: { children: string }) {
  return (
    <Box sx={{ mt: 2, mb: 1, fontSize: 12, fontWeight: 600, color: colors.textSecondary }}>
      {children}
    </Box>
  )
}

export function SendFlashScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [companies, setCompanies] = useState<CompanySummary[]>([])
  const [types, setTypes] = useState<string[]>([])
  const [sendToAll, setSendToAll] = useState(false)
  const [recipients, setRecipients] = useState<CompanySummary[]>([])
  const [title, setTitle] = useState('')
  const [value, setValue] = useState('')
  const [type, setType] = useState('')
  const [description, setDescription] = useState('')
  const [links, setLinks] = useState('')
  const [files, setFiles] = useState<File[]>([])
  const [sendByEmail, setSendByEmail] = useState(false)
  const [errors, setErrors] = useState<Errors>({})
  const [sendError, setSendError] = useState(false)
  const [sending, setSending] = useState(false)

  useEffect(() => {
    let current = true
    gateway.listCompanies().then(
      (loaded) => {
        if (current) setCompanies(loaded.filter((company) => !company.isArchived))
      },
      () => undefined,
    )
    gateway.listFlashTypes().then(
      (loaded) => {
        if (current) setTypes(loaded)
      },
      () => undefined,
    )
    return () => {
      current = false
    }
  }, [gateway])

  function clearError(field: Field) {
    setErrors((current) => ({ ...current, [field]: undefined }))
  }

  async function send() {
    setSendError(false)
    const found: Errors = {}
    if (!sendToAll && recipients.length === 0)
      found.recipients = t('flashes.compose.recipientRequired')
    if (!title.trim()) found.title = t('flashes.compose.subjectRequired')
    if (!value.trim()) found.value = t('flashes.compose.companyRequired')
    if (!type) found.type = t('flashes.compose.typeRequired')
    if (isRichTextEmpty(description)) found.description = t('flashes.compose.messageRequired')
    setErrors(found)
    if (Object.keys(found).length > 0) return
    setSending(true)
    try {
      const created = await gateway.createFlash(
        {
          title,
          value,
          description,
          type,
          links: links
            .split('\n')
            .map((line) => line.trim())
            .filter((line) => line !== ''),
          emittersUUID: sendToAll ? [] : recipients.map((company) => company.id),
          sendByEmail,
          sendToAll,
        },
        files,
      )
      void navigate(`/flashes/${created.id}`)
    } catch {
      setSendError(true)
      setSending(false)
    }
  }

  return (
    <>
      <ScreenTitle>{t('flashes.send')}</ScreenTitle>
      {sendError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {t('flashes.compose.sendFailed')}
        </Alert>
      )}
      <Panel>
        <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <SectionHeading>{t('flashes.compose.recipients')}</SectionHeading>
          <FormControlLabel
            control={
              <Checkbox
                checked={sendToAll}
                onChange={(event) => {
                  setSendToAll(event.target.checked)
                  if (event.target.checked) clearError('recipients')
                }}
              />
            }
            label={t('flashes.compose.sendToAll')}
          />
          <Autocomplete
            multiple
            options={companies}
            value={recipients}
            disabled={sendToAll}
            getOptionLabel={(company) => company.name}
            isOptionEqualToValue={(option, chosen) => option.id === chosen.id}
            onChange={(_event, chosen) => {
              setRecipients(chosen)
              clearError('recipients')
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                label={t('flashes.compose.companies')}
                placeholder={t('flashes.compose.searchCompanies')}
                error={Boolean(errors.recipients)}
                helperText={errors.recipients}
              />
            )}
          />
          <SectionHeading>{t('flashes.compose.content')}</SectionHeading>
          <TextField
            label={t('flashes.compose.subject')}
            value={title}
            onChange={(event) => {
              setTitle(event.target.value)
              clearError('title')
            }}
            error={Boolean(errors.title)}
            helperText={errors.title}
          />
          <TextField
            label={t('flashes.compose.company')}
            value={value}
            onChange={(event) => {
              setValue(event.target.value)
              clearError('value')
            }}
            error={Boolean(errors.value)}
            helperText={errors.value}
          />
          <TextField
            select
            label={t('flashes.compose.type')}
            value={type}
            onChange={(event) => {
              setType(event.target.value)
              clearError('type')
            }}
            error={Boolean(errors.type)}
            helperText={errors.type}
          >
            {types.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </TextField>
          <RichTextEditor
            label={t('flashes.compose.message')}
            value={description}
            onChange={(html) => {
              setDescription(html)
              if (!isRichTextEmpty(html)) clearError('description')
            }}
            toolbar="full"
            error={errors.description}
          />
          <TextField
            label={t('flashes.compose.links')}
            placeholder={t('flashes.compose.linksHint')}
            multiline
            minRows={3}
            value={links}
            onChange={(event) => {
              setLinks(event.target.value)
            }}
          />
          <AttachmentPicker
            label={t('flashes.compose.attachment')}
            files={files}
            onChange={setFiles}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={sendByEmail}
                onChange={(event) => {
                  setSendByEmail(event.target.checked)
                }}
              />
            }
            label={t('flashes.compose.alsoEmail')}
          />
          <Box>
            <Button
              variant="contained"
              disabled={sending}
              onClick={() => {
                void send()
              }}
            >
              {t('flashes.compose.submit')}
            </Button>
          </Box>
        </Box>
      </Panel>
    </>
  )
}
