import { describe, expect, it } from 'vitest'
import { availableIndices } from './indexOptions'
import type { IndexInfo } from '@/data/types'

const all: IndexInfo[] = [
  { codeRIC: 'A', name: 'a', type: 'national' },
  { codeRIC: 'B', name: 'b', type: 'sector' },
  { codeRIC: 'C', name: 'c', type: 'national' },
]

describe('availableIndices', () => {
  it('keeps everything when nothing is chosen', () => {
    expect(availableIndices(all, [null, null, null, null], 0).map((i) => i.codeRIC)).toEqual([
      'A',
      'B',
      'C',
    ])
  })

  it('removes indices chosen in the other slots', () => {
    expect(availableIndices(all, ['A', 'B', null, null], 2).map((i) => i.codeRIC)).toEqual(['C'])
  })

  it('keeps the slot own choice', () => {
    expect(availableIndices(all, ['A', 'B', null, null], 0).map((i) => i.codeRIC)).toEqual([
      'A',
      'C',
    ])
  })
})
