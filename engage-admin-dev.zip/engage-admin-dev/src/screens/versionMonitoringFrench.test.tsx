import { describe, expect, it } from 'vitest'
import { screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { setLanguage } from '@/i18n'
import { VersionScreen } from '@/screens/Version/VersionScreen'
import { MonitoringScreen } from '@/screens/Monitoring/MonitoringScreen'
import userEvent from '@testing-library/user-event'
import type { ReactElement } from 'react'

function renderFrench(screenElement: ReactElement) {
  setLanguage('fr')
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter>{screenElement}</MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

describe('version and monitoring in French', () => {
  it('version: labels, format error and the toast', async () => {
    const user = renderFrench(<VersionScreen />)
    expect(await screen.findByText('Version actuelle')).toBeInTheDocument()
    expect(
      screen.getByRole('checkbox', { name: "Forcer l'utilisateur à mettre à jour l'application" }),
    ).toBeInTheDocument()
    const field = screen.getByRole('textbox', { name: 'Saisissez la nouvelle version :' })
    await user.type(field, 'abc')
    await user.click(screen.getByRole('button', { name: 'Envoyer' }))
    expect(await screen.findByText('Le format doit être X.X.X')).toBeInTheDocument()
    await user.clear(field)
    await user.type(field, '9.9.9')
    await user.click(screen.getByRole('button', { name: 'Envoyer' }))
    expect(await screen.findByText('Version ajoutée avec succès')).toBeInTheDocument()
  })

  it('monitoring: headings, columns, reasons, platforms and summary', async () => {
    renderFrench(<MonitoringScreen />)
    expect(
      screen.getByRole('heading', { level: 1, name: 'Monitoring des déconnexions' }),
    ).toBeInTheDocument()
    expect(screen.getByRole('combobox', { name: "Période d'analyse :" })).toHaveTextContent(
      '7 jours',
    )
    expect(screen.getByRole('button', { name: 'Actualiser' })).toBeInTheDocument()
    expect(screen.getByText("Vue d'ensemble")).toBeInTheDocument()
    expect(screen.getByText('Analyses')).toBeInTheDocument()
    expect(screen.getByText('Tous les logs de déconnexion')).toBeInTheDocument()
    expect(screen.getByText('Chargement des logs...')).toBeInTheDocument()
    expect(await screen.findByText(/logs au total • Page 1 sur/)).toBeInTheDocument()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Date',
      'Utilisateur',
      'Plateforme',
      'Raison',
      'Adresse IP',
      'Navigateur/Système',
      'Détails',
    ])
    expect(screen.getAllByText('Application bureau').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Application mobile').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Session expirée').length).toBeGreaterThan(0)
  })
})
