import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { VersionScreen } from './VersionScreen'

function renderVersion() {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter>
          <VersionScreen />
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

const field = () => screen.getByRole('textbox', { name: 'Enter the new version:' })
const send = () => screen.getByRole('button', { name: 'Send' })
const formatError = 'Format should be like this X.X.X'

describe('VersionScreen', () => {
  it('shows the heading, current version, empty field, unticked force box and Send', async () => {
    renderVersion()
    expect(screen.getByRole('heading', { level: 1, name: 'Version' })).toBeInTheDocument()
    expect(await screen.findByText('3.4.0')).toBeInTheDocument()
    expect(screen.getByText('Current version')).toBeInTheDocument()
    expect(field()).toHaveValue('')
    expect(
      screen.getByRole('checkbox', { name: 'Force users to update the application' }),
    ).not.toBeChecked()
    expect(send()).toBeEnabled()
  })

  it.each([null, ''])('shows "No version published yet" when the version is %j', async (value) => {
    server.use(
      http.get('*/api-admin/app-version', () =>
        HttpResponse.json({ version: value, forceUpdate: false }),
      ),
    )
    renderVersion()
    expect(await screen.findByText('No version published yet')).toBeInTheDocument()
  })

  it.each([['3.5'], ['abc'], ['']])('rejects "%s" and sends nothing', async (value) => {
    let posted = false
    server.use(
      http.post('*/api-admin/app-version', () => {
        posted = true
        return HttpResponse.json({}, { status: 200 })
      }),
    )
    const user = renderVersion()
    await screen.findByText('3.4.0')
    if (value) await user.type(field(), value)
    await user.click(send())
    expect(await screen.findByText(formatError)).toBeInTheDocument()
    expect(posted).toBe(false)
  })

  it('publishes, toasts, refreshes the current version and resets the form', async () => {
    let body: unknown
    const user = renderVersion()
    await screen.findByText('3.4.0')
    await user.type(field(), '3.5.0')
    await user.click(
      screen.getByRole('checkbox', { name: 'Force users to update the application' }),
    )
    server.use(
      http.post('*/api-admin/app-version', async ({ request }) => {
        body = await request.json()
        return HttpResponse.json({ version: '3.5.0', forceUpdate: true }, { status: 200 })
      }),
      http.get('*/api-admin/app-version', () =>
        HttpResponse.json({
          version: '3.5.0',
          forceUpdate: true,
          createdAt: '2026-10-12T10:00:00Z',
        }),
      ),
    )
    await user.click(send())
    expect(await screen.findByText('Version added successfully')).toBeInTheDocument()
    expect(body).toEqual({ version: '3.5.0', forceUpdate: true })
    expect(await screen.findByText('3.5.0')).toBeInTheDocument()
    expect(field()).toHaveValue('')
    expect(
      screen.getByRole('checkbox', { name: 'Force users to update the application' }),
    ).not.toBeChecked()
  })

  it('shows the duplicate message verbatim and keeps the current version', async () => {
    const user = renderVersion()
    await screen.findByText('3.4.0')
    await user.type(field(), '3.4.0')
    await user.click(send())
    expect(await screen.findByRole('alert')).toHaveTextContent('A version 3.4.0 already exists.')
    expect(screen.queryByText('Version added successfully')).not.toBeInTheDocument()
    expect(screen.getByText('3.4.0', { selector: 'strong' })).toBeInTheDocument()
  })

  it('disables Send while the request runs', async () => {
    let release: () => void = () => undefined
    const gate = new Promise<void>((resolve) => {
      release = resolve
    })
    server.use(
      http.post('*/api-admin/app-version', async () => {
        await gate
        return HttpResponse.json({ version: '3.6.0', forceUpdate: false }, { status: 200 })
      }),
    )
    const user = renderVersion()
    await screen.findByText('3.4.0')
    await user.type(field(), '3.6.0')
    await user.click(send())
    expect(send()).toBeDisabled()
    release()
    expect(await screen.findByText('Version added successfully')).toBeInTheDocument()
    await waitFor(() => {
      expect(send()).toBeEnabled()
    })
  })
})
