import { Alert, Box, Button, Checkbox, FormControlLabel, Snackbar, TextField } from '@mui/material'
import { useCallback, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import { ScreenTitle } from '@/screens/ScreenTitle'

const versionFormat = /^\d+\.\d+\.\d+$/

export function VersionScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [current, setCurrent] = useState<string | null>(null)
  const [loaded, setLoaded] = useState(false)
  const [version, setVersion] = useState('')
  const [force, setForce] = useState(false)
  const [formatError, setFormatError] = useState(false)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [toast, setToast] = useState(false)

  const load = useCallback(() => {
    return gateway.getAppVersion().then(
      (latest) => {
        setCurrent(latest.version === '' ? null : latest.version)
        setLoaded(true)
      },
      (failure: unknown) => {
        setError(gatewayMessage(failure, t('version.loadFailed')))
      },
    )
  }, [gateway, t])

  useEffect(() => {
    void load()
  }, [load])

  async function send() {
    setError('')
    if (!versionFormat.test(version)) {
      setFormatError(true)
      return
    }
    setFormatError(false)
    setSending(true)
    try {
      await gateway.publishAppVersion({ version, forceUpdate: force })
      setToast(true)
      setVersion('')
      setForce(false)
      await load()
    } catch (failure) {
      setError(gatewayMessage(failure, t('version.publishFailed')))
    } finally {
      setSending(false)
    }
  }

  return (
    <>
      <ScreenTitle>{t('shell.version')}</ScreenTitle>
      <Panel>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 480 }}>
          {loaded && (
            <Box sx={{ fontSize: 14, color: colors.textPrimary }}>
              {current === null ? (
                t('version.none')
              ) : (
                <>
                  {t('version.current')} <strong>{current}</strong>
                </>
              )}
            </Box>
          )}
          {error && <Alert severity="error">{error}</Alert>}
          <TextField
            label={t('version.enter')}
            value={version}
            error={formatError}
            helperText={formatError ? t('version.formatError') : undefined}
            onChange={(event) => {
              setVersion(event.target.value)
            }}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={force}
                onChange={(event) => {
                  setForce(event.target.checked)
                }}
              />
            }
            label={t('version.force')}
          />
          <Box>
            <Button
              variant="contained"
              disabled={sending}
              onClick={() => {
                void send()
              }}
            >
              {t('version.send')}
            </Button>
          </Box>
        </Box>
      </Panel>
      <Snackbar
        open={toast}
        autoHideDuration={4000}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        onClose={() => {
          setToast(false)
        }}
      >
        <Alert severity="success" variant="filled">
          {t('version.added')}
        </Alert>
      </Snackbar>
    </>
  )
}
