import type { ReactNode } from 'react'
import { describe, expect, it } from 'vitest'
import { act, screen } from '@testing-library/react'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthContext, type Auth } from '@/auth/authContext'
import { setLanguage } from '@/i18n'
import { SignInScreen } from '@/screens/SignIn/SignInScreen'
import { NoAccessScreen } from '@/screens/NoAccess/NoAccessScreen'
import { MockEntraSignInScreen } from '@/screens/MockEntraSignIn/MockEntraSignInScreen'
import { PlaceholderScreen } from '@/screens/Placeholder/PlaceholderScreen'

const auth: Auth = {
  status: 'signedOut',
  name: null,
  roles: [],
  getToken: () => Promise.resolve(''),
  signIn: () => Promise.resolve(),
  signOut: () => undefined,
  onAuthError: () => undefined,
}

function renderSignedOut(ui: ReactNode) {
  return renderWithTheme(<AuthContext.Provider value={auth}>{ui}</AuthContext.Provider>)
}

describe('screens outside the shell in French', () => {
  it('sign-in page', () => {
    renderSignedOut(<SignInScreen />)
    act(() => {
      setLanguage('fr')
    })
    expect(screen.getByRole('button', { name: 'Se connecter avec Microsoft' })).toBeInTheDocument()
    expect(screen.getByRole('heading', { name: 'Engage Admin' })).toBeInTheDocument()
  })

  it('no-access page', () => {
    renderSignedOut(<NoAccessScreen />)
    act(() => {
      setLanguage('fr')
    })
    expect(screen.getByText("Vous n'avez pas accès à Engage Admin.")).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Se déconnecter' })).toBeInTheDocument()
  })

  it('stand-in sign-in page keeps the account names', () => {
    renderSignedOut(<MockEntraSignInScreen />)
    act(() => {
      setLanguage('fr')
    })
    expect(screen.getByRole('heading', { name: 'Connexion Microsoft simulée' })).toBeInTheDocument()
    expect(
      screen.getByText(
        "Choisissez un compte. Cette page remplace Microsoft en attendant la configuration d'un tenant Entra.",
      ),
    ).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Admin User' })).toBeInTheDocument()
  })

  it('placeholder', () => {
    renderSignedOut(<PlaceholderScreen titleKey="shell.reports" />)
    act(() => {
      setLanguage('fr')
    })
    expect(screen.getByRole('heading', { name: 'Rapports' })).toBeInTheDocument()
    expect(screen.getByText('Bientôt disponible')).toBeInTheDocument()
  })
})
