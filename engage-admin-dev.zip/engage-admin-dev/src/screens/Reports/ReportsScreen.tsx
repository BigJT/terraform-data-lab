import {
  Alert,
  Box,
  InputBase,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tabs,
} from '@mui/material'
import { DatePicker } from '@mui/x-date-pickers/DatePicker'
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider'
import dayjs from 'dayjs'
import { useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useNavigate, useSearchParams } from 'react-router'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { MarketReportSummary, ReportSummary, WorkStatus } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'

type Tab = 'companies' | 'markets'
interface Row {
  id: string
  label: string
  ric: string
  updatedAt: string
  status: WorkStatus
  sent: boolean
  sentAt?: string | null
}

const validation: Record<WorkStatus, { key: string; color: string }> = {
  todo: { key: 'reports.validationTodo', color: colors.textSecondary },
  doing: { key: 'reports.validationDoing', color: colors.amber },
  done: { key: 'reports.validationDone', color: colors.green },
}

function toRow(report: ReportSummary | MarketReportSummary): Row {
  const company = 'companyName' in report ? report : null
  return {
    id: report.id,
    label: company?.companyName ?? ('languageName' in report ? report.languageName : ''),
    ric: company?.ric ?? '',
    updatedAt: report.updatedAt,
    status: report.validation.status,
    sent: report.sent,
    sentAt: company?.sentAt,
  }
}

export function ReportsScreen() {
  const { t, i18n } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [params, setParams] = useSearchParams()
  const today = dayjs().format('YYYY-MM-DD')
  const tab: Tab = params.get('tab') === 'markets' ? 'markets' : 'companies'
  const parsed = dayjs(params.get('date') ?? '', 'YYYY-MM-DD', true)
  const date = parsed.isValid() ? parsed.format('YYYY-MM-DD') : today
  const isToday = date === today
  const [loaded, setLoaded] = useState<{ key: string; rows: Row[] } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const key = `${tab}|${date}`

  useEffect(() => {
    let current = true
    const argument = isToday ? null : date
    const request =
      tab === 'companies' ? gateway.listReports(argument) : gateway.listMarketReports(argument)
    request.then(
      (reports) => {
        if (!current) return
        setError(null)
        setLoaded({ key, rows: reports.map(toRow) })
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, t('reports.listLoadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, tab, date, isToday, key, t])

  const rows = useMemo(() => {
    if (loaded?.key !== key) return []
    const needle = search.trim().toLowerCase()
    const matching = loaded.rows.filter((row) =>
      `${row.label}\n${row.ric}`.toLowerCase().includes(needle),
    )
    return tab === 'companies' ? matching.sort((a, b) => a.label.localeCompare(b.label)) : matching
  }, [loaded, key, search, tab])

  const update = (changes: Record<string, string>) => {
    const next = new URLSearchParams(params)
    for (const [name, value] of Object.entries(changes)) next.set(name, value)
    setParams(next)
  }

  const dateLine = dayjs(date).format('dddd D MMMM YYYY')
  const n = rows.length
  const columns = [
    tab === 'companies' ? t('reports.columnCompanies', { n }) : t('reports.columnLanguage', { n }),
    t('reports.columnLastModified'),
    t('reports.columnValidation'),
    t('reports.columnStatus'),
  ]
  const open = (row: Row) => {
    void navigate(tab === 'companies' ? `/reports/${row.id}` : `/reports/market/${row.id}`)
  }

  return (
    <>
      <ScreenTitle>{t('reports.title')}</ScreenTitle>
      <Panel>
        <Tabs
          value={tab}
          onChange={(_event, value: Tab) => {
            update({ tab: value })
          }}
          sx={{ borderBottom: `1px solid ${colors.rule}` }}
        >
          <Tab value="companies" label={t('reports.tabCompanies')} />
          <Tab value="markets" label={t('reports.tabMarkets')} />
        </Tabs>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2 }}>
          <Box sx={{ fontSize: 16, fontWeight: 600, color: colors.textPrimary, minWidth: 280 }}>
            {isToday ? t('reports.today', { date: dateLine }) : dateLine}
          </Box>
          <LocalizationProvider dateAdapter={AdapterDayjs} adapterLocale={i18n.resolvedLanguage}>
            <DatePicker
              label={t('reports.date')}
              format="DD/MM/YYYY"
              value={dayjs(date)}
              onChange={(value) => {
                if (value?.isValid()) update({ date: value.format('YYYY-MM-DD') })
              }}
              slotProps={{ textField: { size: 'small' } }}
            />
          </LocalizationProvider>
          <InputBase
            placeholder={t('reports.search')}
            value={search}
            onChange={(event) => {
              setSearch(event.target.value)
            }}
            inputProps={{ 'aria-label': t('reports.search') }}
            sx={{ flex: 1, px: 1.5, height: 32, border: `1px solid ${colors.rule}`, fontSize: 14 }}
          />
        </Box>
        {error !== null && (
          <Alert severity="error" sx={{ mx: 2, mb: 2 }}>
            {error}
          </Alert>
        )}
        <Table size="small">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column} sx={{ fontWeight: 600 }}>
                  {column}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => {
              const status = validation[row.status]
              return (
                <TableRow
                  key={row.id}
                  hover
                  onClick={() => {
                    open(row)
                  }}
                  sx={{ cursor: 'pointer' }}
                >
                  <TableCell>{row.label}</TableCell>
                  <TableCell>{dayjs(row.updatedAt).format('DD/MM/YYYY HH:mm')}</TableCell>
                  <TableCell sx={{ color: status.color }}>{t(status.key)}</TableCell>
                  <TableCell sx={row.sent ? { color: colors.green } : undefined}>
                    {!row.sent
                      ? t('reports.toSend')
                      : row.sentAt
                        ? t('reports.sentAtMark', { time: dayjs(row.sentAt).format('HH:mm') })
                        : t('reports.sentMark')}
                  </TableCell>
                </TableRow>
              )
            })}
            {loaded?.key === key && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={columns.length} sx={{ color: colors.textSecondary }}>
                  {t('reports.empty')}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Panel>
    </>
  )
}
