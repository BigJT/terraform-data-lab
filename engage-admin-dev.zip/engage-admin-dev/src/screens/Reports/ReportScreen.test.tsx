import { afterEach, beforeAll, describe, expect, it } from 'vitest'
import { cleanup, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import dayjs from 'dayjs'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import type { ReportDetail } from '@/data/types'
import { db, emptyReport } from '@/mocks/fixtures'
import { ReportScreen } from './ReportScreen'

const today = dayjs().format('YYYY-MM-DD')

function renderScreen(id: string) {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/reports/${id}`]}>
          <Routes>
            <Route path="reports/:id" element={<ReportScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

// Unmounting releases the lock with a request; let it finish so it cannot land in the next test.
let inFlight = 0
beforeAll(() => {
  server.events.on('request:start', () => {
    inFlight += 1
  })
  server.events.on('request:end', () => {
    inFlight -= 1
  })
})
afterEach(async () => {
  cleanup()
  await waitFor(() => {
    expect(inFlight).toBe(0)
  })
})

describe('ReportScreen', () => {
  it('shows the layout, market block and company details for an editable report', async () => {
    renderScreen(`r-c4-${today}`)
    expect(await screen.findByRole('heading', { level: 1, name: 'Write a report' })).toBeVisible()
    expect(screen.getAllByText('Accor').length).toBeGreaterThan(0)
    expect(screen.getByRole('link', { name: 'Back to reports' })).toHaveAttribute(
      'href',
      `/reports?tab=companies&date=${today}`,
    )
    for (const title of ['COMPANY', 'SECTOR', 'CUSTOM CONTENT 1', 'CUSTOM CONTENT 2', 'MARKET']) {
      expect(screen.getByText(title)).toBeVisible()
    }
    expect(screen.getAllByText('Enter your analysis here')).toHaveLength(2)
    expect(screen.getByRole('link', { name: 'View' })).toHaveAttribute(
      'href',
      expect.stringMatching(/^\/reports\/market\/m-fr-FR-/),
    )
    expect(screen.getByText('European markets closed higher, led by luxury stocks.')).toBeVisible()
    expect(screen.getByRole('heading', { name: /company details/i })).toBeVisible()
    expect(await screen.findByText('ACCP.PA')).toBeVisible()
    expect(screen.getByText('Euronext Paris')).toBeVisible()
    expect(screen.getByText('Hospitality')).toBeVisible()
    expect(screen.getAllByText('French').length).toBeGreaterThan(1)
    expect(screen.queryByText(/^Sent at/)).not.toBeInTheDocument()
  })

  it('shows the company details from the company, with the sector before "/"', async () => {
    renderScreen(`r-c1-${today}`)
    expect(await screen.findByText('LVMH.PA')).toBeVisible()
    expect(screen.getByText('Luxury')).toBeVisible()
    expect(screen.queryByText('Luxury/Fashion')).not.toBeInTheDocument()
  })

  it('says there is no market report when its content is empty', async () => {
    renderScreen(`r-c5-${today}`)
    expect(await screen.findByText('No market report yet.')).toBeVisible()
  })

  it('shows "Sent at HH:mm" and sanitised HTML for a sent report', async () => {
    renderScreen(`r-c1-${today}`)
    expect(await screen.findByText('Sent at 07:45')).toBeVisible()
    expect(screen.getByText('Desk note').tagName).toBe('STRONG')
    expect(document.querySelector('script')).toBeNull()
    expect(screen.queryByText('Enter your analysis here')).not.toBeInTheDocument()
  })

  it('is read-only with no sent caption for a past report', async () => {
    const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
    db.reports.push({ ...emptyReport('c4', 'fr-FR', past), id: 'r-past' })
    renderScreen('r-past')
    await screen.findByRole('heading', { name: 'Write a report' })
    expect(screen.getByRole('link', { name: 'Back to reports' })).toHaveAttribute(
      'href',
      `/reports?tab=companies&date=${past}`,
    )
    expect(screen.queryByText(/^Sent at/)).not.toBeInTheDocument()
    expect(screen.queryByText('Enter your analysis here')).not.toBeInTheDocument()
  })

  it('shows "Report not found" for an unknown id', async () => {
    renderScreen('nope')
    expect(await screen.findByText('Report not found')).toBeVisible()
  })

  describe('sign-off and send', () => {
    it('enables the action bar per status and disables the finished actions', async () => {
      renderScreen(`r-c4-${today}`)
      for (const name of ['Request validation', 'Validate content', 'Validate writing', 'Send']) {
        expect(await screen.findByRole('button', { name })).toBeEnabled()
      }
    })

    it('shows done actions as disabled labels', async () => {
      db.reports.push({
        ...emptyReport('c4', 'fr-FR', today),
        id: 'r-done',
        writingStatus: 'done',
        validation: { writing: 'done', content: 'done', status: 'done' },
      })
      renderScreen('r-done')
      expect(await screen.findByRole('button', { name: 'Request validation' })).toBeDisabled()
      expect(screen.getByRole('button', { name: 'Content validated' })).toBeDisabled()
      expect(screen.getByRole('button', { name: 'Writing validated' })).toBeDisabled()
    })

    it('calls each action and re-renders from the answer', async () => {
      const user = userEvent.setup()
      renderScreen(`r-c4-${today}`)
      await user.click(await screen.findByRole('button', { name: 'Request validation' }))
      await waitFor(() => {
        expect(screen.getByRole('button', { name: 'Request validation' })).toBeDisabled()
      })
      await user.click(screen.getByRole('button', { name: 'Validate content' }))
      expect(await screen.findByRole('button', { name: 'Content validated' })).toBeDisabled()
      await user.click(screen.getByRole('button', { name: 'Validate writing' }))
      expect(await screen.findByRole('button', { name: 'Writing validated' })).toBeDisabled()
    })

    it('hides the action bar for sent and past reports', async () => {
      renderScreen(`r-c1-${today}`)
      await screen.findByText(/^Sent at/)
      expect(screen.queryByRole('button', { name: 'Send' })).not.toBeInTheDocument()
    })

    it('warns when unvalidated, cancel sends nothing, Yes sends', async () => {
      const user = userEvent.setup()
      let sends = 0
      server.use(
        http.put('*/api-admin/reports/:id/sent', () => {
          sends += 1
          return undefined
        }),
      )
      renderScreen(`r-c5-${today}`)
      await user.click(await screen.findByRole('button', { name: 'Send' }))
      expect(screen.getByRole('dialog', { name: 'Send the report' })).toBeVisible()
      expect(
        screen.getByText('The report content and writing have not been validated.'),
      ).toBeVisible()
      expect(screen.getByText('Are you sure you want to send the report to Diageo?')).toBeVisible()
      await user.click(screen.getByRole('button', { name: 'Cancel' }))
      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
      })
      expect(sends).toBe(0)
      await user.click(screen.getByRole('button', { name: 'Send' }))
      await user.click(screen.getByRole('button', { name: 'Yes' }))
      expect(await screen.findByText(/^Sent at \d\d:\d\d$/)).toBeVisible()
      expect(await screen.findByRole('button', { name: 'Edit' })).toBeVisible()
      expect(screen.queryByRole('button', { name: 'Send' })).not.toBeInTheDocument()
      expect(screen.queryByText('Enter your analysis here')).not.toBeInTheDocument()
    })

    it('omits the warning when writing is done', async () => {
      const user = userEvent.setup()
      db.reports.push({ ...emptyReport('c4', 'fr-FR', today), id: 'r-w', writingStatus: 'done' })
      renderScreen('r-w')
      await user.click(await screen.findByRole('button', { name: 'Send' }))
      expect(screen.getByText('Are you sure you want to send the report to Accor?')).toBeVisible()
      expect(screen.queryByText(/have not been validated/)).not.toBeInTheDocument()
    })
  })

  describe('edit a sent report', () => {
    it('edits, saves via saveReportContent only and returns to read-only', async () => {
      const user = userEvent.setup()
      const puts: string[] = []
      server.use(
        http.put('*/api-admin/reports/:id/:action*', ({ request }) => {
          puts.push(new URL(request.url).pathname)
          return undefined
        }),
      )
      renderScreen(`r-c1-${today}`)
      expect(screen.queryByRole('button', { name: 'Save' })).not.toBeInTheDocument()
      await user.click(await screen.findByRole('button', { name: 'Edit' }))
      expect(screen.queryByRole('button', { name: 'Edit' })).not.toBeInTheDocument()
      expect(screen.getByRole('textbox', { name: 'SECTOR' })).toBeVisible()
      await user.click(screen.getByRole('button', { name: 'Save' }))
      expect(screen.getByRole('dialog', { name: 'Save the report' })).toBeVisible()
      expect(
        screen.getByText('Are you sure you want to save the changes to the report for LVMH?'),
      ).toBeVisible()
      await user.click(screen.getByRole('button', { name: 'Yes' }))
      expect(await screen.findByText('Sent at 07:45')).toBeVisible()
      expect(await screen.findByText('Luxury names traded higher across Europe.')).toBeVisible()
      expect(screen.queryByRole('textbox', { name: 'SECTOR' })).not.toBeInTheDocument()
      expect(puts).toEqual([`/api-admin/reports/r-c1-${today}/content`])
    })

    it('cancel in the save dialog saves nothing', async () => {
      const user = userEvent.setup()
      renderScreen(`r-c1-${today}`)
      await user.click(await screen.findByRole('button', { name: 'Edit' }))
      await user.click(screen.getByRole('button', { name: 'Save' }))
      await user.click(screen.getByRole('button', { name: 'Cancel' }))
      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
      })
      expect(screen.getByRole('button', { name: 'Save' })).toBeVisible()
    })

    it('never shows Edit on a past report', async () => {
      const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
      db.reports.push({ ...emptyReport('c4', 'fr-FR', past), id: 'r-past2', sent: true })
      renderScreen('r-past2')
      await screen.findByRole('heading', { name: 'Write a report' })
      expect(screen.queryByRole('button', { name: 'Edit' })).not.toBeInTheDocument()
    })
  })
  describe('editing lock', () => {
    function spyLocks() {
      const calls: string[] = []
      server.use(
        http.put('*/api-admin/reports/:id/lock', ({ params }) => {
          calls.push(`lock ${String(params.id)}`)
          return undefined
        }),
        http.put('*/api-admin/reports/:id/unlock', ({ params }) => {
          calls.push(`unlock ${String(params.id)}`)
          return undefined
        }),
      )
      return calls
    }

    it('locks an unlocked today report on open and unlocks on unmount', async () => {
      const calls = spyLocks()
      const view = renderScreen(`r-c4-${today}`)
      await screen.findByRole('button', { name: 'Send' })
      await waitFor(() => {
        expect(calls).toEqual([`lock r-c4-${today}`])
      })
      view.unmount()
      await waitFor(() => {
        expect(calls).toEqual([`lock r-c4-${today}`, `unlock r-c4-${today}`])
      })
    })

    it('unlocks on pagehide', async () => {
      const calls = spyLocks()
      renderScreen(`r-c4-${today}`)
      await screen.findByRole('button', { name: 'Send' })
      window.dispatchEvent(new Event('pagehide'))
      await waitFor(() => {
        expect(calls).toContain(`unlock r-c4-${today}`)
      })
    })

    it('opens without asking when the lock is already held by the caller', async () => {
      db.reports.push({
        ...emptyReport('c4', 'fr-FR', today),
        id: 'r-mine',
        lockedBy: 'Local Admin',
      })
      renderScreen('r-mine')
      expect(await screen.findByRole('button', { name: 'Send' })).toBeEnabled()
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })

    it('asks before taking over a lock held by someone else, and Cancel stays read-only', async () => {
      const user = userEvent.setup()
      const calls = spyLocks()
      const view = renderScreen(`r-c3-${today}`)
      const dialog = await screen.findByRole('dialog', { name: 'CONTENT BEING WRITTEN' })
      expect(dialog).toHaveTextContent(
        'The report is being written by jean.martin@rothschildandco.com',
      )
      expect(dialog).toHaveTextContent('Do you want to unlock access to this report?')
      await user.click(screen.getByRole('button', { name: 'Cancel' }))
      await waitFor(() => {
        expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
      })
      expect(screen.queryByRole('button', { name: 'Send' })).not.toBeInTheDocument()
      expect(screen.queryByText('Enter your analysis here')).not.toBeInTheDocument()
      expect(screen.getByText('Kering slipped 0.8%.')).toBeVisible()
      view.unmount()
      expect(calls).toEqual([])
    })

    it('Yes takes the lock and makes the report editable', async () => {
      const user = userEvent.setup()
      const calls = spyLocks()
      renderScreen(`r-c3-${today}`)
      await screen.findByRole('dialog', { name: 'CONTENT BEING WRITTEN' })
      expect(calls).toEqual([])
      await user.click(screen.getByRole('button', { name: 'Yes' }))
      expect(await screen.findByRole('button', { name: 'Send' })).toBeVisible()
      expect(calls).toEqual([`lock r-c3-${today}`])
    })

    it('releases a taken-over lock when the screen closes before the lock answers', async () => {
      const user = userEvent.setup()
      const calls = spyLocks()
      server.use(
        http.put('*/api-admin/reports/:id/lock', async ({ params }) => {
          calls.push(`lock ${String(params.id)}`)
          await new Promise((resolve) => setTimeout(resolve, 100))
          return undefined
        }),
      )
      const view = renderScreen(`r-c3-${today}`)
      await screen.findByRole('dialog', { name: 'CONTENT BEING WRITTEN' })
      await user.click(screen.getByRole('button', { name: 'Yes' }))
      view.unmount()
      await waitFor(() => {
        expect(calls).toEqual([`lock r-c3-${today}`, `unlock r-c3-${today}`])
      })
    })

    it('stays read-only with an alert, and sends no unlock, when the lock fails', async () => {
      const calls = spyLocks()
      server.use(
        http.put('*/api-admin/reports/:id/lock', ({ params }) => {
          calls.push(`lock ${String(params.id)}`)
          return new Response(null, { status: 500 })
        }),
      )
      const view = renderScreen(`r-c4-${today}`)
      expect(
        await screen.findByText('This report could not be opened for editing. Try again later.'),
      ).toBeVisible()
      expect(screen.queryByRole('button', { name: 'Send' })).not.toBeInTheDocument()
      expect(screen.queryByText('Enter your analysis here')).not.toBeInTheDocument()
      view.unmount()
      expect(calls).toEqual([`lock r-c4-${today}`])
    })

    it('never locks or unlocks sent or past reports', async () => {
      const calls = spyLocks()
      const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
      db.reports.push({ ...emptyReport('c4', 'fr-FR', past), id: 'r-past' })
      const sent = renderScreen(`r-c1-${today}`)
      await screen.findByText(/^Sent at/)
      sent.unmount()
      const old = renderScreen('r-past')
      await screen.findByRole('heading', { name: 'Write a report' })
      old.unmount()
      expect(calls).toEqual([])
    })
  })
})

describe('short positions chart', () => {
  const png = () => new File(['x'], 'accor.png', { type: 'image/png' })
  const jpeg = () => new File(['y'], 'accor.jpg', { type: 'image/jpeg' })
  const pdf = () => new File(['z'], 'accor.pdf', { type: 'application/pdf' })
  const upload = (file: File) =>
    userEvent.setup({ applyAccept: false }).upload(screen.getByLabelText('Chart file'), file)

  // jsdom's FormData drops file names on the wire, so the stand-in reports the name the test sent.
  const nameUploads = (names: string[]) => {
    server.use(
      http.post('*/api-admin/reports/:id/graph-position', async ({ request, params }) => {
        const row = db.reports.find((candidate) => candidate.id === params.id)
        if (row)
          row.graphPosition = {
            id: 'g1',
            fileName: names.shift() ?? '',
            contentType: 'image/png',
            size: 1,
          }
        const origin = new URL(request.url).origin
        const detail = (await (
          await fetch(`${origin}/api-admin/reports/byId/${String(params.id)}`)
        ).json()) as ReportDetail
        return HttpResponse.json(detail)
      }),
    )
  }

  it('adds, replaces and removes the chart on an editable report', async () => {
    const user = userEvent.setup()
    nameUploads(['accor.png', 'accor.jpg'])
    renderScreen(`r-c4-${today}`)
    expect(await screen.findByText('SHORT POSITIONS')).toBeVisible()
    expect(screen.queryByRole('button', { name: 'Replace' })).not.toBeInTheDocument()
    expect(screen.getByLabelText('Chart file')).toHaveAttribute('accept', 'image/png,image/jpeg')
    await user.click(screen.getByRole('button', { name: 'Add chart' }))
    await upload(png())
    expect(await screen.findByText('accor.png')).toBeVisible()
    expect(screen.queryByRole('button', { name: 'Add chart' })).not.toBeInTheDocument()
    await upload(jpeg())
    expect(await screen.findByText('accor.jpg')).toBeVisible()
    await user.click(screen.getByRole('button', { name: 'Remove' }))
    expect(await screen.findByRole('button', { name: 'Add chart' })).toBeVisible()
  })

  it('refuses a non-image file without sending anything', async () => {
    let posts = 0
    server.use(
      http.post('*/api-admin/reports/:id/graph-position', () => {
        posts += 1
        return undefined
      }),
    )
    renderScreen(`r-c4-${today}`)
    await screen.findByText('SHORT POSITIONS')
    await upload(pdf())
    expect(await screen.findByText('Choose a PNG or JPEG image.')).toBeVisible()
    expect(posts).toBe(0)
  })

  it('shows the gateway message when the upload fails', async () => {
    server.use(
      http.post('*/api-admin/reports/:id/graph-position', () =>
        HttpResponse.json({ message: 'Chart too large' }, { status: 400 }),
      ),
    )
    renderScreen(`r-c4-${today}`)
    await screen.findByText('SHORT POSITIONS')
    await upload(png())
    expect(await screen.findByText('Chart too large')).toBeVisible()
  })

  it('shows the file name or "No chart." read-only, and buttons only in Edit mode', async () => {
    const user = userEvent.setup()
    const sent = db.reports.find((row) => row.id === `r-c1-${today}`)
    expect(sent).toBeDefined()
    renderScreen(`r-c1-${today}`)
    expect(await screen.findByText('SHORT POSITIONS')).toBeVisible()
    expect(screen.getByText('No chart.')).toBeVisible()
    expect(screen.queryByRole('button', { name: 'Add chart' })).not.toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Edit' }))
    expect(screen.getByRole('button', { name: 'Add chart' })).toBeVisible()
    expect(screen.queryByText('No chart.')).not.toBeInTheDocument()
  })

  it('shows "No chart." and no buttons on a past report', async () => {
    const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
    db.reports.push({ ...emptyReport('c4', 'fr-FR', past), id: 'r-past-chart' })
    renderScreen('r-past-chart')
    expect(await screen.findByText('No chart.')).toBeVisible()
    expect(screen.queryByRole('button', { name: 'Add chart' })).not.toBeInTheDocument()
  })
})

describe('economic statistics', () => {
  it("lists the day's statistics under the market block", async () => {
    renderScreen(`r-c4-${today}`)
    expect(await screen.findByText('ECONOMIC STATISTICS')).toBeVisible()
    for (const name of [
      'Zone',
      'Country',
      'Indicator',
      'Period',
      'Actual',
      'Expected',
      'Previous',
      'Released',
    ]) {
      expect(await screen.findByRole('columnheader', { name })).toBeVisible()
    }
    const rows = await screen.findAllByRole('row')
    expect(rows).toHaveLength(4)
    expect(rows[1]).toHaveTextContent('EuropeFranceCPI (YoY)Sep1.2%1.3%1.4%08:45')
    expect(rows[3]).toHaveTextContent('AmericasUnited StatesRetail Sales (MoM)Sep0.4%0.3%0.1%14:30')
  })

  it('is shown on a sent report without editing', async () => {
    renderScreen(`r-c1-${today}`)
    expect(await screen.findByText('Retail Sales (MoM)')).toBeVisible()
  })

  it('says there are none for another day', async () => {
    const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
    db.reports.push({ ...emptyReport('c4', 'fr-FR', past), id: 'r-past-stats' })
    renderScreen('r-past-stats')
    expect(await screen.findByText('No statistics for this day.')).toBeVisible()
  })

  it('says the statistics could not be loaded on failure', async () => {
    server.use(
      http.get('*/api-admin/reports/statistics/economic', () =>
        HttpResponse.json({ message: 'boom' }, { status: 500 }),
      ),
    )
    renderScreen(`r-c4-${today}`)
    expect(await screen.findByText('The statistics could not be loaded.')).toBeVisible()
    expect(screen.getByText('MARKET')).toBeVisible()
  })
})
