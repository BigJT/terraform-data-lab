import dayjs from 'dayjs'

export type ReportMode = 'past' | 'sent' | 'editable'

/** The report's day: the local `YYYY-MM-DD` of its `createdAt`. */
export function reportDate(createdAt: string): string {
  return dayjs(createdAt).format('YYYY-MM-DD')
}

export function reportMode(
  report: { createdAt: string; sent: boolean },
  today: string,
): ReportMode {
  if (dayjs(reportDate(report.createdAt)).isBefore(dayjs(today), 'day')) return 'past'
  return report.sent ? 'sent' : 'editable'
}
