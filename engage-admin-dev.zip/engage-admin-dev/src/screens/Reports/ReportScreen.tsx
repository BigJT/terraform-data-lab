import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Link,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material'
import dayjs from 'dayjs'
import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { Link as RouterLink, useParams } from 'react-router'
import { Panel, RichTextEditor, SafeHtml } from '@/ds/components'
import { colors } from '@/ds/theme'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { CompanyDetail, EconomicStatistic, ReportContent, ReportDetail } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { LastSaved } from './LastSavedLine'
import { ReportActionBar } from './ReportActionBar'
import { reportDate, reportMode } from './reportMode'
import { useAutoSave } from './useAutoSave'
import { useActionRunner } from './useActionRunner'
import { useReportLock } from './useReportLock'

const languageKeys = { 'fr-FR': 'reports.languageFr', 'en-EN': 'reports.languageEn' } as const

function Heading({ children }: { children: ReactNode }) {
  return (
    <Box sx={{ fontSize: 12, fontWeight: 600, color: colors.textSecondary, mb: 0.5 }}>
      {children}
    </Box>
  )
}

function Block({ title, html }: { title: string; html: string }) {
  return (
    <Box sx={{ mb: 3 }}>
      <Heading>{title}</Heading>
      <Box sx={{ fontSize: 14, color: colors.textPrimary }}>
        <SafeHtml html={html} />
      </Box>
    </Box>
  )
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <>
      <Box component="dt" sx={{ color: colors.textSecondary, fontSize: 14 }}>
        {label}
      </Box>
      <Box component="dd" sx={{ m: 0, color: colors.textPrimary, fontSize: 14 }}>
        {value}
      </Box>
    </>
  )
}

function ChartBlock({
  chart,
  canEdit,
  error,
  onPick,
  onRemove,
}: {
  chart: ReportDetail['graphPosition']
  canEdit: boolean
  error: string
  onPick: (file: File) => void
  onRemove: () => void
}) {
  const { t } = useTranslation()
  const input = useRef<HTMLInputElement>(null)
  return (
    <Box sx={{ mb: 3 }}>
      <Heading>{t('reports.headingShortPositions')}</Heading>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, fontSize: 14 }}>
        {chart || !canEdit ? (
          <Box sx={{ color: colors.textPrimary }}>
            {chart ? chart.fileName : t('reports.noChart')}
          </Box>
        ) : null}
        {canEdit ? (
          <>
            <input
              ref={input}
              type="file"
              hidden
              aria-label={t('reports.chartFile')}
              accept="image/png,image/jpeg"
              onChange={(event) => {
                const file = event.target.files?.[0]
                event.target.value = ''
                if (file) onPick(file)
              }}
            />
            <Button
              variant="outlined"
              size="small"
              onClick={() => {
                input.current?.click()
              }}
            >
              {chart ? t('reports.replaceChart') : t('reports.addChart')}
            </Button>
            {chart ? (
              <Button variant="outlined" size="small" onClick={onRemove}>
                {t('common.remove')}
              </Button>
            ) : null}
          </>
        ) : null}
      </Box>
      {error ? <Box sx={{ mt: 0.5, fontSize: 14, color: colors.red }}>{error}</Box> : null}
    </Box>
  )
}

const statisticColumns = [
  ['reports.statZone', 'zone'],
  ['reports.statCountry', 'country'],
  ['reports.statIndicator', 'object'],
  ['reports.statPeriod', 'period'],
  ['reports.statActual', 'actual'],
  ['reports.statExpected', 'expected'],
  ['reports.statPrevious', 'previous'],
  ['reports.statReleased', 'released'],
] as const

function StatisticsPanel({ date }: { date: string }) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [state, setState] = useState<{
    date: string
    rows?: EconomicStatistic[]
    failed?: boolean
  } | null>(null)
  useEffect(() => {
    let current = true
    gateway.listEconomicStatistics(date).then(
      (rows) => {
        if (current) setState({ date, rows })
      },
      () => {
        if (current) setState({ date, failed: true })
      },
    )
    return () => {
      current = false
    }
  }, [gateway, date])
  const loaded = state?.date === date ? state : null
  return (
    <Panel heading={t('reports.statistics')} sx={{ mt: 3 }}>
      {!loaded ? null : loaded.failed ? (
        <Box sx={{ p: 2, fontSize: 14, color: colors.red }}>{t('reports.statisticsFailed')}</Box>
      ) : loaded.rows?.length ? (
        <Table size="small">
          <TableHead>
            <TableRow>
              {statisticColumns.map(([label]) => (
                <TableCell key={label}>{t(label)}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {loaded.rows.map((row, index) => (
              <TableRow key={index}>
                {statisticColumns.map(([label, key]) => (
                  <TableCell key={label}>{row[key]}</TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      ) : (
        <Box sx={{ p: 2, fontSize: 14, color: colors.textPrimary }}>
          {t('reports.statisticsEmpty')}
        </Box>
      )}
    </Panel>
  )
}

export function ReportScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const { id = '' } = useParams()
  const [result, setResult] = useState<{
    id: string
    report?: ReportDetail
    error?: string
  } | null>(null)
  const [updatedAt, setUpdatedAt] = useState('')
  const [editing, setEditing] = useState(false)
  const [dialog, setDialog] = useState<'send' | 'save' | null>(null)
  const content = useRef<ReportContent | null>(null)
  const blurPending = useRef(new Set<keyof ReportContent>())
  const report = result?.id === id ? result.report : undefined
  const mode = report ? reportMode(report, dayjs().format('YYYY-MM-DD')) : undefined
  const flushRef = useRef<() => Promise<void>>(() => Promise.resolve())
  const lock = useReportLock({
    report,
    editable: mode === 'editable',
    lock: gateway.lockReport,
    // Leaving saves first, so the unlock never beats the last edit.
    unlock: (reportId) => flushRef.current().then(() => gateway.unlockReport(reportId)),
  })
  const editable = mode === 'editable' && lock.access === 'held'
  const showEditors = editable || (mode === 'sent' && editing)

  const save = useCallback(
    (values: ReportContent) =>
      gateway.saveReportContent(id, values).then((saved) => {
        setUpdatedAt((shown) => (saved.updatedAt > shown ? saved.updatedAt : shown))
      }),
    [gateway, id],
  )
  const autoSave = useAutoSave<ReportContent>({ enabled: editable, save })
  useEffect(() => {
    flushRef.current = autoSave.flush
  }, [autoSave.flush])

  useEffect(() => {
    let current = true
    gateway.getReport(id).then(
      (report) => {
        if (!current) return
        content.current = {
          sector: report.sector,
          value: report.value,
          customContent1: report.customContent1,
          customContent2: report.customContent2,
        }
        blurPending.current.clear()
        setUpdatedAt(report.updatedAt)
        setResult({ id, report })
      },
      (failure: unknown) => {
        if (!current) return
        const error =
          failure instanceof GatewayError && failure.status === 404
            ? t('reports.notFound')
            : gatewayMessage(failure, t('reports.loadFailed'))
        setResult({ id, error })
      },
    )
    return () => {
      current = false
    }
  }, [gateway, id, t])

  const emitterId = report?.emitterId
  const [company, setCompany] = useState<CompanyDetail | null>(null)
  useEffect(() => {
    if (!emitterId) return
    let current = true
    gateway.getCompany(emitterId).then(
      (loaded) => {
        if (current) setCompany(loaded)
      },
      () => undefined,
    )
    return () => {
      current = false
    }
  }, [gateway, emitterId])
  const details = company?.id === emitterId ? company : null

  // COMPANY and SECTOR start the 3 s countdown on every edit; the custom boxes only when they lose focus (leaving saves either way).
  const change = (field: keyof ReportContent, html: string, onBlurOnly = false) => {
    if (!content.current) return
    content.current = { ...content.current, [field]: html }
    if (onBlurOnly) blurPending.current.add(field)
    autoSave.change(content.current, html, !onBlurOnly)
  }
  const blur = (field: keyof ReportContent) => {
    if (!content.current || !blurPending.current.delete(field)) return
    autoSave.change(content.current, content.current[field])
  }

  // Keep what the admin has typed over the server copy, which may lag the 3 s auto-save.
  const apply = (detail: ReportDetail) => {
    setUpdatedAt(detail.updatedAt)
    setResult({ id, report: { ...detail, ...content.current } })
  }
  const { run, error: actionError } = useActionRunner(apply)
  const act = (action: (id: string) => Promise<ReportDetail>) => {
    run(() => action(id), t('reports.actionFailed'))
  }
  const [chartMessage, setChartMessage] = useState('')
  const { run: runChart, error: chartError } = useActionRunner(apply)
  const pickChart = (file: File) => {
    if (file.type !== 'image/png' && file.type !== 'image/jpeg') {
      setChartMessage(t('reports.chartType'))
      return
    }
    setChartMessage('')
    runChart(() => gateway.attachReportChart(id, file), t('reports.chartSaveFailed'))
  }
  const removeChart = () => {
    setChartMessage('')
    runChart(() => gateway.removeReportChart(id), t('reports.chartRemoveFailed'))
  }
  const confirm = () => {
    const which = dialog
    setDialog(null)
    const values = content.current
    if (!values) return
    if (which === 'send') {
      // Flush typing still waiting for auto-save, so the sent report has it.
      run(
        () => gateway.saveReportContent(id, values).then(() => gateway.sendReport(id)),
        t('reports.sendFailed'),
      )
    } else if (which === 'save') {
      run(
        () => gateway.saveReportContent(id, values),
        t('reports.saveFailed'),
        () => {
          setEditing(false)
        },
      )
    }
  }

  if (result?.id !== id) return null
  if (result.error) return <Alert severity="error">{result.error}</Alert>
  if (!report) return null

  const market = report.marketContent ?? ''
  const date = reportDate(report.createdAt)

  return (
    <>
      <ScreenTitle>{t('reports.writeReport')}</ScreenTitle>
      <Box sx={{ fontSize: 18, fontWeight: 600, color: colors.textPrimary, mb: 1 }}>
        {report.companyName}
      </Box>
      <Link
        component={RouterLink}
        to={`/reports?tab=companies&date=${date}`}
        sx={{ display: 'inline-block', mb: 2, fontSize: 14 }}
      >
        {t('reports.back')}
      </Link>
      {actionError || lock.error ? (
        <Alert severity="error" sx={{ mb: 2 }}>
          {actionError || lock.error}
        </Alert>
      ) : null}
      {editable && updatedAt ? <LastSaved key={updatedAt} updatedAt={updatedAt} /> : null}
      {mode === 'sent' && report.sentAt ? (
        <Box sx={{ mb: 2, fontSize: 14, color: colors.green }}>
          {t('reports.sentAt', { time: dayjs(report.sentAt).format('HH:mm') })}
        </Box>
      ) : null}
      {editable ? (
        <ReportActionBar
          status={report}
          actions={{
            requestValidation: () => {
              act(gateway.requestReportValidation)
            },
            validateContent: () => {
              act(gateway.validateReportContent)
            },
            validateAnalysis: () => {
              act(gateway.validateReportAnalysis)
            },
            send: () => {
              setDialog('send')
            },
          }}
        />
      ) : null}
      {mode === 'sent' && !editing ? (
        <Button
          variant="outlined"
          sx={{ mb: 2 }}
          onClick={() => {
            setEditing(true)
          }}
        >
          {t('reports.edit')}
        </Button>
      ) : null}
      <Box sx={{ display: 'flex', gap: 3, alignItems: 'flex-start' }}>
        <Box sx={{ flex: 7, minWidth: 0 }}>
          {showEditors ? (
            <>
              {editable && autoSave.failed ? (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {t('reports.autoSaveFailed')}
                </Alert>
              ) : null}
              <RichTextEditor
                label={t('reports.headingCompany')}
                toolbar="basic"
                placeholder={t('reports.placeholder')}
                value={report.value}
                onChange={(html) => {
                  change('value', html)
                }}
              />
              <RichTextEditor
                label={t('reports.headingSector')}
                toolbar="basic"
                placeholder={t('reports.placeholder')}
                value={report.sector}
                onChange={(html) => {
                  change('sector', html)
                }}
              />
              <RichTextEditor
                label="CUSTOM CONTENT 1"
                toolbar="full"
                value={report.customContent1}
                onChange={(html) => {
                  change('customContent1', html, true)
                }}
                onBlur={() => {
                  blur('customContent1')
                }}
              />
              <RichTextEditor
                label="CUSTOM CONTENT 2"
                toolbar="full"
                value={report.customContent2}
                onChange={(html) => {
                  change('customContent2', html, true)
                }}
                onBlur={() => {
                  blur('customContent2')
                }}
              />
            </>
          ) : (
            <>
              <Block title={t('reports.headingCompany')} html={report.value} />
              <Block title={t('reports.headingSector')} html={report.sector} />
              <Block title="CUSTOM CONTENT 1" html={report.customContent1} />
              <Block title="CUSTOM CONTENT 2" html={report.customContent2} />
            </>
          )}
          <ChartBlock
            chart={report.graphPosition}
            canEdit={showEditors}
            error={chartMessage || chartError}
            onPick={pickChart}
            onRemove={removeChart}
          />
          <Box sx={{ mb: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 2, mb: 0.5 }}>
              <Heading>{t('reports.headingMarket')}</Heading>
              <Box sx={{ fontSize: 14, color: colors.textPrimary }}>
                {t(languageKeys[report.languageCode])}
              </Box>
              {report.marketReportId ? (
                <Link
                  component={RouterLink}
                  to={`/reports/market/${report.marketReportId}`}
                  sx={{ fontSize: 14 }}
                >
                  {t('reports.view')}
                </Link>
              ) : null}
            </Box>
            <Box sx={{ fontSize: 14, color: colors.textPrimary }}>
              {market === '' ? t('reports.noMarketReport') : <SafeHtml html={market} />}
            </Box>
          </Box>
        </Box>
        <Panel heading={t('reports.companyDetails')} sx={{ flex: 3, minWidth: 0 }}>
          <Box
            component="dl"
            sx={{ m: 0, p: 2, display: 'grid', gridTemplateColumns: '90px 1fr', rowGap: 1.5 }}
          >
            <Detail label={t('reports.detailName')} value={details?.name ?? ''} />
            <Detail label={t('reports.detailRic')} value={details?.ric ?? ''} />
            <Detail label={t('reports.detailMarket')} value={details?.market.fullName ?? ''} />
            <Detail label={t('reports.detailSector')} value={details?.sector.split('/')[0] ?? ''} />
            <Detail
              label={t('reports.detailLanguage')}
              value={details ? t(languageKeys[details.languageCode]) : ''}
            />
          </Box>
        </Panel>
      </Box>
      <StatisticsPanel date={date} />
      {mode === 'sent' && editing ? (
        <Button
          variant="contained"
          onClick={() => {
            setDialog('save')
          }}
        >
          {t('reports.save')}
        </Button>
      ) : null}
      <Dialog open={mode === 'editable' && lock.access === 'prompt'} aria-labelledby="lock-title">
        <DialogTitle id="lock-title">{t('reports.lockTitle')}</DialogTitle>
        <DialogContent>
          <Box>{t('reports.lockedBy', { name: report.lockedBy })}</Box>
          <Box>{t('reports.lockQuestion')}</Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={lock.cancel}>{t('common.cancel')}</Button>
          <Button variant="contained" onClick={lock.takeOver}>
            {t('common.yes')}
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={dialog !== null}
        onClose={() => {
          setDialog(null)
        }}
        aria-labelledby="report-dialog-title"
      >
        <DialogTitle id="report-dialog-title">
          {dialog === 'save' ? t('reports.saveTitle') : t('reports.sendTitle')}
        </DialogTitle>
        <DialogContent>
          {dialog === 'send' && report.writingStatus !== 'done' ? (
            <Box>{t('reports.notValidated')}</Box>
          ) : null}
          <Box>
            {dialog === 'save'
              ? t('reports.confirmSave', { company: report.companyName })
              : t('reports.confirmSend', { company: report.companyName })}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setDialog(null)
            }}
          >
            {t('common.cancel')}
          </Button>
          <Button variant="contained" onClick={confirm}>
            {t('common.yes')}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}
