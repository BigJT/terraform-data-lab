import { Box } from '@mui/material'
import { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { lastSavedCaption } from './lastSaved'

export function LastSaved({ updatedAt }: { updatedAt: string }) {
  const { t } = useTranslation()
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date())
    }, 30_000)
    return () => {
      clearInterval(timer)
    }
  }, [])
  return (
    <Box sx={{ mb: 2, fontSize: 14, color: colors.textSecondary }}>
      {lastSavedCaption(updatedAt, now, t)}
    </Box>
  )
}
