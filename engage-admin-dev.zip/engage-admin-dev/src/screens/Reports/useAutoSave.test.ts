import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { act, renderHook } from '@testing-library/react'
import { useAutoSave } from './useAutoSave'

interface Values {
  a: string
  b: string
}

function setup(
  enabled = true,
  save = vi.fn<(values: Values) => Promise<void>>(() => Promise.resolve()),
) {
  const hook = renderHook(() => useAutoSave<Values>({ enabled, save }))
  return { hook, save }
}

describe('useAutoSave', () => {
  beforeEach(() => {
    vi.useFakeTimers()
  })
  afterEach(() => {
    vi.useRealTimers()
  })

  it('saves once, 3000 ms after the last of several changes, with the latest values', async () => {
    const { hook, save } = setup()
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(2000))
    act(() => {
      hook.result.current.change({ a: '<p>12</p>', b: '' }, '<p>12</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(2999))
    expect(save).not.toHaveBeenCalled()
    await act(() => vi.advanceTimersByTimeAsync(1))
    expect(save).toHaveBeenCalledTimes(1)
    expect(save).toHaveBeenCalledWith({ a: '<p>12</p>', b: '' })
  })

  it('never saves when disabled', async () => {
    const { hook, save } = setup(false)
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(5000))
    expect(save).not.toHaveBeenCalled()
  })

  it('does not save for a blanked box, but sends the blank with the next save', async () => {
    const { hook, save } = setup()
    act(() => {
      hook.result.current.change({ a: '<p></p>', b: '<p>old</p>' }, '<p></p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(5000))
    expect(save).not.toHaveBeenCalled()
    act(() => {
      hook.result.current.change({ a: '<p></p>', b: '<p>new</p>' }, '<p>new</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(3000))
    expect(save).toHaveBeenCalledWith({ a: '<p></p>', b: '<p>new</p>' })
  })

  it('reports a failure, retries on the next change and clears it on success', async () => {
    const save = vi
      .fn<(values: Values) => Promise<void>>(() => Promise.resolve())
      .mockRejectedValueOnce(new Error('down'))
    const { hook } = setup(true, save)
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(3000))
    expect(hook.result.current.failed).toBe(true)
    act(() => {
      hook.result.current.change({ a: '<p>2</p>', b: '' }, '<p>2</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(3000))
    expect(save).toHaveBeenCalledTimes(2)
    expect(hook.result.current.failed).toBe(false)
  })

  it('saves pending values on unmount', () => {
    const { hook, save } = setup()
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    hook.unmount()
    expect(save).toHaveBeenCalledTimes(1)
    expect(save).toHaveBeenCalledWith({ a: '<p>1</p>', b: '' })
  })

  it('saves pending values on pagehide', () => {
    const { hook, save } = setup()
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    window.dispatchEvent(new Event('pagehide'))
    expect(save).toHaveBeenCalledWith({ a: '<p>1</p>', b: '' })
    hook.unmount()
    expect(save).toHaveBeenCalledTimes(1)
  })

  it('saves an unscheduled change (custom box not yet blurred) on unmount', () => {
    const { hook, save } = setup()
    act(() => {
      hook.result.current.change({ a: '', b: '<p>typed</p>' }, '<p>typed</p>', false)
    })
    hook.unmount()
    expect(save).toHaveBeenCalledWith({ a: '', b: '<p>typed</p>' })
  })

  it('does not save again on unmount once the timer has saved', async () => {
    const { hook, save } = setup()
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    await act(() => vi.advanceTimersByTimeAsync(3000))
    hook.unmount()
    expect(save).toHaveBeenCalledTimes(1)
  })

  it('does not save on unmount when disabled, nothing changed, or only blanked', () => {
    const off = setup(false)
    act(() => {
      off.hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    off.hook.unmount()
    expect(off.save).not.toHaveBeenCalled()
    const idle = setup()
    idle.hook.unmount()
    expect(idle.save).not.toHaveBeenCalled()
    const blank = setup()
    act(() => {
      blank.hook.result.current.change({ a: '<p></p>', b: '<p>old</p>' }, '<p></p>')
    })
    blank.hook.unmount()
    expect(blank.save).not.toHaveBeenCalled()
  })

  it('flush resolves only after the save finishes', async () => {
    let finish: () => void = () => undefined
    const save = vi.fn<(values: Values) => Promise<void>>(
      () =>
        new Promise<void>((resolve) => {
          finish = resolve
        }),
    )
    const { hook } = setup(true, save)
    act(() => {
      hook.result.current.change({ a: '<p>1</p>', b: '' }, '<p>1</p>')
    })
    let done = false
    void hook.result.current.flush().then(() => {
      done = true
    })
    await act(() => Promise.resolve())
    expect(done).toBe(false)
    finish()
    await act(() => Promise.resolve())
    expect(done).toBe(true)
  })
})
