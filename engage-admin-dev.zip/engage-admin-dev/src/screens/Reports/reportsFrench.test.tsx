import { afterEach, beforeAll, describe, expect, it } from 'vitest'
import { cleanup, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import dayjs from 'dayjs'
import { MemoryRouter, Route, Routes } from 'react-router'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { setLanguage } from '@/i18n'
import { MarketReportScreen } from './MarketReportScreen'
import { ReportScreen } from './ReportScreen'
import { ReportsScreen } from './ReportsScreen'

const today = dayjs().format('YYYY-MM-DD')

function renderFrench(path: string) {
  setLanguage('fr')
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[path]}>
          <Routes>
            <Route path="reports" element={<ReportsScreen />} />
            <Route path="reports/market/:id" element={<MarketReportScreen />} />
            <Route path="reports/:id" element={<ReportScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

let inFlight = 0
beforeAll(() => {
  server.events.on('request:start', () => {
    inFlight += 1
  })
  server.events.on('request:end', () => {
    inFlight -= 1
  })
})
afterEach(async () => {
  cleanup()
  await waitFor(() => {
    expect(inFlight).toBe(0)
  })
})

describe('reports screens in French', () => {
  it('list: tabs, date line, search, columns and states', async () => {
    renderFrench('/reports')
    await screen.findByText('LVMH')
    expect(screen.getByRole('heading', { level: 1, name: 'Rapports' })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: 'Valeurs', selected: true })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: 'Marchés' })).toBeInTheDocument()
    expect(
      screen.getByText(`Aujourd'hui (${dayjs().locale('fr').format('dddd D MMMM YYYY')})`),
    ).toBeInTheDocument()
    expect(screen.getByPlaceholderText('Rechercher un rapport')).toBeInTheDocument()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Valeurs (5)',
      'Dernière modification',
      'Validation',
      'Statut',
    ])
    expect(screen.getAllByText('À envoyer').length).toBeGreaterThan(0)
    expect(screen.getAllByText(/^✓ Envoyé à \d\d:\d\d$/).length).toBeGreaterThan(0)
  })

  it('list: markets tab and an empty past day', async () => {
    const user = renderFrench('/reports')
    await screen.findByText('LVMH')
    await user.click(screen.getByRole('tab', { name: 'Marchés' }))
    expect(await screen.findByRole('columnheader', { name: 'Langue (2)' })).toBeInTheDocument()
    expect(screen.getByText('French')).toBeInTheDocument()
    await user.type(screen.getByPlaceholderText('Rechercher un rapport'), 'zzzz')
    expect(await screen.findByText('Aucun rapport trouvé.')).toBeInTheDocument()
  })

  it('company report: title, headings, placeholder, action bar and send dialog', async () => {
    const user = renderFrench(`/reports/r-c4-${today}`)
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Rédiger un rapport' }),
    ).toBeVisible()
    expect(screen.getByRole('link', { name: 'Retour aux rapports' })).toBeVisible()
    for (const title of ['VALEUR', 'SECTEUR', 'MARCHÉ', 'POSITIONS COURTES']) {
      expect(screen.getByText(title)).toBeVisible()
    }
    expect(screen.getByText('CUSTOM CONTENT 1')).toBeVisible()
    expect(screen.getAllByText('Renseignez votre analyse ici')).toHaveLength(2)
    expect(screen.getByRole('link', { name: 'Consulter' })).toBeVisible()
    expect(screen.getByText('Dernière sauvegarde', { exact: false })).toBeVisible()
    expect(screen.getAllByRole('button', { name: 'Gras' }).length).toBeGreaterThan(0)
    await user.click(screen.getByRole('button', { name: 'Envoyer' }))
    const dialog = await screen.findByRole('dialog', { name: 'Envoyer le rapport' })
    expect(dialog).toHaveTextContent("Le contenu et la rédaction du rapport n'ont pas été validés.")
    expect(dialog).toHaveTextContent('Êtes-vous certain de vouloir envoyer le rapport à Accor ?')
    expect(screen.getByRole('button', { name: 'Annuler' })).toBeVisible()
    expect(screen.getByRole('button', { name: 'Oui' })).toBeVisible()
  })

  it('company report: a sent report shows Envoyé à and Modifier', async () => {
    renderFrench(`/reports/r-c1-${today}`)
    expect(await screen.findByText('Envoyé à 07:45')).toBeVisible()
    expect(screen.getByRole('button', { name: 'Modifier' })).toBeVisible()
  })

  it('company report: lock dialog and statistics', async () => {
    renderFrench(`/reports/r-c3-${today}`)
    const dialog = await screen.findByRole('dialog', { name: 'CONTENU EN COURS DE RÉDACTION' })
    expect(dialog).toHaveTextContent(
      'Le rapport est en cours de rédaction par jean.martin@rothschildandco.com',
    )
    expect(dialog).toHaveTextContent("Désirez-vous déverrouiller l'accès à ce rapport ?")
    expect(await screen.findByText('STATISTIQUES ÉCONOMIQUES')).toBeVisible()
  })

  it('company report: an unknown id is reported in French', async () => {
    renderFrench('/reports/unknown')
    expect(await screen.findByText('Rapport introuvable')).toBeVisible()
  })

  it('market report: title and send dialog', async () => {
    const user = renderFrench(`/reports/market/m-en-EN-${today}`)
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Rédiger un rapport de marché' }),
    ).toBeVisible()
    await user.click(screen.getByRole('button', { name: 'Demander la validation' }))
    await user.click(screen.getByRole('button', { name: 'Envoyer' }))
    const dialog = await screen.findByRole('dialog', { name: 'Envoyer le rapport' })
    expect(dialog).toHaveTextContent('English')
  })
})
