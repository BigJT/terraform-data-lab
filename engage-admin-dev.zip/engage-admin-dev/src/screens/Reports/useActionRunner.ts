import { useRef, useState } from 'react'
import { gatewayMessage } from '@/data/gatewayClient'

/** Runs one action at a time: later calls are ignored until the current one settles. */
export function useActionRunner<T>(apply: (result: T) => void) {
  const [error, setError] = useState('')
  const busy = useRef(false)
  const run = (task: () => Promise<T>, failureText: string, after?: () => void) => {
    if (busy.current) return
    busy.current = true
    setError('')
    task()
      .then((result) => {
        after?.()
        apply(result)
      })
      .catch((failure: unknown) => {
        setError(gatewayMessage(failure, failureText))
      })
      .finally(() => {
        busy.current = false
      })
  }
  return { run, error }
}
