import dayjs from 'dayjs'
import type { TFunction } from 'i18next'

/** "Last saved just now" under a minute, minutes under an hour, else the time of day. */
export function lastSavedCaption(updatedAt: string, now: Date, t: TFunction): string {
  const seconds = Math.max(0, Math.floor((now.getTime() - new Date(updatedAt).getTime()) / 1000))
  const minutes = Math.floor(seconds / 60)
  const relative =
    seconds < 60
      ? t('reports.relativeJustNow')
      : minutes < 60
        ? t('reports.relativeMinutes', { count: minutes })
        : t('reports.relativeAt', { time: dayjs(updatedAt).format('HH:mm') })
  return t('reports.lastSaved', { relative })
}
