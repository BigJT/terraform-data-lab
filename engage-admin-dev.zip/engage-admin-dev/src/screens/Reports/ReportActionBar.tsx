import { Box, Button } from '@mui/material'
import { useTranslation } from 'react-i18next'
import type { ReportValidation, WorkStatus } from '@/data/types'

export interface ReportActions {
  requestValidation: () => void
  validateAnalysis: () => void
  validateContent: () => void
  send: () => void
}

export function ReportActionBar({
  status,
  actions,
}: {
  status: { writingStatus: WorkStatus; validation: ReportValidation }
  actions: ReportActions
}) {
  const { t } = useTranslation()
  return (
    <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
      <Button
        variant="outlined"
        disabled={status.writingStatus === 'done'}
        onClick={actions.requestValidation}
      >
        {t('reports.requestValidation')}
      </Button>
      <Button
        variant="outlined"
        disabled={status.validation.content === 'done'}
        onClick={actions.validateContent}
      >
        {status.validation.content === 'done'
          ? t('reports.contentValidated')
          : t('reports.validateContent')}
      </Button>
      <Button
        variant="outlined"
        disabled={status.validation.writing === 'done'}
        onClick={actions.validateAnalysis}
      >
        {status.validation.writing === 'done'
          ? t('reports.writingValidated')
          : t('reports.validateWriting')}
      </Button>
      <Button variant="contained" onClick={actions.send}>
        {t('reports.send')}
      </Button>
    </Box>
  )
}
