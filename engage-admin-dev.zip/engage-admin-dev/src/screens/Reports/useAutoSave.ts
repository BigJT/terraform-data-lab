import { useCallback, useEffect, useRef, useState } from 'react'
import { isRichTextEmpty } from '@/ds/components'

const delay = 3000

/** Saves the latest values 3 s after the last non-blank change, and at once on unmount or pagehide; blanks ride along with the next. */
export function useAutoSave<T>({
  enabled,
  save,
}: {
  enabled: boolean
  save: (values: T) => Promise<void>
}) {
  const [failed, setFailed] = useState(false)
  const latest = useRef<T | null>(null)
  const dirty = useRef(false)
  const inFlight = useRef<Promise<void>>(Promise.resolve())
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const saveRef = useRef(save)
  const enabledRef = useRef(enabled)
  const lastStarted = useRef(0)

  useEffect(() => {
    saveRef.current = save
    enabledRef.current = enabled
  }, [save, enabled])

  useEffect(() => {
    if (!enabled) clearTimeout(timer.current)
    return () => {
      clearTimeout(timer.current)
    }
  }, [enabled])

  /** Saves what has changed since the last save, if anything; resolves (never rejects) once it is done. */
  const flush = useCallback(() => {
    clearTimeout(timer.current)
    if (!enabledRef.current || !dirty.current || latest.current === null) return inFlight.current
    dirty.current = false
    // Only the newest save decides the alert, so a slow earlier answer cannot overrule it.
    const started = ++lastStarted.current
    inFlight.current = saveRef.current(latest.current).then(
      () => {
        if (started === lastStarted.current) setFailed(false)
      },
      () => {
        dirty.current = true
        if (started === lastStarted.current) setFailed(true)
      },
    )
    return inFlight.current
  }, [])

  useEffect(() => {
    const leave = () => {
      void flush()
    }
    window.addEventListener('pagehide', leave)
    return () => {
      window.removeEventListener('pagehide', leave)
      leave()
    }
  }, [flush])

  const change = useCallback(
    (values: T, changed: string, schedule = true) => {
      latest.current = values
      if (!enabled || isRichTextEmpty(changed)) return
      dirty.current = true
      if (!schedule) return
      clearTimeout(timer.current)
      timer.current = setTimeout(() => {
        void flush()
      }, delay)
    },
    [enabled, flush],
  )

  return { change, flush, failed }
}
