import { describe, expect, it } from 'vitest'
import i18next from 'i18next'
import { setLanguage } from '@/i18n'
import { lastSavedCaption } from './lastSaved'

const now = new Date(2026, 9, 12, 10, 0, 0)
const ago = (seconds: number) => new Date(now.getTime() - seconds * 1000).toISOString()

describe('lastSavedCaption', () => {
  it.each([
    [0, 'Last saved just now'],
    [59, 'Last saved just now'],
    [60, 'Last saved 1 minute ago'],
    [119, 'Last saved 1 minute ago'],
    [120, 'Last saved 2 minutes ago'],
    [59 * 60 + 59, 'Last saved 59 minutes ago'],
    [60 * 60, 'Last saved at 09:00'],
  ])('%i seconds ago reads "%s"', (seconds, caption) => {
    expect(lastSavedCaption(ago(seconds), now, i18next.t)).toBe(caption)
  })
})

describe('lastSavedCaption in French', () => {
  it.each([
    [0, "Dernière sauvegarde à l'instant"],
    [60, 'Dernière sauvegarde il y a 1 minute'],
    [120, 'Dernière sauvegarde il y a 2 minutes'],
    [60 * 60, 'Dernière sauvegarde à 09:00'],
  ])('%i seconds ago reads "%s"', (seconds, caption) => {
    setLanguage('fr')
    expect(lastSavedCaption(ago(seconds), now, i18next.t)).toBe(caption)
  })
})
