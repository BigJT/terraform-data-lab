import { afterEach, beforeAll, describe, expect, it } from 'vitest'
import { cleanup, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { http } from 'msw'
import dayjs from 'dayjs'
import { MemoryRouter, Route, Routes } from 'react-router'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { db, emptyMarketReport } from '@/mocks/fixtures'
import { MarketReportScreen } from './MarketReportScreen'

const today = dayjs().format('YYYY-MM-DD')

function renderScreen(id: string) {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/reports/market/${id}`]}>
          <Routes>
            <Route path="reports/market/:id" element={<MarketReportScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

let inFlight = 0
beforeAll(() => {
  server.events.on('request:start', () => {
    inFlight += 1
  })
  server.events.on('request:end', () => {
    inFlight -= 1
  })
})
afterEach(async () => {
  cleanup()
  await waitFor(() => {
    expect(inFlight).toBe(0)
  })
})

describe('MarketReportScreen', () => {
  it('shows the heading, language, back link, full toolbar editor and action bar', async () => {
    renderScreen(`m-en-EN-${today}`)
    expect(
      await screen.findByRole('heading', { level: 1, name: 'Write a market report' }),
    ).toBeVisible()
    expect(screen.getByText('English')).toBeVisible()
    expect(screen.getByRole('link', { name: 'Back to reports' })).toHaveAttribute(
      'href',
      `/reports?tab=markets&date=${today}`,
    )
    expect(screen.getAllByRole('textbox')).toHaveLength(1)
    expect(screen.queryByText('Market report')).toBeNull()
    expect(screen.getByRole('button', { name: /bold/i })).toBeVisible()
    for (const name of ['Request validation', 'Validate content', 'Validate writing', 'Send']) {
      expect(screen.getByRole('button', { name })).toBeEnabled()
    }
  })

  it('uses market copy in the send dialog and sends', async () => {
    const user = userEvent.setup()
    db.marketReports.push({ ...emptyMarketReport('fr-FR', today), id: 'm-fr-todo' })
    renderScreen('m-fr-todo')
    await user.click(await screen.findByRole('button', { name: 'Send' }))
    expect(screen.getByRole('dialog', { name: 'Send the report' })).toBeVisible()
    expect(
      screen.getByText('The report content and writing have not been validated.'),
    ).toBeVisible()
    expect(
      screen.getByText('Are you sure you want to send the French market report?'),
    ).toBeVisible()
    await user.click(screen.getByRole('button', { name: 'Yes' }))
    expect(await screen.findByText('Sent', { exact: true })).toBeVisible()
    expect(screen.queryByText(/^Sent at/)).not.toBeInTheDocument()
    expect(await screen.findByRole('button', { name: 'Edit' })).toBeVisible()
  })

  it('sends the current content with Validate content', async () => {
    const user = userEvent.setup()
    const bodies: unknown[] = []
    server.use(
      http.put('*/api-admin/reports/market/:id/validation/content', async ({ request }) => {
        bodies.push(await request.clone().json())
        return undefined
      }),
    )
    db.marketReports.push({
      ...emptyMarketReport('fr-FR', today),
      id: 'm-validate',
      content: '<p>Stocks rose.</p>',
    })
    renderScreen('m-validate')
    await user.click(await screen.findByRole('button', { name: 'Validate content' }))
    expect(await screen.findByRole('button', { name: 'Content validated' })).toBeDisabled()
    expect(bodies).toEqual([{ content: '<p>Stocks rose.</p>' }])
  })

  it('shows the language name and the past date in the back link', async () => {
    const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
    db.marketReports.push({ ...emptyMarketReport('fr-FR', past), id: 'm-past-link' })
    renderScreen('m-past-link')
    expect(await screen.findByText('French')).toBeVisible()
    expect(screen.getByRole('link', { name: 'Back to reports' })).toHaveAttribute(
      'href',
      `/reports?tab=markets&date=${past}`,
    )
  })

  it('opens without asking when the lock is already held by the caller', async () => {
    db.marketReports.push({
      ...emptyMarketReport('fr-FR', today),
      id: 'm-mine',
      lockedBy: 'Local Admin',
    })
    renderScreen('m-mine')
    expect(await screen.findByRole('button', { name: 'Send' })).toBeEnabled()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('cancel in the send dialog sends nothing', async () => {
    const user = userEvent.setup()
    let sends = 0
    server.use(
      http.put('*/api-admin/reports/market/:id/sent', () => {
        sends += 1
        return undefined
      }),
    )
    renderScreen(`m-en-EN-${today}`)
    await user.click(await screen.findByRole('button', { name: 'Send' }))
    await user.click(screen.getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(sends).toBe(0)
  })

  it('edits and saves a sent market report with market copy', async () => {
    const user = userEvent.setup()
    db.marketReports.push({ ...emptyMarketReport('en-EN', today), id: 'm-sent', sent: true })
    renderScreen('m-sent')
    await user.click(await screen.findByRole('button', { name: 'Edit' }))
    await user.click(screen.getByRole('button', { name: 'Save' }))
    expect(screen.getByRole('dialog', { name: 'Save the report' })).toBeVisible()
    expect(
      screen.getByText('Are you sure you want to save the changes to the English market report?'),
    ).toBeVisible()
    await user.click(screen.getByRole('button', { name: 'Yes' }))
    expect(await screen.findByRole('button', { name: 'Edit' })).toBeVisible()
    expect(screen.queryByRole('button', { name: 'Save' })).not.toBeInTheDocument()
  })

  it('is read-only for a past report', async () => {
    const past = dayjs().subtract(1, 'day').format('YYYY-MM-DD')
    db.marketReports.push({ ...emptyMarketReport('en-EN', past), id: 'm-past' })
    renderScreen('m-past')
    await screen.findByRole('heading', { name: 'Write a market report' })
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Send' })).not.toBeInTheDocument()
  })

  it('locks on open, unlocks on unmount, using the market endpoints', async () => {
    const calls: string[] = []
    server.use(
      http.put('*/api-admin/reports/market/:id/lock', ({ params }) => {
        calls.push(`lock ${String(params.id)}`)
        return undefined
      }),
      http.put('*/api-admin/reports/market/:id/unlock', ({ params }) => {
        calls.push(`unlock ${String(params.id)}`)
        return undefined
      }),
    )
    const view = renderScreen(`m-en-EN-${today}`)
    await screen.findByRole('textbox')
    await waitFor(() => {
      expect(calls).toEqual([`lock m-en-EN-${today}`])
    })
    view.unmount()
    await waitFor(() => {
      expect(calls).toEqual([`lock m-en-EN-${today}`, `unlock m-en-EN-${today}`])
    })
  })

  it('stays read-only with an alert, and sends no unlock, when the lock fails', async () => {
    const calls: string[] = []
    server.use(
      http.put('*/api-admin/reports/market/:id/lock', () => new Response(null, { status: 500 })),
      http.put('*/api-admin/reports/market/:id/unlock', () => {
        calls.push('unlock')
        return undefined
      }),
    )
    const view = renderScreen(`m-en-EN-${today}`)
    expect(
      await screen.findByText('This report could not be opened for editing. Try again later.'),
    ).toBeVisible()
    expect(screen.queryByRole('textbox')).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Send' })).not.toBeInTheDocument()
    view.unmount()
    expect(calls).toEqual([])
  })

  it('asks before taking a lock held by someone else', async () => {
    db.marketReports.push({
      ...emptyMarketReport('fr-FR', today),
      id: 'm-locked',
      lockedBy: 'jean.martin@rothschildandco.com',
    })
    renderScreen('m-locked')
    const dialog = await screen.findByRole('dialog', { name: 'CONTENT BEING WRITTEN' })
    expect(dialog).toHaveTextContent(
      'The report is being written by jean.martin@rothschildandco.com',
    )
  })

  it('shows "Report not found" for an unknown id', async () => {
    renderScreen('nope')
    expect(await screen.findByText('Report not found')).toBeVisible()
  })
})
