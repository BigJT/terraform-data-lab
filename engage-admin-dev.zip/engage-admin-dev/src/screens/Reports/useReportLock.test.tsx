import { describe, expect, it, vi } from 'vitest'
import { renderHook } from '@testing-library/react'
import { useReportLock } from './useReportLock'

function run(lockedBy: string | null, lockedByCaller: boolean) {
  const lock = vi.fn(() => Promise.resolve())
  const view = renderHook(() =>
    useReportLock({
      report: { id: 'r1', lockedBy, lockedByCaller },
      editable: true,
      lock,
      unlock: () => Promise.resolve(),
    }),
  )
  return { lock, access: view.result.current.access }
}

describe('useReportLock ownership', () => {
  it('takes a free lock', () => {
    const { lock, access } = run(null, false)
    expect(access).toBe('held')
    expect(lock).toHaveBeenCalledWith('r1')
  })

  it('treats a lock held by the caller as free', () => {
    const { lock, access } = run('Local Admin', true)
    expect(access).toBe('held')
    expect(lock).toHaveBeenCalledWith('r1')
  })

  it('asks before taking a lock held by someone else', () => {
    const { lock, access } = run('jean.martin@rothschildandco.com', false)
    expect(access).toBe('prompt')
    expect(lock).not.toHaveBeenCalled()
  })
})
