import { describe, expect, it } from 'vitest'
import { reportDate, reportMode } from './reportMode'

// createdAt is a local 05:00 instant; the report's day is its local date.
const on = (date: string) => new Date(`${date}T05:00:00`).toISOString()

describe('reportMode', () => {
  it('is past for an earlier date, sent or not', () => {
    expect(reportMode({ createdAt: on('2026-10-11'), sent: false }, '2026-10-12')).toBe('past')
    expect(reportMode({ createdAt: on('2026-10-11'), sent: true }, '2026-10-12')).toBe('past')
  })

  it('is sent for a sent report today', () => {
    expect(reportMode({ createdAt: on('2026-10-12'), sent: true }, '2026-10-12')).toBe('sent')
  })

  it('is editable for an unsent report today', () => {
    expect(reportMode({ createdAt: on('2026-10-12'), sent: false }, '2026-10-12')).toBe('editable')
  })
})

describe('reportDate', () => {
  it('is the local date of createdAt', () => {
    expect(reportDate(new Date('2026-10-12T00:30:00').toISOString())).toBe('2026-10-12')
    expect(reportDate(new Date('2026-10-12T23:30:00').toISOString())).toBe('2026-10-12')
  })
})
