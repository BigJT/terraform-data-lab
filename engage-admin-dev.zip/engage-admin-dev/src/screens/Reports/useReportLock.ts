import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'

type Access = 'held' | 'prompt' | 'readonly'

interface Lockable {
  id: string
  lockedBy: string | null
  lockedByCaller: boolean
}

/** Takes the editing lock when the report is editable, asks before taking it from someone else, and releases it on exit. */
export function useReportLock({
  report,
  editable,
  lock,
  unlock,
}: {
  report: Lockable | undefined
  editable: boolean
  lock: (id: string) => Promise<unknown>
  unlock: (id: string) => Promise<unknown>
}) {
  const { t } = useTranslation()
  const [decision, setDecision] = useState<{ id: string; access: Access } | null>(null)
  const [error, setError] = useState('')
  const held = useRef<string | null>(null)
  const decided = useRef<string | null>(null)
  const editableRef = useRef(editable)
  const unlockRef = useRef(unlock)
  const id = report?.id
  const free = report !== undefined && (report.lockedBy === null || report.lockedByCaller)

  useEffect(() => {
    editableRef.current = editable
    unlockRef.current = unlock
  }, [editable, unlock])

  // A lock that was not taken stays read-only, and is never released.
  const fail = (lockId: string) => {
    if (held.current === lockId) held.current = null
    setError(t('reports.lockFailed'))
    setDecision({ id: lockId, access: 'readonly' })
  }

  useEffect(() => {
    if (!report || !editable || decided.current === report.id) return
    decided.current = report.id
    if (!free) return
    held.current = report.id
    const lockId = report.id
    lock(lockId).catch(() => {
      fail(lockId)
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [report, editable, free])

  useEffect(() => {
    if (!id) return
    const release = () => {
      if (held.current !== id || !editableRef.current) return
      held.current = null
      unlockRef.current(id).catch(() => undefined)
    }
    window.addEventListener('pagehide', release)
    return () => {
      window.removeEventListener('pagehide', release)
      release()
      decided.current = null
    }
  }, [id])

  const access: Access | 'pending' =
    decision && decision.id === id ? decision.access : !id ? 'pending' : free ? 'held' : 'prompt'
  return {
    access,
    error,
    takeOver: () => {
      if (!id) return
      setError('')
      // Mark it held before the answer, so closing the screen meanwhile still releases it.
      held.current = id
      lock(id).then(
        () => {
          setDecision({ id, access: 'held' })
        },
        () => {
          fail(id)
        },
      )
    },
    cancel: () => {
      if (id) setDecision({ id, access: 'readonly' })
    },
  }
}
