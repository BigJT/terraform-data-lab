import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Link,
} from '@mui/material'
import dayjs from 'dayjs'
import { useCallback, useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link as RouterLink, useParams } from 'react-router'
import { RichTextEditor, SafeHtml } from '@/ds/components'
import { colors } from '@/ds/theme'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { MarketReportDetail } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { LastSaved } from './LastSavedLine'
import { ReportActionBar } from './ReportActionBar'
import { reportDate, reportMode } from './reportMode'
import { useActionRunner } from './useActionRunner'
import { useAutoSave } from './useAutoSave'
import { useReportLock } from './useReportLock'

export function MarketReportScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const { id = '' } = useParams()
  const [result, setResult] = useState<{
    id: string
    report?: MarketReportDetail
    error?: string
  } | null>(null)
  const [updatedAt, setUpdatedAt] = useState('')
  const [editing, setEditing] = useState(false)
  const [dialog, setDialog] = useState<'send' | 'save' | null>(null)
  const content = useRef('')
  const report = result?.id === id ? result.report : undefined
  const mode = report ? reportMode(report, dayjs().format('YYYY-MM-DD')) : undefined
  const flushRef = useRef<() => Promise<void>>(() => Promise.resolve())
  const lock = useReportLock({
    report,
    editable: mode === 'editable',
    lock: gateway.lockMarketReport,
    // Leaving saves first, so the unlock never beats the last edit.
    unlock: (reportId) => flushRef.current().then(() => gateway.unlockMarketReport(reportId)),
  })
  const editable = mode === 'editable' && lock.access === 'held'
  const showEditor = editable || (mode === 'sent' && editing)

  const save = useCallback(
    (values: { content: string }) =>
      gateway.saveMarketReportContent(id, values).then((saved) => {
        setUpdatedAt((shown) => (saved.updatedAt > shown ? saved.updatedAt : shown))
      }),
    [gateway, id],
  )
  const autoSave = useAutoSave<{ content: string }>({ enabled: editable, save })
  useEffect(() => {
    flushRef.current = autoSave.flush
  }, [autoSave.flush])

  useEffect(() => {
    let current = true
    gateway.getMarketReport(id).then(
      (report) => {
        if (!current) return
        content.current = report.content
        setUpdatedAt(report.updatedAt)
        setResult({ id, report })
      },
      (failure: unknown) => {
        if (!current) return
        const error =
          failure instanceof GatewayError && failure.status === 404
            ? t('reports.notFound')
            : gatewayMessage(failure, t('reports.loadFailed'))
        setResult({ id, error })
      },
    )
    return () => {
      current = false
    }
  }, [gateway, id, t])

  // Keep what the admin has typed over the server copy, which may lag the 3 s auto-save.
  const apply = (detail: MarketReportDetail) => {
    setUpdatedAt(detail.updatedAt)
    setResult({ id, report: { ...detail, content: content.current } })
  }
  const { run, error: actionError } = useActionRunner(apply)
  const act = (action: (id: string) => Promise<MarketReportDetail>) => {
    run(() => action(id), t('reports.actionFailed'))
  }
  const confirm = () => {
    const which = dialog
    setDialog(null)
    const values = { content: content.current }
    if (which === 'send') {
      // Flush typing still waiting for auto-save, so the sent report has it.
      run(
        () => gateway.saveMarketReportContent(id, values).then(() => gateway.sendMarketReport(id)),
        t('reports.sendFailed'),
      )
    } else if (which === 'save') {
      run(
        () => gateway.saveMarketReportContent(id, values),
        t('reports.saveFailed'),
        () => {
          setEditing(false)
        },
      )
    }
  }

  if (result?.id !== id) return null
  if (result.error) return <Alert severity="error">{result.error}</Alert>
  if (!report) return null

  const language = report.languageName

  return (
    <>
      <ScreenTitle>{t('reports.writeMarketReport')}</ScreenTitle>
      <Box sx={{ fontSize: 18, fontWeight: 600, color: colors.textPrimary, mb: 1 }}>{language}</Box>
      <Link
        component={RouterLink}
        to={`/reports?tab=markets&date=${reportDate(report.createdAt)}`}
        sx={{ display: 'inline-block', mb: 2, fontSize: 14 }}
      >
        {t('reports.back')}
      </Link>
      {actionError || lock.error ? (
        <Alert severity="error" sx={{ mb: 2 }}>
          {actionError || lock.error}
        </Alert>
      ) : null}
      {editable && updatedAt ? <LastSaved key={updatedAt} updatedAt={updatedAt} /> : null}
      {mode === 'sent' ? (
        <Box sx={{ mb: 2, fontSize: 14, color: colors.green }}>{t('reports.sent')}</Box>
      ) : null}
      {editable ? (
        <ReportActionBar
          status={report}
          actions={{
            requestValidation: () => {
              act(gateway.requestMarketReportValidation)
            },
            validateContent: () => {
              act((reportId) =>
                gateway.validateMarketReportContent(reportId, { content: content.current }),
              )
            },
            validateAnalysis: () => {
              act(gateway.validateMarketReportAnalysis)
            },
            send: () => {
              setDialog('send')
            },
          }}
        />
      ) : null}
      {mode === 'sent' && !editing ? (
        <Button
          variant="outlined"
          sx={{ mb: 2 }}
          onClick={() => {
            setEditing(true)
          }}
        >
          {t('reports.edit')}
        </Button>
      ) : null}
      {showEditor ? (
        <>
          {editable && autoSave.failed ? (
            <Alert severity="error" sx={{ mb: 2 }}>
              {t('reports.autoSaveFailed')}
            </Alert>
          ) : null}
          <RichTextEditor
            label={t('reports.marketReportLabel')}
            hideLabel
            toolbar="full"
            value={report.content}
            onChange={(html) => {
              content.current = html
              autoSave.change({ content: html }, html)
            }}
          />
        </>
      ) : (
        <Box sx={{ mb: 3, fontSize: 14, color: colors.textPrimary }}>
          <SafeHtml html={report.content} />
        </Box>
      )}
      {mode === 'sent' && editing ? (
        <Button
          variant="contained"
          sx={{ mt: 2 }}
          onClick={() => {
            setDialog('save')
          }}
        >
          {t('reports.save')}
        </Button>
      ) : null}
      <Dialog open={mode === 'editable' && lock.access === 'prompt'} aria-labelledby="lock-title">
        <DialogTitle id="lock-title">{t('reports.lockTitle')}</DialogTitle>
        <DialogContent>
          <Box>{t('reports.lockedBy', { name: report.lockedBy })}</Box>
          <Box>{t('reports.lockQuestion')}</Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={lock.cancel}>{t('common.cancel')}</Button>
          <Button variant="contained" onClick={lock.takeOver}>
            {t('common.yes')}
          </Button>
        </DialogActions>
      </Dialog>
      <Dialog
        open={dialog !== null}
        onClose={() => {
          setDialog(null)
        }}
        aria-labelledby="report-dialog-title"
      >
        <DialogTitle id="report-dialog-title">
          {dialog === 'save' ? t('reports.saveTitle') : t('reports.sendTitle')}
        </DialogTitle>
        <DialogContent>
          {dialog === 'send' && report.writingStatus !== 'done' ? (
            <Box>{t('reports.notValidated')}</Box>
          ) : null}
          <Box>
            {dialog === 'save'
              ? t('reports.confirmSaveMarket', { language })
              : t('reports.confirmSendMarket', { language })}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setDialog(null)
            }}
          >
            {t('common.cancel')}
          </Button>
          <Button variant="contained" onClick={confirm}>
            {t('common.yes')}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}
