import { describe, expect, it } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import dayjs from 'dayjs'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { ReportsScreen } from './ReportsScreen'

function Location() {
  const location = useLocation()
  return <div data-testid="location">{location.pathname + location.search}</div>
}

function renderScreen(url = '/reports') {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[url]}>
          <Routes>
            <Route path="reports" element={<ReportsScreen />} />
            <Route path="*" element={null} />
          </Routes>
          <Location />
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

function bodyRows() {
  return screen.getAllByRole('row').slice(1)
}

function cells(row: HTMLElement) {
  return within(row)
    .getAllByRole('cell')
    .map((cell) => cell.textContent)
}

const today = dayjs()
const pastDate = today.subtract(7, 'day')

describe('ReportsScreen', () => {
  it('lists today by company with the four columns and the Today date line', async () => {
    renderScreen()
    await screen.findByText('LVMH')
    expect(screen.getByRole('heading', { level: 1, name: 'Reports' })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: 'Companies', selected: true })).toBeInTheDocument()
    expect(screen.getByRole('tab', { name: 'Markets', selected: false })).toBeInTheDocument()
    expect(screen.getByText(`Today (${today.format('dddd D MMMM YYYY')})`)).toBeInTheDocument()
    expect(screen.getByPlaceholderText('Search reports')).toBeInTheDocument()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Companies (5)',
      'Last modified',
      'Validation',
      'Status',
    ])
    expect(bodyRows().map((row) => cells(row)[0])).toEqual([
      'Accor',
      'Danone',
      'Diageo',
      'Kering',
      'LVMH',
    ])
    expect(screen.queryByText('Worldline')).not.toBeInTheDocument()
    const lvmh = cells(screen.getByText('LVMH').closest('tr') as HTMLElement)
    expect(lvmh).toEqual([
      'LVMH',
      `${today.format('DD/MM/YYYY')} 07:45`,
      'Validated',
      '✓ Sent at 07:45',
    ])
    expect(cells(screen.getByText('Danone').closest('tr') as HTMLElement).slice(2)).toEqual([
      'To validate',
      'To send',
    ])
    expect(cells(screen.getByText('Accor').closest('tr') as HTMLElement).slice(2)).toEqual([
      '...',
      'To send',
    ])
  })

  it('filters by name or RIC and counts the rows shown', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.type(screen.getByPlaceholderText('Search reports'), 'dan')
    expect(bodyRows().map((row) => cells(row)[0])).toEqual(['Danone'])
    expect(screen.getByRole('columnheader', { name: 'Companies (1)' })).toBeInTheDocument()
    await user.clear(screen.getByPlaceholderText('Search reports'))
    await user.type(screen.getByPlaceholderText('Search reports'), 'dge.l')
    expect(bodyRows().map((row) => cells(row)[0])).toEqual(['Diageo'])
  })

  it('shows No reports found. when nothing matches', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.type(screen.getByPlaceholderText('Search reports'), 'zzz')
    expect(screen.getByText('No reports found.')).toBeInTheDocument()
  })

  it('reads the date from the URL: no Today, every row empty, Worldline absent', async () => {
    renderScreen(`/reports?date=${pastDate.format('YYYY-MM-DD')}`)
    await screen.findByText('LVMH')
    expect(screen.getByText(pastDate.format('dddd D MMMM YYYY'))).toBeInTheDocument()
    expect(screen.queryByText(/Today \(/)).not.toBeInTheDocument()
    expect(bodyRows().map((row) => cells(row).slice(2))).toEqual(
      Array.from({ length: 5 }, () => ['...', 'To send']),
    )
    expect(screen.queryByText('Worldline')).not.toBeInTheDocument()
  })

  it('shows the market languages French then English on the Markets tab', async () => {
    renderScreen('/reports?tab=markets')
    await screen.findByText('French')
    expect(screen.getByRole('tab', { name: 'Markets', selected: true })).toBeInTheDocument()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Language (2)',
      'Last modified',
      'Validation',
      'Status',
    ])
    expect(bodyRows().map((row) => [cells(row)[0], ...cells(row).slice(2)])).toEqual([
      ['French', 'Validated', 'To send'],
      ['English', '...', 'To send'],
    ])
  })

  it('shows a sent market report as "✓ Sent" with no time', async () => {
    const { db } = await import('@/mocks/fixtures')
    const french = db.marketReports.find((row) => row.languageCode === 'fr-FR')
    if (french) french.sent = true
    renderScreen('/reports?tab=markets')
    await screen.findByText('French')
    expect(cells(screen.getByText('French').closest('tr') as HTMLElement)[3]).toBe('✓ Sent')
  })

  it('searches markets by language name', async () => {
    const user = userEvent.setup()
    renderScreen('/reports?tab=markets')
    await screen.findByText('French')
    await user.type(screen.getByPlaceholderText('Search reports'), 'eng')
    expect(bodyRows().map((row) => cells(row)[0])).toEqual(['English'])
  })

  it('switching tab writes it to the URL', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.click(screen.getByRole('tab', { name: 'Markets' }))
    expect(screen.getByTestId('location')).toHaveTextContent('tab=markets')
    expect(await screen.findByText('French')).toBeInTheDocument()
  })

  it('opens a company report and a market report from their rows', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(await screen.findByText('Accor'))
    expect(screen.getByTestId('location')).toHaveTextContent('/reports/r-c4-')
  })

  it('opens a market report from its row', async () => {
    const user = userEvent.setup()
    renderScreen('/reports?tab=markets')
    await user.click(await screen.findByText('French'))
    expect(screen.getByTestId('location')).toHaveTextContent('/reports/market/m-fr-FR-')
  })

  it('shows the load failure', async () => {
    const { server } = await import('@/mocks/server')
    const { http, HttpResponse } = await import('msw')
    server.use(
      http.get('*/api-admin/reports', () =>
        HttpResponse.json({ message: 'Boom' }, { status: 500 }),
      ),
    )
    renderScreen()
    expect(await screen.findByText('Boom')).toBeInTheDocument()
  })
})
