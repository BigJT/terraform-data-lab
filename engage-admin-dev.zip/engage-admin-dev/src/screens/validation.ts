/** Email rule shared by the company wizard and the user form. */
export const emailPattern = /^[^\s@]+@[^\s@]+\.[A-Za-z]{2,10}$/
