import { describe, expect, it } from 'vitest'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { db } from '@/mocks/fixtures'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { BrokerNotesScreen } from './BrokerNotesScreen'

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen() {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/broker-notes']}>
          <Routes>
            <Route path="broker-notes" element={<BrokerNotesScreen />} />
            <Route path="*" element={<Location />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

function bodyRows() {
  return screen.getAllByRole('row').slice(1)
}

function rowAt(index: number) {
  const row = bodyRows()[index]
  if (!row) throw new Error(`No row ${String(index)}`)
  return row
}

function cellTexts(row: HTMLElement) {
  return within(row)
    .getAllByRole('cell')
    .map((cell) => cell.textContent)
}

describe('BrokerNotesScreen', () => {
  it('shows the heading, controls, legend and columns', async () => {
    renderScreen()
    expect(screen.getByRole('heading', { name: 'Broker notes' })).toBeInTheDocument()
    expect(screen.getByPlaceholderText('Search broker notes')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Send a note' })).toBeInTheDocument()
    for (const label of ['Recommendation change', 'Initiation', 'Sector']) {
      expect(screen.getAllByText(label).length).toBeGreaterThan(0)
    }
    await screen.findByText('LVMH')
    expect(screen.getAllByRole('columnheader').map((header) => header.textContent)).toEqual([
      'Sent on',
      'Company',
      'Broker',
      'Type',
      'Target',
      'Recommendation',
      'Previous target',
      'Previous recommendation',
      '',
    ])
  })

  it('lists the notes newest first with formatted cells', async () => {
    renderScreen()
    await screen.findByText('LVMH')
    expect(bodyRows()).toHaveLength(5)
    const first = cellTexts(rowAt(0))
    expect(first[0]).toMatch(/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)
    expect(first.slice(1)).toEqual([
      'LVMH',
      'Barclays',
      'Recommendation change',
      '720.00 €',
      'OVERWEIGHT',
      '680.00 €',
      'NEUTRAL',
      'Delete',
    ])
    expect(cellTexts(rowAt(1)).slice(1, 6)).toEqual([
      'Diageo',
      'Citi',
      'Initiation',
      '3100.00 p',
      'BUY',
    ])
    expect(cellTexts(rowAt(4)).slice(1, 8)).toEqual([
      'Accor',
      'RBC Capital',
      '',
      '48.00 €',
      'OUTPERFORM',
      '',
      '',
    ])
  })

  it('shows one labelled icon per true flag', async () => {
    renderScreen()
    await screen.findByText('LVMH')
    expect(within(rowAt(0)).getByLabelText('Recommendation change')).toBeInTheDocument()
    expect(within(rowAt(1)).getByLabelText('Initiation')).toBeInTheDocument()
    expect(within(rowAt(2)).getByLabelText('Sector')).toBeInTheDocument()
    expect(within(rowAt(4)).queryByLabelText(/Recommendation change|Initiation|Sector/)).toBeNull()
  })

  it('searches after the debounce, and clearing shows all again', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.type(screen.getByPlaceholderText('Search broker notes'), 'barclays')
    await waitFor(() => {
      expect(bodyRows()).toHaveLength(1)
    })
    expect(within(rowAt(0)).getByText('LVMH')).toBeInTheDocument()
    await user.clear(screen.getByPlaceholderText('Search broker notes'))
    await waitFor(() => {
      expect(bodyRows()).toHaveLength(5)
    })
  })

  it('shows the empty state', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.type(screen.getByPlaceholderText('Search broker notes'), 'zzz')
    expect(await screen.findByText('No broker notes found.')).toBeInTheDocument()
  })

  it('pages 20 at a time, and a new search returns to page 0', async () => {
    const seen: string[] = []
    server.use(
      http.get('*/api-admin/broker-note', ({ request }) => {
        const params = new URL(request.url).searchParams
        seen.push(`${params.get('q') ?? ''}|${params.get('page') ?? ''}`)
        return HttpResponse.json({
          content: db.brokerNotes.slice(0, 1),
          totalElements: 45,
          totalPages: 3,
          number: Number(params.get('page')),
          size: 20,
        })
      }),
    )
    const user = userEvent.setup()
    renderScreen()
    expect(await screen.findByText('1–20 of 45')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /next page/i }))
    await waitFor(() => {
      expect(seen).toEqual(['|0', '|1'])
    })
    await user.type(screen.getByPlaceholderText('Search broker notes'), 'a')
    await waitFor(() => {
      expect(seen).toEqual(['|0', '|1', 'a|0'])
    })
  })

  it('goes to compose from the button', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(screen.getByRole('button', { name: 'Send a note' }))
    expect(screen.getByTestId('location')).toHaveTextContent('/broker-notes/new')
  })

  it('Cancel keeps the row, Yes deletes it', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('Kering')
    await user.click(within(rowAt(3)).getByRole('button', { name: 'Delete' }))
    const dialog = screen.getByRole('dialog', { name: 'Delete broker note' })
    expect(within(dialog).getByText('Are you sure you want to delete?')).toBeInTheDocument()
    expect(within(dialog).getByText('This action cannot be undone')).toBeInTheDocument()
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).toBeNull()
    })
    expect(bodyRows()).toHaveLength(5)
    await user.click(within(rowAt(3)).getByRole('button', { name: 'Delete' }))
    await user.click(screen.getByRole('button', { name: 'Yes' }))
    await waitFor(() => {
      expect(bodyRows()).toHaveLength(4)
    })
    expect(screen.queryByText('Kering')).toBeNull()
  })

  it('goes back a page when a delete empties the last page', async () => {
    const seen: number[] = []
    let total = 21
    server.use(
      http.get('*/api-admin/broker-note', ({ request }) => {
        const page = Number(new URL(request.url).searchParams.get('page'))
        seen.push(page)
        const content =
          page === 1 && total === 21
            ? db.brokerNotes.slice(0, 1)
            : page === 0
              ? db.brokerNotes.slice(0, 5)
              : []
        return HttpResponse.json({
          content,
          totalElements: total,
          totalPages: Math.ceil(total / 20),
          number: page,
          size: 20,
        })
      }),
      http.delete('*/api-admin/broker-note/:id', () => {
        total = 20
        return new HttpResponse(null, { status: 200 })
      }),
    )
    const user = userEvent.setup()
    renderScreen()
    expect(await screen.findByText('1–20 of 21')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /next page/i }))
    expect(await screen.findByText('21–21 of 21')).toBeInTheDocument()
    await user.click(within(rowAt(0)).getByRole('button', { name: 'Delete' }))
    await user.click(screen.getByRole('button', { name: 'Yes' }))
    expect(await screen.findByText('1–20 of 20')).toBeInTheDocument()
    expect(seen).toEqual([0, 1, 1, 0])
    expect(screen.queryByText('No broker notes found.')).toBeNull()
  })

  it('shows the gateway message in the dialog when delete fails', async () => {
    server.use(
      http.delete('*/api-admin/broker-note/:id', () =>
        HttpResponse.json({ message: 'Delete refused' }, { status: 500 }),
      ),
    )
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.click(within(rowAt(0)).getByRole('button', { name: 'Delete' }))
    await user.click(screen.getByRole('button', { name: 'Yes' }))
    const dialog = screen.getByRole('dialog')
    expect(await within(dialog).findByText('Delete refused')).toBeInTheDocument()
    expect(screen.getAllByRole('row', { hidden: true })).toHaveLength(6)
  })
})
