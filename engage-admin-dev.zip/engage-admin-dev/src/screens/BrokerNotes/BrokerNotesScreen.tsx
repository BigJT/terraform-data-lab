import CategoryOutlinedIcon from '@mui/icons-material/CategoryOutlined'
import NewReleasesOutlinedIcon from '@mui/icons-material/NewReleasesOutlined'
import SwapVertIcon from '@mui/icons-material/SwapVert'
import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  InputBase,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TablePagination,
  TableRow,
} from '@mui/material'
import { useCallback, useEffect, useState, type ElementType } from 'react'
import { useNavigate } from 'react-router'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { BrokerNoteSummary, Page } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'

const columns = [
  'sentOn',
  'company',
  'broker',
  'type',
  'target',
  'recommendation',
  'previousTarget',
  'previousRecommendation',
]
const pageSize = 20
const pad = (value: number) => String(value).padStart(2, '0')

function formatSentOn(iso: string): string {
  const date = new Date(iso)
  const day = `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${String(date.getFullYear())}`
  return `${day} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function formatObjective(objective: number | null, currency: string): string {
  return objective === null ? '' : `${objective.toFixed(2)} ${currency}`
}

const types: {
  flag: 'recommendationChange' | 'initiationNote' | 'sectorNote'
  labelKey: string
  Icon: ElementType
}[] = [
  { flag: 'recommendationChange', labelKey: 'brokerNotes.types.recoChange', Icon: SwapVertIcon },
  {
    flag: 'initiationNote',
    labelKey: 'brokerNotes.types.initiation',
    Icon: NewReleasesOutlinedIcon,
  },
  { flag: 'sectorNote', labelKey: 'brokerNotes.types.sector', Icon: CategoryOutlinedIcon },
]

export function BrokerNotesScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [search, setSearch] = useState('')
  const [query, setQuery] = useState('')
  const [page, setPage] = useState(0)
  const [result, setResult] = useState<Page<BrokerNoteSummary> | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [reload, setReload] = useState(0)
  const [deleting, setDeleting] = useState<BrokerNoteSummary | null>(null)
  const [deleteError, setDeleteError] = useState<string | null>(null)

  useEffect(() => {
    if (search === query) return
    const timer = setTimeout(() => {
      setQuery(search)
      setPage(0)
    }, 300)
    return () => {
      clearTimeout(timer)
    }
  }, [search, query])

  useEffect(() => {
    let current = true
    gateway.listBrokerNotes({ q: query, page, size: pageSize }).then(
      (loaded) => {
        if (!current) return
        if (loaded.content.length === 0 && page > 0) {
          setPage(page - 1)
          return
        }
        setResult(loaded)
        setError(null)
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, t('brokerNotes.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, query, page, reload, t])

  const close = useCallback(() => {
    setDeleting(null)
    setDeleteError(null)
  }, [])

  async function remove() {
    if (deleting === null) return
    try {
      await gateway.deleteBrokerNote(deleting.id)
      close()
      setReload((count) => count + 1)
    } catch (failure) {
      setDeleteError(gatewayMessage(failure, t('brokerNotes.deleteFailed')))
    }
  }

  const rows = result?.content ?? []

  return (
    <>
      <ScreenTitle>{t('shell.brokerNotes')}</ScreenTitle>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <InputBase
          placeholder={t('brokerNotes.search')}
          value={search}
          onChange={(event) => {
            setSearch(event.target.value)
          }}
          inputProps={{ 'aria-label': t('brokerNotes.search') }}
          sx={{ flex: 1, px: 1.5, height: 32, border: `1px solid ${colors.rule}`, fontSize: 14 }}
        />
        <Button
          variant="contained"
          onClick={() => {
            void navigate('/broker-notes/new')
          }}
        >
          {t('brokerNotes.send')}
        </Button>
      </Box>
      <Box sx={{ display: 'flex', gap: 3, mb: 2, color: colors.textSecondary }}>
        {types.map(({ labelKey, Icon }) => (
          <Box
            key={labelKey}
            sx={{ display: 'flex', alignItems: 'center', gap: 0.5, fontSize: 13 }}
          >
            <Icon fontSize="small" />
            {t(labelKey)}
          </Box>
        ))}
      </Box>
      <Panel>
        {error !== null && (
          <Alert severity="error" sx={{ m: 2 }}>
            {error}
          </Alert>
        )}
        <Table size="small">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column} sx={{ fontWeight: 600 }}>
                  {t(`brokerNotes.columns.${column}`)}
                </TableCell>
              ))}
              <TableCell />
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((note) => (
              <TableRow key={note.id}>
                <TableCell>{formatSentOn(note.createdAt)}</TableCell>
                <TableCell>{note.company.name}</TableCell>
                <TableCell>{note.broker}</TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', gap: 0.5, color: colors.textSecondary }}>
                    {types
                      .filter(({ flag }) => note[flag])
                      .map(({ labelKey, Icon }) => (
                        <Icon
                          key={labelKey}
                          fontSize="small"
                          aria-label={t(labelKey)}
                          titleAccess={t(labelKey)}
                        />
                      ))}
                  </Box>
                </TableCell>
                <TableCell>{formatObjective(note.currentObjective, note.currency)}</TableCell>
                <TableCell>{note.currentRecommendation}</TableCell>
                <TableCell>
                  {note.recommendationChange
                    ? formatObjective(note.previousObjective, note.currency)
                    : ''}
                </TableCell>
                <TableCell>
                  {note.recommendationChange ? (note.previousRecommendation ?? '') : ''}
                </TableCell>
                <TableCell>
                  <Button
                    size="small"
                    onClick={() => {
                      setDeleting(note)
                    }}
                  >
                    {t('common.delete')}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {result !== null && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={columns.length + 1} sx={{ color: colors.textSecondary }}>
                  {t('brokerNotes.empty')}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={result?.totalElements ?? 0}
          page={page}
          rowsPerPage={pageSize}
          rowsPerPageOptions={[]}
          onPageChange={(_event, next) => {
            setPage(next)
          }}
        />
      </Panel>
      <Dialog open={deleting !== null} onClose={close}>
        <DialogTitle>{t('brokerNotes.deleteTitle')}</DialogTitle>
        <DialogContent>
          {deleteError !== null && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {deleteError}
            </Alert>
          )}
          <Box>{t('brokerNotes.deleteQuestion')}</Box>
          <Box sx={{ fontWeight: 700 }}>{t('brokerNotes.deleteWarning')}</Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={close}>{t('common.cancel')}</Button>
          <Button
            onClick={() => {
              void remove()
            }}
          >
            {t('common.yes')}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  )
}
