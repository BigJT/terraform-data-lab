import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  MenuItem,
  Snackbar,
  Switch,
  TextField,
} from '@mui/material'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router'
import { useTranslation } from 'react-i18next'
import { AttachmentPicker, Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { useGateway } from '@/data/gatewayContext'
import type { CompanySummary } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'

const currencies = ['€', '$', '£', 'p', 'SFr']

type Field = 'company' | 'broker' | 'target' | 'type' | 'previousTarget' | 'previousType'
type Errors = Partial<Record<Field, string>>

function SectionHeading({ children }: { children: string }) {
  return (
    <Box sx={{ mt: 2, mb: 1, fontSize: 12, fontWeight: 600, color: colors.textSecondary }}>
      {children}
    </Box>
  )
}

export function SendBrokerNoteScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [companies, setCompanies] = useState<CompanySummary[]>([])
  const [brokers, setBrokers] = useState<string[]>([])
  const [recommendations, setRecommendations] = useState<string[]>([])
  const [company, setCompany] = useState<CompanySummary | null>(null)
  const [title, setTitle] = useState('')
  const [broker, setBroker] = useState<string | null>(null)
  const [target, setTarget] = useState('')
  const [currency, setCurrency] = useState('€')
  const [recommendation, setRecommendation] = useState('')
  const [sectorNote, setSectorNote] = useState(false)
  const [initiationNote, setInitiationNote] = useState(false)
  const [recoChange, setRecoChange] = useState(false)
  const [previousTarget, setPreviousTarget] = useState('')
  const [previousRecommendation, setPreviousRecommendation] = useState('')
  const [sendByEmail, setSendByEmail] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [pickerKey, setPickerKey] = useState(0)
  const [errors, setErrors] = useState<Errors>({})
  const [sendError, setSendError] = useState(false)
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)

  useEffect(() => {
    let current = true
    gateway.listCompanies().then(
      (loaded) => {
        if (current) {
          setCompanies(
            loaded
              .filter((candidate) => !candidate.isArchived)
              .sort((a, b) => a.name.localeCompare(b.name)),
          )
        }
      },
      () => undefined,
    )
    gateway.listBrokers().then(
      (loaded) => {
        if (current) setBrokers(loaded)
      },
      () => undefined,
    )
    gateway.listRecommendations().then(
      (loaded) => {
        if (current) setRecommendations(loaded)
      },
      () => undefined,
    )
    return () => {
      current = false
    }
  }, [gateway])

  function clearError(field: Field) {
    setErrors((existing) => ({ ...existing, [field]: undefined }))
  }

  function reset() {
    setCompany(null)
    setTitle('')
    setBroker(null)
    setTarget('')
    setCurrency('€')
    setRecommendation('')
    setSectorNote(false)
    setInitiationNote(false)
    setRecoChange(false)
    setPreviousTarget('')
    setPreviousRecommendation('')
    setSendByEmail(false)
    setFiles([])
    setPickerKey((key) => key + 1)
  }

  async function send(andContinue: boolean) {
    setSendError(false)
    const found: Errors = {}
    if (!company) found.company = t('brokerNotes.compose.companyRequired')
    if (!broker) found.broker = t('brokerNotes.compose.brokerRequired')
    if (!target.trim()) found.target = t('brokerNotes.compose.targetRequired')
    if (!recommendation) found.type = t('brokerNotes.compose.typeRequired')
    if (recoChange && !previousTarget.trim())
      found.previousTarget = t('brokerNotes.compose.targetRequired')
    if (recoChange && !previousRecommendation)
      found.previousType = t('brokerNotes.compose.typeRequired')
    setErrors(found)
    if (!company || !broker || Object.keys(found).length > 0) return
    setSending(true)
    try {
      await gateway.createBrokerNote(
        {
          emitterId: company.id,
          ...(title.trim() ? { title: title.trim() } : {}),
          broker,
          currency,
          currentObjective: target.trim(),
          currentRecommendation: recommendation,
          sectorNote,
          initiationNote,
          recoChange,
          ...(recoChange
            ? {
                previousObjective: previousTarget.trim(),
                previousRecommendation,
              }
            : {}),
          sendByEmail,
        },
        files,
      )
    } catch {
      setSendError(true)
      setSending(false)
      return
    }
    if (andContinue) {
      reset()
      setSending(false)
      setSent(true)
    } else {
      void navigate('/broker-notes')
    }
  }

  return (
    <>
      <ScreenTitle>{t('brokerNotes.compose.title')}</ScreenTitle>
      {sendError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {t('brokerNotes.compose.sendFailed')}
        </Alert>
      )}
      <Panel>
        <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Autocomplete
            options={companies}
            value={company}
            getOptionLabel={(option) => `${option.name} (${option.ric})`}
            isOptionEqualToValue={(option, chosen) => option.id === chosen.id}
            onChange={(_event, chosen) => {
              setCompany(chosen)
              clearError('company')
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                label={t('brokerNotes.compose.company')}
                placeholder={t('brokerNotes.compose.searchCompanies')}
                error={Boolean(errors.company)}
                helperText={errors.company}
              />
            )}
          />
          <TextField
            label={t('brokerNotes.compose.noteTitle')}
            value={title}
            onChange={(event) => {
              setTitle(event.target.value)
            }}
          />
          <Autocomplete
            options={brokers}
            value={broker}
            onChange={(_event, chosen) => {
              setBroker(chosen)
              clearError('broker')
            }}
            renderInput={(params) => (
              <TextField
                {...params}
                label={t('brokerNotes.compose.broker')}
                placeholder={t('brokerNotes.compose.searchBrokers')}
                error={Boolean(errors.broker)}
                helperText={errors.broker}
              />
            )}
          />
          <SectionHeading>{t('brokerNotes.compose.details')}</SectionHeading>
          <Box sx={{ display: 'flex', gap: 2 }}>
            <TextField
              label={t('brokerNotes.compose.target')}
              placeholder="0.00"
              value={target}
              onChange={(event) => {
                setTarget(event.target.value)
                clearError('target')
              }}
              slotProps={{ htmlInput: { inputMode: 'decimal' } }}
              error={Boolean(errors.target)}
              helperText={errors.target}
              sx={{ flex: 1 }}
            />
            <TextField
              select
              label={t('brokerNotes.compose.currency')}
              value={currency}
              onChange={(event) => {
                setCurrency(event.target.value)
              }}
              sx={{ width: 120 }}
            >
              {currencies.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </TextField>
          </Box>
          <TextField
            select
            label={t('brokerNotes.compose.recommendation')}
            value={recommendation}
            onChange={(event) => {
              setRecommendation(event.target.value)
              clearError('type')
            }}
            error={Boolean(errors.type)}
            helperText={errors.type}
          >
            {recommendations.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </TextField>
          <Box>
            <FormControlLabel
              control={
                <Checkbox
                  checked={sectorNote}
                  onChange={(event) => {
                    setSectorNote(event.target.checked)
                  }}
                />
              }
              label={t('brokerNotes.compose.sector')}
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={initiationNote}
                  onChange={(event) => {
                    setInitiationNote(event.target.checked)
                  }}
                />
              }
              label={t('brokerNotes.compose.initiation')}
            />
          </Box>
          <SectionHeading>{t('brokerNotes.compose.recoChange')}</SectionHeading>
          <FormControlLabel
            control={
              <Switch
                checked={recoChange}
                onChange={(event) => {
                  setRecoChange(event.target.checked)
                  if (!event.target.checked) {
                    clearError('previousTarget')
                    clearError('previousType')
                  }
                }}
              />
            }
            label={t('brokerNotes.compose.recoChange')}
          />
          {recoChange && (
            <>
              <TextField
                label={t('brokerNotes.compose.previousTarget')}
                placeholder="0.00"
                value={previousTarget}
                onChange={(event) => {
                  setPreviousTarget(event.target.value)
                  clearError('previousTarget')
                }}
                slotProps={{ htmlInput: { inputMode: 'decimal' } }}
                error={Boolean(errors.previousTarget)}
                helperText={errors.previousTarget}
              />
              <TextField
                select
                label={t('brokerNotes.compose.previousRecommendation')}
                value={previousRecommendation}
                onChange={(event) => {
                  setPreviousRecommendation(event.target.value)
                  clearError('previousType')
                }}
                error={Boolean(errors.previousType)}
                helperText={errors.previousType}
              >
                {recommendations.map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </TextField>
            </>
          )}
          <AttachmentPicker
            key={pickerKey}
            label={t('brokerNotes.compose.attachments')}
            files={files}
            onChange={setFiles}
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={sendByEmail}
                onChange={(event) => {
                  setSendByEmail(event.target.checked)
                }}
              />
            }
            label={t('brokerNotes.compose.alsoEmail')}
          />
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Button
              variant="contained"
              disabled={sending}
              onClick={() => {
                void send(false)
              }}
            >
              {t('brokerNotes.compose.submit')}
            </Button>
            <Button
              variant="outlined"
              disabled={sending}
              onClick={() => {
                void send(true)
              }}
            >
              {t('brokerNotes.compose.submitContinue')}
            </Button>
          </Box>
        </Box>
      </Panel>
      <Snackbar
        open={sent}
        autoHideDuration={4000}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        onClose={() => {
          setSent(false)
        }}
        message={t('brokerNotes.compose.sent')}
      />
    </>
  )
}
