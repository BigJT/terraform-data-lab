import { describe, expect, it } from 'vitest'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import type { BrokerNoteRequest } from '@/data/types'
import { SendBrokerNoteScreen } from './SendBrokerNoteScreen'

const requiredErrors = [
  'Please enter a company',
  'Please enter a broker',
  'Target is required',
  'Type is required',
]

type User = ReturnType<typeof userEvent.setup>

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen() {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/broker-notes/new']}>
          <Routes>
            <Route path="broker-notes/new" element={<SendBrokerNoteScreen />} />
            <Route path="*" element={<Location />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

/** Records each posted `note` part and answers 201. */
function capturePosts() {
  const posted: BrokerNoteRequest[] = []
  server.use(
    http.post('*/api-admin/broker-note', async ({ request }) => {
      const part = (await request.formData()).get('note') as Blob
      posted.push(JSON.parse(await part.text()) as BrokerNoteRequest)
      return HttpResponse.json({ id: 'new1' }, { status: 201 })
    }),
  )
  return posted
}

async function pick(user: User, name: string, option: string) {
  await user.click(screen.getByRole('combobox', { name }))
  await user.click(await screen.findByRole('option', { name: option }))
}

async function fillValid(user: User) {
  await screen.findByRole('heading', { name: 'Send a broker note' })
  await pick(user, 'Company', 'Danone (DANO.PA)')
  await pick(user, 'Broker', 'Citi')
  await user.type(screen.getByRole('textbox', { name: 'Target' }), ' 70.00 ')
  await pick(user, 'Recommendation', 'BUY')
}

describe('SendBrokerNoteScreen', () => {
  it('shows every required error on an empty Send and sends nothing', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await screen.findByRole('heading', { name: 'Send a broker note' })
    await user.click(screen.getByRole('button', { name: 'Send' }))
    for (const error of requiredErrors) expect(await screen.findByText(error)).toBeInTheDocument()
    expect(posted).toEqual([])
  })

  it('treats the note title as optional', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.click(screen.getByRole('button', { name: 'Send' }))
    await waitFor(() => {
      expect(posted).toHaveLength(1)
    })
    expect(posted[0]).not.toHaveProperty('title')
  })

  it('offers the five currencies with € chosen', async () => {
    const user = userEvent.setup()
    renderScreen()
    const currency = await screen.findByRole('combobox', { name: 'Currency' })
    expect(currency).toHaveTextContent('€')
    await user.click(currency)
    const options = within(await screen.findByRole('listbox')).getAllByRole('option')
    expect(options.map((option) => option.textContent)).toEqual(['€', '$', '£', 'p', 'SFr'])
  })

  it('never offers archived companies', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(await screen.findByRole('combobox', { name: 'Company' }))
    const options = within(await screen.findByRole('listbox')).getAllByRole('option')
    expect(options.map((option) => option.textContent)).toEqual([
      'Accor (ACCP.PA)',
      'Danone (DANO.PA)',
      'Diageo (DGE.L)',
      'Kering (PRTP.PA)',
      'LVMH (LVMH.PA)',
    ])
  })

  it('shows and validates the previous fields only while the switch is on', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    expect(screen.queryByRole('textbox', { name: 'Previous target' })).not.toBeInTheDocument()
    await user.click(screen.getByRole('switch', { name: 'Recommendation change' }))
    expect(screen.getByRole('textbox', { name: 'Previous target' })).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Send' }))
    expect(await screen.findByText('Target is required')).toBeInTheDocument()
    expect(await screen.findByText('Type is required')).toBeInTheDocument()
    expect(posted).toEqual([])
    await user.click(screen.getByRole('switch', { name: 'Recommendation change' }))
    expect(screen.queryByRole('textbox', { name: 'Previous target' })).not.toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Send' }))
    await waitFor(() => {
      expect(posted).toHaveLength(1)
    })
  })

  it('sends a trimmed note without the previous fields when the switch is off', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.type(screen.getByRole('textbox', { name: 'Note title' }), '  Upgrade  ')
    await user.click(screen.getByRole('checkbox', { name: 'Sector' }))
    await user.click(screen.getByRole('button', { name: 'Send' }))
    await waitFor(() => {
      expect(posted).toHaveLength(1)
    })
    expect(posted[0]).toEqual({
      emitterId: 'c2',
      title: 'Upgrade',
      broker: 'Citi',
      currency: '€',
      currentObjective: '70.00',
      currentRecommendation: 'BUY',
      sectorNote: true,
      initiationNote: false,
      recoChange: false,
      sendByEmail: false,
    })
  })

  it('sends the previous fields when the switch is on', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.click(screen.getByRole('switch', { name: 'Recommendation change' }))
    await user.type(screen.getByRole('textbox', { name: 'Previous target' }), '60.00')
    await pick(user, 'Previous recommendation', 'HOLD')
    await user.click(screen.getByRole('button', { name: 'Send' }))
    await waitFor(() => {
      expect(posted).toHaveLength(1)
    })
    expect(posted[0]).toMatchObject({
      recoChange: true,
      previousObjective: '60.00',
      previousRecommendation: 'HOLD',
    })
  })

  it('goes to the list after Send', async () => {
    capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.click(screen.getByRole('button', { name: 'Send' }))
    expect(await screen.findByTestId('location')).toHaveTextContent('/broker-notes')
  })

  it('resets the form and shows the snackbar after Send and continue', async () => {
    const posted = capturePosts()
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.click(screen.getByRole('checkbox', { name: 'Also send by email' }))
    await user.click(screen.getByRole('button', { name: 'Send and continue' }))
    expect(await screen.findByText('Broker note sent')).toBeInTheDocument()
    expect(posted[0]?.sendByEmail).toBe(true)
    expect(screen.getByRole('textbox', { name: 'Target' })).toHaveValue('')
    expect(screen.getByRole('combobox', { name: 'Company' })).toHaveValue('')
    expect(screen.getByRole('checkbox', { name: 'Also send by email' })).not.toBeChecked()
    expect(screen.getByRole('combobox', { name: 'Currency' })).toHaveTextContent('€')
  })

  it('sends the chosen files as attachments parts and clears them after Send and continue', async () => {
    let sizes: number[] = []
    server.use(
      http.post('*/api-admin/broker-note', async ({ request }) => {
        const form = await request.formData()
        sizes = (form.getAll('attachments') as File[]).map((file) => file.size)
        return HttpResponse.json({ id: 'new1' }, { status: 201 })
      }),
    )
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.upload(screen.getByLabelText('Add an attachment input'), [
      new File(['a'], 'a.txt'),
      new File(['b'], 'b.txt'),
    ])
    expect(screen.getByText('Attachments')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Send and continue' }))
    expect(await screen.findByText('Broker note sent')).toBeInTheDocument()
    expect(sizes).toEqual([1, 1])
    expect(screen.queryByText('a.txt')).not.toBeInTheDocument()
  })

  it('clears attachment errors after Send and continue', async () => {
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.upload(screen.getByLabelText('Add an attachment input'), [new File([], 'empty.txt')])
    expect(await screen.findByText('Attachment empty.txt is empty.')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Send and continue' }))
    expect(await screen.findByText('Broker note sent')).toBeInTheDocument()
    expect(screen.queryByText('Attachment empty.txt is empty.')).not.toBeInTheDocument()
  })

  it('shows the failure message and keeps the values on a 500', async () => {
    server.use(
      http.post('*/api-admin/broker-note', () =>
        HttpResponse.json({ message: 'Boom' }, { status: 500 }),
      ),
    )
    const user = userEvent.setup()
    renderScreen()
    await fillValid(user)
    await user.click(screen.getByRole('button', { name: 'Send' }))
    expect(
      await screen.findByText('Unable to create a note right now. Please try again later.'),
    ).toBeInTheDocument()
    expect(screen.getByRole('textbox', { name: 'Target' })).toHaveValue(' 70.00 ')
    expect(screen.queryByTestId('location')).not.toBeInTheDocument()
  })
})
