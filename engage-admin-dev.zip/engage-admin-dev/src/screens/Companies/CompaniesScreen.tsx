import {
  Alert,
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  InputBase,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material'
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { CompanySummary } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'

const columns = [
  'companies.company',
  'companies.ric',
  'companies.sector',
  'companies.users',
  'companies.status',
]

export function CompaniesScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [companies, setCompanies] = useState<CompanySummary[] | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [showArchived, setShowArchived] = useState(false)

  useEffect(() => {
    let current = true
    gateway.listCompanies().then(
      (loaded) => {
        if (current) setCompanies(loaded)
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, i18next.t('companies.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway])

  const rows = useMemo(() => {
    const needle = search.trim().toLowerCase()
    return (companies ?? [])
      .filter((company) => showArchived || !company.isArchived)
      .filter((company) => `${company.name}\n${company.ric}`.toLowerCase().includes(needle))
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [companies, search, showArchived])

  return (
    <>
      <ScreenTitle>{t('shell.companies')}</ScreenTitle>
      <Panel>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2 }}>
          <InputBase
            placeholder={t('companies.search')}
            value={search}
            onChange={(event) => {
              setSearch(event.target.value)
            }}
            inputProps={{ 'aria-label': t('companies.search') }}
            sx={{ flex: 1, px: 1.5, height: 32, border: `1px solid ${colors.rule}`, fontSize: 14 }}
          />
          <FormControlLabel
            control={
              <Checkbox
                size="small"
                checked={showArchived}
                onChange={(event) => {
                  setShowArchived(event.target.checked)
                }}
              />
            }
            label={t('companies.showArchived')}
          />
          <Button
            variant="contained"
            onClick={() => {
              void navigate('/companies/new')
            }}
          >
            {t('companies.add')}
          </Button>
        </Box>
        {error !== null && (
          <Alert severity="error" sx={{ mx: 2, mb: 2 }}>
            {error}
          </Alert>
        )}
        <Table size="small">
          <TableHead>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column} sx={{ fontWeight: 600 }}>
                  {t(column)}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((company) => (
              <TableRow
                key={company.id}
                hover
                onClick={() => {
                  void navigate(`/companies/${company.id}`)
                }}
                sx={{ cursor: 'pointer' }}
              >
                <TableCell>{company.name}</TableCell>
                <TableCell>{company.ric}</TableCell>
                <TableCell>{company.sectors.map((sector) => sector.name).join(', ')}</TableCell>
                <TableCell>{company.associatedAccountsCount}</TableCell>
                <TableCell>
                  {company.isArchived ? t('companies.archived') : t('companies.active')}
                </TableCell>
              </TableRow>
            ))}
            {companies !== null && rows.length === 0 && (
              <TableRow>
                <TableCell colSpan={columns.length} sx={{ color: colors.textSecondary }}>
                  {t('companies.empty')}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Panel>
    </>
  )
}
