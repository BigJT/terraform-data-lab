import { describe, expect, it } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { setLanguage } from '@/i18n'
import { CompaniesScreen } from './CompaniesScreen'

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen() {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/companies']}>
          <Routes>
            <Route path="companies" element={<CompaniesScreen />} />
            <Route path="*" element={<Location />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

function bodyRows() {
  return screen.getAllByRole('row').slice(1)
}

function names() {
  return bodyRows().map((row) => within(row).getAllByRole('cell')[0]?.textContent)
}

describe('CompaniesScreen', () => {
  it('lists active companies by name with the five columns', async () => {
    renderScreen()
    await screen.findByText('LVMH')
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Company',
      'RIC',
      'Sector',
      'Users',
      'Status',
    ])
    expect(names()).toEqual(['Accor', 'Danone', 'Diageo', 'Kering', 'LVMH'])
    const lvmh = within(screen.getByText('LVMH').closest('tr') ?? document.body)
      .getAllByRole('cell')
      .map((cell) => cell.textContent)
    expect(lvmh).toEqual(['LVMH', 'LVMH.PA', 'Luxury/Fashion', '2', 'Active'])
    expect(screen.getByPlaceholderText('Search companies')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Add company' })).toBeInTheDocument()
  })

  it('shows archived companies only while the checkbox is ticked', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    expect(screen.queryByText('Worldline')).not.toBeInTheDocument()
    const box = screen.getByRole('checkbox', { name: 'Show archived companies' })
    expect(box).not.toBeChecked()
    await user.click(box)
    const row = screen.getByText('Worldline').closest('tr')
    expect(row).not.toBeNull()
    expect(within(row as HTMLElement).getByText('Archived')).toBeInTheDocument()
    await user.click(box)
    expect(screen.queryByText('Worldline')).not.toBeInTheDocument()
  })

  it('filters on name or RIC, case-insensitively, and restores on clear', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    const search = screen.getByPlaceholderText('Search companies')
    await user.type(search, 'dan')
    expect(names()).toEqual(['Danone'])
    await user.clear(search)
    expect(bodyRows()).toHaveLength(5)
    await user.type(search, 'dge.l')
    expect(names()).toEqual(['Diageo'])
  })

  it('searches archived companies only when they are shown', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.type(screen.getByPlaceholderText('Search companies'), 'wln')
    expect(screen.getByText('No companies found')).toBeInTheDocument()
    await user.click(screen.getByRole('checkbox', { name: 'Show archived companies' }))
    expect(names()).toEqual(['Worldline'])
  })

  it('opens the company on row click and the wizard on Add company', async () => {
    const user = userEvent.setup()
    renderScreen()
    await user.click(await screen.findByText('Danone'))
    expect(screen.getByTestId('location')).toHaveTextContent('/companies/c2')
  })

  it('goes to /companies/new from Add company', async () => {
    const user = userEvent.setup()
    renderScreen()
    await screen.findByText('LVMH')
    await user.click(screen.getByRole('button', { name: 'Add company' }))
    expect(screen.getByTestId('location')).toHaveTextContent('/companies/new')
  })

  it('shows the gateway message when loading fails', async () => {
    server.use(
      http.get('*/api-admin/emitters-management/emitter', () =>
        HttpResponse.json({ message: 'Database down' }, { status: 500 }),
      ),
    )
    renderScreen()
    expect(await screen.findByRole('alert')).toHaveTextContent('Database down')
  })

  it('shows its own French text when the error body has no message', async () => {
    setLanguage('fr')
    server.use(
      http.get(
        '*/api-admin/emitters-management/emitter',
        () => new HttpResponse(null, { status: 500, statusText: 'Internal Server Error' }),
      ),
    )
    renderScreen()
    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Impossible de charger les émetteurs',
    )
  })

  it('shows its own French text when the request never reaches the gateway', async () => {
    setLanguage('fr')
    server.use(http.get('*/api-admin/emitters-management/emitter', () => HttpResponse.error()))
    renderScreen()
    expect(await screen.findByRole('alert')).toHaveTextContent(
      'Impossible de charger les émetteurs',
    )
  })
})
