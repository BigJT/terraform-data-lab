import { describe, expect, it } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { setLanguage } from '@/i18n'
import { CompaniesScreen } from '@/screens/Companies/CompaniesScreen'
import { AddCompanyScreen } from '@/screens/AddCompany/AddCompanyScreen'
import { CompanyDetailScreen } from '@/screens/CompanyDetail/CompanyDetailScreen'

function renderFrench(path: string) {
  setLanguage('fr')
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[path]}>
          <Routes>
            <Route path="companies" element={<CompaniesScreen />} />
            <Route path="companies/new" element={<AddCompanyScreen />} />
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

describe('companies screens in French', () => {
  it('list: search, archived switch, add button, columns and status', async () => {
    renderFrench('/companies')
    expect(await screen.findAllByText('Actif', { selector: 'td' })).not.toHaveLength(0)
    expect(screen.getByPlaceholderText('Rechercher un émetteur')).toBeInTheDocument()
    expect(screen.getByLabelText('Afficher les émetteurs archivés')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Ajouter un émetteur' })).toBeInTheDocument()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Valeurs',
      'Id ric',
      'Secteur',
      'Utilisateurs associés',
      'Statut',
    ])
  })

  it('list: an empty search shows the French empty text', async () => {
    const user = renderFrench('/companies')
    await screen.findAllByText('Actif', { selector: 'td' })
    await user.type(screen.getByPlaceholderText('Rechercher un émetteur'), 'zzzz')
    expect(screen.getByText('Aucun émetteur trouvé')).toBeInTheDocument()
  })

  it('detail: tabs, archive button, indices and the edit dialog', async () => {
    const user = renderFrench('/companies/c1')
    expect(await screen.findByRole('button', { name: 'Archiver' })).toBeInTheDocument()
    expect(screen.getAllByRole('tab').map((tab) => tab.textContent)).toEqual([
      'Informations',
      'Listes',
      'Utilisateurs',
      'Imports',
      'Factset',
    ])
    expect(screen.getByText('Indice 1', { selector: 'dt' })).toBeInTheDocument()
    expect(screen.getByText('INDICES')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Modifier' }))
    const dialog = await screen.findByRole('dialog', { name: 'Modifier les indices' })
    expect(within(dialog).getByRole('button', { name: 'Annuler' })).toBeInTheDocument()
    expect(within(dialog).getByRole('button', { name: 'Enregistrer' })).toBeInTheDocument()
  })

  it('detail: an archived company shows the French banner and Désarchiver', async () => {
    const user = renderFrench('/companies/c1')
    await user.click(await screen.findByRole('button', { name: 'Archiver' }))
    expect(await screen.findByText('Attention ! Émetteur archivé')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Désarchiver' })).toBeInTheDocument()
  })

  it('detail: an unknown company shows the French not-found text', async () => {
    renderFrench('/companies/nope')
    expect(await screen.findByText('Émetteur introuvable')).toBeInTheDocument()
  })

  it('lists tab: French plural counts, create dialog and required error', async () => {
    const user = renderFrench('/companies/c1/lists')
    expect(await screen.findByText('3 éléments')).toBeInTheDocument()
    expect(screen.getByText('1 élément')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Créer une liste' }))
    const dialog = await screen.findByRole('dialog', { name: 'Créer une liste' })
    expect(within(dialog).getByPlaceholderText('rechercher un pair')).toBeInTheDocument()
    await user.click(within(dialog).getByRole('button', { name: 'Enregistrer' }))
    expect(within(dialog).getByText('Requis')).toBeInTheDocument()
  })

  it('lists tab: the delete item dialog is French', async () => {
    const user = renderFrench('/companies/c1/lists')
    await user.click(await screen.findByText('Luxury peers'))
    await screen.findByText('PRTP.PA')
    await user.click(screen.getAllByRole('button', { name: 'Supprimer' })[3] ?? document.body)
    const dialog = await screen.findByRole('dialog', { name: "Suppression d'un élément" })
    expect(
      within(dialog).getByText('Êtes-vous sûr de vouloir supprimer PRTP.PA ?'),
    ).toBeInTheDocument()
    expect(within(dialog).getByText('Cette action est irréversible')).toBeInTheDocument()
    expect(within(dialog).getByRole('button', { name: 'Oui' })).toBeInTheDocument()
  })

  it('users tab: columns, edit read dates and the validation error', async () => {
    const user = renderFrench('/companies/c1/users')
    await screen.findByText('Claire Martin')
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Nom',
      'Poste',
      'Adresse e-mail',
      'N° de téléphone',
      'CGU acceptées le',
      '',
    ])
    const claire = screen.getByText('Claire Martin').closest('tr') as HTMLElement
    await user.click(within(claire).getByRole('button', { name: 'Modifier' }))
    const dialog = await screen.findByRole('dialog', { name: "Modifier l'utilisateur" })
    expect(within(dialog).getByText(/Date de dernière lecture de daily report/)).toBeInTheDocument()
    expect(within(dialog).getByText(/Date de dernière lecture de flash/)).toBeInTheDocument()
    await user.clear(within(dialog).getByLabelText('E-mail'))
    await user.click(within(dialog).getByRole('button', { name: 'Enregistrer' }))
    expect(within(dialog).getByText("L'email est requis")).toBeInTheDocument()
  })

  it('imports tab and factset tab labels', async () => {
    const user = renderFrench('/companies/c1/imports')
    expect(await screen.findByRole('button', { name: 'Importer un fichier' })).toBeInTheDocument()
    expect(screen.getByText('Choisir un type')).toBeInTheDocument()
    await user.click(screen.getByRole('tab', { name: 'Factset' }))
    expect(
      await screen.findByRole('button', { name: 'Ajouter un nouveau pair Factset' }),
    ).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Rechercher' })).toBeInTheDocument()
  })

  it('factset tab: saving shows the French toast', async () => {
    const user = renderFrench('/companies/c1/factset')
    await user.click(await screen.findByRole('button', { name: 'Enregistrer' }))
    expect(await screen.findByText('Enregistrement effectué avec succès')).toBeInTheDocument()
  })

  it('wizard: steps, labels and required errors in French', async () => {
    const user = renderFrench('/companies/new')
    expect(await screen.findByText('1. Informations')).toBeInTheDocument()
    expect(screen.getByLabelText('ID RIC')).toBeInTheDocument()
    expect(screen.getByLabelText('Français')).toBeInTheDocument()
    await user.type(screen.getByLabelText('ID RIC'), 'ZZZZ.PA')
    await user.click(screen.getByRole('button', { name: 'Suivant' }))
    expect(await screen.findByText("Ce code RIC n'existe pas")).toBeInTheDocument()
    expect(screen.getByText('Le nom est requis')).toBeInTheDocument()
    expect(screen.getByText('Le marché est requis')).toBeInTheDocument()
  })

  it('wizard: user step shows French labels and email errors', async () => {
    const user = renderFrench('/companies/new')
    await user.type(await screen.findByLabelText('ID RIC'), 'OREP.PA')
    await user.type(screen.getByLabelText('Nom'), "L'Oreal")
    await user.click(screen.getByRole('combobox', { name: 'Marché' }))
    await user.click(screen.getByRole('option', { name: 'Euronext Paris' }))
    await user.click(screen.getByRole('combobox', { name: 'Secteur' }))
    await user.click(screen.getByRole('option', { name: 'Luxury' }))
    await user.click(screen.getByRole('button', { name: 'Suivant' }))
    expect(await screen.findByRole('combobox', { name: 'Indice 1' })).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Suivant' }))
    await user.click(await screen.findByRole('button', { name: 'Ajouter un utilisateur' }))
    expect(screen.getByText('Utilisateur 1')).toBeInTheDocument()
    await user.type(screen.getByLabelText('E-mail'), 'pas-un-email')
    await user.click(screen.getByRole('button', { name: 'Ajouter' }))
    expect(screen.getByText("Format d'email invalide")).toBeInTheDocument()
    expect(screen.getByText('Le prénom est requis')).toBeInTheDocument()
  })
})
