import { Box, Button } from '@mui/material'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { Panel } from '@/ds/components'
import { useAuth } from '@/auth/authContext'

export function SignInScreen() {
  const { signIn } = useAuth()
  const { t } = useTranslation()
  return (
    <Box
      component="main"
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: colors.canvas,
      }}
    >
      <Panel>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 3,
            px: 6,
            py: 5,
          }}
        >
          <Box
            component="h1"
            sx={{ m: 0, fontSize: 24, fontWeight: 700, color: colors.textPrimary }}
          >
            Engage Admin
          </Box>
          <Button variant="contained" onClick={() => void signIn()}>
            {t('signIn.button')}
          </Button>
        </Box>
      </Panel>
    </Box>
  )
}
