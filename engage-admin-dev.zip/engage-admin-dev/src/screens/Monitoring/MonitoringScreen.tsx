import {
  Alert,
  Box,
  Button,
  LinearProgress,
  MenuItem,
  Pagination,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
} from '@mui/material'
import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { DisconnectionLog, DisconnectionStats, Page } from '@/data/types'
import { formatSent } from '@/screens/Flashes/formatSent'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { labelFor, platformCodes, reasonCodes } from './labels'

const pageSize = 20
const periods = [7, 30, 90]
const columns = ['date', 'user', 'platform', 'reason', 'ip', 'agent', 'details']

interface Filters {
  userEmail: string
  startDate: string
  endDate: string
  platform: string
  reason: string
}

const noFilters: Filters = { userEmail: '', startDate: '', endDate: '', platform: '', reason: '' }

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <Box sx={{ p: 2 }}>
      <Box component="h2" sx={{ m: 0, mb: 1.5, fontSize: 18, fontWeight: 600 }}>
        {title}
      </Box>
      {children}
    </Box>
  )
}

function Figure({ label, value }: { label: string; value: number }) {
  return (
    <Box sx={{ minWidth: 160 }}>
      <Box sx={{ fontSize: 13, color: colors.textSecondary }}>{label}</Box>
      <Box sx={{ fontSize: 24, fontWeight: 600 }}>{value}</Box>
    </Box>
  )
}

function Breakdown({
  title,
  entries,
  total,
}: {
  title: string
  entries: [string, number][]
  total: number
}) {
  const shown = entries
    .filter(([, count]) => count > 0)
    .sort(([a, x], [b, y]) => y - x || a.localeCompare(b))
  return (
    <Box sx={{ flex: 1, minWidth: 280 }}>
      <Box sx={{ fontWeight: 600, mb: 1 }}>{title}</Box>
      {shown.map(([label, count]) => {
        const percentage = (count / total) * 100
        return (
          <Box key={label} sx={{ mb: 1.5 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
              <span>{label}</span>
              <span>{`${String(count)} (${percentage.toFixed(1)}%)`}</span>
            </Box>
            <LinearProgress variant="determinate" value={percentage} />
          </Box>
        )
      })}
    </Box>
  )
}

export function MonitoringScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [days, setDays] = useState(7)
  const [stats, setStats] = useState<DisconnectionStats | null>(null)
  const [draft, setDraft] = useState<Filters>(noFilters)
  const [applied, setApplied] = useState<Filters>(noFilters)
  const [page, setPage] = useState(0)
  const [loaded, setLoaded] = useState<{ key: string; page: Page<DisconnectionLog> } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [logsFailure, setLogsFailure] = useState<{ key: string; message: string } | null>(null)
  const [refreshes, setRefreshes] = useState(0)
  const [logReloads, setLogReloads] = useState(0)

  useEffect(() => {
    let current = true
    gateway.getDisconnectionStats(days).then(
      (loaded) => {
        if (!current) return
        setStats(loaded)
        setError(null)
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, t('monitoring.statsFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, days, refreshes, t])

  const logsKey = JSON.stringify([applied, page, refreshes, logReloads])
  useEffect(() => {
    let current = true
    gateway.listDisconnections({ page, size: pageSize, ...applied }).then(
      (logs) => {
        if (!current) return
        setLoaded({ key: logsKey, page: logs })
      },
      (failure: unknown) => {
        if (current)
          setLogsFailure({
            key: logsKey,
            message: gatewayMessage(failure, t('monitoring.logsFailed')),
          })
      },
    )
    return () => {
      current = false
    }
  }, [gateway, applied, page, refreshes, logReloads, logsKey, t])
  const result = loaded?.key === logsKey ? loaded.page : null
  const logsError = logsFailure?.key === logsKey ? logsFailure.message : null

  const count = (platform: string) =>
    stats?.platformBreakdown.find((entry) => entry.platform === platform)?.count ?? 0
  const rows = result?.content ?? []
  const totalPages = result?.totalPages ?? 0
  const setFilter = (name: keyof Filters, value: string) => {
    setDraft((previous) => ({ ...previous, [name]: value }))
  }
  const dateProps = {
    type: 'date',
    size: 'small',
    slotProps: { inputLabel: { shrink: true } },
  } as const
  const selectProps = {
    select: true,
    size: 'small',
    sx: { minWidth: 180 },
    slotProps: { inputLabel: { shrink: true }, select: { displayEmpty: true } },
  } as const

  return (
    <>
      <ScreenTitle>{t('monitoring.title')}</ScreenTitle>
      <Panel>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2 }}>
          <TextField
            {...selectProps}
            label={t('monitoring.period')}
            value={days}
            onChange={(event) => {
              setDays(Number(event.target.value))
            }}
          >
            {periods.map((period) => (
              <MenuItem key={period} value={period}>
                {t('monitoring.days', { n: period })}
              </MenuItem>
            ))}
          </TextField>
          <Button
            variant="outlined"
            onClick={() => {
              setRefreshes((previous) => previous + 1)
            }}
          >
            {t('monitoring.refresh')}
          </Button>
        </Box>
        {error !== null && (
          <Alert severity="error" sx={{ mx: 2, mb: 2 }}>
            {error}
          </Alert>
        )}
        <Section title={t('monitoring.overview')}>
          <Box sx={{ display: 'flex', gap: 4 }}>
            <Figure label={t('monitoring.total')} value={stats?.totalDisconnections ?? 0} />
            <Figure label={labelFor(t, 'platforms', 'DESKTOP')} value={count('DESKTOP')} />
            <Figure label={labelFor(t, 'platforms', 'MOBILE')} value={count('MOBILE')} />
          </Box>
        </Section>
        <Section title={t('monitoring.analysis')}>
          <Box sx={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
            <Breakdown
              title={t('monitoring.byReason')}
              entries={(stats?.reasonBreakdown ?? []).map((entry) => [
                labelFor(t, 'reasons', entry.reason),
                entry.count,
              ])}
              total={stats?.totalDisconnections ?? 0}
            />
            <Breakdown
              title={t('monitoring.byPlatform')}
              entries={(stats?.platformBreakdown ?? []).map((entry) => [
                labelFor(t, 'platforms', entry.platform),
                entry.count,
              ])}
              total={stats?.totalDisconnections ?? 0}
            />
          </Box>
        </Section>
        <Section title={t('monitoring.allLogs')}>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center', mb: 2 }}>
            <TextField
              size="small"
              label={t('monitoring.filters.userEmail')}
              value={draft.userEmail}
              onChange={(event) => {
                setFilter('userEmail', event.target.value)
              }}
            />
            <TextField
              {...dateProps}
              label={t('monitoring.filters.from')}
              value={draft.startDate}
              onChange={(event) => {
                setFilter('startDate', event.target.value)
              }}
            />
            <TextField
              {...dateProps}
              label={t('monitoring.filters.to')}
              value={draft.endDate}
              onChange={(event) => {
                setFilter('endDate', event.target.value)
              }}
            />
            <TextField
              {...selectProps}
              label={t('monitoring.filters.platform')}
              value={draft.platform}
              onChange={(event) => {
                setFilter('platform', event.target.value)
              }}
            >
              <MenuItem value="">{t('monitoring.filters.allPlatforms')}</MenuItem>
              {platformCodes.map((code) => (
                <MenuItem key={code} value={code}>
                  {labelFor(t, 'platforms', code)}
                </MenuItem>
              ))}
            </TextField>
            <TextField
              {...selectProps}
              label={t('monitoring.filters.reason')}
              value={draft.reason}
              onChange={(event) => {
                setFilter('reason', event.target.value)
              }}
            >
              <MenuItem value="">{t('monitoring.filters.allReasons')}</MenuItem>
              {reasonCodes.map((code) => (
                <MenuItem key={code} value={code}>
                  {labelFor(t, 'reasons', code)}
                </MenuItem>
              ))}
            </TextField>
            <Button
              variant="contained"
              onClick={() => {
                setApplied(draft)
                setPage(0)
                setLogReloads((previous) => previous + 1)
              }}
            >
              {t('monitoring.filters.apply')}
            </Button>
            <Button
              variant="outlined"
              onClick={() => {
                setDraft(noFilters)
                setApplied(noFilters)
                setPage(0)
                setLogReloads((previous) => previous + 1)
              }}
            >
              {t('monitoring.filters.clear')}
            </Button>
          </Box>
          <Table size="small">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={column} sx={{ fontWeight: 600 }}>
                    {t(`monitoring.columns.${column}`)}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((log) => (
                <TableRow key={log.id}>
                  <TableCell>{formatSent(log.createdAt)}</TableCell>
                  <TableCell>{log.userEmail}</TableCell>
                  <TableCell>{labelFor(t, 'platforms', log.platform)}</TableCell>
                  <TableCell>{labelFor(t, 'reasons', log.reason)}</TableCell>
                  <TableCell>{log.ipAddress}</TableCell>
                  <TableCell>{log.userAgent}</TableCell>
                  <TableCell>{log.details}</TableCell>
                </TableRow>
              ))}
              {(result === null || rows.length === 0) && (
                <TableRow>
                  <TableCell colSpan={columns.length} sx={{ color: colors.textSecondary }}>
                    {result !== null
                      ? t('monitoring.empty')
                      : (logsError ?? t('monitoring.loading'))}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
          {result !== null && (
            <Box
              sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', pt: 2 }}
            >
              <Box sx={{ fontSize: 14, color: colors.textSecondary }}>
                {t('monitoring.summary', {
                  total: result.totalElements,
                  page: result.number + 1,
                  pages: Math.max(totalPages, 1),
                })}
              </Box>
              <Pagination
                count={totalPages}
                page={page + 1}
                onChange={(_event, next) => {
                  setPage(next - 1)
                }}
              />
            </Box>
          )}
        </Section>
      </Panel>
    </>
  )
}
