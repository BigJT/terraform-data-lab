import { describe, expect, it } from 'vitest'
import { delay, http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { MonitoringScreen } from './MonitoringScreen'

function renderMonitoring() {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter>
          <MonitoringScreen />
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

function parentOf(element: HTMLElement): HTMLElement {
  if (!element.parentElement) throw new Error('No parent element')
  return element.parentElement
}

const figure = (label: string) => parentOf(screen.getByText(label))
const breakdown = (title: string) => parentOf(screen.getByText(title))
const emptyPage = { content: [], totalElements: 0, totalPages: 0, number: 0, size: 20 }

describe('MonitoringScreen', () => {
  it('shows the heading, sections and the 7-day overview', async () => {
    renderMonitoring()
    expect(
      screen.getByRole('heading', { level: 1, name: 'Disconnection monitoring' }),
    ).toBeVisible()
    for (const name of ['Overview', 'Analysis', 'All disconnection logs']) {
      expect(screen.getByRole('heading', { name })).toBeVisible()
    }
    await waitFor(() => {
      expect(within(figure('Total disconnections')).getByText('4')).toBeVisible()
    })
    const overview = parentOf(screen.getByRole('heading', { name: 'Overview' }))
    expect(within(parentOf(within(overview).getByText('Desktop app'))).getByText('2')).toBeVisible()
    expect(within(parentOf(within(overview).getByText('Mobile app'))).getByText('2')).toBeVisible()
  })

  it('reloads the figures when the period changes', async () => {
    const user = renderMonitoring()
    await screen.findByText('Total disconnections')
    await user.click(screen.getByRole('combobox', { name: 'Analysis period:' }))
    await user.click(screen.getByRole('option', { name: '90 days' }))
    await waitFor(() => {
      expect(within(figure('Total disconnections')).getByText('45')).toBeVisible()
    })
  })

  it('lists reason and platform bars with counts and one-decimal percentages', async () => {
    renderMonitoring()
    expect(await screen.findAllByText('1 (25.0%)')).toHaveLength(4)
    expect(screen.getAllByText('2 (50.0%)')).toHaveLength(2)
    expect(screen.getByText('Breakdown by disconnection reason')).toBeVisible()
    expect(screen.getByText('Breakdown by platform')).toBeVisible()
    expect(
      within(breakdown('Breakdown by disconnection reason')).getByText('Session expired'),
    ).toBeVisible()
    expect(screen.getAllByRole('progressbar')).toHaveLength(6)
    expect(screen.queryByText(/\(0\.0%\)/)).not.toBeInTheDocument()
  })

  it('sorts by count descending then label ascending and shows unknown codes as-is', async () => {
    server.use(
      http.get('*/api-admin/disconnections/stats', () =>
        HttpResponse.json({
          days: 7,
          totalDisconnections: 3,
          reasonBreakdown: [
            { reason: 'TOKEN_REVOKED', count: 1 },
            { reason: 'MYSTERY', count: 1 },
            { reason: 'TOKEN_EXPIRED', count: 1 },
          ],
          platformBreakdown: [],
        }),
      ),
    )
    renderMonitoring()
    await screen.findByText('MYSTERY')
    const labels = within(breakdown('Breakdown by disconnection reason'))
      .getAllByText(/^(Access revoked|MYSTERY|Session expired)$/)
      .map((node) => node.textContent)
    expect(labels).toEqual(['Access revoked', 'MYSTERY', 'Session expired'])
    expect(screen.getAllByText('1 (33.3%)')).toHaveLength(3)
  })

  it('shows the log table, date format, labels and caption', async () => {
    renderMonitoring()
    expect(screen.getByText('Loading logs...')).toBeVisible()
    await screen.findByText('Mock disconnection 1')
    for (const name of [
      'Date',
      'User',
      'Platform',
      'Reason',
      'IP address',
      'Browser/System',
      'Details',
    ]) {
      expect(screen.getByRole('columnheader', { name })).toBeVisible()
    }
    expect(screen.getAllByRole('row')).toHaveLength(21)
    const first = screen.getAllByRole('row')[1] ?? document.body
    const cells = within(first).getAllByRole('cell')
    expect(cells[0]).toHaveTextContent(/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)
    expect(cells[1]).toHaveTextContent('claire.martin@lvmh.example')
    expect(cells[2]).toHaveTextContent('Desktop app')
    expect(cells[3]).toHaveTextContent('Session expired')
    expect(screen.getByText('45 logs in total • Page 1 of 3')).toBeVisible()
  })

  it('goes to the next page', async () => {
    const user = renderMonitoring()
    await screen.findByText('Mock disconnection 1')
    await user.click(screen.getByRole('button', { name: 'Go to page 3' }))
    expect(await screen.findByText('45 logs in total • Page 3 of 3')).toBeVisible()
    expect(screen.getAllByRole('row')).toHaveLength(6)
  })

  it('applies filters from page 1 and clears them', async () => {
    const user = renderMonitoring()
    await screen.findByText('Mock disconnection 1')
    await user.click(screen.getByRole('combobox', { name: 'Platform' }))
    await user.click(screen.getByRole('option', { name: 'Mobile app' }))
    await user.click(screen.getByRole('combobox', { name: 'Reason' }))
    await user.click(screen.getByRole('option', { name: 'Access revoked' }))
    await user.click(screen.getByRole('button', { name: 'Apply filters' }))
    expect(await screen.findByText('2 logs in total • Page 1 of 1')).toBeVisible()
    expect(screen.getAllByRole('row')).toHaveLength(3)

    await user.click(screen.getByRole('button', { name: 'Clear filters' }))
    expect(await screen.findByText('45 logs in total • Page 1 of 3')).toBeVisible()
    expect(screen.getByRole('combobox', { name: 'Platform' })).toHaveTextContent('All platforms')
  })

  it('sends the email filter and shows the empty state', async () => {
    const user = renderMonitoring()
    await screen.findByText('Mock disconnection 1')
    await user.type(screen.getByRole('textbox', { name: 'User email' }), 'zzz')
    await user.click(screen.getByRole('button', { name: 'Apply filters' }))
    expect(await screen.findByText('No disconnection logs found.')).toBeVisible()
    expect(screen.getByText('0 logs in total • Page 1 of 1')).toBeVisible()
  })

  it('sends the date filters', async () => {
    const urls: string[] = []
    server.use(
      http.get('*/api-admin/disconnections', ({ request }) => {
        urls.push(request.url)
        return HttpResponse.json(emptyPage)
      }),
    )
    const user = renderMonitoring()
    await screen.findByText('No disconnection logs found.')
    await user.type(screen.getByLabelText('From'), '2026-10-01')
    await user.type(screen.getByLabelText('To'), '2026-10-05')
    await user.click(screen.getByRole('button', { name: 'Apply filters' }))
    await waitFor(() => {
      expect(urls).toHaveLength(2)
    })
    const params = new URL(urls[1] ?? '').searchParams
    expect(params.get('startDate')).toBe('2026-10-01')
    expect(params.get('endDate')).toBe('2026-10-05')
  })

  it('reloads the list on a repeat Apply and on Clear with nothing changed', async () => {
    let calls = 0
    server.use(
      http.get('*/api-admin/disconnections', () => {
        calls += 1
        return HttpResponse.json(emptyPage)
      }),
    )
    const user = renderMonitoring()
    await screen.findByText('No disconnection logs found.')
    expect(calls).toBe(1)
    await user.click(screen.getByRole('button', { name: 'Apply filters' }))
    await waitFor(() => {
      expect(calls).toBe(2)
    })
    await user.click(screen.getByRole('button', { name: 'Clear filters' }))
    await waitFor(() => {
      expect(calls).toBe(3)
    })
  })

  it('Refresh reloads the stats and the current page', async () => {
    let statsCalls = 0
    server.use(
      http.get('*/api-admin/disconnections/stats', async () => {
        statsCalls += 1
        await delay(0)
        return HttpResponse.json({
          days: 7,
          totalDisconnections: 0,
          reasonBreakdown: [],
          platformBreakdown: [],
        })
      }),
    )
    const user = renderMonitoring()
    await screen.findByText('Mock disconnection 1')
    await waitFor(() => {
      expect(statsCalls).toBe(1)
    })
    await user.click(screen.getByRole('button', { name: 'Refresh' }))
    await waitFor(() => {
      expect(statsCalls).toBe(2)
    })
  })

  it('shows a load failure', async () => {
    server.use(
      http.get('*/api-admin/disconnections', () =>
        HttpResponse.json({ message: 'Boom' }, { status: 500 }),
      ),
    )
    renderMonitoring()
    expect(await screen.findByText('Boom')).toBeVisible()
    expect(screen.queryByText('Loading logs...')).toBeNull()
  })

  it('keeps a stats failure on screen after the logs load', async () => {
    server.use(
      http.get('*/api-admin/disconnections/stats', () =>
        HttpResponse.json({ message: 'Stats down' }, { status: 500 }),
      ),
      http.get('*/api-admin/disconnections', async () => {
        await delay(50)
        return HttpResponse.json(emptyPage)
      }),
    )
    renderMonitoring()
    expect(await screen.findByText('Stats down')).toBeVisible()
    expect(await screen.findByText('No disconnection logs found.')).toBeVisible()
    expect(screen.getByText('Stats down')).toBeVisible()
  })
})
