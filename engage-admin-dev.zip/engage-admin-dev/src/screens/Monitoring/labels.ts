export const reasonCodes = [
  'TOKEN_EXPIRED',
  'TOKEN_INVALID_SIGNATURE',
  'TOKEN_REVOKED',
  'USER_NOT_FOUND',
  'SESSION_CORRUPTED',
  'TOKEN_REPLACED_BY_NEW_LOGIN',
  'TOKEN_MALFORMED',
  'TOKEN_INVALID',
  'USER_DEACTIVATED',
  'INSUFFICIENT_ROLES',
  'MANUAL_LOGOUT',
]

export const platformCodes = ['DESKTOP', 'MOBILE']

/** The translated label for a code, or the code itself when unknown. */
export function labelFor(
  t: (key: string, options?: { defaultValue: string }) => string,
  group: 'reasons' | 'platforms',
  code: string,
): string {
  return t(`monitoring.${group}.${code}`, { defaultValue: code })
}
