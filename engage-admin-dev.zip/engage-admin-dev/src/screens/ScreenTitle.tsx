import { Box } from '@mui/material'
import type { ReactNode } from 'react'
import { colors } from '@/ds/theme'

export function ScreenTitle({ children }: { children: ReactNode }) {
  return (
    <Box
      component="h1"
      sx={{ m: 0, mb: 2, fontSize: 24, fontWeight: 600, color: colors.textPrimary }}
    >
      {children}
    </Box>
  )
}
