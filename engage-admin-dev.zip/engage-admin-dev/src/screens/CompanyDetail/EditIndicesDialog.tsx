import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  TextField,
} from '@mui/material'
import { useEffect, useState } from 'react'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { CompanyDetail, IndexInfo } from '@/data/types'
import { availableIndices } from '@/screens/indexOptions'

const none = 'none'

interface EditIndicesDialogProps {
  company: CompanyDetail
  onClose: () => void
  onSaved: () => void
}

export function EditIndicesDialog({ company, onClose, onSaved }: EditIndicesDialogProps) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [all, setAll] = useState<IndexInfo[]>([])
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const [chosen, setChosen] = useState<string[]>([
    company.primaryIndice1?.codeRIC ?? none,
    company.primaryIndice2?.codeRIC ?? none,
    company.primaryIndice3?.codeRIC ?? none,
    company.primaryIndice4?.codeRIC ?? none,
  ])

  useEffect(() => {
    let current = true
    gateway.listIndices().then(
      (loaded) => {
        if (current) setAll(loaded)
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, i18next.t('companyDetail.indicesLoadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway])

  function save() {
    const rics = chosen.map((ric) => (ric === none ? null : ric))
    setSaving(true)
    setError('')
    gateway
      .updateCompanyIndices(company.id, {
        primaryIndiceRic1: rics[0] ?? null,
        primaryIndiceRic2: rics[1] ?? null,
        primaryIndiceRic3: rics[2] ?? null,
        primaryIndiceRic4: rics[3] ?? null,
      })
      .then(onSaved, (failure: unknown) => {
        setError(gatewayMessage(failure, i18next.t('companyDetail.indicesSaveFailed')))
        setSaving(false)
      })
  }

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{t('companyDetail.editIndices')}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          {error ? <Alert severity="error">{error}</Alert> : null}
          {(all.length === 0 ? [] : chosen).map((value, slot) => (
            <TextField
              key={slot}
              select
              size="small"
              label={t('fields.index', { n: slot + 1 })}
              value={value}
              onChange={(event) => {
                setChosen(
                  chosen.map((ric, position) => (position === slot ? event.target.value : ric)),
                )
              }}
            >
              <MenuItem value={none}>{t('common.none')}</MenuItem>
              {availableIndices(
                all,
                chosen.map((ric) => (ric === none ? null : ric)),
                slot,
              ).map((index) => (
                <MenuItem key={index.codeRIC} value={index.codeRIC}>
                  {`${index.codeRIC} ${index.name}`}
                </MenuItem>
              ))}
            </TextField>
          ))}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.cancel')}</Button>
        <Button variant="contained" onClick={save} disabled={saving || all.length === 0}>
          {t('common.save')}
        </Button>
      </DialogActions>
    </Dialog>
  )
}
