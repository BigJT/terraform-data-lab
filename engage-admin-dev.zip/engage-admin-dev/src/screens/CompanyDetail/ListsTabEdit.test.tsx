import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { CompanyDetailScreen } from './CompanyDetailScreen'

type User = ReturnType<typeof userEvent.setup>

function renderLists(id: string) {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/companies/${id}/lists`]}>
          <Routes>
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

function parentRow(element: HTMLElement) {
  return element.parentElement ?? element
}

async function rowButton(user: User, listName: string, button: string) {
  const row = parentRow(await screen.findByText(listName))
  await user.click(within(row).getByRole('button', { name: button }))
}

async function openAddItem(user: User, listName: string) {
  await rowButton(user, listName, 'Add an item')
  return screen.findByRole('dialog', { name: 'Add an item' })
}

describe('Add an item', () => {
  it('looks up the RIC, saves, closes and updates the count', async () => {
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.type(within(dialog).getByLabelText('Ticker'), 'HRMS.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('2 items')).toBeInTheDocument()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    await user.click(screen.getByText('European consumer'))
    expect(await screen.findByText('Hermes International', { selector: 'div' })).toBeVisible()
  })

  it('rejects an unknown RIC and keeps the dialog open', async () => {
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.type(within(dialog).getByLabelText('Ticker'), 'ZZZZ.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await within(dialog).findByText('This RIC code does not exist')).toBeInTheDocument()
  })

  it('rejects a RIC the list already holds, ignoring case', async () => {
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.type(within(dialog).getByLabelText('Ticker'), 'orep.pa')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(
      await within(dialog).findByText('This ticker is already in the list'),
    ).toBeInTheDocument()
  })

  it('asks for a ticker when the field is blank', async () => {
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(within(dialog).getByText('Required')).toBeInTheDocument()
  })

  it('shows a server failure verbatim in the dialog', async () => {
    server.use(
      http.put('*/api-admin/tickers/:listId/ticker', () =>
        HttpResponse.json({ message: 'Ticker service down' }, { status: 500 }),
      ),
    )
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.type(within(dialog).getByLabelText('Ticker'), 'AIR.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await within(dialog).findByText('Ticker service down')).toBeInTheDocument()
  })

  it('Cancel closes without adding', async () => {
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.type(within(dialog).getByLabelText('Ticker'), 'AIR.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(screen.getByText('1 item')).toBeInTheDocument()
  })

  it('disables Save while the request is in flight', async () => {
    let calls = 0
    server.use(
      http.put('*/api-admin/tickers/:listId/ticker', async () => {
        calls += 1
        await new Promise((resolve) => setTimeout(resolve, 100))
        return HttpResponse.json({ id: 'x', ric: 'AIR.PA', name: 'Airbus' }, { status: 200 })
      }),
    )
    const user = renderLists('c1')
    const dialog = await openAddItem(user, 'European consumer')
    await user.type(within(dialog).getByLabelText('Ticker'), 'AIR.PA')
    const save = within(dialog).getByRole('button', { name: 'Save' })
    await user.click(save)
    await waitFor(() => {
      expect(save).toBeDisabled()
    })
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(calls).toBe(1)
  })
})

describe('Rename a list', () => {
  async function openRename(user: User) {
    await rowButton(user, 'European consumer', 'Rename')
    return screen.findByRole('dialog', { name: 'Rename a list' })
  }

  it('prefills the title, saves and shows the new name', async () => {
    const user = renderLists('c1')
    const dialog = await openRename(user)
    const title = within(dialog).getByLabelText('Title')
    expect(title).toHaveValue('European consumer')
    await user.clear(title)
    await user.type(title, 'EU consumer')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('EU consumer')).toBeInTheDocument()
    expect(screen.queryByText('European consumer')).not.toBeInTheDocument()
  })

  it('shows Required for a blank title', async () => {
    const user = renderLists('c1')
    const dialog = await openRename(user)
    await user.clear(within(dialog).getByLabelText('Title'))
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(within(dialog).getByText('Required')).toBeInTheDocument()
  })

  it('shows the duplicate message verbatim and stays open', async () => {
    const user = renderLists('c1')
    const dialog = await openRename(user)
    const title = within(dialog).getByLabelText('Title')
    await user.clear(title)
    await user.type(title, 'luxury PEERS')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(
      await within(dialog).findByText(
        'A list with name [luxury PEERS] already exists for the emitter.',
      ),
    ).toBeInTheDocument()
    expect(screen.getByRole('dialog', { name: 'Rename a list' })).toBeInTheDocument()
  })

  it('Cancel keeps the old name', async () => {
    const user = renderLists('c1')
    const dialog = await openRename(user)
    await user.type(within(dialog).getByLabelText('Title'), ' X')
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(screen.getByText('European consumer')).toBeInTheDocument()
  })
})

describe('Delete a list', () => {
  async function openDelete(user: User) {
    await rowButton(user, 'Luxury peers', 'Delete')
    return screen.findByRole('dialog', { name: 'Delete a list' })
  }

  it('asks for confirmation, Cancel changes nothing', async () => {
    const user = renderLists('c1')
    const dialog = await openDelete(user)
    expect(
      within(dialog).getByText('Are you sure you want to delete Luxury peers?'),
    ).toBeInTheDocument()
    expect(within(dialog).getByText('This action cannot be undone')).toBeInTheDocument()
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(screen.getByText('Luxury peers')).toBeInTheDocument()
  })

  it('Yes removes the list', async () => {
    const user = renderLists('c1')
    const dialog = await openDelete(user)
    await user.click(within(dialog).getByRole('button', { name: 'Yes' }))
    await waitFor(() => {
      expect(screen.queryByText('Luxury peers')).not.toBeInTheDocument()
    })
    expect(screen.getByText('European consumer')).toBeInTheDocument()
  })

  it('shows a failure verbatim and keeps the dialog open', async () => {
    server.use(
      http.delete('*/api-admin/tickers/:id', () =>
        HttpResponse.json({ message: 'Cannot delete now' }, { status: 500 }),
      ),
    )
    const user = renderLists('c1')
    const dialog = await openDelete(user)
    await user.click(within(dialog).getByRole('button', { name: 'Yes' }))
    expect(await within(dialog).findByText('Cannot delete now')).toBeInTheDocument()
    expect(screen.getByText('Luxury peers')).toBeInTheDocument()
  })
})

describe('Delete an item', () => {
  async function openDelete(user: User) {
    await user.click(await screen.findByText('Luxury peers'))
    const row = parentRow(await screen.findByText('PRTP.PA'))
    await user.click(within(row).getByRole('button', { name: 'Delete' }))
    return screen.findByRole('dialog', { name: 'Delete an item' })
  }

  it('asks for confirmation, Cancel keeps it, Yes removes it and updates the count', async () => {
    const user = renderLists('c1')
    const dialog = await openDelete(user)
    expect(within(dialog).getByText('Are you sure you want to delete PRTP.PA?')).toBeInTheDocument()
    expect(within(dialog).getByText('This action cannot be undone')).toBeInTheDocument()
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(screen.getByText('3 items')).toBeInTheDocument()
    await user.click(screen.getAllByRole('button', { name: 'Delete' })[3] ?? document.body)
    const again = await screen.findByRole('dialog', { name: 'Delete an item' })
    await user.click(within(again).getByRole('button', { name: 'Yes' }))
    expect(await screen.findByText('2 items')).toBeInTheDocument()
    expect(screen.queryByText('PRTP.PA')).not.toBeInTheDocument()
  })

  it('shows a failure verbatim', async () => {
    server.use(
      http.delete('*/api-admin/tickers/ticker/:id', () =>
        HttpResponse.json({ message: 'Ticker is locked' }, { status: 500 }),
      ),
    )
    const user = renderLists('c1')
    const dialog = await openDelete(user)
    await user.click(within(dialog).getByRole('button', { name: 'Yes' }))
    expect(await within(dialog).findByText('Ticker is locked')).toBeInTheDocument()
  })
})
