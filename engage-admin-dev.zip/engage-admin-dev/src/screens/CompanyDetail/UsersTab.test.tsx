import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { CompanyDetailScreen } from './CompanyDetailScreen'

async function renderUsers(id = 'c1') {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/companies/${id}/users`]}>
          <Routes>
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  await screen.findByText('Claire Martin')
  return userEvent.setup()
}

function rowTexts() {
  return screen
    .getAllByRole('row', { hidden: true })
    .slice(1)
    .map((row) => within(row).getAllByRole('cell', { hidden: true })[0]?.textContent)
}

async function openForm(user: ReturnType<typeof userEvent.setup>) {
  await user.click(screen.getByRole('button', { name: 'Add user' }))
  return screen.findByRole('dialog', { name: 'Add user' })
}

async function fill(dialog: HTMLElement, user: ReturnType<typeof userEvent.setup>, email: string) {
  await user.type(within(dialog).getByLabelText('First name'), 'Bob')
  await user.type(within(dialog).getByLabelText('Last name'), 'Stone')
  await user.type(within(dialog).getByLabelText('Position'), 'Analyst')
  await user.type(within(dialog).getByLabelText('Email'), email)
  await user.click(within(dialog).getByRole('combobox', { name: 'Role' }))
  await user.click(screen.getByRole('option', { name: 'Standard' }))
}

describe('Users tab', () => {
  it('lists the columns and formats for LVMH users', async () => {
    await renderUsers()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      'Name',
      'Position',
      'Email',
      'Phone',
      'Terms accepted',
      '',
    ])
    const claire = screen.getByRole('row', { name: /Claire Martin/ })
    const julien = screen.getByRole('row', { name: /Julien Bernard/ })
    const claireCells = within(claire)
      .getAllByRole('cell')
      .map((cell) => cell.textContent)
    expect(claireCells.slice(0, 5)).toEqual([
      'Claire Martin',
      'Head of Investor Relations',
      'claire.martin@lvmh.example',
      '+33 1 44 13 22 22',
      '14/03/2025',
    ])
    const julienCells = within(julien)
      .getAllByRole('cell')
      .map((cell) => cell.textContent)
    expect(julienCells.slice(3, 5)).toEqual(['', 'No'])
    expect(within(claire).getByRole('button', { name: 'Edit' })).toBeInTheDocument()
    expect(within(claire).getByRole('button', { name: 'Delete' })).toBeInTheDocument()
    expect(screen.getByPlaceholderText('Search users')).toBeInTheDocument()
  })

  it('searches first name, last name and email, case-insensitively', async () => {
    const user = await renderUsers()
    const search = screen.getByPlaceholderText('Search users')
    await user.type(search, 'JULIEN')
    expect(rowTexts()).toEqual(['Julien Bernard'])
    await user.clear(search)
    await user.type(search, 'martin')
    expect(rowTexts()).toEqual(['Claire Martin'])
    await user.clear(search)
    await user.type(search, 'julien.bernard@')
    expect(rowTexts()).toEqual(['Julien Bernard'])
    await user.clear(search)
    await user.type(search, 'zzz')
    expect(rowTexts()).toEqual([])
  })

  it('shows required errors, the email format error and both role options', async () => {
    const user = await renderUsers()
    const dialog = await openForm(user)
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    for (const message of [
      'First name is required',
      'Last name is required',
      'Position is required',
      'Email is required',
      'Role is required',
    ]) {
      expect(within(dialog).getByText(message)).toBeInTheDocument()
    }
    await user.type(within(dialog).getByLabelText('Email'), 'bob@x')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(within(dialog).getByText('Invalid email address')).toBeInTheDocument()
    await user.click(within(dialog).getByRole('combobox', { name: 'Role' }))
    expect(screen.getAllByRole('option').map((option) => option.textContent)).toEqual([
      'Standard',
      'Limited access',
    ])
  })

  it('adds a valid user to the table and closes the dialog', async () => {
    const user = await renderUsers()
    const dialog = await openForm(user)
    await fill(dialog, user, 'bob@stone.example')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('Bob Stone')).toBeInTheDocument()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(rowTexts()).toContain('Bob Stone')
  })

  it('clears a load error once a later reload succeeds', async () => {
    server.use(
      http.get(
        '*/api-admin/accounts-management/emitter/:id',
        () => HttpResponse.json({ message: 'Users unavailable' }, { status: 400 }),
        { once: true },
      ),
    )
    renderWithTheme(
      <AuthProvider>
        <GatewayProvider>
          <MemoryRouter initialEntries={['/companies/c1/users']}>
            <Routes>
              <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
            </Routes>
          </MemoryRouter>
        </GatewayProvider>
      </AuthProvider>,
    )
    expect(await screen.findByText('Users unavailable')).toBeInTheDocument()
    const user = userEvent.setup()
    const dialog = await openForm(user)
    await fill(dialog, user, 'bob@stone.example')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('Bob Stone')).toBeInTheDocument()
    expect(screen.queryByText('Users unavailable')).not.toBeInTheDocument()
  })

  it('Cancel closes the dialog without adding', async () => {
    const user = await renderUsers()
    const dialog = await openForm(user)
    await user.type(within(dialog).getByLabelText('First name'), 'Bob')
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(rowTexts()).toEqual(['Claire Martin', 'Julien Bernard'])
  })

  it('shows the duplicate-email message verbatim and adds nothing', async () => {
    const user = await renderUsers()
    const dialog = await openForm(user)
    await fill(dialog, user, 'claire.martin@lvmh.example')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(
      await within(dialog).findByText('Email claire.martin@lvmh.example is already used.'),
    ).toBeInTheDocument()
    expect(screen.getByRole('dialog', { name: 'Add user' })).toBeInTheDocument()
    expect(rowTexts()).toEqual(['Claire Martin', 'Julien Bernard'])
  })

  it('maps fieldErrors from a 400 to the fields', async () => {
    server.use(
      http.put('*/api-admin/accounts-management/account', () =>
        HttpResponse.json(
          {
            message: 'Validation failed',
            fieldErrors: [
              { objectName: 'account', field: 'email', code: 'Pattern', message: 'Bad email' },
              { objectName: 'account', field: 'jobFunction', code: 'Size', message: 'Too long' },
            ],
          },
          { status: 400 },
        ),
      ),
    )
    const user = await renderUsers()
    const dialog = await openForm(user)
    await fill(dialog, user, 'bob@stone.example')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await within(dialog).findByText('Validation failed')).toBeInTheDocument()
    expect(within(dialog).getByText('Bad email')).toBeInTheDocument()
    expect(within(dialog).getByText('Too long')).toBeInTheDocument()
    expect(rowTexts()).toEqual(['Claire Martin', 'Julien Bernard'])
  })

  it('opens Edit prefilled with read-only read dates', async () => {
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Julien Bernard/ })).getByRole('button', {
        name: 'Edit',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Edit user' })
    expect(within(dialog).getByLabelText('First name')).toHaveValue('Julien')
    expect(within(dialog).getByLabelText('Last name')).toHaveValue('Bernard')
    expect(within(dialog).getByLabelText('Position')).toHaveValue('Investor Relations Analyst')
    expect(within(dialog).getByLabelText('Email')).toHaveValue('julien.bernard@lvmh.example')
    expect(within(dialog).getByLabelText('Phone')).toHaveValue('')
    expect(within(dialog).getByRole('combobox', { name: 'Role' })).toHaveTextContent(
      'Limited access',
    )
    expect(within(dialog).getByText('Last daily report read: N/A')).toBeInTheDocument()
    expect(within(dialog).getByText('Last flash read: N/A')).toBeInTheDocument()
  })

  it('edit has no password change switch and saves the existing passwordChangeRequired value', async () => {
    const bodies: unknown[] = []
    server.events.on('request:start', async ({ request }) => {
      if (request.method === 'POST' && request.url.includes('/account/')) {
        bodies.push(await request.clone().json())
      }
    })
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Edit',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Edit user' })
    expect(within(dialog).queryByRole('switch')).not.toBeInTheDocument()
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    await waitFor(() => {
      expect(bodies).toHaveLength(1)
    })
    expect(bodies[0]).toMatchObject({ emitterId: 'c1', passwordChangeRequired: false })
    server.events.removeAllListeners()
  })

  it('shows formatted read dates for a user who has read', async () => {
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Edit',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Edit user' })
    expect(within(dialog).getByText('Last daily report read: 09/10/2026')).toBeInTheDocument()
    expect(within(dialog).getByText('Last flash read: 08/10/2026')).toBeInTheDocument()
  })

  it('saves an edit and updates the row', async () => {
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Edit',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Edit user' })
    const position = within(dialog).getByLabelText('Position')
    await user.clear(position)
    await user.type(position, 'Chief of IR')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('Chief of IR')).toBeInTheDocument()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('clears the phone on edit by sending an empty string', async () => {
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Edit',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Edit user' })
    await user.clear(within(dialog).getByLabelText('Phone'))
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    await waitFor(() => {
      const claire = screen.getByRole('row', { name: /Claire Martin/ })
      expect(within(claire).getAllByRole('cell')[3]?.textContent).toBe('')
    })
  })

  it('shows a server error on edit and keeps the dialog', async () => {
    server.use(
      http.post('*/api-admin/accounts-management/account/:accountId', () =>
        HttpResponse.json({ message: 'Edit refused' }, { status: 400 }),
      ),
    )
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Edit',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Edit user' })
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await within(dialog).findByText('Edit refused')).toBeInTheDocument()
    expect(screen.getByRole('dialog', { name: 'Edit user' })).toBeInTheDocument()
  })

  it('Delete asks first; No keeps the row', async () => {
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Delete',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Delete user' })
    expect(
      within(dialog).getByText('Are you sure you want to delete Claire Martin?'),
    ).toBeInTheDocument()
    await user.click(within(dialog).getByRole('button', { name: 'No' }))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(rowTexts()).toEqual(['Claire Martin', 'Julien Bernard'])
  })

  it('Delete Yes removes the row', async () => {
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Delete',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Delete user' })
    await user.click(within(dialog).getByRole('button', { name: 'Yes' }))
    await waitFor(() => {
      expect(rowTexts()).toEqual(['Julien Bernard'])
    })
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('Delete Yes double-clicked sends one request', async () => {
    let requests = 0
    server.use(
      http.delete('*/api-admin/accounts-management/account/delete/:accountId', () => {
        requests += 1
        return new HttpResponse(null, { status: 200 })
      }),
    )
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Delete',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Delete user' })
    await user.dblClick(within(dialog).getByRole('button', { name: 'Yes' }))
    await waitFor(() => {
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    })
    expect(requests).toBe(1)
  })

  it('Delete failure shows the message in the dialog', async () => {
    server.use(
      http.delete('*/api-admin/accounts-management/account/delete/:accountId', () =>
        HttpResponse.json({ message: 'No account with UUID: u1' }, { status: 400 }),
      ),
    )
    const user = await renderUsers()
    await user.click(
      within(screen.getByRole('row', { name: /Claire Martin/ })).getByRole('button', {
        name: 'Delete',
      }),
    )
    const dialog = await screen.findByRole('dialog', { name: 'Delete user' })
    await user.click(within(dialog).getByRole('button', { name: 'Yes' }))
    expect(await within(dialog).findByText('No account with UUID: u1')).toBeInTheDocument()
    expect(rowTexts()).toEqual(['Claire Martin', 'Julien Bernard'])
  })
})
