import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  InputBase,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@mui/material'
import { useEffect, useMemo, useState } from 'react'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { AccountDto } from '@/data/types'
import { UserFormDialog, type UserFormValues } from './UserFormDialog'

const columns = ['users.name', 'users.position', 'users.email', 'users.phone', 'users.terms']

function formatDate(value: string) {
  const date = new Date(value)
  const part = (number: number) => String(number).padStart(2, '0')
  return `${part(date.getDate())}/${part(date.getMonth() + 1)}/${String(date.getFullYear())}`
}

export function UsersTab({ companyId }: { companyId: string }) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [users, setUsers] = useState<AccountDto[] | null>(null)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [adding, setAdding] = useState(false)
  const [editing, setEditing] = useState<AccountDto | null>(null)
  const [deleting, setDeleting] = useState<AccountDto | null>(null)
  const [deleteError, setDeleteError] = useState('')
  const [removing, setRemoving] = useState(false)
  const [reloads, setReloads] = useState(0)

  useEffect(() => {
    let current = true
    gateway.listCompanyUsers(companyId).then(
      (loaded) => {
        if (current) {
          setUsers(loaded)
          setError('')
        }
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, i18next.t('users.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, companyId, reloads])

  const rows = useMemo(() => {
    const needle = search.trim().toLowerCase()
    return (users ?? []).filter((user) =>
      `${user.firstname}\n${user.lastname}\n${user.email}`.toLowerCase().includes(needle),
    )
  }, [users, search])

  async function add(values: UserFormValues) {
    await gateway.createUser({
      email: values.email.trim(),
      firstName: values.firstName.trim(),
      lastName: values.lastName.trim(),
      jobFunction: values.jobFunction.trim(),
      ...(values.phone.trim() ? { phone: values.phone.trim() } : {}),
      emitterId: companyId,
      roles: [values.role],
    })
    setAdding(false)
    setReloads((count) => count + 1)
  }

  async function edit(values: UserFormValues) {
    if (!editing) return
    await gateway.updateUser(editing.id, {
      email: values.email.trim(),
      firstName: values.firstName.trim(),
      lastName: values.lastName.trim(),
      jobFunction: values.jobFunction.trim(),
      phone: values.phone.trim(),
      emitterId: companyId,
      roles: [values.role],
      passwordChangeRequired: editing.passwordChangeRequired,
    })
    setEditing(null)
    setReloads((count) => count + 1)
  }

  function confirmDelete() {
    if (!deleting) return
    setRemoving(true)
    gateway.deleteUser(deleting.id).then(
      () => {
        setRemoving(false)
        setDeleting(null)
        setReloads((count) => count + 1)
      },
      (failure: unknown) => {
        setRemoving(false)
        setDeleteError(gatewayMessage(failure, i18next.t('users.deleteFailed')))
      },
    )
  }

  return (
    <>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, p: 2 }}>
        <InputBase
          placeholder={t('users.search')}
          value={search}
          onChange={(event) => {
            setSearch(event.target.value)
          }}
          inputProps={{ 'aria-label': t('users.search') }}
          sx={{ flex: 1, px: 1.5, height: 32, border: `1px solid ${colors.rule}`, fontSize: 14 }}
        />
        <Button
          variant="contained"
          onClick={() => {
            setAdding(true)
          }}
        >
          {t('users.add')}
        </Button>
      </Box>
      {error ? (
        <Alert severity="error" sx={{ mx: 2, mb: 2 }}>
          {error}
        </Alert>
      ) : null}
      <Table size="small">
        <TableHead>
          <TableRow>
            {columns.map((column) => (
              <TableCell key={column} sx={{ fontWeight: 600 }}>
                {t(column)}
              </TableCell>
            ))}
            <TableCell />
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((user) => (
            <TableRow key={user.id}>
              <TableCell>{`${user.firstname} ${user.lastname}`}</TableCell>
              <TableCell>{user.jobFunction}</TableCell>
              <TableCell>{user.email}</TableCell>
              <TableCell>{user.phone ?? ''}</TableCell>
              <TableCell>{user.cgu ? formatDate(user.cgu) : t('users.termsNo')}</TableCell>
              <TableCell align="right">
                <Button
                  size="small"
                  onClick={() => {
                    setEditing(user)
                  }}
                >
                  {t('common.edit')}
                </Button>
                <Button
                  size="small"
                  onClick={() => {
                    setDeleteError('')
                    setDeleting(user)
                  }}
                >
                  {t('common.delete')}
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {adding ? (
        <UserFormDialog
          title={t('users.add')}
          onSubmit={add}
          onClose={() => {
            setAdding(false)
          }}
        />
      ) : null}
      {editing ? (
        <UserFormDialog
          title={t('users.editTitle')}
          initial={{
            firstName: editing.firstname,
            lastName: editing.lastname,
            jobFunction: editing.jobFunction,
            email: editing.email,
            phone: editing.phone ?? '',
            role: editing.authorities[0] ?? '',
            passwordChangeRequired: editing.passwordChangeRequired,
          }}
          readOnlyLines={[
            t('users.lastDailyRead', {
              date: editing.lastDailyReadDate
                ? formatDate(editing.lastDailyReadDate)
                : t('users.notAvailable'),
            }),
            t('users.lastFlashRead', {
              date: editing.lastFlashReadDate
                ? formatDate(editing.lastFlashReadDate)
                : t('users.notAvailable'),
            }),
          ]}
          onSubmit={edit}
          onClose={() => {
            setEditing(null)
          }}
        />
      ) : null}
      {deleting ? (
        <Dialog
          open
          onClose={() => {
            setDeleting(null)
          }}
        >
          <DialogTitle>{t('users.deleteTitle')}</DialogTitle>
          <DialogContent>
            {deleteError ? (
              <Alert severity="error" sx={{ mb: 2 }}>
                {deleteError}
              </Alert>
            ) : null}
            {t('users.confirmDelete', { name: `${deleting.firstname} ${deleting.lastname}` })}
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                setDeleting(null)
              }}
            >
              {t('common.no')}
            </Button>
            <Button variant="contained" onClick={confirmDelete} disabled={removing}>
              {t('common.yes')}
            </Button>
          </DialogActions>
        </Dialog>
      ) : null}
    </>
  )
}
