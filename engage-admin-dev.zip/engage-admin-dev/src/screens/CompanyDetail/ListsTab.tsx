import {
  Alert,
  Box,
  Button,
  Chip,
  Collapse,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from '@mui/material'
import { useEffect, useRef, useState } from 'react'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { useGateway } from '@/data/gatewayContext'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import type { TickerList } from '@/data/types'

const rowSx = {
  display: 'flex',
  alignItems: 'center',
  gap: 2,
  px: 2,
  py: 1,
  borderTop: `1px solid ${colors.rule}`,
  fontSize: 14,
}

function CreateListDialog({ companyId, onClose, onCreated }: CreateListDialogProps) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [title, setTitle] = useState('')
  const [ticker, setTicker] = useState('')
  const [rics, setRics] = useState<{ ric: string; name: string }[]>([])
  const latestRics = useRef(rics)
  const [titleError, setTitleError] = useState('')
  const [tickerError, setTickerError] = useState('')
  const [serverMessage, setServerMessage] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    latestRics.current = rics
  }, [rics])

  function add() {
    const search = ticker.trim()
    if (!search) return
    setTickerError('')
    gateway.lookupRic(search).then(
      (found) => {
        const known = latestRics.current
        if (known.some((item) => item.ric.toLowerCase() === found.ric.toLowerCase())) {
          setTickerError(i18next.t('lists.tickerExists'))
          return
        }
        latestRics.current = [...known, { ric: found.ric, name: found.name }]
        setRics(latestRics.current)
        setTicker('')
      },
      (failure: unknown) => {
        setTickerError(
          failure instanceof GatewayError && failure.status === 404
            ? i18next.t('validation.unknownRic')
            : gatewayMessage(failure, i18next.t('lists.tickerCheckFailed')),
        )
      },
    )
  }

  function save() {
    const missingTitle = !title.trim()
    setTitleError(missingTitle ? i18next.t('validation.required') : '')
    setTickerError(rics.length === 0 ? i18next.t('lists.addAtLeastOne') : '')
    setServerMessage('')
    if (missingTitle || rics.length === 0) return
    setSaving(true)
    gateway
      .createTickerList({ emitterId: companyId, name: title.trim(), comments: '', tickers: rics })
      .then(onCreated, (failure: unknown) => {
        setSaving(false)
        setServerMessage(gatewayMessage(failure, i18next.t('lists.createFailed')))
      })
  }

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{t('lists.create')}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          {serverMessage ? <Alert severity="error">{serverMessage}</Alert> : null}
          <TextField
            size="small"
            label={t('fields.title')}
            value={title}
            error={Boolean(titleError)}
            helperText={titleError}
            onChange={(event) => {
              setTitle(event.target.value)
            }}
          />
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
            <TextField
              size="small"
              fullWidth
              label={t('fields.ticker')}
              placeholder={t('lists.peerPlaceholder')}
              value={ticker}
              error={Boolean(tickerError)}
              helperText={tickerError}
              onChange={(event) => {
                setTicker(event.target.value)
              }}
            />
            <Button variant="outlined" onClick={add}>
              {t('common.add')}
            </Button>
          </Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
            {rics.map(({ ric }) => (
              <Chip
                key={ric}
                label={ric}
                onDelete={() => {
                  setRics(rics.filter((other) => other.ric !== ric))
                }}
              />
            ))}
          </Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.cancel')}</Button>
        <Button variant="contained" onClick={save} disabled={saving}>
          {t('common.save')}
        </Button>
      </DialogActions>
    </Dialog>
  )
}

function failureMessage(failure: unknown, fallback: string) {
  return gatewayMessage(failure, fallback)
}

function AddItemDialog({
  list,
  onClose,
  onSaved,
}: {
  list: TickerList
  onClose: () => void
  onSaved: () => void
}) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [ticker, setTicker] = useState('')
  const [tickerError, setTickerError] = useState('')
  const [serverMessage, setServerMessage] = useState('')
  const [saving, setSaving] = useState(false)

  function save() {
    const search = ticker.trim()
    setServerMessage('')
    if (!search) {
      setTickerError(i18next.t('validation.required'))
      return
    }
    setTickerError('')
    setSaving(true)
    gateway
      .lookupRic(search)
      .then(
        (found) => {
          if (list.tickers.some((item) => item.ricCode.toLowerCase() === found.ric.toLowerCase())) {
            setTickerError(i18next.t('lists.tickerExists'))
            setSaving(false)
            return undefined
          }
          return gateway.addTicker(list.id, found.ric, found.name).then(onSaved)
        },
        (failure: unknown) => {
          setSaving(false)
          if (failure instanceof GatewayError && failure.status === 404) {
            setTickerError(i18next.t('validation.unknownRic'))
          } else {
            setServerMessage(failureMessage(failure, i18next.t('lists.tickerCheckFailed')))
          }
        },
      )
      .catch((failure: unknown) => {
        setSaving(false)
        setServerMessage(failureMessage(failure, i18next.t('lists.addFailed')))
      })
  }

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{t('lists.addItemTitle')}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          {serverMessage ? <Alert severity="error">{serverMessage}</Alert> : null}
          <TextField
            size="small"
            label={t('fields.ticker')}
            placeholder={t('lists.peerPlaceholder')}
            value={ticker}
            error={Boolean(tickerError)}
            helperText={tickerError}
            onChange={(event) => {
              setTicker(event.target.value)
            }}
          />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.cancel')}</Button>
        <Button variant="contained" onClick={save} disabled={saving}>
          {t('common.save')}
        </Button>
      </DialogActions>
    </Dialog>
  )
}

function RenameDialog({
  list,
  onClose,
  onSaved,
}: {
  list: TickerList
  onClose: () => void
  onSaved: () => void
}) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [title, setTitle] = useState(list.name)
  const [titleError, setTitleError] = useState('')
  const [serverMessage, setServerMessage] = useState('')
  const [saving, setSaving] = useState(false)

  function save() {
    const missing = !title.trim()
    setTitleError(missing ? i18next.t('validation.required') : '')
    setServerMessage('')
    if (missing) return
    setSaving(true)
    gateway
      .renameTickerList(list.id, title.trim(), list.comments ?? '')
      .then(onSaved, (failure: unknown) => {
        setSaving(false)
        setServerMessage(failureMessage(failure, i18next.t('lists.renameFailed')))
      })
  }

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{t('lists.renameTitle')}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          {serverMessage ? <Alert severity="error">{serverMessage}</Alert> : null}
          <TextField
            size="small"
            label={t('fields.title')}
            value={title}
            error={Boolean(titleError)}
            helperText={titleError}
            onChange={(event) => {
              setTitle(event.target.value)
            }}
          />
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.cancel')}</Button>
        <Button variant="contained" onClick={save} disabled={saving}>
          {t('common.save')}
        </Button>
      </DialogActions>
    </Dialog>
  )
}

interface DeleteTarget {
  title: string
  subject: string
  remove: () => Promise<void>
}

function DeleteDialog({
  target,
  onClose,
  onDeleted,
}: {
  target: DeleteTarget
  onClose: () => void
  onDeleted: () => void
}) {
  const { t } = useTranslation()
  const [serverMessage, setServerMessage] = useState('')
  const [saving, setSaving] = useState(false)

  function confirm() {
    setServerMessage('')
    setSaving(true)
    target.remove().then(onDeleted, (failure: unknown) => {
      setSaving(false)
      setServerMessage(failureMessage(failure, i18next.t('lists.deleteFailed')))
    })
  }

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>{target.title}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          {serverMessage ? <Alert severity="error">{serverMessage}</Alert> : null}
          <Box>{t('lists.confirmDelete', { subject: target.subject })}</Box>
          <Box sx={{ fontWeight: 700 }}>{t('lists.irreversible')}</Box>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.cancel')}</Button>
        <Button variant="contained" onClick={confirm} disabled={saving}>
          {t('common.yes')}
        </Button>
      </DialogActions>
    </Dialog>
  )
}

interface CreateListDialogProps {
  companyId: string
  onClose: () => void
  onCreated: () => void
}

export function ListsTab({ companyId }: { companyId: string }) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [lists, setLists] = useState<TickerList[] | null>(null)
  const [error, setError] = useState('')
  const [open, setOpen] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [adding, setAdding] = useState<TickerList | null>(null)
  const [renaming, setRenaming] = useState<TickerList | null>(null)
  const [deleting, setDeleting] = useState<DeleteTarget | null>(null)
  const [reloads, setReloads] = useState(0)

  function reload() {
    setReloads((count) => count + 1)
  }

  useEffect(() => {
    let current = true
    gateway.listTickerLists(companyId).then(
      (loaded) => {
        if (current) {
          setLists(loaded)
          setError('')
        }
      },
      (failure: unknown) => {
        if (current) setError(gatewayMessage(failure, i18next.t('lists.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, companyId, reloads])

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
        <Button
          variant="contained"
          onClick={() => {
            setCreating(true)
          }}
        >
          {t('lists.create')}
        </Button>
      </Box>
      {error ? (
        <Alert severity="error" sx={{ mx: 2, mb: 2 }}>
          {error}
        </Alert>
      ) : null}
      {lists?.length === 0 ? (
        <Box sx={{ ...rowSx, color: colors.textSecondary }}>{t('lists.empty')}</Box>
      ) : null}
      {(lists ?? []).map((list) => (
        <Box key={list.id}>
          <Box
            sx={{ ...rowSx, cursor: 'pointer' }}
            onClick={() => {
              setOpen(open === list.id ? null : list.id)
            }}
          >
            <Box sx={{ flex: 1, fontWeight: 600 }}>{list.name}</Box>
            <Box sx={{ color: colors.textSecondary }}>
              {t('lists.itemCount', { count: list.tickers.length })}
            </Box>
            <Button
              size="small"
              onClick={(event) => {
                event.stopPropagation()
                setAdding(list)
              }}
            >
              {t('lists.addItemButton')}
            </Button>
            <Button
              size="small"
              onClick={(event) => {
                event.stopPropagation()
                setRenaming(list)
              }}
            >
              {t('lists.rename')}
            </Button>
            <Button
              size="small"
              onClick={(event) => {
                event.stopPropagation()
                setDeleting({
                  title: t('lists.deleteListTitle'),
                  subject: list.name,
                  remove: () => gateway.deleteTickerList(list.id),
                })
              }}
            >
              {t('common.delete')}
            </Button>
          </Box>
          <Collapse in={open === list.id} unmountOnExit>
            {list.tickers.map((ticker) => (
              <Box key={ticker.id} sx={{ ...rowSx, pl: 4 }}>
                <Box sx={{ width: 120 }}>{ticker.ricCode}</Box>
                <Box sx={{ flex: 1 }}>{ticker.name}</Box>
                <Button
                  size="small"
                  onClick={() => {
                    setDeleting({
                      title: t('lists.deleteItemTitle'),
                      subject: ticker.ricCode,
                      remove: () => gateway.deleteTicker(ticker.id),
                    })
                  }}
                >
                  {t('common.delete')}
                </Button>
              </Box>
            ))}
          </Collapse>
        </Box>
      ))}
      {creating ? (
        <CreateListDialog
          companyId={companyId}
          onClose={() => {
            setCreating(false)
          }}
          onCreated={() => {
            setCreating(false)
            setReloads((count) => count + 1)
          }}
        />
      ) : null}
      {adding ? (
        <AddItemDialog
          list={adding}
          onClose={() => {
            setAdding(null)
          }}
          onSaved={() => {
            setAdding(null)
            reload()
          }}
        />
      ) : null}
      {renaming ? (
        <RenameDialog
          list={renaming}
          onClose={() => {
            setRenaming(null)
          }}
          onSaved={() => {
            setRenaming(null)
            reload()
          }}
        />
      ) : null}
      {deleting ? (
        <DeleteDialog
          target={deleting}
          onClose={() => {
            setDeleting(null)
          }}
          onDeleted={() => {
            setDeleting(null)
            reload()
          }}
        />
      ) : null}
    </>
  )
}
