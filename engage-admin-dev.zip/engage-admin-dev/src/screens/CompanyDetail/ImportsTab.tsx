import { Alert, Box, Button, MenuItem, TextField, Typography } from '@mui/material'
import { useEffect, useRef, useState } from 'react'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { ImportResult, ImportType } from '@/data/types'

interface ImportsTabProps {
  companyId: string
}

export function ImportsTab({ companyId }: ImportsTabProps) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const fileInput = useRef<HTMLInputElement>(null)
  const [types, setTypes] = useState<ImportType[]>([])
  const [kind, setKind] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [result, setResult] = useState<ImportResult | null>(null)
  const [error, setError] = useState('')
  const request = useRef(0)

  useEffect(() => {
    gateway.listImportTypes().then(setTypes, (failure: unknown) => {
      setError(gatewayMessage(failure, i18next.t('imports.loadFailed')))
    })
  }, [gateway])

  function clearResult() {
    request.current += 1
    setResult(null)
    setError('')
  }

  function upload() {
    if (!file || !kind) return
    clearResult()
    const mine = request.current
    setUploading(true)
    gateway
      .importFile(companyId, kind, file)
      .then(
        (loaded) => {
          if (mine === request.current) setResult(loaded)
        },
        (failure: unknown) => {
          if (mine === request.current)
            setError(gatewayMessage(failure, i18next.t('imports.failed')))
        },
      )
      .finally(() => {
        setUploading(false)
      })
  }

  const errorRows = result
    ? Object.entries(result.rowErrors)
        .sort(([a], [b]) => Number(a) - Number(b))
        .flatMap(([row, messages]) => messages.map((message) => ({ row, message })))
    : []
  const summary = result ? t('imports.summary', { ok: result.okRows, total: result.totalRows }) : ''

  return (
    <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 520 }}>
      <TextField
        select
        label={t('imports.type')}
        value={kind}
        size="small"
        slotProps={{
          select: {
            displayEmpty: true,
            renderValue: (value) =>
              types.find((type) => type.kind === value)?.label ?? t('imports.choose'),
          },
          inputLabel: { shrink: true },
        }}
        onChange={(event) => {
          setKind(event.target.value)
          clearResult()
        }}
      >
        {types.map((type) => (
          <MenuItem key={type.kind} value={type.kind}>
            {type.label}
          </MenuItem>
        ))}
      </TextField>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        <input
          ref={fileInput}
          type="file"
          accept=".xlsx,.xls"
          hidden
          data-testid="import-file"
          onChange={(event) => {
            setFile(event.target.files?.[0] ?? null)
            clearResult()
          }}
        />
        <Button
          variant="outlined"
          onClick={() => {
            fileInput.current?.click()
          }}
        >
          {t('imports.chooseFile')}
        </Button>
        <Typography sx={{ fontSize: 14, color: colors.textSecondary }}>{file?.name}</Typography>
      </Box>
      <Box>
        <Button variant="contained" disabled={!kind || !file || uploading} onClick={upload}>
          {t('imports.import')}
        </Button>
      </Box>
      {error ? <Alert severity="error">{error}</Alert> : null}
      {result ? (
        <Alert severity={errorRows.length === 0 ? 'success' : 'warning'}>{summary}</Alert>
      ) : null}
      {errorRows.length > 0 ? (
        <Box>
          <Typography component="h3" sx={{ fontSize: 14, fontWeight: 600, mb: 1 }}>
            {t('imports.errorsHeading')}
          </Typography>
          {errorRows.map(({ row, message }) => (
            <Typography key={`${row}-${message}`} sx={{ fontSize: 14 }}>
              {t('imports.row', { row, message })}
            </Typography>
          ))}
        </Box>
      ) : null}
    </Box>
  )
}
