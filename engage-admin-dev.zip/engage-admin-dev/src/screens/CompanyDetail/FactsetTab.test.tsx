import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { CompanyDetailScreen } from './CompanyDetailScreen'

function renderFactset(id = 'c1') {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/companies/${id}/factset`]}>
          <Routes>
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

function nth(elements: HTMLElement[], index: number) {
  const element = elements[index]
  if (!element) throw new Error(`No element at ${String(index)}`)
  return element
}

function multiplesPanel() {
  const panel = screen.getByText('MULTIPLES').parentElement
  if (!panel) throw new Error('No multiples panel')
  return panel
}

const savePeers = () => screen.getByRole('button', { name: 'Save peers' })

describe('Factset tab peers', () => {
  it('lists the peers as Name and ID fields', async () => {
    renderFactset()
    expect(await screen.findByText('FACTSET PEERS')).toBeInTheDocument()
    const names = screen.getAllByRole('textbox', { name: 'Name' })
    const ids = screen.getAllByRole('textbox', { name: 'ID' })
    expect(names.map((field) => (field as HTMLInputElement).value)).toEqual([
      'Hermes International',
      'Kering',
    ])
    expect(ids.map((field) => (field as HTMLInputElement).value)).toEqual(['HRMS-FR', 'PRTP-FR'])
  })

  it('says there are no peers for a company without any', async () => {
    renderFactset('c2')
    expect(await screen.findByText('No Factset peers yet.')).toBeInTheDocument()
  })

  it('disables Save peers while a row is incomplete, then sends the whole list', async () => {
    let body: unknown = null
    server.use(
      http.post('*/api-admin/factset/emitter/:emitterId/peers', async ({ request }) => {
        body = await request.json()
        return new HttpResponse(null, { status: 200 })
      }),
    )
    const user = renderFactset()
    await screen.findAllByRole('textbox', { name: 'Name' })
    await user.click(screen.getByRole('button', { name: 'Add a new Factset peer' }))
    expect(savePeers()).toBeDisabled()
    const names = screen.getAllByRole('textbox', { name: 'Name' })
    await user.type(nth(names, 2), 'Richemont')
    expect(savePeers()).toBeDisabled()
    await user.type(nth(screen.getAllByRole('textbox', { name: 'ID' }), 2), 'CFR-CH')
    expect(savePeers()).toBeEnabled()
    await user.click(savePeers())
    expect(await screen.findByText('Saved successfully')).toBeInTheDocument()
    expect(body).toEqual({
      emitterBloomIds: [
        { factsetName: 'Hermes International', factsetId: 'HRMS-FR' },
        { factsetName: 'Kering', factsetId: 'PRTP-FR' },
        { factsetName: 'Richemont', factsetId: 'CFR-CH' },
      ],
    })
  })

  it('removes a row and sends the rest', async () => {
    let body: unknown = null
    server.use(
      http.post('*/api-admin/factset/emitter/:emitterId/peers', async ({ request }) => {
        body = await request.json()
        return new HttpResponse(null, { status: 200 })
      }),
    )
    const user = renderFactset()
    await screen.findAllByRole('textbox', { name: 'Name' })
    await user.click(nth(screen.getAllByRole('button', { name: 'Remove' }), 0))
    await user.click(savePeers())
    await screen.findByText('Saved successfully')
    expect(body).toEqual({
      emitterBloomIds: [{ factsetName: 'Kering', factsetId: 'PRTP-FR' }],
    })
  })

  it('shows the gateway message in the peers panel when saving fails', async () => {
    server.use(
      http.post('*/api-admin/factset/emitter/:emitterId/peers', () =>
        HttpResponse.json({ message: 'Peers rejected' }, { status: 400 }),
      ),
    )
    const user = renderFactset()
    await screen.findAllByRole('textbox', { name: 'Name' })
    await user.click(savePeers())
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('Peers rejected')
    expect(screen.queryByText('Saved successfully')).not.toBeInTheDocument()
  })
})

describe('Factset tab multiples', () => {
  const box = (label: string) => screen.getByRole('checkbox', { name: label })

  it('lists every available multiple with the company ones ticked', async () => {
    renderFactset()
    expect(await screen.findByText('MULTIPLES')).toBeInTheDocument()
    const labels = (await screen.findAllByRole('checkbox')).map(
      (checkbox) => checkbox.closest('label')?.textContent,
    )
    expect(labels).toEqual(['P/E', 'EV/EBITDA', 'EV/Sales', 'P/B', 'Dividend yield', 'FCF yield'])
    expect(box('P/E')).toBeChecked()
    expect(box('EV/EBITDA')).toBeChecked()
    expect(box('EV/Sales')).not.toBeChecked()
  })

  it('filters by label case-insensitively on Search and shows all when empty', async () => {
    const user = renderFactset()
    await screen.findByText('MULTIPLES')
    await screen.findByRole('checkbox', { name: 'P/E' })
    await user.type(screen.getByPlaceholderText('Search multiples'), 'EV')
    await user.click(screen.getByRole('button', { name: 'Search' }))
    expect(screen.getAllByRole('checkbox').map((c) => c.closest('label')?.textContent)).toEqual([
      'EV/EBITDA',
      'EV/Sales',
    ])
    await user.clear(screen.getByPlaceholderText('Search multiples'))
    await user.click(screen.getByRole('button', { name: 'Search' }))
    expect(screen.getAllByRole('checkbox')).toHaveLength(6)
  })

  it('sends the ticked keys including ones hidden by the search', async () => {
    let body: unknown = null
    server.use(
      http.put('*/api-admin/factset/emitter/:emitterId/multiples', async ({ request }) => {
        body = await request.json()
        return new HttpResponse(null, { status: 200 })
      }),
    )
    const user = renderFactset()
    await screen.findByRole('checkbox', { name: 'P/E' })
    await user.type(screen.getByPlaceholderText('Search multiples'), 'ev')
    await user.click(screen.getByRole('button', { name: 'Search' }))
    await user.click(box('EV/Sales'))
    const panel = multiplesPanel()
    await user.click(within(panel).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('Saved successfully')).toBeInTheDocument()
    expect(body).toEqual(['PE', 'EV_EBITDA', 'EV_SALES'])
  })

  it('shows the gateway message in the multiples panel when saving fails', async () => {
    server.use(
      http.put('*/api-admin/factset/emitter/:emitterId/multiples', () =>
        HttpResponse.json({ message: 'Multiples rejected' }, { status: 400 }),
      ),
    )
    const user = renderFactset()
    await screen.findByRole('checkbox', { name: 'P/E' })
    const panel = multiplesPanel()
    await user.click(within(panel).getByRole('button', { name: 'Save' }))
    expect(await within(panel).findByRole('alert')).toHaveTextContent('Multiples rejected')
  })
})
