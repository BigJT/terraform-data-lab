import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { CompanyDetailScreen } from './CompanyDetailScreen'

function renderImports() {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/companies/c1/imports']}>
          <Routes>
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

async function chooseType(user: ReturnType<typeof userEvent.setup>, label: string) {
  await user.click(await screen.findByRole('combobox', { name: 'Type' }))
  await user.click(await screen.findByRole('option', { name: label }))
}

async function chooseFile(user: ReturnType<typeof userEvent.setup>, name: string) {
  await user.upload(screen.getByTestId('import-file'), new File(['x'], name))
}

const importButton = () => screen.getByRole('button', { name: 'Import a file' })

describe('Imports tab', () => {
  it('offers the four types in order with a placeholder, and gates the button', async () => {
    const user = renderImports()
    const select = await screen.findByRole('combobox', { name: 'Type' })
    expect(select).toHaveTextContent('Choose a type')
    expect(importButton()).toBeDisabled()
    await user.click(select)
    const options = within(await screen.findByRole('listbox')).getAllByRole('option')
    expect(options.map((option) => option.textContent)).toEqual([
      'Short BlackApp (file 10)',
      'Consensus',
      'Short Markit (file 9)',
      'Reco TP',
    ])
    await user.click(screen.getByRole('option', { name: 'Consensus' }))
    expect(importButton()).toBeDisabled()
    await chooseFile(user, 'consensus.xlsx')
    expect(screen.getByText('consensus.xlsx')).toBeInTheDocument()
    expect(importButton()).toBeEnabled()
  })

  it('stays disabled with a file but no type', async () => {
    const user = renderImports()
    await screen.findByRole('combobox', { name: 'Type' })
    await chooseFile(user, 'consensus.xlsx')
    expect(importButton()).toBeDisabled()
  })

  it('shows the success line when every row imports', async () => {
    const user = renderImports()
    await chooseType(user, 'Consensus')
    await chooseFile(user, 'consensus.xlsx')
    await user.click(importButton())
    expect(await screen.findByText('20 of 20 rows imported')).toBeInTheDocument()
    expect(screen.queryByText('Rows with errors')).not.toBeInTheDocument()
  })

  it('lists row errors in ascending numeric order', async () => {
    server.use(
      http.post('*/api-admin/emitter/:emitterId/import/:kind', () =>
        HttpResponse.json({
          totalRows: 150,
          okRows: 147,
          rowErrors: { '117': ['b'], '9': ['a1', 'a2'], '101': ['c'] },
        }),
      ),
    )
    const user = renderImports()
    await chooseType(user, 'Short BlackApp (file 10)')
    await chooseFile(user, 'stock-errors.xlsx')
    await user.click(importButton())
    expect(await screen.findByText('147 of 150 rows imported')).toBeInTheDocument()
    const lines = screen.getAllByText(/^Row \d+: /).map((line) => line.textContent)
    expect(lines).toEqual(['Row 9: a1', 'Row 9: a2', 'Row 101: c', 'Row 117: b'])
  })

  it('shows the row errors under a warning line', async () => {
    server.use(
      http.post('*/api-admin/emitter/:emitterId/import/:kind', () =>
        HttpResponse.json({
          totalRows: 150,
          okRows: 148,
          rowErrors: {
            '101': ["Field [Value] shouldn't be empty"],
            '117': ['Value [LVMH.PA] was expected for field [RIC].'],
          },
        }),
      ),
    )
    const user = renderImports()
    await chooseType(user, 'Short BlackApp (file 10)')
    await chooseFile(user, 'stock-errors.xlsx')
    await user.click(importButton())
    expect(await screen.findByText('148 of 150 rows imported')).toBeInTheDocument()
    expect(screen.getByText('Rows with errors')).toBeInTheDocument()
    expect(screen.getByText("Row 101: Field [Value] shouldn't be empty")).toBeInTheDocument()
    expect(
      screen.getByText('Row 117: Value [LVMH.PA] was expected for field [RIC].'),
    ).toBeInTheDocument()
  })

  it('shows whole-file errors verbatim and no result line', async () => {
    server.use(
      http.post('*/api-admin/emitter/:emitterId/import/:kind', () =>
        HttpResponse.json({ message: 'Invalid Excel file' }, { status: 400 }),
      ),
    )
    const user = renderImports()
    await chooseType(user, 'Consensus')
    await chooseFile(user, 'invalid.xlsx')
    await user.click(importButton())
    expect(await screen.findByText('Invalid Excel file')).toBeInTheDocument()
    expect(screen.queryByText(/rows imported/)).not.toBeInTheDocument()
    await chooseFile(user, 'other.xlsx')
    expect(screen.queryByText('Invalid Excel file')).not.toBeInTheDocument()
  })

  it('disables the button while uploading and clears the result on a new choice', async () => {
    server.use(
      http.post('*/api-admin/emitter/:emitterId/import/:kind', async () => {
        await new Promise((resolve) => setTimeout(resolve, 50))
        return HttpResponse.json({ totalRows: 2, okRows: 2, rowErrors: {} })
      }),
    )
    const user = renderImports()
    await chooseType(user, 'Consensus')
    await chooseFile(user, 'consensus.xlsx')
    await user.click(importButton())
    expect(importButton()).toBeDisabled()
    expect(await screen.findByText('2 of 2 rows imported')).toBeInTheDocument()
    await waitFor(() => {
      expect(importButton()).toBeEnabled()
    })
    await chooseType(user, 'Reco TP')
    expect(screen.queryByText('2 of 2 rows imported')).not.toBeInTheDocument()
  })

  it('drops a result that arrives after the file changed', async () => {
    server.use(
      http.post('*/api-admin/emitter/:emitterId/import/:kind', async () => {
        await new Promise((resolve) => setTimeout(resolve, 50))
        return HttpResponse.json({ message: 'Invalid Excel file' }, { status: 400 })
      }),
    )
    const user = renderImports()
    await chooseType(user, 'Consensus')
    await chooseFile(user, 'invalid.xlsx')
    await user.click(importButton())
    await chooseFile(user, 'consensus.xlsx')
    await new Promise((resolve) => setTimeout(resolve, 100))
    expect(screen.queryByText('Invalid Excel file')).not.toBeInTheDocument()
  })
})
