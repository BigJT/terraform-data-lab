import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { CompanyDetailScreen } from './CompanyDetailScreen'

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen(path: string, state?: unknown) {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[{ pathname: path, state }]}>
          <Routes>
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
          <Location />
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

function valueOf(label: string) {
  return screen.getByText(label, { selector: 'dt' }).nextElementSibling?.textContent
}

describe('CompanyDetailScreen', () => {
  it('shows the name, Archive button and five tabs in order', async () => {
    renderScreen('/companies/c1')
    expect(await screen.findByRole('heading', { level: 1, name: 'LVMH' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Archive' })).toBeInTheDocument()
    expect(screen.getAllByRole('tab').map((tab) => tab.textContent)).toEqual([
      'Information',
      'Lists',
      'Users',
      'Imports',
      'Factset',
    ])
    expect(screen.getByRole('tab', { name: 'Information' })).toHaveAttribute(
      'aria-selected',
      'true',
    )
  })

  it('shows the Information values for LVMH', async () => {
    renderScreen('/companies/c1/information')
    await screen.findByRole('heading', { level: 1, name: 'LVMH' })
    expect(valueOf('RIC')).toBe('LVMH.PA')
    expect(valueOf('Name')).toBe('LVMH')
    expect(valueOf('Language')).toBe('French')
    expect(valueOf('Market')).toBe('Euronext Paris')
    expect(valueOf('Sector')).toBe('Luxury')
    expect(valueOf('Sub-sector')).toBe('Fashion')
    expect(screen.getByText('INDICES')).toBeInTheDocument()
    expect(valueOf('Index 1')).toBe('.FCHI CAC 40')
    expect(valueOf('Index 2')).toBe('.SXQP Stoxx Europe 600 Personal & Household Goods')
    expect(valueOf('Index 3')).toBe('.STOXX50E Euro Stoxx 50')
    expect(valueOf('Index 4')).toBe('None')
    expect(screen.getByRole('button', { name: 'Edit' })).toBeInTheDocument()
  })

  it('shows None for Accor sub-sector and empty indices', async () => {
    renderScreen('/companies/c4')
    await screen.findByRole('heading', { level: 1, name: 'Accor' })
    expect(valueOf('Sub-sector')).toBe('None')
    expect(valueOf('Index 1')).toBe('.FCHI CAC 40')
    expect(valueOf('Index 2')).toBe('None')
    expect(valueOf('Index 3')).toBe('None')
    expect(valueOf('Index 4')).toBe('None')
  })

  it('shows English for Diageo and the London market', async () => {
    renderScreen('/companies/c5')
    await screen.findByRole('heading', { level: 1, name: 'Diageo' })
    expect(valueOf('Language')).toBe('English')
    expect(valueOf('Market')).toBe('London Stock Exchange')
  })

  it('warns about users that could not be created, one line each', async () => {
    renderScreen('/companies/c1/information', {
      failures: [{ collaborator: 'a@x.example', message: 'Email a@x.example is already used.' }],
    })
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('Some users could not be created:')
    expect(alert).toHaveTextContent('a@x.example: Email a@x.example is already used.')
  })

  it('shows no warning when there are no failures', async () => {
    renderScreen('/companies/c1/information', { failures: [] })
    await screen.findByRole('heading', { level: 1, name: 'LVMH' })
    expect(screen.queryByText('Some users could not be created:')).toBeNull()
  })

  it('shows the Factset tab and puts the tab in the URL', async () => {
    const user = userEvent.setup()
    renderScreen('/companies/c1')
    await screen.findByRole('heading', { level: 1, name: 'LVMH' })
    await user.click(screen.getByRole('tab', { name: 'Factset' }))
    expect(screen.getByTestId('location')).toHaveTextContent('/companies/c1/factset')
    expect(await screen.findByText('FACTSET PEERS')).toBeInTheDocument()
    expect(screen.queryByText('INDICES')).not.toBeInTheDocument()
  })

  it('selects the tab named in the URL', async () => {
    renderScreen('/companies/c1/imports')
    await screen.findByRole('heading', { level: 1, name: 'LVMH' })
    expect(screen.getByRole('tab', { name: 'Imports' })).toHaveAttribute('aria-selected', 'true')
  })

  it('reads Unarchive for an archived company', async () => {
    renderScreen('/companies/c6')
    await screen.findByRole('heading', { level: 1, name: 'Worldline' })
    expect(screen.getByRole('button', { name: 'Unarchive' })).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Archive' })).not.toBeInTheDocument()
  })

  it('shows Company not found for an unknown id', async () => {
    renderScreen('/companies/nope')
    expect(await screen.findByText('Company not found')).toBeInTheDocument()
    expect(screen.queryByRole('tab')).not.toBeInTheDocument()
  })

  describe('Edit indices dialog', () => {
    async function openDialog(path = '/companies/c1') {
      const user = userEvent.setup()
      renderScreen(path)
      await screen.findByRole('heading', { level: 1 })
      await user.click(screen.getByRole('button', { name: 'Edit' }))
      const dialog = await screen.findByRole('dialog', { name: 'Edit indices' })
      await within(dialog).findByRole('combobox', { name: 'Index 1' })
      return { user, dialog }
    }

    async function optionsOf(user: ReturnType<typeof userEvent.setup>, label: string) {
      await user.click(screen.getByRole('combobox', { name: label }))
      const names = screen.getAllByRole('option').map((option) => option.textContent)
      await user.keyboard('{Escape}')
      return names
    }

    it('presets the four pickers to the current values', async () => {
      const { dialog } = await openDialog()
      expect(within(dialog).getByRole('combobox', { name: 'Index 1' })).toHaveTextContent(
        '.FCHI CAC 40',
      )
      expect(within(dialog).getByRole('combobox', { name: 'Index 4' })).toHaveTextContent('None')
    })

    it('excludes the indices chosen in the other pickers and offers None', async () => {
      const { user } = await openDialog()
      expect(await optionsOf(user, 'Index 4')).toEqual([
        'None',
        '.FTSE FTSE 100',
        '.SXNP Stoxx Europe 600 Industrials',
        '.SX3P Stoxx Europe 600 Food & Beverage',
      ])
      expect(await optionsOf(user, 'Index 1')).toEqual([
        'None',
        '.FCHI CAC 40',
        '.FTSE FTSE 100',
        '.SXNP Stoxx Europe 600 Industrials',
        '.SX3P Stoxx Europe 600 Food & Beverage',
      ])
    })

    it('Save sends the chosen RICs and refreshes the block', async () => {
      const { user } = await openDialog()
      await user.click(screen.getByRole('combobox', { name: 'Index 2' }))
      await user.click(
        screen.getByRole('option', { name: '.SX3P Stoxx Europe 600 Food & Beverage' }),
      )
      await user.click(screen.getByRole('combobox', { name: 'Index 4' }))
      await user.click(screen.getByRole('option', { name: '.FTSE FTSE 100' }))
      await user.click(screen.getByRole('button', { name: 'Save' }))
      await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
      await waitFor(() => {
        expect(valueOf('Index 2')).toBe('.SX3P Stoxx Europe 600 Food & Beverage')
      })
      expect(valueOf('Index 1')).toBe('.FCHI CAC 40')
      expect(valueOf('Index 3')).toBe('.STOXX50E Euro Stoxx 50')
      expect(valueOf('Index 4')).toBe('.FTSE FTSE 100')
    })

    it('Save sends null for None', async () => {
      const { user } = await openDialog()
      await user.click(screen.getByRole('combobox', { name: 'Index 3' }))
      await user.click(screen.getByRole('option', { name: 'None' }))
      await user.click(screen.getByRole('button', { name: 'Save' }))
      await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
      await waitFor(() => {
        expect(valueOf('Index 3')).toBe('None')
      })
      expect(valueOf('Index 1')).toBe('.FCHI CAC 40')
    })

    it('Cancel discards the change', async () => {
      const { user } = await openDialog()
      await user.click(screen.getByRole('combobox', { name: 'Index 2' }))
      await user.click(screen.getByRole('option', { name: 'None' }))
      await user.click(screen.getByRole('button', { name: 'Cancel' }))
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
      expect(valueOf('Index 2')).toBe('.SXQP Stoxx Europe 600 Personal & Household Goods')
      await user.click(screen.getByRole('button', { name: 'Edit' }))
      expect(screen.getByRole('combobox', { name: 'Index 2' })).toHaveTextContent('.SXQP')
    })

    it('keeps the dialog open and shows the message when Save fails', async () => {
      server.use(
        http.put('*/api-admin/emitters-management/emitter/indice/:id', () =>
          HttpResponse.json({ message: 'Boom' }, { status: 404 }),
        ),
      )
      const { user, dialog } = await openDialog()
      await user.click(screen.getByRole('button', { name: 'Save' }))
      expect(await within(dialog).findByText('Boom')).toBeInTheDocument()
      expect(screen.getByRole('dialog', { name: 'Edit indices' })).toBeInTheDocument()
    })
  })

  describe('Archive and unarchive', () => {
    it('archives, shows the banner and toggles back', async () => {
      const user = userEvent.setup()
      renderScreen('/companies/c1')
      await screen.findByRole('heading', { level: 1, name: 'LVMH' })
      expect(screen.queryByText('This company is archived')).not.toBeInTheDocument()
      await user.click(screen.getByRole('button', { name: 'Archive' }))
      expect(await screen.findByText('This company is archived')).toBeInTheDocument()
      await user.click(await screen.findByRole('button', { name: 'Unarchive' }))
      await screen.findByRole('button', { name: 'Archive' })
      expect(screen.queryByText('This company is archived')).not.toBeInTheDocument()
    })

    it('sends one archive request when Archive is double-clicked', async () => {
      let requests = 0
      server.use(
        http.put('*/api-admin/emitters-management/emitter/:id/archive', () => {
          requests += 1
          return new HttpResponse(null, { status: 200 })
        }),
      )
      const user = userEvent.setup()
      renderScreen('/companies/c1')
      await screen.findByRole('heading', { level: 1, name: 'LVMH' })
      await user.dblClick(screen.getByRole('button', { name: 'Archive' }))
      await waitFor(() => {
        expect(screen.getByRole('button', { name: 'Archive' })).toBeEnabled()
      })
      expect(requests).toBe(1)
    })

    it('shows the banner for an archived company', async () => {
      renderScreen('/companies/c6')
      expect(await screen.findByText('This company is archived')).toBeInTheDocument()
    })

    it('shows the message and keeps the button when archiving fails', async () => {
      server.use(
        http.put('*/api-admin/emitters-management/emitter/:id/archive', () =>
          HttpResponse.json({ message: 'Cannot archive' }, { status: 400 }),
        ),
      )
      const user = userEvent.setup()
      renderScreen('/companies/c1')
      await screen.findByRole('heading', { level: 1, name: 'LVMH' })
      await user.click(screen.getByRole('button', { name: 'Archive' }))
      expect(await screen.findByText('Cannot archive')).toBeInTheDocument()
      expect(screen.getByRole('button', { name: 'Archive' })).toBeInTheDocument()
      expect(screen.queryByText('This company is archived')).not.toBeInTheDocument()
    })
  })
})
