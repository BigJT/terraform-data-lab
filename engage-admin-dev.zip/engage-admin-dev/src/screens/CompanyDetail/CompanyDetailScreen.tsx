import { Alert, Box, Button, Link, Tab, Tabs } from '@mui/material'
import { useEffect, useState } from 'react'
import { Link as RouterLink, useLocation, useParams } from 'react-router'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { useGateway } from '@/data/gatewayContext'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import type { CompanyDetail, CreateCompanyFailure, IndexInfo } from '@/data/types'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { EditIndicesDialog } from './EditIndicesDialog'
import { FactsetTab } from './FactsetTab'
import { ImportsTab } from './ImportsTab'
import { ListsTab } from './ListsTab'
import { UsersTab } from './UsersTab'

const tabs = [
  { value: 'information', label: 'companyDetail.tabInformation' },
  { value: 'lists', label: 'companyDetail.tabLists' },
  { value: 'users', label: 'companyDetail.tabUsers' },
  { value: 'imports', label: 'companyDetail.tabImports' },
  { value: 'factset', label: 'companyDetail.tabFactset' },
]

const languages = { 'fr-FR': 'fields.french', 'en-EN': 'fields.english' }

function indice(value: IndexInfo | null, none: string) {
  return value ? `${value.codeRIC} ${value.name}` : none
}

function Field({ label, value }: { label: string; value: string }) {
  const { t } = useTranslation()
  return (
    <>
      <Box component="dt" sx={{ color: colors.textSecondary, fontSize: 14 }}>
        {label}
      </Box>
      <Box component="dd" sx={{ m: 0, color: colors.textPrimary, fontSize: 14 }}>
        {value || t('common.none')}
      </Box>
    </>
  )
}

function Information({ company, onEdit }: { company: CompanyDetail; onEdit: () => void }) {
  const { t } = useTranslation()
  return (
    <Box sx={{ p: 2 }}>
      <Box
        component="dl"
        sx={{ m: 0, display: 'grid', gridTemplateColumns: '160px 1fr', rowGap: 1.5 }}
      >
        <Field label={t('fields.ric')} value={company.ric} />
        <Field label={t('fields.name')} value={company.name} />
        <Field label={t('fields.language')} value={t(languages[company.languageCode])} />
        <Field label={t('fields.market')} value={company.market.fullName} />
        <Field label={t('fields.sector')} value={company.sector.split('/')[0] ?? ''} />
        <Field
          label={t('fields.subSector')}
          value={
            company.sector.includes('/')
              ? company.sector.slice(company.sector.indexOf('/') + 1)
              : ''
          }
        />
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mt: 3, mb: 1.5 }}>
        <Box sx={{ fontSize: 12, fontWeight: 600, color: colors.textSecondary }}>
          {t('companyDetail.indices')}
        </Box>
        <Link
          component="button"
          type="button"
          underline="hover"
          sx={{ fontSize: 14 }}
          onClick={onEdit}
        >
          {t('common.edit')}
        </Link>
      </Box>
      <Box
        component="dl"
        sx={{ m: 0, display: 'grid', gridTemplateColumns: '160px 1fr', rowGap: 1.5 }}
      >
        <Field
          label={t('fields.index', { n: 1 })}
          value={indice(company.primaryIndice1, t('common.none'))}
        />
        <Field
          label={t('fields.index', { n: 2 })}
          value={indice(company.primaryIndice2, t('common.none'))}
        />
        <Field
          label={t('fields.index', { n: 3 })}
          value={indice(company.primaryIndice3, t('common.none'))}
        />
        <Field
          label={t('fields.index', { n: 4 })}
          value={indice(company.primaryIndice4, t('common.none'))}
        />
      </Box>
    </Box>
  )
}

export function CompanyDetailScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const { id = '', tab } = useParams()
  const location = useLocation()
  const failures = (location.state as { failures?: CreateCompanyFailure[] } | null)?.failures ?? []
  const [result, setResult] = useState<{
    id: string
    company?: CompanyDetail
    error?: string
  } | null>(null)
  const [reloads, setReloads] = useState(0)
  const [editing, setEditing] = useState(false)
  const [actionError, setActionError] = useState('')
  const [archiving, setArchiving] = useState(false)

  useEffect(() => {
    let current = true
    gateway.getCompany(id).then(
      (loaded) => {
        if (!current) return
        setResult({ id, company: loaded })
        setArchiving(false)
      },
      (failure: unknown) => {
        if (!current) return
        const message =
          failure instanceof GatewayError && failure.status === 404
            ? i18next.t('companyDetail.notFound')
            : gatewayMessage(failure, i18next.t('companyDetail.loadFailed'))
        setResult({ id, error: message })
        setArchiving(false)
      },
    )
    return () => {
      current = false
    }
  }, [gateway, id, reloads])

  if (result?.id !== id) return null
  if (result.error) return <Alert severity="error">{result.error}</Alert>
  const company = result.company
  if (!company) return null

  const selected = tabs.some((entry) => entry.value === tab)
    ? (tab ?? 'information')
    : 'information'

  function toggleArchive() {
    setActionError('')
    setArchiving(true)
    const request = company?.isArchived ? gateway.unarchiveCompany(id) : gateway.archiveCompany(id)
    request.then(
      () => {
        setReloads((count) => count + 1)
      },
      (failure: unknown) => {
        setArchiving(false)
        setActionError(gatewayMessage(failure, i18next.t('companyDetail.updateFailed')))
      },
    )
  }

  return (
    <>
      <Box sx={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <ScreenTitle>{company.name}</ScreenTitle>
        <Button variant="outlined" onClick={toggleArchive} disabled={archiving}>
          {company.isArchived ? t('companyDetail.unarchive') : t('companyDetail.archive')}
        </Button>
      </Box>
      {company.isArchived ? (
        <Alert severity="warning">{t('companyDetail.archivedBanner')}</Alert>
      ) : null}
      {failures.length > 0 ? (
        <Alert severity="warning">
          {t('companyDetail.createFailures')}
          {failures.map((failure) => (
            <div key={failure.collaborator}>{`${failure.collaborator}: ${failure.message}`}</div>
          ))}
        </Alert>
      ) : null}
      {actionError ? <Alert severity="error">{actionError}</Alert> : null}
      <Panel>
        <Tabs value={selected} sx={{ borderBottom: `1px solid ${colors.rule}` }}>
          {tabs.map((entry) => (
            <Tab
              key={entry.value}
              value={entry.value}
              label={t(entry.label)}
              component={RouterLink}
              to={`/companies/${id}/${entry.value}`}
            />
          ))}
        </Tabs>
        {selected === 'information' ? (
          <Information
            company={company}
            onEdit={() => {
              setEditing(true)
            }}
          />
        ) : selected === 'lists' ? (
          <ListsTab companyId={id} />
        ) : selected === 'users' ? (
          <UsersTab companyId={id} />
        ) : selected === 'imports' ? (
          <ImportsTab companyId={id} />
        ) : (
          <FactsetTab companyId={id} />
        )}
      </Panel>
      {editing ? (
        <EditIndicesDialog
          company={company}
          onClose={() => {
            setEditing(false)
          }}
          onSaved={() => {
            setEditing(false)
            setReloads((count) => count + 1)
          }}
        />
      ) : null}
    </>
  )
}
