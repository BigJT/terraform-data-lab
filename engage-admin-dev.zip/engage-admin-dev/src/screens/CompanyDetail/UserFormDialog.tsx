import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  MenuItem,
  TextField,
  Typography,
} from '@mui/material'
import { useState } from 'react'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import { emailPattern } from '@/screens/validation'

export interface UserFormValues {
  firstName: string
  lastName: string
  jobFunction: string
  email: string
  phone: string
  role: string
  passwordChangeRequired?: boolean
}

type Field = Exclude<keyof UserFormValues, 'passwordChangeRequired'>

const roles = [
  { value: 'ROLE_EMITTER', label: 'users.roleStandard' },
  { value: 'ROLE_EMITTER_LIMITED', label: 'users.roleLimited' },
]

const labels: Record<Field, string> = {
  firstName: 'fields.firstName',
  lastName: 'fields.lastName',
  jobFunction: 'fields.position',
  email: 'fields.email',
  phone: 'fields.phone',
  role: 'fields.role',
}

const serverFields: Record<string, Field> = {
  firstName: 'firstName',
  lastName: 'lastName',
  jobFunction: 'jobFunction',
  email: 'email',
  phone: 'phone',
  roles: 'role',
}

const emptyUserForm: UserFormValues = {
  firstName: '',
  lastName: '',
  jobFunction: '',
  email: '',
  phone: '',
  role: '',
}

function validate(values: UserFormValues) {
  const errors: Partial<Record<Field, string>> = {}
  if (!values.firstName.trim()) errors.firstName = i18next.t('validation.firstNameRequired')
  if (!values.lastName.trim()) errors.lastName = i18next.t('validation.lastNameRequired')
  if (!values.jobFunction.trim()) errors.jobFunction = i18next.t('validation.positionRequired')
  if (!values.email.trim()) errors.email = i18next.t('validation.emailRequired')
  else if (!emailPattern.test(values.email.trim()))
    errors.email = i18next.t('validation.emailInvalidAddress')
  if (!values.role) errors.role = i18next.t('validation.roleRequired')
  return errors
}

interface UserFormDialogProps {
  title: string
  initial?: UserFormValues
  readOnlyLines?: string[]
  onSubmit: (values: UserFormValues) => Promise<void>
  onClose: () => void
}

export function UserFormDialog({
  title,
  initial = emptyUserForm,
  readOnlyLines = [],
  onSubmit,
  onClose,
}: UserFormDialogProps) {
  const { t } = useTranslation()
  const [values, setValues] = useState(initial)
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({})
  const [serverMessage, setServerMessage] = useState('')
  const [saving, setSaving] = useState(false)

  function change(field: Field, value: string) {
    setValues({ ...values, [field]: value })
  }

  function save() {
    const found = validate(values)
    setErrors(found)
    setServerMessage('')
    if (Object.keys(found).length > 0) return
    setSaving(true)
    onSubmit(values).catch((failure: unknown) => {
      setSaving(false)
      if (!(failure instanceof GatewayError)) {
        setServerMessage(gatewayMessage(failure, i18next.t('users.saveFailed')))
        return
      }
      setServerMessage(gatewayMessage(failure, i18next.t('users.saveFailed')))
      const mapped: Partial<Record<Field, string>> = {}
      for (const entry of failure.fieldErrors ?? []) {
        const field = serverFields[entry.field]
        if (field) mapped[field] = entry.message
      }
      setErrors(mapped)
    })
  }

  function text(field: Exclude<Field, 'role'>) {
    return (
      <TextField
        size="small"
        label={t(labels[field])}
        value={values[field]}
        error={Boolean(errors[field])}
        helperText={errors[field]}
        onChange={(event) => {
          change(field, event.target.value)
        }}
      />
    )
  }

  return (
    <Dialog open onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'grid', gap: 2, pt: 1 }}>
          {serverMessage ? <Alert severity="error">{serverMessage}</Alert> : null}
          {text('firstName')}
          {text('lastName')}
          {text('jobFunction')}
          {text('email')}
          {text('phone')}
          <TextField
            select
            size="small"
            label={t(labels.role)}
            value={values.role}
            error={Boolean(errors.role)}
            helperText={errors.role}
            onChange={(event) => {
              change('role', event.target.value)
            }}
          >
            {roles.map((role) => (
              <MenuItem key={role.value} value={role.value}>
                {t(role.label)}
              </MenuItem>
            ))}
          </TextField>
          {readOnlyLines.map((line) => (
            <Typography key={line} variant="body2">
              {line}
            </Typography>
          ))}
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{t('common.cancel')}</Button>
        <Button variant="contained" onClick={save} disabled={saving}>
          {t('common.save')}
        </Button>
      </DialogActions>
    </Dialog>
  )
}
