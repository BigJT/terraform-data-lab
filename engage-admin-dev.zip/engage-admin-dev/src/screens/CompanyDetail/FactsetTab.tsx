import {
  Alert,
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  IconButton,
  Snackbar,
  TextField,
} from '@mui/material'
import DeleteOutlinedIcon from '@mui/icons-material/DeleteOutlined'
import { useEffect, useState } from 'react'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { gatewayMessage } from '@/data/gatewayClient'
import { useGateway } from '@/data/gatewayContext'
import type { Factset, FactsetPeer } from '@/data/types'

interface FactsetTabProps {
  companyId: string
}

const heading = { fontSize: 12, fontWeight: 600, color: colors.textSecondary }

function message(failure: unknown) {
  return gatewayMessage(failure, i18next.t('factset.saveFailed'))
}

export function FactsetTab({ companyId }: FactsetTabProps) {
  const { t } = useTranslation()
  const gateway = useGateway()
  const [factset, setFactset] = useState<Factset | null>(null)
  const [loadError, setLoadError] = useState('')
  const [peers, setPeers] = useState<FactsetPeer[]>([])
  const [ticked, setTicked] = useState<string[]>([])
  const [search, setSearch] = useState('')
  const [applied, setApplied] = useState('')
  const [peersError, setPeersError] = useState('')
  const [multiplesError, setMultiplesError] = useState('')
  const [toast, setToast] = useState(false)

  useEffect(() => {
    let current = true
    gateway.getFactset(companyId).then(
      (loaded) => {
        if (!current) return
        setFactset(loaded)
        setPeers(loaded.peersBloomIds)
        setTicked(loaded.multiples.map((multiple) => multiple.key))
      },
      (failure: unknown) => {
        if (current) setLoadError(gatewayMessage(failure, i18next.t('factset.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway, companyId])

  if (loadError) return <Alert severity="error">{loadError}</Alert>
  if (!factset) return null

  const incomplete = peers.some((peer) => !peer.factsetName.trim() || !peer.factsetId.trim())
  const shown = factset.availableMultiples.filter((multiple) =>
    multiple.label.toLowerCase().includes(applied.trim().toLowerCase()),
  )

  function editPeer(index: number, change: Partial<FactsetPeer>) {
    setPeers((rows) => rows.map((row, at) => (at === index ? { ...row, ...change } : row)))
  }

  function savePeers() {
    setPeersError('')
    gateway.saveFactsetPeers(companyId, peers).then(
      () => {
        setToast(true)
      },
      (failure: unknown) => {
        setPeersError(message(failure))
      },
    )
  }

  function saveMultiples() {
    setMultiplesError('')
    gateway.saveFactsetMultiples(companyId, ticked).then(
      () => {
        setToast(true)
      },
      (failure: unknown) => {
        setMultiplesError(message(failure))
      },
    )
  }

  return (
    <Box sx={{ p: 2, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
      <Panel>
        <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <Box sx={heading}>{t('factset.peers')}</Box>
          {peers.length === 0 ? (
            <Box sx={{ fontSize: 14, color: colors.textSecondary }}>{t('factset.noPeers')}</Box>
          ) : null}
          {peers.map((peer, index) => (
            <Box key={index} sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField
                label={t('fields.name')}
                size="small"
                value={peer.factsetName}
                onChange={(event) => {
                  editPeer(index, { factsetName: event.target.value })
                }}
              />
              <TextField
                label={t('factset.id')}
                size="small"
                value={peer.factsetId}
                onChange={(event) => {
                  editPeer(index, { factsetId: event.target.value })
                }}
              />
              <IconButton
                aria-label={t('common.remove')}
                onClick={() => {
                  setPeers((rows) => rows.filter((_, at) => at !== index))
                }}
              >
                <DeleteOutlinedIcon />
              </IconButton>
            </Box>
          ))}
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Button
              variant="outlined"
              onClick={() => {
                setPeers((rows) => [...rows, { factsetName: '', factsetId: '' }])
              }}
            >
              {t('factset.addPeer')}
            </Button>
            <Button variant="contained" disabled={incomplete} onClick={savePeers}>
              {t('factset.savePeers')}
            </Button>
          </Box>
          {peersError ? <Alert severity="error">{peersError}</Alert> : null}
        </Box>
      </Panel>
      <Panel>
        <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <Box sx={heading}>{t('factset.multiples')}</Box>
          <Box sx={{ display: 'flex', gap: 1 }}>
            <TextField
              size="small"
              placeholder={t('factset.searchMultiples')}
              value={search}
              onChange={(event) => {
                setSearch(event.target.value)
              }}
            />
            <Button
              variant="outlined"
              onClick={() => {
                setApplied(search)
              }}
            >
              {t('factset.search')}
            </Button>
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            {shown.map((multiple) => (
              <FormControlLabel
                key={multiple.key}
                label={multiple.label}
                control={
                  <Checkbox
                    checked={ticked.includes(multiple.key)}
                    onChange={(event) => {
                      setTicked((keys) =>
                        event.target.checked
                          ? [...keys, multiple.key]
                          : keys.filter((key) => key !== multiple.key),
                      )
                    }}
                  />
                }
              />
            ))}
          </Box>
          <Box>
            <Button variant="contained" onClick={saveMultiples}>
              {t('common.save')}
            </Button>
          </Box>
          {multiplesError ? <Alert severity="error">{multiplesError}</Alert> : null}
        </Box>
      </Panel>
      <Snackbar
        open={toast}
        autoHideDuration={4000}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        onClose={() => {
          setToast(false)
        }}
      >
        <Alert severity="success" variant="filled">
          {t('factset.saved')}
        </Alert>
      </Snackbar>
    </Box>
  )
}
