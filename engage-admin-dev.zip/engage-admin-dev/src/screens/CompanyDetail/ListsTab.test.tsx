import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { CompanyDetailScreen } from './CompanyDetailScreen'

function renderLists(id: string) {
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[`/companies/${id}/lists`]}>
          <Routes>
            <Route path="companies/:id/:tab?" element={<CompanyDetailScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

async function openCreate(user: ReturnType<typeof userEvent.setup>) {
  await user.click(await screen.findByRole('button', { name: 'Create a list' }))
  return screen.findByRole('dialog', { name: 'Create a list' })
}

async function addTicker(
  dialog: HTMLElement,
  user: ReturnType<typeof userEvent.setup>,
  ric: string,
) {
  await user.type(within(dialog).getByLabelText('Ticker'), ric)
  await user.click(within(dialog).getByRole('button', { name: 'Add' }))
}

describe('Lists tab', () => {
  it('shows each list with its count and buttons, and expands to the tickers', async () => {
    const user = renderLists('c1')
    expect(await screen.findByText('Luxury peers')).toBeInTheDocument()
    expect(screen.getByText('3 items')).toBeInTheDocument()
    expect(screen.getByText('European consumer')).toBeInTheDocument()
    expect(screen.getByText('1 item')).toBeInTheDocument()
    expect(screen.getAllByRole('button', { name: 'Add an item' })).toHaveLength(2)
    expect(screen.getAllByRole('button', { name: 'Rename' })).toHaveLength(2)
    expect(screen.getAllByRole('button', { name: 'Delete' })).toHaveLength(2)
    await user.click(screen.getByText('Luxury peers'))
    expect(await screen.findByText('HRMS.PA')).toBeVisible()
    expect(screen.getByText('Hermes International')).toBeVisible()
    expect(screen.getByText('CDI.PA')).toBeVisible()
    expect(screen.getByText('Christian Dior')).toBeVisible()
    expect(screen.getByText('PRTP.PA')).toBeVisible()
    expect(screen.getByText('Kering')).toBeVisible()
    expect(screen.getAllByRole('button', { name: 'Delete' })).toHaveLength(5)
  })

  it('shows the empty state for a company with no lists', async () => {
    renderLists('c4')
    expect(await screen.findByText('No lists yet')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Create a list' })).toBeInTheDocument()
  })

  it('shows the load failure message', async () => {
    server.use(
      http.get('*/api-admin/tickers/by-emitter/:id', () =>
        HttpResponse.json({ message: 'Lists are down' }, { status: 500 }),
      ),
    )
    renderLists('c1')
    expect(await screen.findByText('Lists are down')).toBeInTheDocument()
  })

  it('shows Required and Add at least one ticker when saving an empty form', async () => {
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(within(dialog).getByText('Required')).toBeInTheDocument()
    expect(within(dialog).getByText('Add at least one ticker')).toBeInTheDocument()
  })

  it('treats a blank title as Required', async () => {
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await user.type(within(dialog).getByLabelText('Title'), '   ')
    await addTicker(dialog, user, 'AIR.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(within(dialog).getByText('Required')).toBeInTheDocument()
    expect(within(dialog).queryByText('Add at least one ticker')).not.toBeInTheDocument()
  })

  it('rejects an unknown RIC', async () => {
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await addTicker(dialog, user, 'ZZZZ.PA')
    expect(await within(dialog).findByText('This RIC code does not exist')).toBeInTheDocument()
    expect(within(dialog).queryByText('ZZZZ.PA')).not.toBeInTheDocument()
  })

  it('adds a chip, clears the field and rejects the same RIC in another case', async () => {
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await addTicker(dialog, user, 'AIR.PA')
    expect(await within(dialog).findByText('AIR.PA')).toBeInTheDocument()
    expect(within(dialog).getByLabelText('Ticker')).toHaveValue('')
    await addTicker(dialog, user, 'air.pa')
    expect(
      await within(dialog).findByText('This ticker is already in the list'),
    ).toBeInTheDocument()
    expect(within(dialog).getAllByText('AIR.PA')).toHaveLength(1)
  })

  it('keeps both chips when a second Add starts before the first answers', async () => {
    server.use(
      http.get('*/api-admin/pairs-management/pairs/ric/:search', async ({ params }) => {
        await new Promise((resolve) => setTimeout(resolve, 300))
        return HttpResponse.json({ ric: String(params.search), name: 'Any' })
      }),
    )
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await addTicker(dialog, user, 'AIR.PA')
    await user.clear(within(dialog).getByLabelText('Ticker'))
    await addTicker(dialog, user, 'HRMS.PA')
    expect(await within(dialog).findByText('HRMS.PA')).toBeInTheDocument()
    expect(within(dialog).getByText('AIR.PA')).toBeInTheDocument()
  })

  it('removes a chip', async () => {
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await addTicker(dialog, user, 'AIR.PA')
    const chip = (await within(dialog).findByText('AIR.PA')).closest('.MuiChip-root')
    await user.click(within(chip as HTMLElement).getByTestId('CancelIcon'))
    expect(within(dialog).queryByText('AIR.PA')).not.toBeInTheDocument()
  })

  it('saves, closes and shows the new list with 1 item', async () => {
    const user = renderLists('c4')
    const dialog = await openCreate(user)
    await user.type(within(dialog).getByLabelText('Title'), 'Watchlist')
    await addTicker(dialog, user, 'AIR.PA')
    await within(dialog).findByText('AIR.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(await screen.findByText('Watchlist')).toBeInTheDocument()
    expect(screen.getByText('1 item')).toBeInTheDocument()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
  })

  it('keeps the dialog open and shows the duplicate message verbatim', async () => {
    const user = renderLists('c1')
    const dialog = await openCreate(user)
    await user.type(within(dialog).getByLabelText('Title'), 'luxury PEERS')
    await addTicker(dialog, user, 'AIR.PA')
    await within(dialog).findByText('AIR.PA')
    await user.click(within(dialog).getByRole('button', { name: 'Save' }))
    expect(
      await within(dialog).findByText(
        'A list with name [luxury PEERS] already exists for the emitter.',
      ),
    ).toBeInTheDocument()
    expect(screen.getByRole('dialog', { name: 'Create a list' })).toBeInTheDocument()
    expect(screen.queryByText('luxury PEERS')).not.toBeInTheDocument()
  })

  it('Cancel closes the dialog without saving', async () => {
    const user = renderLists('c4')
    const dialog = await openCreate(user)
    await user.click(within(dialog).getByRole('button', { name: 'Cancel' }))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(screen.getByText('No lists yet')).toBeInTheDocument()
  })
})
