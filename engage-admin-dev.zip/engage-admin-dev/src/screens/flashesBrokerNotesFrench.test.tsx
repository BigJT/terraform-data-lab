import { describe, expect, it } from 'vitest'
import { screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { setLanguage } from '@/i18n'
import { FlashesScreen } from '@/screens/Flashes/FlashesScreen'
import { FlashDetailScreen } from '@/screens/Flashes/FlashDetailScreen'
import { SendFlashScreen } from '@/screens/Flashes/SendFlashScreen'
import { BrokerNotesScreen } from '@/screens/BrokerNotes/BrokerNotesScreen'
import { SendBrokerNoteScreen } from '@/screens/BrokerNotes/SendBrokerNoteScreen'

function renderFrench(path: string) {
  setLanguage('fr')
  renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={[path]}>
          <Routes>
            <Route path="flashes" element={<FlashesScreen />} />
            <Route path="flashes/new" element={<SendFlashScreen />} />
            <Route path="flashes/:id" element={<FlashDetailScreen />} />
            <Route path="broker-notes" element={<BrokerNotesScreen />} />
            <Route path="broker-notes/new" element={<SendBrokerNoteScreen />} />
          </Routes>
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
  return userEvent.setup()
}

describe('flashes screens in French', () => {
  it('list: search, send button, columns and empty text', async () => {
    const user = renderFrench('/flashes')
    expect(await screen.findAllByRole('cell')).not.toHaveLength(1)
    expect(screen.getByPlaceholderText('Rechercher un flash')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Envoyer un flash' })).toBeInTheDocument()
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      "Date d'envoi",
      'Destinataire(s)',
      'Valeur',
      'Titre',
      'Type',
    ])
    expect(screen.getAllByText('1 émetteur').length).toBeGreaterThan(0)
    expect(screen.getByText('2 émetteurs')).toBeInTheDocument()
    await user.type(screen.getByPlaceholderText('Rechercher un flash'), 'zzzz')
    expect(await screen.findByText('Aucun flash trouvé.')).toBeInTheDocument()
  })

  it('detail: headings, email note and the delete dialog', async () => {
    const user = renderFrench('/flashes/f1')
    expect(await screen.findByText('DESTINATAIRE(S)')).toBeInTheDocument()
    expect(screen.getByText('CONTENU')).toBeInTheDocument()
    expect(screen.getByText('LIENS ASSOCIÉS :')).toBeInTheDocument()
    expect(screen.getByText('Duplicata envoyé par email')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Retour aux flashs' })).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Supprimer' }))
    const dialog = screen.getByRole('dialog', { name: "Suppression d'un flash" })
    expect(within(dialog).getByText('Êtes-vous sûr de vouloir supprimer ?')).toBeInTheDocument()
    expect(within(dialog).getByText('Cette action est irréversible')).toBeInTheDocument()
    expect(within(dialog).getByRole('button', { name: 'Oui' })).toBeInTheDocument()
  })

  it('detail: an unknown flash shows the French not-found text', async () => {
    renderFrench('/flashes/nope')
    expect(await screen.findByRole('heading', { name: 'Flash introuvable' })).toBeInTheDocument()
  })

  it('compose: empty send shows the French errors', async () => {
    const user = renderFrench('/flashes/new')
    expect(screen.getByLabelText('Envoyer à tous les émetteurs')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Envoyer' }))
    expect(await screen.findByText('Merci de saisir un destinataire')).toBeInTheDocument()
    expect(screen.getByText("L'objet est requis")).toBeInTheDocument()
    expect(screen.getByText('La valeur est requise')).toBeInTheDocument()
    expect(screen.getByText('Le type est requis')).toBeInTheDocument()
    expect(screen.getByText('Le message est requis')).toBeInTheDocument()
  })

  it('compose: an empty attachment shows the French picker error', async () => {
    const user = renderFrench('/flashes/new')
    expect(screen.getByRole('button', { name: 'Ajouter une pièce jointe' })).toBeInTheDocument()
    const input = screen.getByLabelText('Champ de pièce jointe')
    await user.upload(input, new File([], 'vide.pdf'))
    expect(await screen.findByText('La pièce jointe vide.pdf est vide.')).toBeInTheDocument()
  })
})

describe('broker notes screens in French', () => {
  it('list: search, legend and columns', async () => {
    renderFrench('/broker-notes')
    expect(await screen.findAllByRole('cell')).not.toHaveLength(1)
    expect(screen.getByPlaceholderText('Rechercher une note de broker')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Envoyer une note' })).toBeInTheDocument()
    for (const label of ['Changement de recommandation', 'Initiation', 'Secteur']) {
      expect(screen.getAllByText(label).length).toBeGreaterThan(0)
    }
    expect(screen.getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual([
      "Date d'envoi",
      'Valeur',
      'Broker',
      'Type',
      'Objectif',
      'Recommandation',
      'Ancien Objectif',
      'Ancienne Recommandation',
      '',
    ])
  })

  it('compose: empty send shows the French errors and the continue button', async () => {
    const user = renderFrench('/broker-notes/new')
    expect(screen.getByRole('button', { name: 'Envoyer et continuer' })).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: /^Envoyer$/ }))
    expect(await screen.findByText('Merci de saisir un émetteur')).toBeInTheDocument()
    expect(screen.getByText('Merci de saisir un broker')).toBeInTheDocument()
    expect(screen.getByText("L'objectif est requis")).toBeInTheDocument()
    expect(screen.getByText('Le type est requis')).toBeInTheDocument()
  })
})
