import { Box } from '@mui/material'
import { useTranslation } from 'react-i18next'
import { colors } from '@/ds/theme'
import { ScreenTitle } from '@/screens/ScreenTitle'

export function PlaceholderScreen({ titleKey }: { titleKey: string }) {
  const { t } = useTranslation()
  return (
    <>
      <ScreenTitle>{t(titleKey)}</ScreenTitle>
      <Box sx={{ fontSize: 14, color: colors.textSecondary }}>{t('placeholder.comingSoon')}</Box>
    </>
  )
}
