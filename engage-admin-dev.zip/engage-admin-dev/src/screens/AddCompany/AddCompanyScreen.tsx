import {
  Alert,
  Box,
  Button,
  FormControl,
  FormControlLabel,
  FormLabel,
  MenuItem,
  Radio,
  RadioGroup,
  TextField,
} from '@mui/material'
import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router'
import i18next from 'i18next'
import { useTranslation } from 'react-i18next'
import { Panel } from '@/ds/components'
import { colors } from '@/ds/theme'
import { useGateway } from '@/data/gatewayContext'
import { GatewayError, gatewayMessage } from '@/data/gatewayClient'
import type { Collaborator, CreateCompanyRequest, IndexInfo, Market } from '@/data/types'
import { availableIndices } from '@/screens/indexOptions'
import { ScreenTitle } from '@/screens/ScreenTitle'
import { emailPattern } from '@/screens/validation'

const steps = ['addCompany.stepInformation', 'addCompany.stepIndices', 'addCompany.stepUsers']
const none = 'none'

interface Information {
  ric: string
  name: string
  languageCode: 'fr-FR' | 'en-EN'
  marketCode: string
  sector: string
  subSector: string
}

type InformationErrors = Partial<Record<'ric' | 'name' | 'marketCode' | 'sector', string>>

interface UserDraft {
  key: number
  firstName: string
  lastName: string
  jobFunction: string
  email: string
  phone: string
}

type UserField = Exclude<keyof UserDraft, 'key'>
type UserErrors = Partial<Record<UserField, string>>

const userFields: { field: UserField; label: string }[] = [
  { field: 'firstName', label: 'fields.firstName' },
  { field: 'lastName', label: 'fields.lastName' },
  { field: 'jobFunction', label: 'fields.position' },
  { field: 'email', label: 'fields.email' },
  { field: 'phone', label: 'fields.phone' },
]

function informationErrors(information: Information): InformationErrors {
  const errors: InformationErrors = {}
  if (!information.ric.trim()) errors.ric = i18next.t('validation.ricRequired')
  if (!information.name.trim()) errors.name = i18next.t('validation.nameRequired')
  if (!information.marketCode) errors.marketCode = i18next.t('validation.marketRequired')
  if (!information.sector) errors.sector = i18next.t('validation.sectorRequired')
  return errors
}

function userErrors(user: UserDraft): UserErrors {
  const errors: UserErrors = {}
  if (!user.firstName.trim()) errors.firstName = i18next.t('validation.firstNameRequired')
  if (!user.lastName.trim()) errors.lastName = i18next.t('validation.lastNameRequired')
  if (!user.jobFunction.trim()) errors.jobFunction = i18next.t('validation.positionRequired')
  if (!user.email.trim()) errors.email = i18next.t('validation.emailRequired')
  else if (!emailPattern.test(user.email.trim()))
    errors.email = i18next.t('validation.emailInvalid')
  return errors
}

function collaborator(user: UserDraft): Collaborator {
  const phone = user.phone.trim()
  return {
    email: user.email.trim(),
    firstName: user.firstName.trim(),
    lastName: user.lastName.trim(),
    jobFunction: user.jobFunction.trim(),
    ...(phone ? { phone } : {}),
    roles: ['ROLE_EMITTER'],
  }
}

function message(failure: unknown, fallback: string) {
  return gatewayMessage(failure, fallback)
}

export function AddCompanyScreen() {
  const { t } = useTranslation()
  const gateway = useGateway()
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [markets, setMarkets] = useState<Market[]>([])
  const [sectors, setSectors] = useState<string[]>([])
  const [indices, setIndices] = useState<IndexInfo[]>([])
  const [loadError, setLoadError] = useState('')
  const [serverError, setServerError] = useState('')
  const [information, setInformation] = useState<Information>({
    ric: '',
    name: '',
    languageCode: 'fr-FR',
    marketCode: '',
    sector: '',
    subSector: '',
  })
  const [errors, setErrors] = useState<InformationErrors>({})
  const [chosen, setChosen] = useState<string[]>([none, none, none, none])
  const [users, setUsers] = useState<UserDraft[]>([])
  const [usersErrors, setUsersErrors] = useState<Record<number, UserErrors>>({})
  const [busy, setBusy] = useState(false)
  const nextKey = useRef(0)
  // The RIC being typed, so a slow lookup for an older value never overwrites a newer result.
  const currentRic = useRef('')

  useEffect(() => {
    let current = true
    Promise.all([gateway.listMarkets(), gateway.listSectors(), gateway.listIndices()]).then(
      ([loadedMarkets, loadedSectors, loadedIndices]) => {
        if (!current) return
        setMarkets(loadedMarkets)
        setSectors(loadedSectors)
        setIndices(loadedIndices)
      },
      (failure: unknown) => {
        if (current) setLoadError(message(failure, i18next.t('addCompany.loadFailed')))
      },
    )
    return () => {
      current = false
    }
  }, [gateway])

  const parentSectors = sectors.filter((sector) => !sector.includes('/'))
  const subSectors = sectors
    .filter((sector) => sector.startsWith(`${information.sector}/`))
    .map((sector) => sector.slice(information.sector.length + 1))

  function update(changes: Partial<Information>) {
    setInformation((previous) => ({ ...previous, ...changes }))
  }

  /** Resolves true when the RIC exists; sets or clears the RIC error for the value checked. */
  async function checkRic(ric: string): Promise<boolean> {
    try {
      await gateway.lookupRic(ric)
      if (currentRic.current === ric) setErrors((previous) => ({ ...previous, ric: undefined }))
      return true
    } catch (failure) {
      const text =
        failure instanceof GatewayError && failure.status === 404
          ? i18next.t('validation.unknownRic')
          : message(failure, i18next.t('addCompany.ricCheckFailed'))
      if (currentRic.current === ric) setErrors((previous) => ({ ...previous, ric: text }))
      return false
    }
  }

  async function next() {
    if (step === 0) {
      const found = informationErrors(information)
      setErrors(found)
      const ric = information.ric.trim()
      if (!ric) return
      setBusy(true)
      const exists = await checkRic(ric)
      setBusy(false)
      // Stay put if other fields are missing, the RIC is unknown, or it was edited during the lookup.
      if (Object.keys(found).length > 0 || !exists || currentRic.current !== ric) return
    }
    setServerError('')
    setStep(step + 1)
  }

  function add() {
    const found: Record<number, UserErrors> = {}
    for (const user of users) {
      const userFound = userErrors(user)
      if (Object.keys(userFound).length > 0) found[user.key] = userFound
    }
    setUsersErrors(found)
    if (Object.keys(found).length > 0) return

    const [national1, sector1, national2, sector2] = chosen.map((ric) =>
      ric === none ? undefined : ric,
    )
    const request: CreateCompanyRequest = {
      name: information.name.trim(),
      ric: information.ric.trim(),
      marketCode: information.marketCode,
      languageCode: information.languageCode,
      sector: information.sector,
      ...(information.subSector
        ? { subSector: `${information.sector}/${information.subSector}` }
        : {}),
      ...(national1 ? { primaryIndiceRic1: national1 } : {}),
      ...(sector1 ? { primaryIndiceRic2: sector1 } : {}),
      ...(national2 ? { primaryIndiceRic3: national2 } : {}),
      ...(sector2 ? { primaryIndiceRic4: sector2 } : {}),
      otherIndicesRic: [],
      collaborators: users.map(collaborator),
    }
    setBusy(true)
    setServerError('')
    gateway.createCompany(request).then(
      ({ emitter, failures }) => {
        void navigate(`/companies/${emitter.id}/information`, { state: { failures } })
      },
      (failure: unknown) => {
        setServerError(message(failure, i18next.t('addCompany.createFailed')))
        setBusy(false)
        setStep(0)
      },
    )
  }

  function updateUser(key: number, field: UserField, value: string) {
    setUsers((previous) =>
      previous.map((user) => (user.key === key ? { ...user, [field]: value } : user)),
    )
  }

  return (
    <>
      <ScreenTitle>{t('companies.add')}</ScreenTitle>
      <Panel>
        <Box sx={{ display: 'flex', gap: 4, p: 2, borderBottom: `1px solid ${colors.rule}` }}>
          {steps.map((label, position) => (
            <Box
              key={label}
              aria-current={position === step ? 'step' : undefined}
              sx={{
                fontSize: 14,
                fontWeight: position === step ? 600 : 400,
                color: position === step ? colors.textPrimary : colors.textMuted,
              }}
            >
              {t(label)}
            </Box>
          ))}
        </Box>
        <Box sx={{ display: 'grid', gap: 2, p: 2, maxWidth: 560 }}>
          {loadError ? <Alert severity="error">{loadError}</Alert> : null}
          {serverError ? <Alert severity="error">{serverError}</Alert> : null}

          {step === 0 && (
            <>
              <TextField
                size="small"
                label={t('fields.ric')}
                value={information.ric}
                error={Boolean(errors.ric)}
                helperText={errors.ric}
                onChange={(event) => {
                  currentRic.current = event.target.value.trim()
                  update({ ric: event.target.value })
                }}
                onBlur={() => {
                  const ric = information.ric.trim()
                  if (ric) void checkRic(ric)
                }}
              />
              <TextField
                size="small"
                label={t('fields.name')}
                value={information.name}
                error={Boolean(errors.name)}
                helperText={errors.name}
                onChange={(event) => {
                  update({ name: event.target.value })
                }}
              />
              <FormControl>
                <FormLabel id="language-label" sx={{ fontSize: 14 }}>
                  {t('fields.language')}
                </FormLabel>
                <RadioGroup
                  row
                  aria-labelledby="language-label"
                  value={information.languageCode}
                  onChange={(event) => {
                    update({ languageCode: event.target.value as Information['languageCode'] })
                  }}
                >
                  <FormControlLabel
                    value="fr-FR"
                    control={<Radio size="small" />}
                    label={t('fields.french')}
                  />
                  <FormControlLabel
                    value="en-EN"
                    control={<Radio size="small" />}
                    label={t('fields.english')}
                  />
                </RadioGroup>
              </FormControl>
              <TextField
                select
                size="small"
                label={t('fields.market')}
                value={markets.length === 0 ? '' : information.marketCode}
                error={Boolean(errors.marketCode)}
                helperText={errors.marketCode}
                onChange={(event) => {
                  update({ marketCode: event.target.value })
                }}
              >
                {markets.map((market) => (
                  <MenuItem key={market.code} value={market.code}>
                    {market.fullName}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                select
                size="small"
                label={t('fields.sector')}
                value={sectors.length === 0 ? '' : information.sector}
                error={Boolean(errors.sector)}
                helperText={errors.sector}
                onChange={(event) => {
                  update({ sector: event.target.value, subSector: '' })
                }}
              >
                {parentSectors.map((sector) => (
                  <MenuItem key={sector} value={sector}>
                    {sector}
                  </MenuItem>
                ))}
              </TextField>
              <TextField
                select
                size="small"
                label={t('fields.subSector')}
                value={information.subSector || none}
                disabled={subSectors.length === 0}
                onChange={(event) => {
                  update({ subSector: event.target.value === none ? '' : event.target.value })
                }}
              >
                <MenuItem value={none}>{t('common.none')}</MenuItem>
                {subSectors.map((subSector) => (
                  <MenuItem key={subSector} value={subSector}>
                    {subSector}
                  </MenuItem>
                ))}
              </TextField>
            </>
          )}

          {step === 1 &&
            indices.length > 0 &&
            chosen.map((value, slot) => (
              <TextField
                key={slot}
                select
                size="small"
                label={t('fields.index', { n: slot + 1 })}
                value={value}
                onChange={(event) => {
                  setChosen(
                    chosen.map((ric, position) => (position === slot ? event.target.value : ric)),
                  )
                }}
              >
                <MenuItem value={none}>{t('common.none')}</MenuItem>
                {availableIndices(
                  indices,
                  chosen.map((ric) => (ric === none ? null : ric)),
                  slot,
                ).map((index) => (
                  <MenuItem key={index.codeRIC} value={index.codeRIC}>
                    {`${index.codeRIC} ${index.name}`}
                  </MenuItem>
                ))}
              </TextField>
            ))}

          {step === 2 && (
            <>
              {users.map((user, position) => {
                const heading = `user-${String(user.key)}-heading`
                const userFound = usersErrors[user.key] ?? {}
                return (
                  <Box
                    key={user.key}
                    role="group"
                    aria-labelledby={heading}
                    sx={{ display: 'grid', gap: 1.5, p: 2, border: `1px solid ${colors.rule}` }}
                  >
                    <Box
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                      }}
                    >
                      <Box
                        id={heading}
                        sx={{ fontSize: 14, fontWeight: 600, color: colors.textPrimary }}
                      >
                        {t('fields.user', { n: position + 1 })}
                      </Box>
                      <Button
                        onClick={() => {
                          setUsers(users.filter((entry) => entry.key !== user.key))
                        }}
                      >
                        {t('common.remove')}
                      </Button>
                    </Box>
                    {userFields.map(({ field, label }) => (
                      <TextField
                        key={field}
                        size="small"
                        label={t(label)}
                        value={user[field]}
                        error={Boolean(userFound[field])}
                        helperText={userFound[field]}
                        onChange={(event) => {
                          updateUser(user.key, field, event.target.value)
                        }}
                      />
                    ))}
                  </Box>
                )
              })}
              <Box>
                <Button
                  variant="outlined"
                  onClick={() => {
                    nextKey.current += 1
                    setUsers([
                      ...users,
                      {
                        key: nextKey.current,
                        firstName: '',
                        lastName: '',
                        jobFunction: '',
                        email: '',
                        phone: '',
                      },
                    ])
                  }}
                >
                  {t('addCompany.addUser')}
                </Button>
              </Box>
            </>
          )}

          <Box sx={{ display: 'flex', gap: 1, justifyContent: 'flex-end' }}>
            {step > 0 && (
              <Button
                variant="outlined"
                disabled={busy}
                onClick={() => {
                  setStep(step - 1)
                }}
              >
                {t('common.back')}
              </Button>
            )}
            {step < 2 ? (
              <Button
                variant="contained"
                disabled={busy}
                onClick={() => {
                  void next()
                }}
              >
                {t('common.next')}
              </Button>
            ) : (
              <Button variant="contained" disabled={busy} onClick={add}>
                {t('common.add')}
              </Button>
            )}
          </Box>
        </Box>
      </Panel>
    </>
  )
}
