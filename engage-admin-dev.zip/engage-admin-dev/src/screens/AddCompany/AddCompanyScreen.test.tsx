import { describe, expect, it } from 'vitest'
import { http, HttpResponse } from 'msw'
import { server } from '@/mocks/server'
import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { GatewayProvider } from '@/data/GatewayProvider'
import { db } from '@/mocks/fixtures'
import { AddCompanyScreen } from './AddCompanyScreen'

type User = ReturnType<typeof userEvent.setup>

function Location() {
  return <div data-testid="location">{useLocation().pathname}</div>
}

function renderScreen() {
  return renderWithTheme(
    <AuthProvider>
      <GatewayProvider>
        <MemoryRouter initialEntries={['/companies/new']}>
          <Routes>
            <Route path="companies/new" element={<AddCompanyScreen />} />
          </Routes>
          <Location />
        </MemoryRouter>
      </GatewayProvider>
    </AuthProvider>,
  )
}

async function choose(user: User, label: string, option: string) {
  await user.click(await screen.findByRole('combobox', { name: label }))
  await user.click(screen.getByRole('option', { name: option }))
}

async function optionsOf(user: User, label: string) {
  await user.click(screen.getByRole('combobox', { name: label }))
  const names = screen.getAllByRole('option').map((option) => option.textContent)
  await user.keyboard('{Escape}')
  return names
}

async function fillStepOne(user: User, ric = 'OREP.PA') {
  await user.type(screen.getByRole('textbox', { name: 'RIC' }), ric)
  await user.type(screen.getByRole('textbox', { name: 'Name' }), "L'Oreal")
  await choose(user, 'Market', 'Euronext Paris')
  await choose(user, 'Sector', 'Luxury')
}

async function toStepThree(user: User, ric?: string) {
  await fillStepOne(user, ric)
  await user.click(screen.getByRole('button', { name: 'Next' }))
  await screen.findByRole('combobox', { name: 'Index 1' })
  await user.click(screen.getByRole('button', { name: 'Next' }))
  await screen.findByRole('button', { name: 'Add user' })
}

function created(ric: string) {
  return db.companies.filter((company) => company.ric === ric)
}

describe('AddCompanyScreen', () => {
  describe('step 1', () => {
    it('shows the three-step header, French by default and no Back button', async () => {
      renderScreen()
      expect(await screen.findByText('1. Information')).toBeInTheDocument()
      expect(screen.getByText('2. Indices')).toBeInTheDocument()
      expect(screen.getByText('3. Users')).toBeInTheDocument()
      expect(screen.getByRole('radio', { name: 'French' })).toBeChecked()
      expect(screen.getByRole('radio', { name: 'English' })).not.toBeChecked()
      expect(screen.queryByRole('button', { name: 'Back' })).not.toBeInTheDocument()
    })

    it('shows the four required errors on Next when empty and stays on step 1', async () => {
      const user = userEvent.setup()
      renderScreen()
      await user.click(await screen.findByRole('button', { name: 'Next' }))
      for (const message of [
        'RIC is required',
        'Name is required',
        'Market is required',
        'Sector is required',
      ]) {
        expect(await screen.findByText(message)).toBeInTheDocument()
      }
      expect(screen.queryByRole('combobox', { name: 'Index 1' })).not.toBeInTheDocument()
    })

    it('shows an unknown RIC error on blur that blocks Next, and a known RIC clears it', async () => {
      const user = userEvent.setup()
      renderScreen()
      await fillStepOne(user, 'NOPE.PA')
      await user.click(screen.getByRole('textbox', { name: 'Name' }))
      expect(await screen.findByText('This RIC code does not exist')).toBeInTheDocument()
      await user.click(screen.getByRole('button', { name: 'Next' }))
      expect(await screen.findByText('This RIC code does not exist')).toBeInTheDocument()
      expect(screen.queryByRole('combobox', { name: 'Index 1' })).not.toBeInTheDocument()

      const ric = screen.getByRole('textbox', { name: 'RIC' })
      await user.clear(ric)
      await user.type(ric, 'OREP.PA')
      await user.click(screen.getByRole('textbox', { name: 'Name' }))
      await waitFor(() => {
        expect(screen.queryByText('This RIC code does not exist')).not.toBeInTheDocument()
      })
      expect(screen.getByRole('textbox', { name: 'Name' })).toHaveValue("L'Oreal")
    })

    it('lists the sectors without sub-sectors and the chosen sector’s sub-sectors, cleared on change', async () => {
      const user = userEvent.setup()
      renderScreen()
      await screen.findByRole('combobox', { name: 'Sector' })
      expect(await optionsOf(user, 'Sector')).toEqual([
        'Luxury',
        'Food',
        'Hospitality',
        'Beverages',
        'Payments',
        'Industrials',
      ])
      await choose(user, 'Sector', 'Food')
      expect(await optionsOf(user, 'Sub-sector')).toEqual(['None', 'Dairy'])
      await choose(user, 'Sub-sector', 'Dairy')
      expect(screen.getByRole('combobox', { name: 'Sub-sector' })).toHaveTextContent('Dairy')
      await choose(user, 'Sector', 'Payments')
      const subSector = screen.getByRole('combobox', { name: 'Sub-sector' })
      expect(subSector).not.toHaveTextContent('Dairy')
      expect(subSector).toHaveAttribute('aria-disabled', 'true')
    })
    it('keeps the unknown RIC error when Next is clicked with other fields missing', async () => {
      const user = userEvent.setup()
      renderScreen()
      await user.type(await screen.findByRole('textbox', { name: 'RIC' }), 'NOPE.PA')
      await user.click(screen.getByRole('button', { name: 'Next' }))
      expect(await screen.findByText('Name is required')).toBeInTheDocument()
      expect(await screen.findByText('This RIC code does not exist')).toBeInTheDocument()
    })

    it('shows a lookup failure other than 404 under RIC and blocks Next', async () => {
      server.use(
        http.get('*/api-admin/pairs-management/pairs/ric/:search', () =>
          HttpResponse.json({ message: 'Lookup unavailable' }, { status: 500 }),
        ),
      )
      const user = userEvent.setup()
      renderScreen()
      await fillStepOne(user)
      await user.click(screen.getByRole('button', { name: 'Next' }))
      expect(await screen.findByText('Lookup unavailable')).toBeInTheDocument()
      expect(screen.queryByRole('combobox', { name: 'Index 1' })).not.toBeInTheDocument()
    })

    it('shows an error when the reference data cannot load', async () => {
      server.use(
        http.get('*/api-admin/referential/market', () =>
          HttpResponse.json({ message: 'Markets unavailable' }, { status: 500 }),
        ),
      )
      renderScreen()
      expect(await screen.findByRole('alert')).toHaveTextContent('Markets unavailable')
    })
  })

  describe('step 2', () => {
    it('excludes chosen indices from the other pickers, allows none and Back keeps step 1', async () => {
      const user = userEvent.setup()
      renderScreen()
      await fillStepOne(user)
      await user.click(screen.getByRole('radio', { name: 'English' }))
      await user.click(screen.getByRole('button', { name: 'Next' }))
      await choose(user, 'Index 1', '.FCHI CAC 40')
      expect(await optionsOf(user, 'Index 2')).not.toContain('.FCHI CAC 40')
      expect(await optionsOf(user, 'Index 2')).toContain('None')

      await user.click(screen.getByRole('button', { name: 'Back' }))
      expect(await screen.findByRole('textbox', { name: 'RIC' })).toHaveValue('OREP.PA')
      expect(screen.getByRole('textbox', { name: 'Name' })).toHaveValue("L'Oreal")
      expect(screen.getByRole('radio', { name: 'English' })).toBeChecked()
      expect(screen.getByRole('combobox', { name: 'Market' })).toHaveTextContent('Euronext Paris')

      await user.click(screen.getByRole('button', { name: 'Next' }))
      expect(await screen.findByRole('combobox', { name: 'Index 1' })).toHaveTextContent('.FCHI')
      await choose(user, 'Index 1', 'None')
      await user.click(screen.getByRole('button', { name: 'Next' }))
      expect(await screen.findByRole('button', { name: 'Add' })).toBeInTheDocument()
    })
  })

  describe('step 3', () => {
    it('adds numbered user blocks, validates them, blocks Add and renumbers after Remove', async () => {
      const user = userEvent.setup()
      renderScreen()
      await toStepThree(user)
      expect(screen.queryByRole('button', { name: 'Next' })).not.toBeInTheDocument()
      await user.click(screen.getByRole('button', { name: 'Add user' }))
      await user.click(screen.getByRole('button', { name: 'Add user' }))
      const first = screen.getByRole('group', { name: 'User 1' })
      const second = screen.getByRole('group', { name: 'User 2' })
      for (const label of ['First name', 'Last name', 'Position', 'Email', 'Phone']) {
        expect(within(first).getByRole('textbox', { name: label })).toBeInTheDocument()
      }

      await user.click(screen.getByRole('button', { name: 'Add' }))
      expect(within(first).getByText('First name is required')).toBeInTheDocument()
      expect(within(first).getByText('Last name is required')).toBeInTheDocument()
      expect(within(first).getByText('Position is required')).toBeInTheDocument()
      expect(within(first).getByText('Email is required')).toBeInTheDocument()

      await user.type(within(first).getByRole('textbox', { name: 'First name' }), 'Anne')
      await user.type(within(first).getByRole('textbox', { name: 'Last name' }), 'Moreau')
      await user.type(within(first).getByRole('textbox', { name: 'Position' }), 'IR')
      await user.type(within(first).getByRole('textbox', { name: 'Email' }), 'anne@oreal.example')
      await user.type(within(second).getByRole('textbox', { name: 'First name' }), 'Bob')
      await user.type(within(second).getByRole('textbox', { name: 'Last name' }), 'Smith')
      await user.type(within(second).getByRole('textbox', { name: 'Position' }), 'CFO')
      await user.type(within(second).getByRole('textbox', { name: 'Email' }), 'bob@x')
      await user.click(screen.getByRole('button', { name: 'Add' }))
      expect(within(second).getByText('Invalid email format')).toBeInTheDocument()
      expect(within(first).queryByText(/required|Invalid/)).not.toBeInTheDocument()
      expect(screen.getByTestId('location')).toHaveTextContent('/companies/new')
      expect(created('OREP.PA')).toEqual([])

      await user.click(within(first).getByRole('button', { name: 'Remove' }))
      const renumbered = screen.getByRole('group', { name: 'User 1' })
      expect(within(renumbered).getByRole('textbox', { name: 'First name' })).toHaveValue('Bob')
      expect(screen.queryByRole('group', { name: 'User 2' })).not.toBeInTheDocument()
    })

    it('creates a company with zero users and opens its Information tab', async () => {
      const user = userEvent.setup()
      renderScreen()
      await toStepThree(user)
      await user.click(screen.getByRole('button', { name: 'Add' }))
      await waitFor(() => {
        expect(screen.getByTestId('location').textContent).toMatch(
          /^\/companies\/[0-9a-f-]+\/information$/,
        )
      })
      const [company] = created('OREP.PA')
      expect(company).toMatchObject({
        name: "L'Oreal",
        marketCode: 'EPA',
        languageCode: 'fr-FR',
        sector: 'Luxury',
        subSector: '',
        indices: [null, null, null, null],
      })
      expect(screen.getByTestId('location')).toHaveTextContent(`/companies/${company?.id ?? ''}/`)
      expect(db.users.filter((entry) => entry.companyId === company?.id)).toEqual([])
    })

    it('sends sub-sector, indices and collaborators, omitting an empty phone', async () => {
      const user = userEvent.setup()
      renderScreen()
      await user.type(await screen.findByRole('textbox', { name: 'RIC' }), 'OREP.PA')
      await user.type(screen.getByRole('textbox', { name: 'Name' }), "L'Oreal")
      await choose(user, 'Market', 'Euronext Paris')
      await choose(user, 'Sector', 'Luxury')
      await choose(user, 'Sub-sector', 'Fashion')
      await user.click(screen.getByRole('button', { name: 'Next' }))
      await choose(user, 'Index 1', '.FCHI CAC 40')
      await choose(user, 'Index 3', '.STOXX50E Euro Stoxx 50')
      await user.click(screen.getByRole('button', { name: 'Next' }))
      await user.click(await screen.findByRole('button', { name: 'Add user' }))
      await user.click(screen.getByRole('button', { name: 'Add user' }))
      const [first, second] = [
        screen.getByRole('group', { name: 'User 1' }),
        screen.getByRole('group', { name: 'User 2' }),
      ]
      await user.type(within(first).getByRole('textbox', { name: 'First name' }), 'Anne')
      await user.type(within(first).getByRole('textbox', { name: 'Last name' }), 'Moreau')
      await user.type(within(first).getByRole('textbox', { name: 'Position' }), 'IR')
      await user.type(within(first).getByRole('textbox', { name: 'Email' }), 'anne@oreal.example')
      await user.type(within(first).getByRole('textbox', { name: 'Phone' }), '+33 1 00')
      await user.type(within(second).getByRole('textbox', { name: 'First name' }), 'Bob')
      await user.type(within(second).getByRole('textbox', { name: 'Last name' }), 'Smith')
      await user.type(within(second).getByRole('textbox', { name: 'Position' }), 'CFO')
      await user.type(within(second).getByRole('textbox', { name: 'Email' }), 'bob@oreal.example')
      await user.click(screen.getByRole('button', { name: 'Add' }))
      await waitFor(() => {
        expect(screen.getByTestId('location').textContent).toMatch(/\/information$/)
      })
      const [company] = created('OREP.PA')
      expect(company).toMatchObject({
        subSector: 'Luxury/Fashion',
        indices: ['.FCHI', null, '.STOXX50E', null],
      })
      const users = db.users.filter((entry) => entry.companyId === company?.id)
      expect(users).toMatchObject([
        {
          email: 'anne@oreal.example',
          firstname: 'Anne',
          lastname: 'Moreau',
          jobFunction: 'IR',
          phone: '+33 1 00',
          authorities: ['ROLE_EMITTER'],
          passwordChangeRequired: true,
        },
        { email: 'bob@oreal.example', firstname: 'Bob', lastname: 'Smith', jobFunction: 'CFO' },
      ])
      expect(users[1]).not.toHaveProperty('phone')
    })

    it('returns to step 1 with the server message on a duplicate RIC and creates nothing', async () => {
      const user = userEvent.setup()
      const before = db.companies.length
      renderScreen()
      await toStepThree(user, 'LVMH.PA')
      await user.click(screen.getByRole('button', { name: 'Add' }))
      const alert = await screen.findByRole('alert')
      expect(alert).toHaveTextContent('An emitter with same RIC code already exists')
      expect(screen.getByRole('textbox', { name: 'RIC' })).toHaveValue('LVMH.PA')
      expect(screen.getByTestId('location')).toHaveTextContent('/companies/new')
      expect(db.companies).toHaveLength(before)
    })

    it('shows a gateway failure other than 400 on step 1 too', async () => {
      server.use(
        http.put('*/api-admin/emitters-management/emitter', () =>
          HttpResponse.json({ message: 'Gateway unavailable' }, { status: 500 }),
        ),
      )
      const user = userEvent.setup()
      renderScreen()
      await toStepThree(user)
      await user.click(screen.getByRole('button', { name: 'Add' }))
      expect(await screen.findByRole('alert')).toHaveTextContent('Gateway unavailable')
      expect(screen.getByRole('textbox', { name: 'RIC' })).toBeInTheDocument()
    })
  })
})
