/// <reference types="node" />
import { execFileSync } from 'node:child_process'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'

const script = join(process.cwd(), 'docker/40-engage-admin-config.sh')

let dir = ''

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), 'engage-admin-config-'))
})

afterEach(() => {
  rmSync(dir, { recursive: true, force: true })
})

function runScript(vars: Record<string, string>) {
  const file = join(dir, 'config.js')
  execFileSync('sh', [script], {
    env: { PATH: process.env.PATH ?? '', CONFIG_FILE: file, ...vars },
  })
  return readFileSync(file, 'utf8').trim()
}

describe('docker/40-engage-admin-config.sh', () => {
  it('writes an empty config when no variables are set', () => {
    expect(runScript({})).toBe('window.__ENGAGE_ADMIN_CONFIG__ = {}')
  })

  it('writes the set variables in a fixed order', () => {
    expect(runScript({ ENTRA_MOCK: '1', GATEWAY_URL: 'https://gw.example' })).toBe(
      'window.__ENGAGE_ADMIN_CONFIG__ = {"gatewayUrl": "https://gw.example", "entraMock": "1"}',
    )
  })

  it('writes all five variables', () => {
    expect(
      runScript({
        GATEWAY_URL: 'g',
        ENTRA_TENANT_ID: 't',
        ENTRA_CLIENT_ID: 'c',
        API_SCOPE: 's',
        ENTRA_MOCK: '1',
      }),
    ).toBe(
      'window.__ENGAGE_ADMIN_CONFIG__ = {"gatewayUrl": "g", "entraTenantId": "t", "entraClientId": "c", "apiScope": "s", "entraMock": "1"}',
    )
  })

  it('escapes quotes and backslashes', () => {
    expect(runScript({ GATEWAY_URL: 'a"b\\c' })).toBe(
      'window.__ENGAGE_ADMIN_CONFIG__ = {"gatewayUrl": "a\\"b\\\\c"}',
    )
  })

  it('removes carriage returns and newlines', () => {
    expect(runScript({ GATEWAY_URL: 'a\r\nb\nc' })).toBe(
      'window.__ENGAGE_ADMIN_CONFIG__ = {"gatewayUrl": "abc"}',
    )
  })

  it('leaves out empty variables', () => {
    expect(runScript({ API_SCOPE: '', GATEWAY_URL: 'g' })).toBe(
      'window.__ENGAGE_ADMIN_CONFIG__ = {"gatewayUrl": "g"}',
    )
  })
})
