/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_GATEWAY_URL?: string
  readonly VITE_ENTRA_TENANT_ID?: string
  readonly VITE_ENTRA_CLIENT_ID?: string
  readonly VITE_API_SCOPE?: string
  readonly VITE_ENTRA_MOCK?: string
}

interface Window {
  __ENGAGE_ADMIN_CONFIG__?: Partial<
    Record<'gatewayUrl' | 'entraTenantId' | 'entraClientId' | 'apiScope' | 'entraMock', string>
  >
}
