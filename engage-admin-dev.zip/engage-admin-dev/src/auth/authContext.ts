import { createContext, useContext } from 'react'

export type AuthStatus = 'loading' | 'signedOut' | 'noAccess' | 'signedIn'

export interface Auth {
  status: AuthStatus
  name: string | null
  roles: string[]
  getToken: () => Promise<string>
  signIn: () => Promise<void>
  signOut: () => void
  /** The gateway client reports 401 (signed out) and 403 (no access) here. */
  onAuthError: (status: 401 | 403) => void
}

export const AuthContext = createContext<Auth | null>(null)

export function useAuth(): Auth {
  const auth = useContext(AuthContext)
  if (!auth) throw new Error('useAuth must be used inside an AuthProvider')
  return auth
}
