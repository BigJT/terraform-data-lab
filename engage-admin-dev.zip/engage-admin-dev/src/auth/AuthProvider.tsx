import { useCallback, useMemo, useState, type ReactNode } from 'react'
import { AuthContext, type Auth, type AuthStatus } from './authContext'
import { useEntraAuth, type EntraSettings } from './entraAuth'
import { mockAuth } from './mockAuth'

interface AuthProviderProps {
  children: ReactNode
  /** Entra settings; null or absent runs in mock mode. */
  entra?: EntraSettings | null
}

export function AuthProvider({ children, entra = null }: AuthProviderProps) {
  const [errorStatus, setErrorStatus] = useState<AuthStatus | null>(null)
  const onAuthError = useCallback((status: 401 | 403) => {
    setErrorStatus(status === 401 ? 'signedOut' : 'noAccess')
  }, [])
  const onSessionExpired = useCallback(() => {
    onAuthError(401)
  }, [onAuthError])
  const entraAuth = useEntraAuth(entra, onSessionExpired)
  // Mock mode keeps its own no-op: a sign-in page there would be a dead end.
  const auth = useMemo<Auth>(() => {
    if (!entraAuth) return mockAuth
    return { ...entraAuth, status: errorStatus ?? entraAuth.status, onAuthError }
  }, [entraAuth, errorStatus, onAuthError])
  return <AuthContext value={auth}>{children}</AuthContext>
}
