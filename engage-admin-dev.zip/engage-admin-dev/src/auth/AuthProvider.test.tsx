import { StrictMode, useState } from 'react'
import { describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router'
import {
  InteractionRequiredAuthError,
  type AccountInfo,
  type AuthenticationResult,
} from '@azure/msal-browser'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { AuthGate } from '@/auth/AuthGate'
import { useAuth } from '@/auth/authContext'
import type { MsalClient } from '@/auth/entraAuth'
import { GatewayProvider } from '@/data/GatewayProvider'
import { AppRoutes } from '@/app/AppRoutes'

const scope = 'api://engage-gateway/.default'

function account(roles?: string[]): AccountInfo {
  return {
    homeAccountId: 'home-1',
    environment: 'login.microsoftonline.com',
    tenantId: 'tenant-1',
    username: 'ada@example.com',
    localAccountId: 'local-1',
    name: 'Ada Lovelace',
    idTokenClaims: roles === undefined ? {} : { roles },
  }
}

function fakeMsal(signedIn: AccountInfo | null) {
  let active: AccountInfo | null = null
  const client = {
    initialize: vi.fn(() => Promise.resolve()),
    handleRedirectPromise: vi.fn((): Promise<AuthenticationResult | null> => Promise.resolve(null)),
    getActiveAccount: vi.fn(() => active),
    setActiveAccount: vi.fn((next: AccountInfo | null) => {
      active = next
    }),
    getAllAccounts: vi.fn(() => (signedIn ? [signedIn] : [])),
    loginRedirect: vi.fn(() => Promise.resolve()),
    logoutRedirect: vi.fn(() => Promise.resolve()),
    acquireTokenSilent: vi.fn(() =>
      Promise.resolve({ accessToken: 'entra-token' } as AuthenticationResult),
    ),
  } satisfies MsalClient
  return client
}

function AuthProbe() {
  const { getToken, onAuthError } = useAuth()
  const [token, setToken] = useState('')
  return (
    <>
      <button
        onClick={() => {
          onAuthError(401)
        }}
      >
        Report 401
      </button>
      <button
        onClick={() => {
          onAuthError(403)
        }}
      >
        Report 403
      </button>
      <button
        onClick={() => {
          getToken().then(setToken, () => {
            setToken('no token')
          })
        }}
      >
        Get token
      </button>
      <output>{token}</output>
    </>
  )
}

function renderApp(entra: { client: MsalClient; scope: string } | null) {
  return renderWithTheme(
    <StrictMode>
      <AuthProvider entra={entra}>
        <AuthProbe />
        <MemoryRouter initialEntries={['/companies']}>
          <AuthGate>
            <GatewayProvider>
              <AppRoutes />
            </GatewayProvider>
          </AuthGate>
        </MemoryRouter>
      </AuthProvider>
    </StrictMode>,
  )
}

function renderEntra(client: MsalClient) {
  return renderApp({ client, scope })
}

describe('AuthProvider in Entra mode', () => {
  it('signs in an account holding the Admin role', async () => {
    const client = fakeMsal(account(['Admin']))
    renderEntra(client)
    expect(await screen.findByText('Ada Lovelace')).toBeInTheDocument()
    expect(screen.getByRole('navigation')).toBeInTheDocument()
    expect(client.initialize).toHaveBeenCalled()
    expect(client.handleRedirectPromise).toHaveBeenCalled()
    expect(client.setActiveAccount).toHaveBeenCalledWith(account(['Admin']))
  })

  it('uses the account returned from the redirect', async () => {
    const client = fakeMsal(null)
    const redirected = account(['Admin'])
    client.handleRedirectPromise.mockResolvedValue({
      account: redirected,
    } as AuthenticationResult)
    renderEntra(client)
    expect(await screen.findByText('Ada Lovelace')).toBeInTheDocument()
    expect(client.setActiveAccount).toHaveBeenCalledWith(redirected)
  })

  it.each([
    ['empty roles', []],
    ['other roles only', ['Reader']],
    ['no roles claim', undefined],
  ])('shows no access for an account with %s', async (_label, roles) => {
    renderEntra(fakeMsal(account(roles)))
    expect(await screen.findByText('You do not have access to Engage Admin.')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Sign out' })).toBeInTheDocument()
    expect(screen.queryByRole('navigation')).not.toBeInTheDocument()
  })

  it('shows the sign-in page when there is no account', async () => {
    renderEntra(fakeMsal(null))
    expect(
      await screen.findByRole('button', { name: 'Sign in with Microsoft' }),
    ).toBeInTheDocument()
    expect(screen.getByText('Engage Admin')).toBeInTheDocument()
    expect(screen.queryByRole('navigation')).not.toBeInTheDocument()
  })

  it('shows the sign-in page when the redirect fails', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const client = fakeMsal(account(['Admin']))
    client.handleRedirectPromise.mockRejectedValue(new Error('redirect failed'))
    renderEntra(client)
    expect(
      await screen.findByRole('button', { name: 'Sign in with Microsoft' }),
    ).toBeInTheDocument()
    expect(warn).toHaveBeenCalled()
  })

  it('shows nothing but the canvas while loading', () => {
    const client = fakeMsal(account(['Admin']))
    client.initialize.mockReturnValue(new Promise(() => undefined))
    renderEntra(client)
    expect(screen.queryByText('Engage Admin')).not.toBeInTheDocument()
    expect(screen.queryByRole('navigation')).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Sign in with Microsoft' })).not.toBeInTheDocument()
  })

  it('signs in with a redirect for the API scope', async () => {
    const user = userEvent.setup()
    const client = fakeMsal(null)
    renderEntra(client)
    await user.click(await screen.findByRole('button', { name: 'Sign in with Microsoft' }))
    expect(client.loginRedirect).toHaveBeenCalledWith({ scopes: [scope] })
  })

  it('signs out with a redirect from the shell', async () => {
    const user = userEvent.setup()
    const client = fakeMsal(account(['Admin']))
    renderEntra(client)
    await user.click(await screen.findByRole('button', { name: 'Sign out' }))
    expect(client.logoutRedirect).toHaveBeenCalled()
  })

  it('signs out with a redirect from the no-access page', async () => {
    const user = userEvent.setup()
    const client = fakeMsal(account([]))
    renderEntra(client)
    await user.click(await screen.findByRole('button', { name: 'Sign out' }))
    expect(client.logoutRedirect).toHaveBeenCalled()
  })

  it('gets the token silently for the API scope and the active account', async () => {
    const user = userEvent.setup()
    const admin = account(['Admin'])
    const client = fakeMsal(admin)
    renderEntra(client)
    await screen.findByText('Ada Lovelace')
    await user.click(screen.getByRole('button', { name: 'Get token' }))
    expect(await screen.findByText('entra-token')).toBeInTheDocument()
    expect(client.acquireTokenSilent).toHaveBeenCalledWith({ scopes: [scope], account: admin })
  })

  it('a 401 from the gateway shows the sign-in page', async () => {
    const user = userEvent.setup()
    renderEntra(fakeMsal(account(['Admin'])))
    await screen.findByText('Ada Lovelace')
    await user.click(screen.getByRole('button', { name: 'Report 401' }))
    expect(screen.getByRole('button', { name: 'Sign in with Microsoft' })).toBeInTheDocument()
    expect(screen.queryByRole('navigation')).not.toBeInTheDocument()
  })

  it('a 403 from the gateway shows the no-access page', async () => {
    const user = userEvent.setup()
    renderEntra(fakeMsal(account(['Admin'])))
    await screen.findByText('Ada Lovelace')
    await user.click(screen.getByRole('button', { name: 'Report 403' }))
    expect(screen.getByText('You do not have access to Engage Admin.')).toBeInTheDocument()
    expect(screen.queryByRole('navigation')).not.toBeInTheDocument()
  })

  it('reads the redirect result once under StrictMode', async () => {
    const client = fakeMsal(account(['Admin']))
    renderEntra(client)
    await screen.findByText('Ada Lovelace')
    expect(client.initialize).toHaveBeenCalledTimes(1)
    expect(client.handleRedirectPromise).toHaveBeenCalledTimes(1)
  })

  it('shows the sign-in page when the session needs a fresh sign-in', async () => {
    const user = userEvent.setup()
    const client = fakeMsal(account(['Admin']))
    client.acquireTokenSilent.mockRejectedValue(
      new InteractionRequiredAuthError('interaction_required', 'Sign in again'),
    )
    renderEntra(client)
    await screen.findByText('Ada Lovelace')
    await user.click(screen.getByRole('button', { name: 'Get token' }))
    expect(
      await screen.findByRole('button', { name: 'Sign in with Microsoft' }),
    ).toBeInTheDocument()
    expect(screen.getByText('no token')).toBeInTheDocument()
  })
})

describe('AuthProvider in mock mode', () => {
  it('signs in at once as Local Admin', () => {
    renderApp(null)
    expect(screen.getByText('Local Admin')).toBeInTheDocument()
    expect(screen.getByRole('navigation')).toBeInTheDocument()
  })

  it.each(['Report 401', 'Report 403'])(
    'ignores %s, as there is no sign-in to return to',
    async (name) => {
      const user = userEvent.setup()
      renderApp(null)
      await user.click(screen.getByRole('button', { name }))
      expect(screen.getByRole('navigation')).toBeInTheDocument()
    },
  )
})
