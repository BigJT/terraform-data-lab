import type { AccountInfo } from '@azure/msal-browser'
import type { MsalClient } from './entraAuth'
import { browserLocation } from './browserLocation'

export const mockAccountKey = 'engage-admin.mock-entra.account'
export const mockRedirectKey = 'engage-admin.mock-entra.redirect'
export const mockSignInPath = `${import.meta.env.BASE_URL}mock-entra-sign-in`

export const mockAccounts: AccountInfo[] = [
  {
    homeAccountId: 'mock-admin',
    localAccountId: 'mock-admin',
    environment: 'mock',
    tenantId: 'mock',
    username: 'admin.user@example.com',
    name: 'Admin User',
    idTokenClaims: { roles: ['Admin'] },
  },
  {
    homeAccountId: 'mock-standard',
    localAccountId: 'mock-standard',
    environment: 'mock',
    tenantId: 'mock',
    username: 'standard.user@example.com',
    name: 'Standard User',
    idTokenClaims: { roles: [] },
  },
]

function storedAccount(): AccountInfo | null {
  const id = sessionStorage.getItem(mockAccountKey)
  return mockAccounts.find((account) => account.homeAccountId === id) ?? null
}

/** Stands in for MSAL in stand-in mode (entraMock): the account lives in sessionStorage. */
export function createFakeMsal(): MsalClient {
  return {
    initialize: () => Promise.resolve(),
    handleRedirectPromise: () => {
      if (sessionStorage.getItem(mockRedirectKey) !== '1') return Promise.resolve(null)
      sessionStorage.removeItem(mockRedirectKey)
      const account = storedAccount()
      return Promise.resolve(
        account ? ({ account } as Awaited<ReturnType<MsalClient['handleRedirectPromise']>>) : null,
      )
    },
    getActiveAccount: storedAccount,
    getAllAccounts: () => {
      const account = storedAccount()
      return account ? [account] : []
    },
    setActiveAccount: () => undefined,
    loginRedirect: () => {
      browserLocation.assign(mockSignInPath)
      return Promise.resolve()
    },
    logoutRedirect: () => {
      sessionStorage.removeItem(mockAccountKey)
      sessionStorage.removeItem(mockRedirectKey)
      browserLocation.replace(import.meta.env.BASE_URL)
      return Promise.resolve()
    },
    acquireTokenSilent: () =>
      Promise.resolve({ accessToken: 'mock-entra-token' } as Awaited<
        ReturnType<MsalClient['acquireTokenSilent']>
      >),
  }
}
