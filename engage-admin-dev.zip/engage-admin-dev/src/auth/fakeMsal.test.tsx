import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router'
import { renderWithTheme } from '@/test/renderWithTheme'
import { AuthProvider } from '@/auth/AuthProvider'
import { AuthGate } from '@/auth/AuthGate'
import { browserLocation } from '@/auth/browserLocation'
import { createFakeMsal, mockAccountKey, mockAccounts, mockRedirectKey } from '@/auth/fakeMsal'

const [admin, standard] = mockAccounts

describe('fake MSAL client', () => {
  beforeEach(() => {
    sessionStorage.clear()
  })
  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('offers an Admin and a Standard account', () => {
    expect(admin).toMatchObject({ name: 'Admin User', idTokenClaims: { roles: ['Admin'] } })
    expect(standard).toMatchObject({ name: 'Standard User', idTokenClaims: { roles: [] } })
  })

  it('returns the picked account from the redirect once, then null', async () => {
    sessionStorage.setItem(mockAccountKey, 'mock-admin')
    sessionStorage.setItem(mockRedirectKey, '1')
    const client = createFakeMsal()
    expect((await client.handleRedirectPromise())?.account).toEqual(admin)
    expect(sessionStorage.getItem(mockRedirectKey)).toBeNull()
    expect(await client.handleRedirectPromise()).toBeNull()
  })

  it('returns null from the redirect when none is pending', async () => {
    sessionStorage.setItem(mockAccountKey, 'mock-admin')
    expect(await createFakeMsal().handleRedirectPromise()).toBeNull()
  })

  it('keeps the stored account across reloads', () => {
    sessionStorage.setItem(mockAccountKey, 'mock-standard')
    const client = createFakeMsal()
    expect(client.getActiveAccount()).toEqual(standard)
    expect(client.getAllAccounts()).toEqual([standard])
  })

  it('has no account when nothing is stored or the id is unknown', () => {
    const client = createFakeMsal()
    expect(client.getActiveAccount()).toBeNull()
    expect(client.getAllAccounts()).toEqual([])
    sessionStorage.setItem(mockAccountKey, 'nobody')
    expect(client.getActiveAccount()).toBeNull()
    expect(client.getAllAccounts()).toEqual([])
  })

  it('sends login to the stand-in page', async () => {
    const assign = vi.spyOn(browserLocation, 'assign').mockImplementation(() => undefined)
    await createFakeMsal().loginRedirect()
    expect(assign).toHaveBeenCalledWith('/engage-admin/mock-entra-sign-in')
  })

  it('issues a mock token', async () => {
    const result = await createFakeMsal().acquireTokenSilent({ scopes: [] })
    expect(result.accessToken).toBe('mock-entra-token')
  })

  it('clears both keys on logout and returns to the app root', async () => {
    const replace = vi.spyOn(browserLocation, 'replace').mockImplementation(() => undefined)
    sessionStorage.setItem(mockAccountKey, 'mock-admin')
    sessionStorage.setItem(mockRedirectKey, '1')
    await createFakeMsal().logoutRedirect()
    expect(sessionStorage.getItem(mockAccountKey)).toBeNull()
    expect(sessionStorage.getItem(mockRedirectKey)).toBeNull()
    expect(replace).toHaveBeenCalledWith('/engage-admin/')
  })
})

function renderGate() {
  return renderWithTheme(
    <AuthProvider entra={{ client: createFakeMsal(), scope: 'api://mock/access_as_user' }}>
      <MemoryRouter>
        <AuthGate>
          <p>Signed in shell</p>
        </AuthGate>
      </MemoryRouter>
    </AuthProvider>,
  )
}

describe('AuthProvider with the fake client', () => {
  beforeEach(() => {
    sessionStorage.clear()
  })

  it('signs in Admin User', async () => {
    sessionStorage.setItem(mockAccountKey, 'mock-admin')
    renderGate()
    expect(await screen.findByText('Signed in shell')).toBeInTheDocument()
  })

  it('shows no access for Standard User', async () => {
    sessionStorage.setItem(mockAccountKey, 'mock-standard')
    renderGate()
    expect(await screen.findByText('You do not have access to Engage Admin.')).toBeInTheDocument()
  })

  it('shows the sign-in page with no account', async () => {
    renderGate()
    expect(
      await screen.findByRole('button', { name: 'Sign in with Microsoft' }),
    ).toBeInTheDocument()
  })
})
