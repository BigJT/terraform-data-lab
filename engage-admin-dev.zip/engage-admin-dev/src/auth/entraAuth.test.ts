import { afterEach, describe, expect, it, vi } from 'vitest'
import type { PublicClientApplication } from '@azure/msal-browser'
import { entraSettingsFromEnv } from '@/auth/entraAuth'

describe('entraSettingsFromEnv', () => {
  afterEach(() => {
    delete window.__ENGAGE_ADMIN_CONFIG__
    vi.unstubAllEnvs()
  })

  it('sends Entra back to the app under its base path', () => {
    window.__ENGAGE_ADMIN_CONFIG__ = {
      entraTenantId: 'tenant',
      entraClientId: 'client',
      apiScope: 'api://engage/access_as_user',
    }
    const settings = entraSettingsFromEnv()
    const config = (settings?.client as PublicClientApplication).getConfiguration()
    expect(config.auth.redirectUri).toBe(`${window.location.origin}/engage-admin/`)
    expect(settings?.scope).toBe('api://engage/access_as_user')
  })

  it.each(['entraTenantId', 'entraClientId', 'apiScope'] as const)(
    'runs on mock data when %s is missing',
    (missing) => {
      vi.stubEnv('VITE_ENTRA_TENANT_ID', '')
      vi.stubEnv('VITE_ENTRA_CLIENT_ID', '')
      vi.stubEnv('VITE_API_SCOPE', '')
      const all = { entraTenantId: 'tenant', entraClientId: 'client', apiScope: 'scope' }
      window.__ENGAGE_ADMIN_CONFIG__ = { ...all, [missing]: '' }
      expect(entraSettingsFromEnv()).toBeNull()
    },
  )

  it('uses the stand-in client when entraMock is on', () => {
    window.__ENGAGE_ADMIN_CONFIG__ = { entraMock: '1' }
    expect(entraSettingsFromEnv()?.scope).toBe('api://mock/access_as_user')
  })
})
