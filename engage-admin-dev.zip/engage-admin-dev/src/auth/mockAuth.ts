import type { Auth } from './authContext'
import { browserLocation } from './browserLocation'

// Mock mode: no Entra settings, so the app is signed in at once as a local admin.
export const mockAuth: Auth = {
  status: 'signedIn',
  name: 'Local Admin',
  roles: ['Admin'],
  getToken: () => Promise.resolve('mock-token'),
  signIn: () => Promise.resolve(),
  signOut: () => {
    browserLocation.replace(import.meta.env.BASE_URL)
  },
  onAuthError: () => undefined,
}
