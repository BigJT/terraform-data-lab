import { useEffect, useMemo, useState } from 'react'
import {
  InteractionRequiredAuthError,
  PublicClientApplication,
  type AccountInfo,
  type IPublicClientApplication,
} from '@azure/msal-browser'
import { appConfig } from '@/config'
import type { Auth, AuthStatus } from './authContext'
import { createFakeMsal } from './fakeMsal'

/** The slice of MSAL the app uses, so tests can hand in a fake. */
export type MsalClient = Pick<
  IPublicClientApplication,
  | 'initialize'
  | 'handleRedirectPromise'
  | 'getActiveAccount'
  | 'setActiveAccount'
  | 'getAllAccounts'
  | 'loginRedirect'
  | 'logoutRedirect'
  | 'acquireTokenSilent'
>

export interface EntraSettings {
  client: MsalClient
  scope: string
}

/** Entra mode needs the tenant, the client and the API scope; without all three the app runs on mock data. */
export function entraSettingsFromEnv(): EntraSettings | null {
  const config = appConfig()
  if (config.entraMock) {
    return { client: createFakeMsal(), scope: 'api://mock/access_as_user' }
  }
  const { entraTenantId: tenantId, entraClientId: clientId, apiScope: scope } = config
  if (!tenantId || !clientId || !scope) return null
  const client = new PublicClientApplication({
    auth: {
      clientId,
      authority: `https://login.microsoftonline.com/${tenantId}`,
      redirectUri: `${window.location.origin}${import.meta.env.BASE_URL}`,
    },
  })
  return { client, scope }
}

function statusFor(account: AccountInfo | null): AuthStatus {
  if (!account) return 'signedOut'
  const roles = account.idTokenClaims?.roles ?? []
  return roles.includes('Admin') ? 'signedIn' : 'noAccess'
}

// One start-up per client: StrictMode runs effects twice, and the redirect result must be read once.
const startups = new WeakMap<MsalClient, Promise<AccountInfo | null>>()

function startUp(client: MsalClient): Promise<AccountInfo | null> {
  let startup = startups.get(client)
  if (!startup) {
    startup = client
      .initialize()
      .then(() => client.handleRedirectPromise())
      .then((result) => {
        const found =
          result?.account ?? client.getActiveAccount() ?? client.getAllAccounts()[0] ?? null
        if (found) client.setActiveAccount(found)
        return found
      })
    startups.set(client, startup)
  }
  return startup
}

/** Signs in through Entra with redirects; null when the app is in mock mode. */
export function useEntraAuth(
  entra: EntraSettings | null,
  onSessionExpired: () => void,
): Omit<Auth, 'onAuthError'> | null {
  const [account, setAccount] = useState<AccountInfo | null>(null)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    if (!entra) return
    let cancelled = false
    startUp(entra.client)
      .then((found) => {
        if (cancelled) return
        setAccount(found)
        setLoaded(true)
      })
      .catch((error: unknown) => {
        console.warn('Entra sign-in failed', error)
        if (cancelled) return
        setAccount(null)
        setLoaded(true)
      })
    return () => {
      cancelled = true
    }
  }, [entra])

  return useMemo(() => {
    if (!entra) return null
    const { client, scope } = entra
    const scopes = [scope]
    return {
      status: loaded ? statusFor(account) : 'loading',
      name: account?.name ?? null,
      roles: account?.idTokenClaims?.roles ?? [],
      getToken: async () => {
        if (!account) throw new Error('Not signed in')
        try {
          return (await client.acquireTokenSilent({ scopes, account })).accessToken
        } catch (error) {
          if (error instanceof InteractionRequiredAuthError) onSessionExpired()
          throw error
        }
      },
      signIn: () => client.loginRedirect({ scopes }),
      signOut: () => {
        void client.logoutRedirect()
      },
    }
  }, [entra, account, loaded, onSessionExpired])
}
