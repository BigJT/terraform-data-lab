import { Box } from '@mui/material'
import type { ReactNode } from 'react'
import { colors } from '@/ds/theme'
import { NoAccessScreen } from '@/screens/NoAccess/NoAccessScreen'
import { SignInScreen } from '@/screens/SignIn/SignInScreen'
import { useAuth } from './authContext'

/** Shows the app only to a signed-in admin; everyone else gets the sign-in or no-access page. */
export function AuthGate({ children }: { children: ReactNode }) {
  const { status } = useAuth()
  switch (status) {
    case 'loading':
      return <Box sx={{ minHeight: '100vh', backgroundColor: colors.canvas }} />
    case 'signedOut':
      return <SignInScreen />
    case 'noAccess':
      return <NoAccessScreen />
    case 'signedIn':
      return <>{children}</>
  }
}
