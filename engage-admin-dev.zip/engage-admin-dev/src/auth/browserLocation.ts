// jsdom's window.location.replace can't be spied on, so sign-out goes through this object.
export const browserLocation = {
  replace: (url: string) => {
    window.location.replace(url)
  },
  assign: (url: string) => {
    window.location.assign(url)
  },
}
