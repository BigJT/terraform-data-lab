import { execSync } from 'node:child_process'

// Block newly-added comment blocks longer than MAX lines. Tune here.
const MAX = 2

const diff = execSync(
  "git diff --cached --unified=0 -- '*.ts' '*.tsx' '*.mts' '*.mjs' '*.js' ':!public/mockServiceWorker.js'",
  {
    encoding: 'utf8',
  },
)
const isComment = (s) => /^(\/\/|\/\*|\*)/.test(s.trim())

const offenders = new Set()
let file = ''
let run = 0
for (const line of diff.split('\n')) {
  if (line.startsWith('+++ b/')) {
    file = line.slice(6)
    run = 0
  } else if (line.startsWith('@@')) {
    run = 0
  } else if (line.startsWith('+') && !line.startsWith('+++')) {
    if (isComment(line.slice(1))) {
      run += 1
      if (run > MAX) offenders.add(file)
    } else {
      run = 0
    }
  } else if (!line.startsWith('-')) {
    run = 0
  }
}

if (offenders.size) {
  console.error(`\n✋ Comment gate: no added comment block longer than ${MAX} lines.\n`)
  for (const f of offenders) console.error(`  ${f}`)
  console.error(
    '\nTighten it or let the code speak. Override (discouraged): git commit --no-verify\n',
  )
  process.exit(1)
}
