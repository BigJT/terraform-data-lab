# Engage Admin

Web back office for Engage, replacing the myCMS admin system. Front end only: it calls the Engage Gateway for every read and write. Admins sign in with Entra.

The gateway contract is `docs/api/gateway-swagger.json` (Pradeep's C# gateway). The pages, types, client and mock follow it exactly.

The behaviour it recreates is specified in `docs/mycms-admin-spec-1.md`, `-2.md` and `-3.md`, extracted from the myCMS repo by prompts `docs/mycms-admin-prompt-N.md`. Production counts are in `docs/mycms-admin-counts-3-results.md`.

Stack: React 19.3 + TypeScript 6.0 + Vite 8, MUI 9, React Router 8, MSAL browser 5 for Entra sign-in, msw 3 for mock data, Vitest 5 + React Testing Library, Playwright 1.64. English only.

## Settings

Copy `.env.example` to `.env.local` and fill in what you need. With nothing set the app runs in mock mode: it signs in as "Local Admin" and serves mock data from inside the browser.

| Setting                | What it does                                                                                                    |
| ---------------------- | --------------------------------------------------------------------------------------------------------------- |
| `VITE_GATEWAY_URL`     | Engage Gateway address. Unset: mock data                                                                        |
| `VITE_ENTRA_TENANT_ID` | Entra tenant id                                                                                                 |
| `VITE_ENTRA_CLIENT_ID` | Entra app registration (client) id                                                                              |
| `VITE_API_SCOPE`       | Gateway API scope. Entra sign-in needs all three Entra settings set                                             |
| `VITE_ENTRA_MOCK`      | `1` swaps Entra for a stand-in Microsoft page (pick Admin or Standard user). Wins over the three Entra settings |

## Scripts

| Script                   | What it does                                                                                 |
| ------------------------ | -------------------------------------------------------------------------------------------- |
| `npm run dev`            | Dev server on port 5174 (mock mode unless `VITE_GATEWAY_URL` is set)                         |
| `npm run dev:entra-mock` | Dev server on port 5175 with `VITE_ENTRA_MOCK=1`: real sign-in flow, stand-in Microsoft page |
| `npm run build`          | Type-check and build to `dist`                                                               |
| `npm run preview`        | Serve the built app                                                                          |
| `npm run lint`           | ESLint                                                                                       |
| `npm run typecheck`      | TypeScript only                                                                              |
| `npm run test`           | Vitest unit and screen tests                                                                 |
| `npm run test:watch`     | Vitest in watch mode                                                                         |
| `npm run test:e2e`       | Playwright against the dev server in mock mode                                               |
| `npm run format`         | Prettier, write                                                                              |
| `npm run format:check`   | Prettier, check only                                                                         |
| `npm run verify`         | Build, lint, format check, unit tests, Playwright                                            |

## Deploying

Build and try the image locally with `npm run docker:build` then `npm run docker:run`, and open http://localhost:8080/engage-admin/. The app is served under `/engage-admin/`.

One image serves every environment. The container reads these variables at start-up (unset or empty ones are left out):

| Variable          | What it does                                                    |
| ----------------- | --------------------------------------------------------------- |
| `GATEWAY_URL`     | Engage Gateway address. Empty: sample data                      |
| `ENTRA_TENANT_ID` | Entra tenant id                                                 |
| `ENTRA_CLIENT_ID` | Entra app registration (client) id                              |
| `API_SCOPE`       | Gateway API scope. Entra sign-in needs all three Entra settings |
| `ENTRA_MOCK`      | `1` swaps Entra for the stand-in Microsoft page                 |

Entra redirect URIs (single-page application platform):

- `http://localhost:5174/engage-admin/`
- `http://localhost:5175/engage-admin/`
- `https://<host>/engage-admin/`

Pipeline (`azure-pipelines.yml`) variables to fill in: `containerRegistry`, `hostName`, `azureServiceConnection`, `kubernetesServiceConnection`, and `namespace` (to confirm with John). The Kubernetes manifest is `deploy/aks.yaml`; set its env values per environment.
