import { defineConfig, devices } from '@playwright/test'

const port = '5174'
const mockPort = '5175'

// https://playwright.dev/docs/test-configuration
export default defineConfig({
  testDir: 'e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  reporter: 'list',
  use: {
    baseURL: `http://localhost:${port}/engage-admin/`,
    locale: 'en-US',
    trace: 'on-first-retry',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      testIgnore: 'entraMock.spec.ts',
    },
    {
      name: 'entra-mock',
      use: { ...devices['Desktop Chrome'], baseURL: `http://localhost:${mockPort}/engage-admin/` },
      testMatch: 'entraMock.spec.ts',
    },
  ],
  // Mock mode: no VITE_* settings reach the dev server, so it serves msw fixtures.
  webServer: [
    {
      command: 'npm run dev',
      url: `http://localhost:${port}/engage-admin/`,
      reuseExistingServer: !process.env.CI,
    },
    {
      command: 'npm run dev:entra-mock',
      url: `http://localhost:${mockPort}/engage-admin/`,
      reuseExistingServer: !process.env.CI,
    },
  ],
})
