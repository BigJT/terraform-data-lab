import { expect, test } from '@playwright/test'

const frenchSidebar = ['Rapports', 'Flashs', 'N. de brokers', 'Émetteurs', 'Version', 'Monitoring']
const englishSidebar = ['Reports', 'Flashes', 'Broker notes', 'Companies', 'Version', 'Monitoring']

test('MTP-LANG-001: the EN | FR switch turns the page French at once, survives a reload, and switches back', async ({
  page,
}) => {
  await page.goto('')
  const nav = page.getByRole('navigation').getByRole('link')
  await expect(nav).toHaveText(englishSidebar)
  const group = page.getByRole('group', { name: 'Language' })
  await expect(group.getByRole('button', { name: 'EN' })).toHaveAttribute('aria-pressed', 'true')
  await page.evaluate(() => {
    ;(window as Window & { beforeSwitch?: boolean }).beforeSwitch = true
  })

  await group.getByRole('button', { name: 'FR' }).click()
  await expect(nav).toHaveText(frenchSidebar)
  await expect(page.getByRole('button', { name: 'Se déconnecter' })).toBeVisible()
  const french = page.getByRole('group', { name: 'Langue' })
  await expect(french.getByRole('button', { name: 'FR' })).toHaveAttribute('aria-pressed', 'true')
  await expect(page.locator('html')).toHaveAttribute('lang', 'fr')
  const noReload = await page.evaluate(
    () => (window as Window & { beforeSwitch?: boolean }).beforeSwitch ?? false,
  )
  expect(noReload).toBe(true)

  await page.reload()
  await expect(nav).toHaveText(frenchSidebar)

  await page.getByRole('button', { name: 'EN' }).click()
  await expect(nav).toHaveText(englishSidebar)
  await expect(page.getByRole('button', { name: 'Sign out' })).toBeVisible()
})

test.describe('MTP-LANG-002: a French browser', () => {
  test.use({ locale: 'fr-FR' })

  test('opens the app in French on a first visit', async ({ page }) => {
    await page.goto('')
    await expect(page.getByRole('navigation').getByRole('link')).toHaveText(frenchSidebar)
    await expect(page.locator('html')).toHaveAttribute('lang', 'fr')
  })
})

test.describe('MTP-LANG-002: an English browser', () => {
  test.use({ locale: 'en-GB' })

  test('opens the app in English on a first visit', async ({ page }) => {
    await page.goto('')
    await expect(page.getByRole('navigation').getByRole('link')).toHaveText(englishSidebar)
    await expect(page.locator('html')).toHaveAttribute('lang', 'en')
  })
})

test('MTP-LANG-004: companies, detail tabs and the wizard are French', async ({ page }) => {
  await page.goto('')
  await page.getByRole('group', { name: 'Language' }).getByRole('button', { name: 'FR' }).click()
  await page.getByRole('navigation').getByRole('link', { name: 'Émetteurs' }).click()

  await expect(page.getByPlaceholder('Rechercher un émetteur')).toBeVisible()
  await expect(page.getByLabel('Afficher les émetteurs archivés')).toBeVisible()
  await expect(page.getByRole('columnheader')).toHaveText([
    'Valeurs',
    'Id ric',
    'Secteur',
    'Utilisateurs associés',
    'Statut',
  ])
  await expect(page.getByRole('cell', { name: 'Actif' }).first()).toBeVisible()

  await page.getByText('LVMH', { exact: true }).click()
  await expect(page.getByRole('tab')).toHaveText([
    'Informations',
    'Listes',
    'Utilisateurs',
    'Imports',
    'Factset',
  ])
  await expect(page.getByRole('button', { name: 'Archiver' })).toBeVisible()
  await page.getByRole('tab', { name: 'Listes' }).click()
  await expect(page.getByText(/^\d+ éléments?$/).first()).toBeVisible()
  await page.getByRole('tab', { name: 'Utilisateurs' }).click()
  await expect(page.getByRole('columnheader', { name: 'CGU acceptées le' })).toBeVisible()

  await page.getByRole('navigation').getByRole('link', { name: 'Émetteurs' }).click()
  await page.getByRole('button', { name: 'Ajouter un émetteur' }).click()
  await expect(page.getByText('1. Informations')).toBeVisible()
  await page.getByRole('button', { name: 'Suivant' }).click()
  await expect(page.getByText('Le nom est requis')).toBeVisible()
  await expect(page.getByText('Le marché est requis')).toBeVisible()
})

test('MTP-LANG-005: reports, the date line and the send dialog are French', async ({ page }) => {
  await page.goto('')
  await page.getByRole('group', { name: 'Language' }).getByRole('button', { name: 'FR' }).click()
  await page.getByRole('navigation').getByRole('link', { name: 'Rapports' }).click()

  await expect(page.getByRole('tab', { name: 'Valeurs', selected: true })).toBeVisible()
  await expect(page.getByRole('tab', { name: 'Marchés' })).toBeVisible()
  const today = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date())
  await expect(page.getByText(`Aujourd'hui (${today})`)).toBeVisible()
  await page.getByRole('button', { name: /^Choisir la date/ }).click()
  const month = new Intl.DateTimeFormat('fr-FR', { month: 'long', year: 'numeric' }).format(
    new Date(),
  )
  await expect(page.getByRole('dialog').getByText(month, { exact: true })).toBeVisible()
  await page.keyboard.press('Escape')
  await expect(page.getByPlaceholder('Rechercher un rapport')).toBeVisible()
  await expect(page.getByRole('columnheader')).toHaveText([
    'Valeurs (5)',
    'Dernière modification',
    'Validation',
    'Statut',
  ])
  await expect(page.getByRole('cell', { name: 'À valider' })).toBeVisible()
  await expect(page.getByRole('cell', { name: '✓ Envoyé à 07:45' })).toBeVisible()

  await page.getByRole('cell', { name: 'Accor', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Rédiger un rapport' })).toBeVisible()
  for (const heading of ['VALEUR', 'SECTEUR', 'MARCHÉ']) {
    await expect(page.getByText(heading, { exact: true })).toBeVisible()
  }
  await page.getByRole('button', { name: 'Envoyer' }).click()
  const dialog = page.getByRole('dialog', { name: 'Envoyer le rapport' })
  await expect(dialog).toContainText('Êtes-vous certain de vouloir envoyer le rapport à Accor ?')
})

test('MTP-LANG-006: flashes and broker notes are French', async ({ page }) => {
  await page.goto('')
  await page.getByRole('group', { name: 'Language' }).getByRole('button', { name: 'FR' }).click()
  await page.getByRole('navigation').getByRole('link', { name: 'Flashs' }).click()
  await expect(page.getByPlaceholder('Rechercher un flash')).toBeVisible()
  await expect(page.getByText(/^\d+–\d+ sur \d+$/)).toBeVisible()
  await page.getByRole('button', { name: 'Envoyer un flash' }).click()
  await expect(page.getByLabel('Envoyer à tous les émetteurs')).toBeVisible()
  await page.getByRole('button', { name: 'Envoyer', exact: true }).click()
  await expect(page.getByText('Merci de saisir un destinataire')).toBeVisible()
  await expect(page.getByText("L'objet est requis")).toBeVisible()

  await page.getByRole('navigation').getByRole('link', { name: 'N. de brokers' }).click()
  await expect(page.getByPlaceholder('Rechercher une note de broker')).toBeVisible()
  await page.getByRole('button', { name: 'Envoyer une note' }).click()
  await expect(page.getByRole('button', { name: 'Envoyer et continuer' })).toBeVisible()
})

test('MTP-LANG-007: version and monitoring are French', async ({ page }) => {
  await page.goto('')
  await page.getByRole('group', { name: 'Language' }).getByRole('button', { name: 'FR' }).click()
  await page.getByRole('navigation').getByRole('link', { name: 'Version' }).click()
  await expect(page.getByText('Version actuelle')).toBeVisible()
  await expect(page.getByLabel('Saisissez la nouvelle version :')).toBeVisible()
  await page.getByRole('navigation').getByRole('link', { name: 'Monitoring' }).click()
  await expect(page.getByRole('heading', { name: 'Monitoring des déconnexions' })).toBeVisible()
  await expect(page.getByLabel("Période d'analyse :")).toBeVisible()
  await expect(page.getByRole('button', { name: 'Actualiser' })).toBeVisible()
  await expect(page.getByText('Session expirée').first()).toBeVisible()
})
