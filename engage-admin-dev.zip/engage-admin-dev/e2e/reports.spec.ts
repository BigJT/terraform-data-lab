import { expect, test, type Page } from '@playwright/test'

function bodyRows(page: Page) {
  return page.getByRole('row').filter({ hasNot: page.getByRole('columnheader') })
}

function ymd(offsetDays: number) {
  const date = new Date()
  date.setDate(date.getDate() + offsetDays)
  const pad = (value: number) => String(value).padStart(2, '0')
  return `${String(date.getFullYear())}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

function pickerText(offsetDays: number) {
  const [year, month, day] = ymd(offsetDays).split('-')
  return `${String(day)}${String(month)}${String(year)}`
}

test('MTP-REP-001: the Reports list shows tabs, date line, picker, search and today rows', async ({
  page,
}) => {
  await page.goto('reports')
  await expect(page.getByRole('tab', { name: 'Companies', selected: true })).toBeVisible()
  await expect(page.getByRole('tab', { name: 'Markets' })).toBeVisible()
  await expect(page.getByText(/^Today \(\w+ \d{1,2} \w+ \d{4}\)$/)).toBeVisible()
  await expect(page.getByRole('group', { name: 'Date' })).toBeVisible()
  await expect(page.getByPlaceholder('Search reports')).toBeVisible()
  await expect(page.getByRole('columnheader')).toHaveText([
    'Companies (5)',
    'Last modified',
    'Validation',
    'Status',
  ])
  await expect(bodyRows(page).locator('td:first-child')).toHaveText([
    'Accor',
    'Danone',
    'Diageo',
    'Kering',
    'LVMH',
  ])
  await expect(page.getByText('Worldline')).toHaveCount(0)
  const lvmh = bodyRows(page).filter({ hasText: 'LVMH' })
  await expect(lvmh).toContainText('Validated')
  await expect(lvmh).toContainText('✓ Sent at 07:45')
  const danone = bodyRows(page).filter({ hasText: 'Danone' })
  await expect(danone).toContainText('To validate')
  await expect(danone).toContainText('To send')
  const accor = bodyRows(page).filter({ hasText: 'Accor' })
  await expect(accor.locator('td').nth(2)).toHaveText('...')
  await expect(accor.locator('td').nth(3)).toHaveText('To send')
})

test('MTP-REP-002: search filters the rows and the date picker moves to another day', async ({
  page,
}) => {
  await page.goto('reports')
  await page.getByPlaceholder('Search reports').fill('dan')
  await expect(bodyRows(page).locator('td:first-child')).toHaveText(['Danone'])
  await expect(page.getByRole('columnheader').first()).toHaveText('Companies (1)')
  await page.getByPlaceholder('Search reports').fill('')
  await expect(bodyRows(page)).toHaveCount(5)

  await page.getByRole('group', { name: 'Date' }).click()
  await page.keyboard.type(pickerText(-1), { delay: 50 })
  await expect(page).toHaveURL(new RegExp(`date=${ymd(-1)}`))
  await expect(page.getByText(/^Today \(/)).toHaveCount(0)
  await expect(page.getByText(/^\w+ \d{1,2} \w+ \d{4}$/)).toBeVisible()
  await expect(bodyRows(page)).toHaveCount(5)
  for (const row of await bodyRows(page).all()) {
    await expect(row.locator('td').nth(2)).toHaveText('...')
    await expect(row.locator('td').nth(3)).toHaveText('To send')
  }
  await expect(page.getByText('Worldline')).toHaveCount(0)
  await page.reload()
  await expect(page).toHaveURL(new RegExp(`date=${ymd(-1)}`))
  await expect(page.getByText(/^Today \(/)).toHaveCount(0)
})

test('MTP-REP-003: the Markets tab lists French then English and opens the market report', async ({
  page,
}) => {
  await page.goto('reports')
  await page.getByRole('tab', { name: 'Markets' }).click()
  await expect(page.getByRole('columnheader')).toHaveText([
    'Language (2)',
    'Last modified',
    'Validation',
    'Status',
  ])
  const rows = bodyRows(page)
  await expect(rows.locator('td:first-child')).toHaveText(['French', 'English'])
  await expect(rows.nth(0)).toContainText('Validated')
  await expect(rows.nth(0)).toContainText('To send')
  await expect(rows.nth(1).locator('td').nth(2)).toHaveText('...')
  await expect(rows.nth(1)).toContainText('To send')
  await rows.nth(0).click()
  await expect(page).toHaveURL(/\/reports\/market\/m-fr-FR-/)
  await expect(page.getByRole('heading', { level: 1, name: 'Write a market report' })).toBeVisible()
})

test('MTP-REP-004: the company report shows its layout, market block and details', async ({
  page,
}) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  await expect(page.getByRole('heading', { level: 1, name: 'Write a report' })).toBeVisible()
  await expect(page.getByRole('link', { name: 'Back to reports' })).toBeVisible()
  for (const title of ['COMPANY', 'SECTOR', 'CUSTOM CONTENT 1', 'CUSTOM CONTENT 2', 'MARKET']) {
    await expect(page.getByText(title, { exact: true })).toBeVisible()
  }
  await expect(page.getByText('Enter your analysis here')).toHaveCount(2)
  await expect(page.getByRole('link', { name: 'View' })).toBeVisible()
  await expect(
    page.getByText('European markets closed higher, led by luxury stocks.'),
  ).toBeVisible()
  const details = page.getByRole('heading', { name: 'COMPANY DETAILS' }).locator('..')
  for (const value of ['Accor', 'ACCP.PA', 'Euronext Paris', 'Hospitality', 'French']) {
    await expect(details.getByText(value, { exact: true })).toBeVisible()
  }
})

test('MTP-REP-011: a past date opens a read-only report', async ({ page }) => {
  await page.goto(`reports?date=${ymd(-1)}`)
  await bodyRows(page).first().click()
  await expect(page.getByRole('heading', { level: 1, name: 'Write a report' })).toBeVisible()
  await expect(page.getByRole('main').getByRole('button')).toHaveCount(0)
  await expect(page.getByText('Enter your analysis here')).toHaveCount(0)
  await expect(page.getByText(/^Sent at/)).toHaveCount(0)
})

test('MTP-REP-013: stored scripts and handlers are stripped, bold stays', async ({ page }) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /LVMH/ }).click()
  await expect(page.getByText('Desk note')).toBeVisible()
  await expect(page.locator('strong', { hasText: 'Desk note' })).toBeVisible()
  await page.waitForTimeout(500)
  expect(await page.evaluate(() => (window as unknown as { __xss?: number }).__xss)).toBeUndefined()
})

const png =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='

function contentSaves(page: Page) {
  const saves: string[] = []
  page.on('request', (request) => {
    if (request.method() === 'PUT' && request.url().endsWith('/content')) {
      saves.push(request.postData() ?? '')
    }
  })
  return saves
}

async function toolbarNames(page: Page, box: string) {
  const group = page.getByRole('group', { name: box })
  await expect(group.getByRole('button').first()).toBeVisible()
  return group
    .getByRole('button')
    .evaluateAll((buttons) => buttons.map((button) => button.getAttribute('aria-label')))
}

// Mock writes live in page memory, so "reload" reopens the report through the app instead.
async function reopenAccor(page: Page) {
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await page.getByRole('row', { name: /Accor/ }).click()
}

test('MTP-REP-005: boxes auto-save, custom boxes only after leaving them', async ({ page }) => {
  const saves = contentSaves(page)
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  await page.getByRole('textbox', { name: 'COMPANY' }).click()
  await page.keyboard.type('Accor beat estimates.')
  await page.waitForTimeout(2000)
  expect(saves).toHaveLength(0)
  await expect.poll(() => saves.length, { timeout: 5000 }).toBe(1)
  expect(saves[0]).toContain('Accor beat estimates.')
  await expect(page.getByText('Last saved just now')).toBeVisible()

  await page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' }).click()
  await page.keyboard.type('Desk colour.')
  await page.waitForTimeout(4000)
  expect(saves).toHaveLength(1)
  await page.getByRole('heading', { level: 1, name: 'Write a report' }).click()
  await expect.poll(() => saves.length, { timeout: 5000 }).toBe(2)
  expect(saves[1]).toContain('Accor beat estimates.')
  expect(saves[1]).toContain('Desk colour.')

  await reopenAccor(page)
  await expect(page.getByRole('textbox', { name: 'COMPANY' })).toHaveText('Accor beat estimates.')
  await expect(page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' })).toHaveText('Desk colour.')
})

test('MTP-REP-006: toolbars per box, tables and pasted inline images', async ({ page }) => {
  const saves = contentSaves(page)
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  for (const name of ['COMPANY', 'SECTOR']) {
    expect(await toolbarNames(page, name)).toEqual(['Bold', 'Italic'])
  }
  const full = [
    'Heading 2',
    'Heading 3',
    'Bold',
    'Italic',
    'Underline',
    'Bullet list',
    'Numbered list',
    'Link',
    'Insert table',
    'Image',
    'Paste as plain text',
  ]
  for (const name of ['CUSTOM CONTENT 1', 'CUSTOM CONTENT 2']) {
    expect(await toolbarNames(page, name)).toEqual(full)
  }

  const custom = page.getByRole('group', { name: 'CUSTOM CONTENT 1' })
  const box = page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' })
  await box.click()
  await custom.getByRole('button', { name: 'Bold' }).click()
  await expect(custom.getByRole('button', { name: 'Bold' })).toHaveAttribute('aria-pressed', 'true')
  await custom.getByRole('button', { name: 'Insert table' }).click()
  await expect(box.locator('table tr')).toHaveCount(3)
  await expect(box.locator('table tr').first().locator('th')).toHaveCount(3)
  await expect(box.locator('table tr').nth(1).locator('td')).toHaveCount(3)

  await box.evaluate((element, src) => {
    const data = new DataTransfer()
    data.setData('text/html', `<p>Logo <img src="${src}"></p>`)
    element.dispatchEvent(
      new ClipboardEvent('paste', { clipboardData: data, bubbles: true, cancelable: true }),
    )
  }, png)
  await expect(box.locator(`img[src="${png}"]`)).toHaveCount(1)
  await page.getByRole('heading', { level: 1, name: 'Write a report' }).click()
  await expect.poll(() => saves.length, { timeout: 5000 }).toBe(1)
  expect(saves[0]).toContain(png)

  await reopenAccor(page)
  await expect(
    page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' }).locator(`img[src="${png}"]`),
  ).toHaveCount(1)
  await expect(
    page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' }).locator('table'),
  ).toHaveCount(1)
})

test('MTP-REP-007: request validation, validate content and writing', async ({ page }) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  await page.getByRole('button', { name: 'Request validation' }).click()
  await expect(page.getByRole('button', { name: 'Request validation' })).toBeDisabled()
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await expect(page.getByRole('row', { name: /Accor/ })).toContainText('To validate')
  await page.getByRole('row', { name: /Accor/ }).click()
  await page.getByRole('button', { name: 'Validate content' }).click()
  await expect(page.getByRole('button', { name: 'Content validated' })).toBeDisabled()
  await page.getByRole('button', { name: 'Validate writing' }).click()
  await expect(page.getByRole('button', { name: 'Writing validated' })).toBeDisabled()
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await expect(page.getByRole('row', { name: /Accor/ })).toContainText('Validated')
})

test('MTP-REP-008: send with warning, cancel and confirm', async ({ page }) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /Diageo/ }).click()
  await page.getByRole('button', { name: 'Send' }).click()
  const dialog = page.getByRole('dialog', { name: 'Send the report' })
  await expect(dialog).toContainText('The report content and writing have not been validated.')
  await expect(dialog).toContainText('Are you sure you want to send the report to Diageo?')
  await dialog.getByRole('button', { name: 'Cancel' }).click()
  await expect(dialog).toBeHidden()
  await expect(page.getByRole('button', { name: 'Send' })).toBeVisible()
  await page.getByRole('button', { name: 'Send' }).click()
  await dialog.getByRole('button', { name: 'Yes' }).click()
  await expect(page.getByText(/^Sent at \d\d:\d\d$/)).toBeVisible()
  await expect(page.getByRole('button', { name: 'Edit' })).toBeVisible()
  await expect(page.getByRole('textbox')).toHaveCount(0)
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await expect(page.getByRole('row', { name: /Diageo/ })).toContainText(/✓ Sent at \d\d:\d\d/)
})

test('MTP-REP-009: edit a sent report and save without resending', async ({ page }) => {
  const saves = contentSaves(page)
  await page.goto('reports')
  await page.getByRole('row', { name: /LVMH/ }).click()
  await expect(page.getByRole('textbox')).toHaveCount(0)
  await page.getByRole('button', { name: 'Edit' }).click()
  await expect(page.getByRole('button', { name: 'Save' })).toBeVisible()
  const sector = page.getByRole('textbox', { name: 'SECTOR' })
  await sector.click()
  await page.keyboard.type(' Edited.')
  await page.waitForTimeout(5000)
  expect(saves).toHaveLength(0)
  await page.getByRole('button', { name: 'Save' }).click()
  const dialog = page.getByRole('dialog', { name: 'Save the report' })
  await expect(dialog).toContainText(
    'Are you sure you want to save the changes to the report for LVMH?',
  )
  await dialog.getByRole('button', { name: 'Yes' }).click()
  await expect(page.getByText('Edited.')).toBeVisible()
  await expect(page.getByRole('textbox')).toHaveCount(0)
  await expect(page.getByText('Sent at 07:45')).toBeVisible()
  expect(saves).toHaveLength(1)
})

test('MTP-REP-010: a report held by someone else asks before unlocking', async ({ page }) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /Kering/ }).click()
  const dialog = page.getByRole('dialog', { name: 'CONTENT BEING WRITTEN' })
  await expect(dialog).toContainText(
    'The report is being written by jean.martin@rothschildandco.com',
  )
  await expect(dialog).toContainText('Do you want to unlock access to this report?')
  await dialog.getByRole('button', { name: 'Cancel' }).click()
  await expect(dialog).toBeHidden()
  await expect(page.getByRole('button', { name: 'Send' })).toHaveCount(0)
  await expect(page.getByRole('textbox')).toHaveCount(0)
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await page.getByRole('row', { name: /Kering/ }).click()
  await page
    .getByRole('dialog', { name: 'CONTENT BEING WRITTEN' })
    .getByRole('button', { name: 'Yes' })
    .click()
  await expect(page.getByRole('button', { name: 'Send' })).toBeVisible()
  await expect(page.getByRole('textbox', { name: 'COMPANY' })).toBeVisible()
})

test('MTP-REP-012: the market report auto-saves and shows in the company report', async ({
  page,
}) => {
  await page.goto('reports')
  await page.getByRole('tab', { name: 'Markets' }).click()
  await bodyRows(page).nth(1).click()
  await expect(page.getByRole('heading', { level: 1, name: 'Write a market report' })).toBeVisible()
  await expect(page.getByText('English', { exact: true })).toBeVisible()
  await expect(page.getByRole('button', { name: 'Image' })).toBeVisible()
  await expect(page.getByRole('button', { name: 'Send' })).toBeVisible()
  await page.getByRole('textbox').click()
  await page.keyboard.type('Asia opened firmer.')
  await expect(page.getByText('Last saved just now')).toBeVisible({ timeout: 8000 })
  await page.getByRole('button', { name: 'Send' }).click()
  await expect(page.getByRole('dialog', { name: 'Send the report' })).toContainText(
    'Are you sure you want to send the English market report?',
  )
  await page.getByRole('dialog').getByRole('button', { name: 'Cancel' }).click()
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await page.getByRole('tab', { name: 'Companies' }).click()
  await page.getByRole('row', { name: /Diageo/ }).click()
  await expect(page.getByText('Asia opened firmer.')).toBeVisible()
})

test('a failed auto-save alert does not come back after Send and Edit', async ({ page }) => {
  // The mock worker hides requests from page.route, so fail the first content save in the page's own fetch.
  await page.addInitScript(() => {
    const realFetch = window.fetch.bind(window)
    let failed = false
    window.fetch = (input, init) => {
      const url = input instanceof Request ? input.url : String(input)
      if (!failed && url.endsWith('/content')) {
        failed = true
        return Promise.resolve(Response.json({ message: 'Down' }, { status: 500 }))
      }
      return realFetch(input, init)
    }
  })
  const alert = page.getByText('The report could not be saved. Your changes are kept on this page.')
  await page.goto('reports')
  await page.getByRole('row', { name: /Diageo/ }).click()
  await page.getByRole('textbox', { name: 'COMPANY' }).click()
  await page.keyboard.type('Diageo held its guidance.')
  await expect(alert).toBeVisible({ timeout: 6000 })
  await page.getByRole('button', { name: 'Send' }).click()
  await page
    .getByRole('dialog', { name: 'Send the report' })
    .getByRole('button', { name: 'Yes' })
    .click()
  await page.getByRole('button', { name: 'Edit' }).click()
  await expect(page.getByRole('textbox', { name: 'COMPANY' })).toBeVisible()
  await expect(alert).toBeHidden()
})

test('typing then leaving within 3 s keeps the edit, custom boxes included', async ({ page }) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  await page.getByRole('textbox', { name: 'COMPANY' }).click()
  await page.keyboard.type('Quick company note.')
  await page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' }).click()
  await page.keyboard.type('Quick custom note.')
  await page.getByRole('textbox', { name: 'CUSTOM CONTENT 2' }).click()
  await page.keyboard.type('Unblurred custom note.')
  await reopenAccor(page)
  await expect(page.getByRole('textbox', { name: 'COMPANY' })).toHaveText('Quick company note.')
  await expect(page.getByRole('textbox', { name: 'CUSTOM CONTENT 1' })).toHaveText(
    'Quick custom note.',
  )
  await expect(page.getByRole('textbox', { name: 'CUSTOM CONTENT 2' })).toHaveText(
    'Unblurred custom note.',
  )
})

test('typing a market report then leaving within 3 s keeps the edit', async ({ page }) => {
  await page.goto('reports')
  await page.getByRole('tab', { name: 'Markets' }).click()
  await bodyRows(page).nth(1).click()
  await page.getByRole('textbox').click()
  await page.keyboard.type('Quick market note.')
  await page.getByRole('link', { name: 'Back to reports' }).click()
  await bodyRows(page).nth(1).click()
  await expect(page.getByRole('textbox')).toHaveText('Quick market note.')
})

test('MTP-GWA-004: short-positions chart add, refuse, replace, remove and read-only', async ({
  page,
}) => {
  const file = (name: string, mimeType: string) => ({ name, mimeType, buffer: Buffer.from('x') })
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  await expect(page.getByText('SHORT POSITIONS')).toBeVisible()
  const chooser = page.getByLabel('Chart file', { exact: true })
  await expect(page.getByRole('button', { name: 'Add chart' })).toBeVisible()
  await chooser.setInputFiles(file('accor.pdf', 'application/pdf'))
  await expect(page.getByText('Choose a PNG or JPEG image.')).toBeVisible()
  await chooser.setInputFiles(file('accor.png', 'image/png'))
  await expect(page.getByText('accor.png')).toBeVisible()
  await expect(page.getByText('Choose a PNG or JPEG image.')).toHaveCount(0)
  await chooser.setInputFiles(file('accor.jpg', 'image/jpeg'))
  await expect(page.getByText('accor.jpg')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Replace' })).toBeVisible()
  await page.getByRole('button', { name: 'Remove' }).click()
  await expect(page.getByRole('button', { name: 'Add chart' })).toBeVisible()
  await page.goto(`reports?date=${ymd(-1)}`)
  await page.getByRole('row', { name: /Accor/ }).click()
  await expect(page.getByText('No chart.')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Add chart' })).toHaveCount(0)
})

test('MTP-GWA-005: economic statistics table for today and none for yesterday', async ({
  page,
}) => {
  await page.goto('reports')
  await page.getByRole('row', { name: /Accor/ }).click()
  await expect(page.getByText('ECONOMIC STATISTICS')).toBeVisible()
  for (const name of [
    'Zone',
    'Country',
    'Indicator',
    'Period',
    'Actual',
    'Expected',
    'Previous',
    'Released',
  ])
    await expect(page.getByRole('columnheader', { name })).toBeVisible()
  await expect(page.getByRole('row', { name: /France CPI \(YoY\)/ })).toBeVisible()
  await expect(page.getByRole('row', { name: /Germany ZEW Economic Sentiment/ })).toBeVisible()
  await expect(page.getByRole('row', { name: /United States Retail Sales \(MoM\)/ })).toBeVisible()
  await page.goto(`reports?date=${ymd(-1)}`)
  await page.getByRole('row', { name: /Accor/ }).click()
  await expect(page.getByText('No statistics for this day.')).toBeVisible()
})
