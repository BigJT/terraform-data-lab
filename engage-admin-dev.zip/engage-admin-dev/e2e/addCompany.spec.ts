import { expect, test, type Page } from '@playwright/test'

async function choose(page: Page, label: string, option: string) {
  await page.getByRole('combobox', { name: label, exact: true }).click()
  await page.getByRole('option', { name: option, exact: true }).click()
}

// Starts from the Companies list without reloading, so mock writes made earlier in a test persist.
async function fillStepOne(page: Page, ric: string) {
  await page.getByRole('button', { name: 'Add company' }).click()
  await expect(page).toHaveURL(/\/companies\/new$/)
  await page.getByLabel('RIC', { exact: true }).fill(ric)
  await page.getByLabel('Name', { exact: true }).fill("L'Oreal")
  await choose(page, 'Market', 'Euronext Paris')
  await choose(page, 'Sector', 'Luxury')
}

async function toStepThree(page: Page, ric: string) {
  await fillStepOne(page, ric)
  await page.getByRole('button', { name: 'Next' }).click()
  await expect(page.getByRole('combobox', { name: 'Index 1' })).toBeVisible()
  await page.getByRole('button', { name: 'Next' }).click()
  await expect(page.getByRole('button', { name: 'Add user' })).toBeVisible()
}

test('MTP-ADMF-010: step 1 shows required errors, French by default, and checks the RIC', async ({
  page,
}) => {
  await page.goto('companies/new')
  await expect(page.getByText('1. Information')).toBeVisible()
  await expect(page.getByRole('radio', { name: 'French' })).toBeChecked()
  await page.getByRole('button', { name: 'Next' }).click()
  for (const message of [
    'RIC is required',
    'Name is required',
    'Market is required',
    'Sector is required',
  ]) {
    await expect(page.getByText(message)).toBeVisible()
  }
  await page.getByLabel('RIC', { exact: true }).fill('NOPE.PA')
  await page.getByLabel('Name', { exact: true }).click()
  await expect(page.getByText('This RIC code does not exist')).toBeVisible()
  await page.getByLabel('Name', { exact: true }).fill('Nope')
  await choose(page, 'Market', 'Euronext Paris')
  await choose(page, 'Sector', 'Luxury')
  await page.getByRole('button', { name: 'Next' }).click()
  await expect(page.getByText('This RIC code does not exist')).toBeVisible()
  await expect(page.getByRole('combobox', { name: 'Index 1' })).toHaveCount(0)
  await page.getByLabel('RIC', { exact: true }).fill('OREP.PA')
  await page.getByLabel('Name', { exact: true }).click()
  await expect(page.getByText('This RIC code does not exist')).toBeHidden()
  await expect(page.getByLabel('Name', { exact: true })).toHaveValue('Nope')
})

test('MTP-ADMF-011: step 2 excludes chosen indices, allows none, and Back keeps step 1', async ({
  page,
}) => {
  await page.goto('companies')
  await fillStepOne(page, 'OREP.PA')
  await page.getByRole('button', { name: 'Next' }).click()
  await expect(page.getByText('2. Indices')).toBeVisible()
  await choose(page, 'Index 1', '.FCHI CAC 40')
  await page.getByRole('combobox', { name: 'Index 2' }).click()
  await expect(page.getByRole('option', { name: /^\.FCHI / })).toHaveCount(0)
  await page.keyboard.press('Escape')
  await page.getByRole('button', { name: 'Back' }).click()
  await expect(page.getByLabel('RIC', { exact: true })).toHaveValue('OREP.PA')
  await expect(page.getByLabel('Name', { exact: true })).toHaveValue("L'Oreal")
  await page.getByRole('button', { name: 'Next' }).click()
  await choose(page, 'Index 1', 'None')
  await page.getByRole('button', { name: 'Next' }).click()
  await expect(page.getByRole('button', { name: 'Add user' })).toBeVisible()
})

test('MTP-ADMF-012: step 3 user blocks validate, block Add, and can be removed', async ({
  page,
}) => {
  await page.goto('companies')
  await toStepThree(page, 'OREP.PA')
  await page.getByRole('button', { name: 'Add user' }).click()
  await page.getByRole('button', { name: 'Add user' }).click()
  const first = page.getByRole('group', { name: 'User 1' })
  const second = page.getByRole('group', { name: 'User 2' })
  for (const label of ['First name', 'Last name', 'Position', 'Email', 'Phone']) {
    await expect(first.getByLabel(label)).toBeVisible()
  }
  await first.getByLabel('First name').fill('Anne')
  await first.getByLabel('Last name').fill('Moreau')
  await first.getByLabel('Position').fill('Investor Relations')
  await first.getByLabel('Email').fill('anne.moreau@loreal.example')
  await second.getByLabel('First name').fill('Bob')
  await second.getByLabel('Last name').fill('Smith')
  await second.getByLabel('Position').fill('CFO')
  await page.getByRole('button', { name: 'Add', exact: true }).click()
  await expect(second.getByText('Email is required')).toBeVisible()
  await second.getByLabel('Email').fill('bob@x')
  await page.getByRole('button', { name: 'Add', exact: true }).click()
  await expect(second.getByText('Invalid email format')).toBeVisible()
  await expect(page).toHaveURL(/\/companies\/new$/)
  await second.getByRole('button', { name: 'Remove' }).click()
  await first.getByRole('button', { name: 'Remove' }).click()
  await expect(page.getByRole('group', { name: /^User / })).toHaveCount(0)
  await page.getByRole('button', { name: 'Add', exact: true }).click()
  await expect(page).toHaveURL(/\/companies\/[0-9a-f-]+\/information$/)
})

test('MTP-ADMF-013: finishing the wizard opens the new company; a used RIC shows the server message', async ({
  page,
}) => {
  await page.goto('companies')
  await toStepThree(page, 'OREP.PA')
  await page.getByRole('button', { name: 'Add user' }).click()
  const block = page.getByRole('group', { name: 'User 1' })
  await block.getByLabel('First name').fill('Anne')
  await block.getByLabel('Last name').fill('Moreau')
  await block.getByLabel('Position').fill('Investor Relations')
  await block.getByLabel('Email').fill('anne.moreau@loreal.example')
  await page.getByRole('button', { name: 'Add', exact: true }).click()
  await expect(page).toHaveURL(/\/companies\/[0-9a-f-]+\/information$/)
  await expect(page.getByRole('heading', { level: 1, name: "L'Oreal" })).toBeVisible()
  await page.getByRole('link', { name: 'Companies' }).click()
  await expect(
    page
      .getByRole('row', { name: /L'Oreal/ })
      .locator('td')
      .nth(3),
  ).toHaveText('1')

  await toStepThree(page, 'LVMH.PA')
  await page.getByRole('button', { name: 'Add', exact: true }).click()
  await expect(page.getByRole('alert')).toHaveText('An emitter with same RIC code already exists')
  await expect(page.getByLabel('RIC', { exact: true })).toHaveValue('LVMH.PA')
  await page.getByRole('link', { name: 'Companies' }).click()
  await expect(page.getByRole('row', { name: /LVMH/ })).toHaveCount(1)
  await expect(page.getByRole('row', { name: /L'Oreal/ })).toHaveCount(1)
})

test('MTP-GWC-001: a user whose email is already used is reported on the new company page', async ({
  page,
}) => {
  await page.goto('companies')
  await toStepThree(page, 'OREP.PA')
  await page.getByRole('button', { name: 'Add user' }).click()
  await page.getByRole('button', { name: 'Add user' }).click()
  const first = page.getByRole('group', { name: 'User 1' })
  const second = page.getByRole('group', { name: 'User 2' })
  await first.getByLabel('First name').fill('Anne')
  await first.getByLabel('Last name').fill('Moreau')
  await first.getByLabel('Position').fill('Investor Relations')
  await first.getByLabel('Email').fill('anne.moreau@loreal.example')
  await second.getByLabel('First name').fill('Claire')
  await second.getByLabel('Last name').fill('Martin')
  await second.getByLabel('Position').fill('CFO')
  await second.getByLabel('Email').fill('claire.martin@lvmh.example')
  await page.getByRole('button', { name: 'Add', exact: true }).click()
  await expect(page).toHaveURL(/\/companies\/[0-9a-f-]+\/information$/)
  const warning = page.getByRole('alert').filter({ hasText: 'Some users could not be created:' })
  await expect(warning).toContainText(
    'claire.martin@lvmh.example: Email claire.martin@lvmh.example is already used.',
  )
  await page.getByRole('tab', { name: 'Users' }).click()
  await expect(page.getByRole('cell', { name: 'anne.moreau@loreal.example' })).toBeVisible()
  await expect(page.getByRole('cell', { name: 'claire.martin@lvmh.example' })).toHaveCount(0)
})
