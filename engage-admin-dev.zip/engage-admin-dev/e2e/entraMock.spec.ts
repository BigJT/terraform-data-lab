import { expect, test } from '@playwright/test'

test('MTP-ADMF-022: the sign-in page leads to the stand-in Microsoft page', async ({ page }) => {
  await page.goto('')
  await expect(page.getByRole('heading', { name: 'Engage Admin' })).toBeVisible()
  await page.getByRole('button', { name: 'Sign in with Microsoft' }).click()
  await expect(page).toHaveURL(/\/mock-entra-sign-in$/)
  await expect(page.getByRole('heading', { name: 'Stand-in Microsoft sign-in' })).toBeVisible()
  await expect(
    page.getByText(
      'Pick an account. This page stands in for Microsoft until an Entra tenant is set up.',
    ),
  ).toBeVisible()
  await expect(page.getByRole('button', { name: 'Admin User' })).toBeVisible()
  await expect(page.getByRole('button', { name: 'Standard User' })).toBeVisible()
})

test('MTP-ADMF-023: Standard User gets the no-access page and Sign out returns to sign-in', async ({
  page,
}) => {
  await page.goto('mock-entra-sign-in')
  await page.getByRole('button', { name: 'Standard User' }).click()
  await expect(page.getByText('You do not have access to Engage Admin.')).toBeVisible()
  await expect(page.getByRole('navigation')).toHaveCount(0)
  await page.getByRole('button', { name: 'Sign out' }).click()
  await expect(page.getByRole('button', { name: 'Sign in with Microsoft' })).toBeVisible()
})

test('MTP-ADMF-024: Admin User opens the shell, survives a reload, and Sign out ends the session', async ({
  page,
}) => {
  await page.goto('mock-entra-sign-in')
  await page.getByRole('button', { name: 'Admin User' }).click()
  await expect(page).toHaveURL(/\/engage-admin\/companies$/)
  await expect(page.getByText('Admin User')).toBeVisible()
  await page.reload()
  await expect(page.getByText('Admin User')).toBeVisible()
  await page.getByRole('button', { name: 'Sign out' }).click()
  await expect(page.getByRole('button', { name: 'Sign in with Microsoft' })).toBeVisible()
  await page.goBack()
  await expect(page.getByRole('navigation')).toHaveCount(0)
  await expect(page.getByText('Admin User')).toHaveCount(0)
})

test('MTP-LANG-003: with French selected, the sign-in, stand-in and no-access pages are French', async ({
  page,
}) => {
  await page.goto('mock-entra-sign-in')
  await page.getByRole('button', { name: 'Admin User' }).click()
  await page.getByRole('button', { name: 'FR' }).click()
  await page.getByRole('button', { name: 'Se déconnecter' }).click()
  await page.getByRole('button', { name: 'Se connecter avec Microsoft' }).click()
  await expect(page.getByRole('heading', { name: 'Connexion Microsoft simulée' })).toBeVisible()
  await page.getByRole('button', { name: 'Standard User' }).click()
  await expect(page.getByText("Vous n'avez pas accès à Engage Admin.")).toBeVisible()
  await expect(page.getByRole('button', { name: 'Se déconnecter' })).toBeVisible()
})
