import { expect, test, type Page } from '@playwright/test'

function bodyRows(page: Page) {
  return page.getByRole('row').filter({ hasNot: page.getByRole('columnheader') })
}

test('MTP-FLS-001: the Flashes list shows controls, columns and five rows newest first', async ({
  page,
}) => {
  await page.goto('flashes')
  await expect(page.getByRole('heading', { name: 'Flashes' })).toBeVisible()
  await expect(page.getByPlaceholder('Search flashes')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Send a flash' })).toBeVisible()
  for (const name of ['Sent', 'Recipients', 'Company', 'Title', 'Type']) {
    await expect(page.getByRole('columnheader', { name })).toBeVisible()
  }
  const rows = bodyRows(page)
  await expect(rows).toHaveCount(5)
  await expect(rows.first()).toContainText('LVMH Q3 revenue ahead of consensus')
  await expect(rows.last()).toContainText('Peer report: hospitality')
  await expect(rows.first().getByRole('cell').first()).toHaveText(
    /^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/,
  )
})

test('MTP-FLS-002: searching narrows the list and clearing restores it', async ({ page }) => {
  await page.goto('flashes')
  await expect(bodyRows(page)).toHaveCount(5)
  await page.getByPlaceholder('Search flashes').fill('luxury')
  await expect(bodyRows(page)).toHaveCount(1)
  await expect(bodyRows(page).first()).toContainText('Pre-opening: European luxury sector')
  await page.getByPlaceholder('Search flashes').clear()
  await expect(bodyRows(page)).toHaveCount(5)
})

test('MTP-FLS-003: the detail shows sections, links, email note and a downloadable attachment', async ({
  page,
}) => {
  await page.goto('flashes')
  await page.getByText('LVMH Q3 revenue ahead of consensus').click()
  await expect(
    page.getByRole('heading', { name: 'LVMH Q3 revenue ahead of consensus' }),
  ).toBeVisible()
  await expect(page.getByText(/^Sent \d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)).toBeVisible()
  await expect(page.getByText('RECIPIENTS')).toBeVisible()
  await expect(page.getByText('Type: Breaking News')).toBeVisible()
  await expect(page.getByText('Company: LVMH')).toBeVisible()
  await expect(page.getByText('RELATED LINKS:')).toBeVisible()
  await expect(page.getByRole('link', { name: 'https://www.lvmh.com/investors' })).toBeVisible()
  await expect(page.getByText('Duplicate sent by email')).toBeVisible()

  await page.getByRole('link', { name: 'Back to flashes' }).click()
  await page.getByText('Pre-opening: European luxury sector').click()
  await expect(page.getByText('Kering', { exact: true })).toBeVisible()
  await expect(page.getByText('RELATED LINKS:')).toHaveCount(0)
  await expect(page.getByText('ATTACHMENT')).toBeVisible()
  const download = page.waitForEvent('download')
  await page.getByRole('button', { name: 'luxury-preopen.pdf' }).click()
  expect((await download).suggestedFilename()).toBe('luxury-preopen.pdf')
})

test('MTP-FLS-004: Cancel keeps the flash, Yes deletes it and returns to the list', async ({
  page,
}) => {
  await page.goto('flashes')
  await page.getByText('Danone shares up 2.4% in early trade').click()
  await page.getByRole('button', { name: 'Delete' }).click()
  const dialog = page.getByRole('dialog', { name: 'Delete flash' })
  await expect(dialog.getByText('Are you sure you want to delete?')).toBeVisible()
  await expect(dialog.getByText('This action cannot be undone')).toBeVisible()
  await dialog.getByRole('button', { name: 'Cancel' }).click()
  await expect(dialog).toHaveCount(0)
  await expect(
    page.getByRole('heading', { name: 'Danone shares up 2.4% in early trade' }),
  ).toBeVisible()
  await page.getByRole('button', { name: 'Delete' }).click()
  await page.getByRole('button', { name: 'Yes' }).click()
  await expect(page).toHaveURL(/\/flashes$/)
  await expect(page.getByText('Danone shares up 2.4% in early trade')).toHaveCount(0)
  await expect(bodyRows(page)).toHaveCount(4)
})

test('MTP-FLS-005: an empty Send shows every error and Type offers the eight types', async ({
  page,
}) => {
  await page.goto('flashes')
  await page.getByRole('button', { name: 'Send a flash' }).click()
  await expect(page.getByRole('heading', { name: 'Send a flash' })).toBeVisible()
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  for (const error of [
    'Please choose a recipient',
    'Subject is required',
    'Company is required',
    'Type is required',
    'Message is required',
  ]) {
    await expect(page.getByText(error)).toBeVisible()
  }
  await expect(page.getByRole('heading', { name: 'Send a flash' })).toBeVisible()
  await page.getByRole('combobox', { name: 'Type' }).click()
  await expect(page.getByRole('option')).toHaveText([
    'Price movement',
    'Pre-opening',
    'Breaking News',
    'Reco / TP',
    "Sales traders' comments",
    'Brokers Interests',
    'Brokers Comments',
    'Peer report',
  ])
})

test('MTP-FLS-006: archived companies are never offered and Send to all disables the picker', async ({
  page,
}) => {
  await page.goto('flashes/new')
  const picker = page.getByRole('combobox', { name: 'Companies' })
  await picker.click()
  await expect(page.getByRole('option', { name: 'Danone' })).toBeVisible()
  await picker.fill('w')
  await expect(page.getByText('No options')).toBeVisible()
  await expect(page.getByRole('option', { name: 'Worldline' })).toHaveCount(0)
  await picker.fill('')
  await page.keyboard.press('Escape')
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  await expect(page.getByText('Please choose a recipient')).toBeVisible()
  await page.getByRole('checkbox', { name: 'Send to all companies' }).check()
  await expect(picker).toBeDisabled()
  await expect(page.getByText('Please choose a recipient')).toHaveCount(0)
})

async function fillFlash(page: Page, subject: string) {
  await page.goto('flashes')
  await page.getByRole('button', { name: 'Send a flash' }).click()
  await page.getByRole('combobox', { name: 'Companies' }).click()
  await page.getByRole('option', { name: 'Danone' }).click()
  await page.getByRole('textbox', { name: 'Subject' }).fill(subject)
  await page.getByRole('textbox', { name: 'Company', exact: true }).fill('Danone')
  await page.getByRole('combobox', { name: 'Type' }).click()
  await page.getByRole('option', { name: 'Breaking News' }).click()
  await page.getByRole('textbox', { name: 'Message' }).click()
  await page.getByRole('button', { name: 'Bold' }).click()
  await page.keyboard.type('Big news')
}

const mb = 1024 * 1024
const fileInput = (page: Page) => page.getByLabel('Add an attachment input')
const buffer = (name: string, size: number) => ({
  name,
  mimeType: 'application/octet-stream',
  buffer: Buffer.alloc(size, 1),
})

test('MTP-FLS-007: attachment rules refuse bad files and list good ones', async ({ page }) => {
  await page.goto('flashes/new')
  await fileInput(page).setInputFiles(buffer('empty.txt', 0))
  await expect(page.getByText('Attachment empty.txt is empty.')).toBeVisible()
  await fileInput(page).setInputFiles(buffer('big.bin', 10 * mb + 1))
  await expect(page.getByText('Attachment big.bin is larger than 10 MB.')).toBeVisible()
  await fileInput(page).setInputFiles(buffer('part1.bin', 8 * mb))
  await expect(page.getByText('part1.bin')).toBeVisible()
  await fileInput(page).setInputFiles(buffer('part2.bin', 8 * mb))
  await expect(page.getByText('Attachments must total 15 MB or less.')).toBeVisible()
  await expect(page.getByText('part2.bin')).toHaveCount(0)
  await fileInput(page).setInputFiles(buffer('notes.txt', 12))
  await expect(page.getByText('notes.txt')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Remove' })).toHaveCount(2)
  await page
    .locator('div')
    .filter({ hasText: /^notes\.txt1 KBRemove$/ })
    .getByRole('button', { name: 'Remove' })
    .click()
  await expect(page.getByText('notes.txt')).toHaveCount(0)
  await expect(page.getByText('part1.bin')).toBeVisible()
})

test('MTP-FLS-008: a valid flash is sent and opens its detail', async ({ page }) => {
  await fillFlash(page, 'Danone upgrade')
  await fileInput(page).setInputFiles(buffer('notes.txt', 12))
  await page
    .getByRole('textbox', { name: 'Related links' })
    .fill('https://a.example\n\nhttps://b.example')
  await page.getByRole('checkbox', { name: 'Also send by email' }).check()
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'Danone upgrade' })).toBeVisible()
  await expect(page.getByText('Type: Breaking News')).toBeVisible()
  await expect(page.getByText('Company: Danone')).toBeVisible()
  await expect(page.locator('strong', { hasText: 'Big news' })).toBeVisible()
  await expect(page.getByRole('link', { name: 'https://a.example' })).toBeVisible()
  await expect(page.getByRole('link', { name: 'https://b.example' })).toBeVisible()
  await expect(page.getByText('ATTACHMENT')).toBeVisible()
  await expect(page.getByText('notes.txt')).toBeVisible()
  await expect(page.getByText('Duplicate sent by email')).toBeVisible()
  await page.getByRole('link', { name: 'Back to flashes' }).click()
  await expect(bodyRows(page).first()).toContainText('Danone upgrade')
})

test('MTP-FLS-009: a server failure shows the alert and keeps every value', async ({ page }) => {
  await fillFlash(page, 'Mock server error')
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  await expect(
    page.getByText('Unable to create a flash right now. Please try again later.'),
  ).toBeVisible()
  await expect(page.getByRole('textbox', { name: 'Subject' })).toHaveValue('Mock server error')
  await expect(page.getByRole('textbox', { name: 'Company', exact: true })).toHaveValue('Danone')
  await expect(page.getByRole('combobox', { name: 'Type' })).toHaveText('Breaking News')
  await expect(page.getByRole('textbox', { name: 'Message' })).toHaveText('Big news')
  await expect(page.getByRole('button', { name: 'Danone' })).toBeVisible()
  await page.getByRole('link', { name: 'Flashes' }).click()
  await expect(bodyRows(page)).toHaveCount(5)
  await expect(bodyRows(page).first()).toContainText('LVMH Q3 revenue ahead of consensus')
})

test('MTP-GWC-002: the Recipients column counts companies and the detail names them', async ({
  page,
}) => {
  await page.goto('flashes')
  const lvmh = bodyRows(page).filter({ hasText: 'LVMH Q3 revenue ahead of consensus' })
  await expect(lvmh).toContainText('1 company')
  const preOpening = bodyRows(page).filter({ hasText: 'Pre-opening: European luxury sector' })
  await expect(preOpening).toContainText('2 companies')
  await preOpening.click()
  await expect(page.getByText('LVMH', { exact: true })).toBeVisible()
  await expect(page.getByText('Kering', { exact: true }).first()).toBeVisible()
})
