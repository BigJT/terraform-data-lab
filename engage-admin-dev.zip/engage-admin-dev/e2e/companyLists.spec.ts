import { expect, test } from '@playwright/test'

test('MTP-CTAB-001: lists show counts and buttons, expand to tickers, empty company', async ({
  page,
}) => {
  await page.goto('companies/c1')
  await page.getByRole('tab', { name: 'Lists' }).click()
  await expect(page.getByText('Luxury peers')).toBeVisible()
  await expect(page.getByText('3 items')).toBeVisible()
  await expect(page.getByText('European consumer')).toBeVisible()
  await expect(page.getByText('1 item', { exact: true })).toBeVisible()
  for (const name of ['Add an item', 'Rename', 'Delete']) {
    await expect(page.getByRole('button', { name })).toHaveCount(2)
  }
  await page.getByText('Luxury peers').click()
  for (const text of ['HRMS.PA', 'Hermes International', 'CDI.PA', 'Christian Dior', 'PRTP.PA']) {
    await expect(page.getByText(text, { exact: true })).toBeVisible()
  }
  await expect(page.getByText('Kering', { exact: true })).toBeVisible()
  await expect(page.getByRole('button', { name: 'Delete' })).toHaveCount(5)
  await page.goto('companies/c4/lists')
  await expect(page.getByText('No lists yet')).toBeVisible()
})

test('MTP-CTAB-002: create validates, checks RICs, rejects repeats and saves', async ({ page }) => {
  await page.goto('companies/c1/lists')
  await page.getByRole('button', { name: 'Create a list' }).click()
  const dialog = page.getByRole('dialog', { name: 'Create a list' })
  await dialog.getByRole('button', { name: 'Save' }).click()
  await expect(dialog.getByText('Required')).toBeVisible()
  await expect(dialog.getByText('Add at least one ticker')).toBeVisible()
  await dialog.getByLabel('Ticker').fill('ZZZZ.PA')
  await dialog.getByRole('button', { name: 'Add' }).click()
  await expect(dialog.getByText('This RIC code does not exist')).toBeVisible()
  await dialog.getByLabel('Title').fill('Watchlist')
  await dialog.getByLabel('Ticker').fill('AIR.PA')
  await dialog.getByRole('button', { name: 'Add' }).click()
  await expect(dialog.getByText('AIR.PA', { exact: true })).toBeVisible()
  await dialog.getByLabel('Ticker').fill('AIR.PA')
  await dialog.getByRole('button', { name: 'Add' }).click()
  await expect(dialog.getByText('This ticker is already in the list')).toBeVisible()
  await dialog.getByRole('button', { name: 'Save' }).click()
  await expect(dialog).toBeHidden()
  await expect(page.getByText('Watchlist')).toBeVisible()
  await expect(page.getByText('1 item', { exact: true })).toHaveCount(2)
})

test('MTP-CTAB-003: a duplicate name keeps the dialog open with the server message', async ({
  page,
}) => {
  await page.goto('companies/c1/lists')
  await page.getByRole('button', { name: 'Create a list' }).click()
  const dialog = page.getByRole('dialog', { name: 'Create a list' })
  await dialog.getByLabel('Title').fill('luxury PEERS')
  await dialog.getByLabel('Ticker').fill('AIR.PA')
  await dialog.getByRole('button', { name: 'Add' }).click()
  await expect(dialog.getByText('AIR.PA', { exact: true })).toBeVisible()
  await dialog.getByRole('button', { name: 'Save' }).click()
  await expect(
    dialog.getByText('A list with name [luxury PEERS] already exists for the emitter.'),
  ).toBeVisible()
  await dialog.getByRole('button', { name: 'Cancel' }).click()
  await expect(page.getByText('luxury PEERS', { exact: true })).toHaveCount(0)
})

test('MTP-CTAB-004: add an item and rename a list', async ({ page }) => {
  await page.goto('companies/c1/lists')
  await page.getByRole('button', { name: 'Add an item' }).nth(1).click()
  const add = page.getByRole('dialog', { name: 'Add an item' })
  await add.getByLabel('Ticker').fill('HRMS.PA')
  await add.getByRole('button', { name: 'Save' }).click()
  await expect(add).toBeHidden()
  await expect(page.getByText('2 items', { exact: true })).toBeVisible()
  await page.getByText('European consumer').click()
  await expect(page.getByText('HRMS.PA', { exact: true })).toBeVisible()
  await page.getByRole('button', { name: 'Rename' }).nth(1).click()
  const rename = page.getByRole('dialog', { name: 'Rename a list' })
  await rename.getByLabel('Title').fill('')
  await rename.getByRole('button', { name: 'Save' }).click()
  await expect(rename.getByText('Required')).toBeVisible()
  await rename.getByLabel('Title').fill('EU consumer')
  await rename.getByRole('button', { name: 'Save' }).click()
  await expect(rename).toBeHidden()
  await expect(page.getByText('EU consumer')).toBeVisible()
})

test('MTP-CTAB-005: delete a ticker and a list, with Cancel first', async ({ page }) => {
  await page.goto('companies/c1/lists')
  await page.getByText('Luxury peers').click()
  await page.getByRole('button', { name: 'Delete' }).nth(3).click()
  const item = page.getByRole('dialog', { name: 'Delete an item' })
  await expect(item.getByText('Are you sure you want to delete PRTP.PA?')).toBeVisible()
  await expect(item.getByText('This action cannot be undone')).toBeVisible()
  await item.getByRole('button', { name: 'Cancel' }).click()
  await expect(page.getByText('3 items')).toBeVisible()
  await page.getByRole('button', { name: 'Delete' }).nth(3).click()
  await item.getByRole('button', { name: 'Yes' }).click()
  await expect(item).toBeHidden()
  await expect(page.getByText('2 items')).toBeVisible()
  await page.getByRole('button', { name: 'Delete' }).first().click()
  const list = page.getByRole('dialog', { name: 'Delete a list' })
  await expect(list.getByText('Are you sure you want to delete Luxury peers?')).toBeVisible()
  await list.getByRole('button', { name: 'Yes' }).click()
  await expect(list).toBeHidden()
  await expect(page.getByText('Luxury peers')).toHaveCount(0)
})
