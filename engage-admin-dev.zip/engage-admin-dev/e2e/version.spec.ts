import { expect, test } from '@playwright/test'

const field = 'Enter the new version:'
const force = 'Force users to update the application'

test('MTP-VMON-001: Version shows the current version, the form, and the empty state', async ({
  page,
}) => {
  await page.goto('version')
  await expect(page.getByRole('heading', { level: 1, name: 'Version' })).toBeVisible()
  await expect(page.getByText('Current version')).toBeVisible()
  await expect(page.locator('strong')).toHaveText('3.4.0')
  await expect(page.getByLabel(field)).toBeVisible()
  await expect(page.getByLabel(force)).not.toBeChecked()
  await expect(page.getByRole('button', { name: 'Send' })).toBeVisible()
})

test('MTP-VMON-001: the empty state reads "No version published yet"', async ({ page }) => {
  // The mock worker hides requests from page.route, so answer 200 with a null version from the page's own fetch.
  await page.addInitScript(() => {
    const realFetch = window.fetch.bind(window)
    window.fetch = (input, init) => {
      const url = input instanceof Request ? input.url : String(input)
      const method = (
        init?.method ?? (input instanceof Request ? input.method : 'GET')
      ).toUpperCase()
      if (method === 'GET' && url.includes('/api-admin/app-version')) {
        return Promise.resolve(
          new Response(JSON.stringify({ version: null, forceUpdate: false }), {
            status: 200,
            headers: { 'Content-Type': 'application/json' },
          }),
        )
      }
      return realFetch(input, init)
    }
  })
  await page.goto('version')
  await expect(page.getByText('No version published yet')).toBeVisible()
})

test('MTP-VMON-002: a badly formed version shows the format error and sends nothing', async ({
  page,
}) => {
  let posts = 0
  await page.route('**/api-admin/app-version', (route) => {
    if (route.request().method() === 'POST') posts += 1
    return route.continue()
  })
  await page.goto('version')
  await expect(page.locator('strong')).toHaveText('3.4.0')
  for (const value of ['3.5', 'abc', '']) {
    await page.getByLabel(field).fill(value)
    await page.getByRole('button', { name: 'Send' }).click()
    await expect(page.getByText('Format should be like this X.X.X')).toBeVisible()
  }
  expect(posts).toBe(0)
  await expect(page.locator('strong')).toHaveText('3.4.0')
})

test('MTP-VMON-003: publishing toasts and updates; a duplicate shows the gateway message', async ({
  page,
}) => {
  await page.goto('version')
  await page.getByLabel(field).fill('3.5.0')
  await page.getByLabel(force).check()
  await page.getByRole('button', { name: 'Send' }).click()
  await expect(page.getByText('Version added successfully')).toBeVisible()
  await expect(page.locator('strong')).toHaveText('3.5.0')
  await expect(page.getByLabel(field)).toHaveValue('')
  await expect(page.getByLabel(force)).not.toBeChecked()
  await expect(page.getByText('Version added successfully')).toBeHidden({ timeout: 8000 })

  await page.getByLabel(field).fill('3.5.0')
  await page.getByRole('button', { name: 'Send' }).click()
  await expect(page.getByRole('alert')).toHaveText('A version 3.5.0 already exists.')
  await expect(page.locator('strong')).toHaveText('3.5.0')
})
