import { expect, test, type Page } from '@playwright/test'

function bodyRows(page: Page) {
  return page.getByRole('row').filter({ hasNot: page.getByRole('columnheader') })
}

test('MTP-BRN-001: the Broker notes list shows controls, legend, columns and five rows newest first', async ({
  page,
}) => {
  await page.goto('broker-notes')
  await expect(page.getByRole('heading', { name: 'Broker notes' })).toBeVisible()
  await expect(page.getByPlaceholder('Search broker notes')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Send a note' })).toBeVisible()
  for (const label of ['Recommendation change', 'Initiation', 'Sector']) {
    await expect(page.getByText(label, { exact: true }).first()).toBeVisible()
  }
  for (const name of [
    'Sent on',
    'Company',
    'Broker',
    'Type',
    'Target',
    'Recommendation',
    'Previous target',
    'Previous recommendation',
  ]) {
    await expect(page.getByRole('columnheader', { name, exact: true })).toBeVisible()
  }
  const rows = bodyRows(page)
  await expect(rows).toHaveCount(5)
  const names = ['LVMH', 'Diageo', 'Danone', 'Kering', 'Accor']
  for (const [index, name] of names.entries()) await expect(rows.nth(index)).toContainText(name)
  const lvmh = rows.first().getByRole('cell')
  await expect(lvmh.first()).toHaveText(/^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)
  await expect(lvmh.nth(3).getByLabel('Recommendation change')).toBeVisible()
  await expect(lvmh.nth(4)).toHaveText('720.00 €')
  await expect(lvmh.nth(6)).toHaveText('680.00 €')
  await expect(lvmh.nth(7)).toHaveText('NEUTRAL')
  const accor = rows.last().getByRole('cell')
  await expect(accor.nth(6)).toHaveText('')
  await expect(accor.nth(7)).toHaveText('')
  await expect(page.getByRole('button', { name: 'Delete' })).toHaveCount(5)
})

test('MTP-BRN-002: searching narrows the list and clearing restores it', async ({ page }) => {
  await page.goto('broker-notes')
  await expect(bodyRows(page)).toHaveCount(5)
  await page.getByPlaceholder('Search broker notes').fill('barclays')
  await expect(bodyRows(page)).toHaveCount(1)
  await expect(bodyRows(page).first()).toContainText('LVMH')
  await page.getByPlaceholder('Search broker notes').fill('zzz')
  await expect(page.getByText('No broker notes found.')).toBeVisible()
  await page.getByPlaceholder('Search broker notes').clear()
  await expect(bodyRows(page)).toHaveCount(5)
})

test('MTP-BRN-003: Cancel keeps the row and Yes deletes it', async ({ page }) => {
  await page.goto('broker-notes')
  const kering = bodyRows(page).filter({ hasText: 'Kering' })
  await kering.getByRole('button', { name: 'Delete' }).click()
  const dialog = page.getByRole('dialog', { name: 'Delete broker note' })
  await expect(dialog.getByText('Are you sure you want to delete?')).toBeVisible()
  await expect(dialog.getByText('This action cannot be undone')).toBeVisible()
  await dialog.getByRole('button', { name: 'Cancel' }).click()
  await expect(dialog).toBeHidden()
  await expect(bodyRows(page)).toHaveCount(5)
  await kering.getByRole('button', { name: 'Delete' }).click()
  await dialog.getByRole('button', { name: 'Yes' }).click()
  await expect(bodyRows(page)).toHaveCount(4)
  await expect(page.getByText('Kering')).toHaveCount(0)
})

test('MTP-BRN-004: empty Send shows the required errors; currency and company options are right', async ({
  page,
}) => {
  await page.goto('broker-notes')
  await page.getByRole('button', { name: 'Send a note' }).click()
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  for (const error of [
    'Please enter a company',
    'Please enter a broker',
    'Target is required',
    'Type is required',
  ]) {
    await expect(page.getByText(error)).toBeVisible()
  }
  await expect(page).toHaveURL(/\/broker-notes\/new$/)
  await page.getByRole('combobox', { name: 'Currency' }).click()
  await expect(page.getByRole('option')).toHaveText(['€', '$', '£', 'p', 'SFr'])
  await page.keyboard.press('Escape')
  await page.getByRole('combobox', { name: 'Company' }).click()
  await expect(page.getByRole('option')).toHaveCount(5)
  await expect(page.getByRole('option', { name: /Worldline/ })).toHaveCount(0)
})

test('MTP-BRN-005: the recommendation change switch shows and validates its fields', async ({
  page,
}) => {
  await page.goto('broker-notes/new')
  await page.getByRole('combobox', { name: 'Company' }).click()
  await page.getByRole('option', { name: 'Danone (DANO.PA)' }).click()
  await page.getByRole('combobox', { name: 'Broker' }).click()
  await page.getByRole('option', { name: 'Citi' }).click()
  await page.getByRole('textbox', { name: 'Target', exact: true }).fill('70.00')
  await page.getByRole('combobox', { name: 'Recommendation', exact: true }).click()
  await page.getByRole('option', { name: 'BUY' }).click()
  await page.getByRole('switch', { name: 'Recommendation change' }).click()
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  await expect(page.getByText('Target is required')).toBeVisible()
  await expect(page.getByText('Type is required')).toBeVisible()
  await page.getByRole('switch', { name: 'Recommendation change' }).click()
  await expect(page.getByRole('textbox', { name: 'Previous target' })).toHaveCount(0)
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  await expect(page).toHaveURL(/\/broker-notes$/)
})

test('MTP-BRN-006: Send creates the note and opens the list with it on top', async ({ page }) => {
  await page.goto('broker-notes/new')
  await page.getByRole('combobox', { name: 'Company' }).click()
  await page.getByRole('option', { name: 'Danone (DANO.PA)' }).click()
  await page.getByRole('combobox', { name: 'Broker' }).click()
  await page.getByRole('option', { name: 'Citi' }).click()
  await page.getByRole('textbox', { name: 'Target', exact: true }).fill('70.00')
  await page.getByRole('combobox', { name: 'Recommendation', exact: true }).click()
  await page.getByRole('option', { name: 'BUY' }).click()
  await page.getByRole('button', { name: 'Send', exact: true }).click()
  await expect(page).toHaveURL(/\/broker-notes$/)
  const first = bodyRows(page).first()
  await expect(first).toContainText('Danone')
  await expect(first).toContainText('Citi')
  await expect(first).toContainText('70.00 €')
  await expect(first).toContainText('BUY')
})

test('MTP-BRN-007: Send and continue resets the form, shows the snackbar and adds the note', async ({
  page,
}) => {
  await page.goto('broker-notes/new')
  await page.getByRole('combobox', { name: 'Company' }).click()
  await page.getByRole('option', { name: 'Kering (PRTP.PA)' }).click()
  await page.getByRole('combobox', { name: 'Broker' }).click()
  await page.getByRole('option', { name: 'Zacks' }).click()
  await page.getByRole('textbox', { name: 'Target', exact: true }).fill('300.00')
  await page.getByRole('combobox', { name: 'Recommendation', exact: true }).click()
  await page.getByRole('option', { name: 'SELL' }).click()
  await page.getByRole('checkbox', { name: 'Also send by email' }).check()
  await page.getByRole('button', { name: 'Send and continue' }).click()
  await expect(page.getByText('Broker note sent')).toBeVisible()
  await expect(page).toHaveURL(/\/broker-notes\/new$/)
  await expect(page.getByRole('textbox', { name: 'Target', exact: true })).toHaveValue('')
  await expect(page.getByRole('combobox', { name: 'Company' })).toHaveValue('')
  await expect(page.getByRole('checkbox', { name: 'Also send by email' })).not.toBeChecked()
  await expect(page.getByRole('combobox', { name: 'Currency' })).toHaveText('€')
  await page.getByRole('link', { name: 'Broker notes' }).click()
  await expect(bodyRows(page).first()).toContainText('Zacks')
})

const mb = 1024 * 1024
const fileInput = (page: Page) => page.getByLabel('Add an attachment input')
const buffer = (name: string, size: number) => ({
  name,
  mimeType: 'application/octet-stream',
  buffer: Buffer.alloc(size, 1),
})

test('MTP-BRN-008: attachment rules refuse bad files and list good ones', async ({ page }) => {
  await page.goto('broker-notes/new')
  await fileInput(page).setInputFiles(buffer('empty.txt', 0))
  await expect(page.getByText('Attachment empty.txt is empty.')).toBeVisible()
  await fileInput(page).setInputFiles(buffer('big.bin', 10 * mb + 1))
  await expect(page.getByText('Attachment big.bin is larger than 10 MB.')).toBeVisible()
  await fileInput(page).setInputFiles(buffer('part1.bin', 8 * mb))
  await expect(page.getByText('part1.bin')).toBeVisible()
  await fileInput(page).setInputFiles(buffer('part2.bin', 8 * mb))
  await expect(page.getByText('Attachments must total 15 MB or less.')).toBeVisible()
  await expect(page.getByText('part2.bin')).toHaveCount(0)
  await fileInput(page).setInputFiles(buffer('notes.txt', 1024))
  await expect(page.getByText('notes.txt')).toBeVisible()
  await expect(page.getByText('1 KB')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Remove' })).toHaveCount(2)
  await page
    .locator('div')
    .filter({ hasText: /^notes\.txt1 KBRemove$/ })
    .getByRole('button', { name: 'Remove' })
    .click()
  await expect(page.getByText('notes.txt')).toHaveCount(0)
  await expect(page.getByText('part1.bin')).toBeVisible()
})
