import { expect, test, type Page } from '@playwright/test'

const activeNames = ['Accor', 'Danone', 'Diageo', 'Kering', 'LVMH']

function bodyRows(page: import('@playwright/test').Page) {
  return page.getByRole('row').filter({ hasNot: page.getByRole('columnheader') })
}

test('MTP-ADMF-007: the Companies list shows the columns, controls and active rows only', async ({
  page,
}) => {
  await page.goto('companies')
  await expect(page.getByRole('columnheader')).toHaveText([
    'Company',
    'RIC',
    'Sector',
    'Users',
    'Status',
  ])
  await expect(page.getByPlaceholder('Search companies')).toBeVisible()
  await expect(page.getByRole('checkbox', { name: 'Show archived companies' })).not.toBeChecked()
  await expect(page.getByRole('button', { name: 'Add company' })).toBeVisible()
  await expect(bodyRows(page).locator('td:first-child')).toHaveText(activeNames)
  await expect(page.getByText('Worldline')).toHaveCount(0)
  await expect(bodyRows(page).first().locator('td').last()).toHaveText('Active')
})

test('MTP-ADMF-008: ticking Show archived companies reveals Worldline as Archived', async ({
  page,
}) => {
  await page.goto('companies')
  const box = page.getByRole('checkbox', { name: 'Show archived companies' })
  await box.check()
  const worldline = page.getByRole('row', { name: /Worldline/ })
  await expect(worldline).toContainText('Archived')
  await box.uncheck()
  await expect(page.getByText('Worldline')).toHaveCount(0)
})

test('MTP-ADMF-009: search narrows by name or RIC, case-insensitively, and clears', async ({
  page,
}) => {
  await page.goto('companies')
  const search = page.getByPlaceholder('Search companies')
  await search.fill('DAN')
  await expect(bodyRows(page).locator('td:first-child')).toHaveText(['Danone'])
  await search.fill('')
  await expect(bodyRows(page).locator('td:first-child')).toHaveText(activeNames)
  await search.fill('dge.l')
  await expect(bodyRows(page).locator('td:first-child')).toHaveText(['Diageo'])
})

test('MTP-ADMF-014: a company opens with five tabs, read-only Information and an Archive button', async ({
  page,
}) => {
  await page.goto('companies')
  await page.getByText('LVMH', { exact: true }).click()
  await expect(page).toHaveURL(/\/companies\/c1$/)
  await expect(page.getByRole('heading', { level: 1, name: 'LVMH' })).toBeVisible()
  await expect(page.getByRole('button', { name: 'Archive', exact: true })).toBeVisible()
  await expect(page.getByRole('tab')).toHaveText([
    'Information',
    'Lists',
    'Users',
    'Imports',
    'Factset',
  ])
  const value = (label: string) => page.locator(`dt:text-is("${label}") + dd`)
  await expect(value('RIC')).toHaveText('LVMH.PA')
  await expect(value('Language')).toHaveText('French')
  await expect(value('Market')).toHaveText('Euronext Paris')
  await expect(value('Sector')).toHaveText('Luxury')
  await expect(value('Sub-sector')).toHaveText('Fashion')
  await expect(page.getByText('INDICES')).toBeVisible()
  await expect(value('Index 1')).toHaveText('.FCHI CAC 40')
  await expect(value('Index 4')).toHaveText('None')
  await expect(page.getByRole('button', { name: 'Edit' })).toBeVisible()
  await page.goto('companies/c4')
  await expect(page.locator('dt:text-is("Sub-sector") + dd')).toHaveText('None')
  await expect(page.locator('dt:text-is("Index 2") + dd')).toHaveText('None')
})

test('MTP-ADMF-017: Factset opens its tab with the address bar following', async ({ page }) => {
  await page.goto('companies/c1')
  await page.getByRole('tab', { name: 'Factset' }).click()
  await expect(page).toHaveURL(/\/companies\/c1\/factset$/)
  await expect(page.getByText('FACTSET PEERS', { exact: true })).toBeVisible()
  await expect(page.getByText('Coming soon')).toHaveCount(0)
})

// A page reload resets the mock gateway, so reopen the tab in the app instead.
async function reopenFactset(page: Page) {
  await page.getByRole('tab', { name: 'Information' }).click()
  await page.getByRole('tab', { name: 'Factset' }).click()
}

test('MTP-GWA-002: Factset peers list, add, remove and save', async ({ page }) => {
  await page.goto('companies/c1/factset')
  await expect(page.getByRole('textbox', { name: 'Name' })).toHaveCount(2)
  await expect(page.getByRole('textbox', { name: 'Name' }).first()).toHaveValue(
    'Hermes International',
  )
  await expect(page.getByRole('textbox', { name: 'ID' }).nth(1)).toHaveValue('PRTP-FR')
  await page.getByRole('button', { name: 'Add a new Factset peer' }).click()
  const save = page.getByRole('button', { name: 'Save peers' })
  await expect(save).toBeDisabled()
  await page.getByRole('textbox', { name: 'Name' }).nth(2).fill('Richemont')
  await expect(save).toBeDisabled()
  await page.getByRole('textbox', { name: 'ID' }).nth(2).fill('CFR-CH')
  await save.click()
  await expect(page.getByText('Saved successfully')).toBeVisible()
  await page.getByRole('button', { name: 'Remove' }).first().click()
  await save.click()
  await reopenFactset(page)
  await expect(page.getByRole('textbox', { name: 'Name' })).toHaveCount(2)
  await expect(page.getByRole('textbox', { name: 'Name' }).first()).toHaveValue('Kering')
  await page.goto('companies/c2/factset')
  await expect(page.getByText('No Factset peers yet.')).toBeVisible()
})

test('MTP-GWA-003: Factset multiples search, tick and save', async ({ page }) => {
  await page.goto('companies/c1/factset')
  const box = (name: string) => page.getByRole('checkbox', { name })
  await expect(page.getByRole('checkbox')).toHaveCount(6)
  await expect(box('P/E')).toBeChecked()
  await expect(box('EV/EBITDA')).toBeChecked()
  await expect(box('EV/Sales')).not.toBeChecked()
  await page.getByPlaceholder('Search multiples').fill('ev')
  await page.getByRole('button', { name: 'Search' }).click()
  await expect(page.getByRole('checkbox')).toHaveCount(2)
  await box('EV/Sales').check()
  await page.getByPlaceholder('Search multiples').fill('')
  await page.getByRole('button', { name: 'Search' }).click()
  await page.getByRole('button', { name: 'Save', exact: true }).click()
  await expect(page.getByText('Saved successfully')).toBeVisible()
  await reopenFactset(page)
  await expect(box('P/E')).toBeChecked()
  await expect(box('EV/EBITDA')).toBeChecked()
  await expect(box('EV/Sales')).toBeChecked()
  await expect(box('P/B')).not.toBeChecked()
})

test('MTP-ADMF-015: Edit indices excludes chosen indices, Save updates the block, Cancel discards', async ({
  page,
}) => {
  await page.goto('companies/c1')
  const value = (label: string) => page.locator(`dt:text-is("${label}") + dd`)
  await page.getByRole('button', { name: 'Edit' }).click()
  const dialog = page.getByRole('dialog', { name: 'Edit indices' })
  await expect(dialog.getByRole('combobox')).toHaveCount(4)
  await dialog.getByRole('combobox', { name: 'Index 4' }).click()
  await expect(page.getByRole('option', { name: /^\.FCHI / })).toHaveCount(0)
  await expect(page.getByRole('option', { name: /^\.SXQP / })).toHaveCount(0)
  await page.keyboard.press('Escape')
  await dialog.getByRole('combobox', { name: 'Index 2' }).click()
  await page.getByRole('option', { name: /^\.SX3P / }).click()
  await dialog.getByRole('button', { name: 'Cancel' }).click()
  await expect(dialog).toBeHidden()
  await expect(value('Index 2')).toHaveText('.SXQP Stoxx Europe 600 Personal & Household Goods')
  await page.getByRole('button', { name: 'Edit' }).click()
  await dialog.getByRole('combobox', { name: 'Index 2' }).click()
  await page.getByRole('option', { name: /^\.SX3P / }).click()
  await dialog.getByRole('button', { name: 'Save' }).click()
  await expect(dialog).toBeHidden()
  await expect(value('Index 2')).toHaveText('.SX3P Stoxx Europe 600 Food & Beverage')
})

test('MTP-ADMF-016: Archive shows the banner, hides the company from the list, Unarchive reverses it', async ({
  page,
}) => {
  await page.goto('companies/c2')
  await page.getByRole('button', { name: 'Archive', exact: true }).click()
  await expect(page.getByText('This company is archived')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Unarchive' })).toBeVisible()
  await page.getByRole('link', { name: 'Companies' }).click()
  await expect(page.getByText('Danone', { exact: true })).toHaveCount(0)
  await page.getByLabel('Show archived companies').check()
  await expect(page.getByRole('row', { name: /Danone/ })).toContainText('Archived')
  await page.getByText('Danone', { exact: true }).click()
  await page.getByRole('button', { name: 'Unarchive' }).click()
  await expect(page.getByText('This company is archived')).toBeHidden()
  await expect(page.getByRole('button', { name: 'Archive', exact: true })).toBeVisible()
  await page.getByRole('link', { name: 'Companies' }).click()
  await expect(page.getByRole('row', { name: /Danone/ })).toContainText('Active')
})

test('MTP-ADMF-018: the Users tab shows the table, search and Add user', async ({ page }) => {
  await page.goto('companies/c1/users')
  await expect(page.getByRole('columnheader')).toHaveText([
    'Name',
    'Position',
    'Email',
    'Phone',
    'Terms accepted',
    '',
  ])
  await expect(page.getByRole('button', { name: 'Edit' })).toHaveCount(2)
  await expect(page.getByRole('button', { name: 'Delete' })).toHaveCount(2)
  await expect(page.getByRole('button', { name: 'Add user' })).toBeVisible()
  await expect(bodyRows(page).first()).toContainText('14/03/2025')
  await expect(bodyRows(page).last()).toContainText('No')
  await page.getByPlaceholder('Search users').fill('BERNARD')
  await expect(bodyRows(page)).toHaveCount(1)
  await expect(bodyRows(page)).toContainText('Julien Bernard')
  await page.getByPlaceholder('Search users').fill('claire.martin@')
  await expect(bodyRows(page)).toContainText('Claire Martin')
})

test('MTP-ADMF-019: the user form validates and offers both roles', async ({ page }) => {
  await page.goto('companies/c1/users')
  await page.getByRole('button', { name: 'Add user' }).click()
  const dialog = page.getByRole('dialog', { name: 'Add user' })
  await dialog.getByRole('button', { name: 'Save' }).click()
  for (const message of [
    'First name is required',
    'Last name is required',
    'Position is required',
    'Email is required',
    'Role is required',
  ]) {
    await expect(dialog.getByText(message)).toBeVisible()
  }
  await dialog.getByLabel('Email').fill('bob@x')
  await dialog.getByRole('button', { name: 'Save' }).click()
  await expect(dialog.getByText('Invalid email address')).toBeVisible()
  await dialog.getByRole('combobox', { name: 'Role' }).click()
  await expect(page.getByRole('option')).toHaveText(['Standard', 'Limited access'])
})

test('MTP-ADMF-020: a valid user is added at once; a duplicate email shows the server message', async ({
  page,
}) => {
  await page.goto('companies/c1/users')
  async function addUser(email: string) {
    await page.getByRole('button', { name: 'Add user' }).click()
    const dialog = page.getByRole('dialog', { name: 'Add user' })
    await dialog.getByLabel('First name').fill('Bob')
    await dialog.getByLabel('Last name').fill('Stone')
    await dialog.getByLabel('Position').fill('Analyst')
    await dialog.getByLabel('Email').fill(email)
    await dialog.getByRole('combobox', { name: 'Role' }).click()
    await page.getByRole('option', { name: 'Standard' }).click()
    await dialog.getByRole('button', { name: 'Save' }).click()
    return dialog
  }
  const first = await addUser('bob.stone@lvmh.example')
  await expect(first).toBeHidden()
  await expect(page.getByRole('row', { name: /Bob Stone/ })).toBeVisible()
  const second = await addUser('claire.martin@lvmh.example')
  await expect(second.getByText('Email claire.martin@lvmh.example is already used.')).toBeVisible()
  await second.getByRole('button', { name: 'Cancel' }).click()
  await expect(page.getByRole('row', { name: /Bob Stone/ })).toHaveCount(1)
  await expect(page.getByRole('row', { name: /Claire Martin/ })).toHaveCount(1)
})

test('MTP-ADMF-021: a user can be edited and deleted', async ({ page }) => {
  await page.goto('companies/c1/users')
  await page
    .getByRole('row', { name: /Julien Bernard/ })
    .getByRole('button', { name: 'Edit' })
    .click()
  const edit = page.getByRole('dialog', { name: 'Edit user' })
  await expect(edit.getByLabel('First name')).toHaveValue('Julien')
  await expect(edit.getByText('Last daily report read: N/A')).toBeVisible()
  await expect(edit.getByText('Last flash read: N/A')).toBeVisible()
  await edit.getByLabel('Position').fill('Senior Analyst')
  await edit.getByRole('button', { name: 'Save' }).click()
  await expect(edit).toBeHidden()
  await expect(page.getByRole('row', { name: /Julien Bernard/ })).toContainText('Senior Analyst')
  await page
    .getByRole('row', { name: /Claire Martin/ })
    .getByRole('button', { name: 'Delete' })
    .click()
  const remove = page.getByRole('dialog', { name: 'Delete user' })
  await expect(remove.getByText('Are you sure you want to delete Claire Martin?')).toBeVisible()
  await remove.getByRole('button', { name: 'No' }).click()
  await expect(page.getByRole('row', { name: /Claire Martin/ })).toHaveCount(1)
  await page
    .getByRole('row', { name: /Claire Martin/ })
    .getByRole('button', { name: 'Delete' })
    .click()
  await remove.getByRole('button', { name: 'Yes' }).click()
  await expect(remove).toBeHidden()
  await expect(page.getByRole('row', { name: /Claire Martin/ })).toHaveCount(0)
})

test.describe('Imports tab', () => {
  async function openImports(page: import('@playwright/test').Page) {
    await page.goto('companies/c1/imports')
    await page.getByRole('combobox', { name: 'Type' }).waitFor()
  }
  async function chooseType(page: import('@playwright/test').Page, label: string) {
    await page.getByRole('combobox', { name: 'Type' }).click()
    await page.getByRole('option', { name: label }).click()
  }
  async function chooseFile(page: import('@playwright/test').Page, name: string) {
    await page
      .getByTestId('import-file')
      .setInputFiles({ name, mimeType: 'application/vnd.ms-excel', buffer: Buffer.from('x') })
  }

  test('MTP-CTAB-006: types, gated button, success line, Factset unchanged', async ({ page }) => {
    await openImports(page)
    await page.getByRole('combobox', { name: 'Type' }).click()
    await expect(page.getByRole('option')).toHaveText([
      'Short BlackApp (file 10)',
      'Consensus',
      'Short Markit (file 9)',
      'Reco TP',
    ])
    await page.getByRole('option', { name: 'Consensus' }).click()
    const button = page.getByRole('button', { name: 'Import a file' })
    await expect(button).toBeDisabled()
    await chooseFile(page, 'consensus.xlsx')
    await expect(button).toBeEnabled()
    await button.click()
    await expect(page.getByText('20 of 20 rows imported')).toBeVisible()
    await page.getByRole('tab', { name: 'Factset' }).click()
    await expect(page.getByText('FACTSET PEERS', { exact: true })).toBeVisible()
  })

  test('MTP-CTAB-007: row errors', async ({ page }) => {
    await openImports(page)
    await chooseType(page, 'Short BlackApp (file 10)')
    await chooseFile(page, 'stock-errors.xlsx')
    await page.getByRole('button', { name: 'Import a file' }).click()
    await expect(page.getByText('148 of 150 rows imported')).toBeVisible()
    await expect(page.getByText('Rows with errors')).toBeVisible()
    await expect(page.getByText("Row 101: Field [Value] shouldn't be empty")).toBeVisible()
    await expect(
      page.getByText('Row 117: Value [LVMH.PA] was expected for field [RIC].'),
    ).toBeVisible()
  })

  test('MTP-CTAB-008: whole-file errors', async ({ page }) => {
    await openImports(page)
    await chooseType(page, 'Consensus')
    await chooseFile(page, 'invalid.xlsx')
    await page.getByRole('button', { name: 'Import a file' }).click()
    await expect(page.getByRole('alert').filter({ hasText: 'Invalid Excel file' })).toBeVisible()
    await chooseFile(page, 'no-brute.xlsx')
    await page.getByRole('button', { name: 'Import a file' }).click()
    await expect(
      page.getByRole('alert').filter({ hasText: 'Tab [Brute] not found in Excel file' }),
    ).toBeVisible()
    await expect(page.getByText(/rows imported/)).toHaveCount(0)
  })
})
