import { expect, test } from '@playwright/test'

const total = (label: string) => `xpath=//*[text()="${label}"]/following-sibling::*[1]`

test('MTP-VMON-004: the overview follows the period and Refresh keeps it', async ({ page }) => {
  await page.goto('monitoring')
  await expect(
    page.getByRole('heading', { level: 1, name: 'Disconnection monitoring' }),
  ).toBeVisible()
  await expect(page.getByRole('combobox', { name: 'Analysis period:' })).toHaveText('7 days')
  for (const name of ['Overview', 'Analysis', 'All disconnection logs']) {
    await expect(page.getByRole('heading', { name })).toBeVisible()
  }
  await expect(page.locator(total('Total disconnections'))).toHaveText('4')
  await expect(page.locator(total('Desktop app')).first()).toHaveText('2')
  await expect(page.locator(total('Mobile app')).first()).toHaveText('2')
  for (const [period, count] of [
    ['30 days', '15'],
    ['90 days', '45'],
  ] as const) {
    await page.getByRole('combobox', { name: 'Analysis period:' }).click()
    await page.getByRole('option', { name: period }).click()
    await expect(page.locator(total('Total disconnections'))).toHaveText(count)
  }
  await page.getByRole('button', { name: 'Refresh' }).click()
  await expect(page.locator(total('Total disconnections'))).toHaveText('45')
})

test('MTP-VMON-005: the breakdowns show labels, counts and percentages', async ({ page }) => {
  await page.goto('monitoring')
  const reasons = page.getByText('Breakdown by disconnection reason').locator('..')
  await expect(reasons.getByText('1 (25.0%)')).toHaveCount(4)
  for (const label of [
    'Session expired',
    'Authentication compromised',
    'Access revoked',
    'User account deleted',
  ]) {
    await expect(reasons.getByText(label)).toBeVisible()
  }
  const platforms = page.getByText('Breakdown by platform').locator('..')
  await expect(platforms.getByText('2 (50.0%)')).toHaveCount(2)
  await expect(platforms.getByText('Desktop app')).toBeVisible()
  await expect(platforms.getByText('Mobile app')).toBeVisible()
})

test('MTP-VMON-006: the log table, caption and paging', async ({ page }) => {
  await page.goto('monitoring')
  const headers = ['Date', 'User', 'Platform', 'Reason', 'IP address', 'Browser/System', 'Details']
  await expect(page.getByRole('columnheader')).toHaveText(headers)
  await expect(page.getByRole('row')).toHaveCount(21)
  await expect(page.getByRole('row').nth(1)).toContainText('Mock disconnection 1')
  await expect(page.getByText('45 logs in total • Page 1 of 3')).toBeVisible()
  await page.getByRole('button', { name: 'Go to page 3' }).click()
  await expect(page.getByText('45 logs in total • Page 3 of 3')).toBeVisible()
  await expect(page.getByRole('row')).toHaveCount(6)
})

test('MTP-VMON-007: filters apply, clear, and show the empty state', async ({ page }) => {
  await page.goto('monitoring')
  await expect(page.getByText('45 logs in total • Page 1 of 3')).toBeVisible()
  await page.getByRole('combobox', { name: 'Platform' }).click()
  await page.getByRole('option', { name: 'Mobile app' }).click()
  await page.getByRole('combobox', { name: 'Reason' }).click()
  await page.getByRole('option', { name: 'Access revoked' }).click()
  await page.getByRole('button', { name: 'Apply filters' }).click()
  await expect(page.getByText('2 logs in total • Page 1 of 1')).toBeVisible()
  await expect(page.getByRole('row')).toHaveCount(3)
  await page.getByRole('button', { name: 'Clear filters' }).click()
  await expect(page.getByText('45 logs in total • Page 1 of 3')).toBeVisible()
  await page.getByRole('textbox', { name: 'User email' }).fill('zzz')
  await page.getByRole('button', { name: 'Apply filters' }).click()
  await expect(page.getByText('No disconnection logs found.')).toBeVisible()
})

test('MTP-VMON-008: neither Version nor Monitoring shows Coming soon', async ({ page }) => {
  await page.goto('')
  for (const label of ['Version', 'Monitoring']) {
    await page.getByRole('navigation').getByRole('link', { name: label }).click()
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
    await expect(page.getByText('Coming soon')).toHaveCount(0)
  }
})
