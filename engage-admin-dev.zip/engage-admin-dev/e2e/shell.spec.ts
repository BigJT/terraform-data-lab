import { expect, test } from '@playwright/test'

const sidebar = ['Reports', 'Flashes', 'Broker notes', 'Companies', 'Version', 'Monitoring']

test('MTP-ADMF-003: mock mode opens the shell signed in as Local Admin with mock data', async ({
  page,
}) => {
  await page.goto('')
  await expect(page.getByText('Local Admin')).toBeVisible()
  await expect(page.getByRole('button', { name: /sign in/i })).toHaveCount(0)
  const mocksActive = await page.evaluate(async () => {
    const registration = await navigator.serviceWorker.ready
    return registration.active?.scriptURL.endsWith('/engage-admin/mockServiceWorker.js') ?? false
  })
  expect(mocksActive).toBe(true)
})

test('MTP-ADMF-004: the sidebar lists six entries, the name and Sign out, opening on Companies', async ({
  page,
}) => {
  await page.goto('')
  await expect(page).toHaveURL(/\/companies$/)
  await expect(page.getByRole('navigation').getByRole('link')).toHaveText(sidebar)
  await expect(page.getByText('Local Admin')).toBeVisible()
  await expect(page.getByRole('button', { name: 'Sign out' })).toBeVisible()
  await expect(page.getByRole('heading', { level: 1, name: 'Companies' })).toBeVisible()
})

test('MTP-ADMF-005: no sidebar entry shows Coming soon and the address bar follows', async ({
  page,
}) => {
  await page.goto('')
  const entries = [
    { label: 'Reports', path: '/reports' },
    { label: 'Flashes', path: '/flashes' },
    { label: 'Broker notes', path: '/broker-notes' },
    { label: 'Companies', path: '/companies' },
    { label: 'Version', path: '/version' },
    { label: 'Monitoring', path: '/monitoring' },
  ]
  for (const { label, path } of entries) {
    await page.getByRole('navigation').getByRole('link', { name: label }).click()
    await expect(page).toHaveURL(new RegExp(`${path}$`))
    await expect(page.getByText('Coming soon')).toHaveCount(0)
  }
})

test('MTP-ADMF-006: Sign out in mock mode reloads the shell as Local Admin', async ({ page }) => {
  await page.goto('reports')
  await page.evaluate(() => {
    ;(window as Window & { beforeSignOut?: boolean }).beforeSignOut = true
  })
  await page.getByRole('button', { name: 'Sign out' }).click()
  await expect(page).toHaveURL(/\/companies$/)
  await expect(page.getByText('Local Admin')).toBeVisible()
  const survived = await page.evaluate(
    () => (window as Window & { beforeSignOut?: boolean }).beforeSignOut ?? false,
  )
  expect(survived).toBe(false)
})
