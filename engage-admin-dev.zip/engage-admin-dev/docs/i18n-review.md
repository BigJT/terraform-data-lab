# French wording review

French wording for the CMS team to check; Source myCMS means taken from myCMS, new means our translation.

| Key | English | French | Source |
|---|---|---|---|
| shell.reports | Reports | Rapports | myCMS |
| shell.flashes | Flashes | Flashs | myCMS |
| shell.brokerNotes | Broker notes | N. de brokers | myCMS |
| shell.companies | Companies | Émetteurs | myCMS |
| shell.version | Version | Version | myCMS |
| shell.monitoring | Monitoring | Monitoring | myCMS |
| shell.language | Language | Langue | new |
| shell.signOut | Sign out | Se déconnecter | new |
| signIn.button | Sign in with Microsoft | Se connecter avec Microsoft | new |
| noAccess.message | You do not have access to Engage Admin. | Vous n'avez pas accès à Engage Admin. | new |
| mockSignIn.title | Stand-in Microsoft sign-in | Connexion Microsoft simulée | new |
| mockSignIn.intro | Pick an account. This page stands in for Microsoft until an Entra tenant is set up. | Choisissez un compte. Cette page remplace Microsoft en attendant la configuration d'un tenant Entra. | new |
| placeholder.comingSoon | Coming soon | Bientôt disponible | new |
| common.cancel | Cancel | Annuler | myCMS |
| common.save | Save | Enregistrer | myCMS |
| common.yes | Yes | Oui | myCMS |
| common.no | No | Non | myCMS |
| common.delete | Delete | Supprimer | myCMS |
| common.edit | Edit | Modifier | myCMS |
| common.add | Add | Ajouter | myCMS |
| common.back | Back | Précédent | myCMS |
| common.next | Next | Suivant | myCMS |
| common.none | None | Aucun | new |
| common.remove | Remove | Retirer | new |
| fields.ric | RIC | ID RIC | myCMS |
| fields.name | Name | Nom | myCMS |
| fields.language | Language | Langue | myCMS |
| fields.french | French | Français | myCMS |
| fields.english | English | Anglais | myCMS |
| fields.market | Market | Marché | myCMS |
| fields.sector | Sector | Secteur | myCMS |
| fields.subSector | Sub-sector | Sous-secteur | myCMS |
| fields.index | Index {{n}} | Indice {{n}} | myCMS |
| fields.user | User {{n}} | Utilisateur {{n}} | myCMS |
| fields.firstName | First name | Prénom | myCMS |
| fields.lastName | Last name | Nom | myCMS |
| fields.position | Position | Poste | myCMS |
| fields.email | Email | E-mail | myCMS |
| fields.phone | Phone | Téléphone | myCMS |
| fields.role | Role | Rôle | new |
| fields.title | Title | Titre | new |
| fields.ticker | Ticker | Ticker | new |
| validation.ricRequired | RIC is required | L'ID RIC est requis | new |
| validation.nameRequired | Name is required | Le nom est requis | new |
| validation.marketRequired | Market is required | Le marché est requis | new |
| validation.sectorRequired | Sector is required | Le secteur est requis | new |
| validation.firstNameRequired | First name is required | Le prénom est requis | new |
| validation.lastNameRequired | Last name is required | Le nom est requis | new |
| validation.positionRequired | Position is required | Le poste est requis | new |
| validation.roleRequired | Role is required | Le rôle est requis | new |
| validation.emailRequired | Email is required | L'email est requis | myCMS |
| validation.emailInvalid | Invalid email format | Format d'email invalide | myCMS |
| validation.emailInvalidAddress | Invalid email address | Adresse e-mail invalide | new |
| validation.unknownRic | This RIC code does not exist | Ce code RIC n'existe pas | myCMS |
| validation.required | Required | Requis | myCMS |
| companies.search | Search companies | Rechercher un émetteur | myCMS |
| companies.showArchived | Show archived companies | Afficher les émetteurs archivés | myCMS |
| companies.add | Add company | Ajouter un émetteur | myCMS |
| companies.company | Company | Valeurs | myCMS |
| companies.ric | RIC | Id ric | myCMS |
| companies.sector | Sector | Secteur | myCMS |
| companies.users | Users | Utilisateurs associés | myCMS |
| companies.status | Status | Statut | myCMS |
| companies.active | Active | Actif | myCMS |
| companies.archived | Archived | Archivé | myCMS |
| companies.empty | No companies found | Aucun émetteur trouvé | new |
| companies.loadFailed | Could not load companies | Impossible de charger les émetteurs | new |
| addCompany.stepInformation | 1. Information | 1. Informations | myCMS |
| addCompany.stepIndices | 2. Indices | 2. Indices | myCMS |
| addCompany.stepUsers | 3. Users | 3. Utilisateurs | myCMS |
| addCompany.addUser | Add user | Ajouter un utilisateur | new |
| addCompany.loadFailed | Could not load the reference data | Impossible de charger les données de référence | new |
| addCompany.ricCheckFailed | Could not check the RIC code | Impossible de vérifier le code RIC | new |
| addCompany.createFailed | Could not create the company | Impossible de créer l'émetteur | new |
| companyDetail.tabInformation | Information | Informations | myCMS |
| companyDetail.tabLists | Lists | Listes | myCMS |
| companyDetail.tabUsers | Users | Utilisateurs | myCMS |
| companyDetail.tabImports | Imports | Imports | myCMS |
| companyDetail.tabFactset | Factset | Factset | myCMS |
| companyDetail.archive | Archive | Archiver | myCMS |
| companyDetail.unarchive | Unarchive | Désarchiver | myCMS |
| companyDetail.archivedBanner | This company is archived | Attention ! Émetteur archivé | myCMS |
| companyDetail.createFailures | Some users could not be created: | Certains utilisateurs n'ont pas pu être créés : | new |
| companyDetail.notFound | Company not found | Émetteur introuvable | new |
| companyDetail.loadFailed | Could not load the company | Impossible de charger l'émetteur | new |
| companyDetail.updateFailed | Could not update the company | Impossible de mettre à jour l'émetteur | new |
| companyDetail.indices | INDICES | INDICES | myCMS |
| companyDetail.editIndices | Edit indices | Modifier les indices | myCMS |
| companyDetail.indicesLoadFailed | Could not load the indices | Impossible de charger les indices | new |
| companyDetail.indicesSaveFailed | Could not save the indices | Impossible d'enregistrer les indices | new |
| lists.itemCount_one | {{count}} item | {{count}} élément | myCMS |
| lists.itemCount_other | {{count}} items | {{count}} éléments | myCMS |
| lists.itemCount_many | {{count}} items | {{count}} éléments | myCMS |
| lists.create | Create a list | Créer une liste | myCMS |
| lists.addItemButton | Add an item | Ajouter un élément | new |
| lists.addItemTitle | Add an item | Ajout d'un élément | myCMS |
| lists.rename | Rename | Renommer | new |
| lists.renameTitle | Rename a list | Modifier une liste | myCMS |
| lists.deleteListTitle | Delete a list | Suppression d'une liste | new |
| lists.deleteItemTitle | Delete an item | Suppression d'un élément | myCMS |
| lists.empty | No lists yet | Aucune liste pour le moment | new |
| lists.peerPlaceholder | Search for a peer | rechercher un pair | myCMS |
| lists.tickerExists | This ticker is already in the list | Ce ticker est déjà dans la liste | new |
| lists.addAtLeastOne | Add at least one ticker | Ajoutez au moins un ticker | new |
| lists.confirmDelete | Are you sure you want to delete {{subject}}? | Êtes-vous sûr de vouloir supprimer {{subject}} ? | new |
| lists.irreversible | This action cannot be undone | Cette action est irréversible | new |
| lists.loadFailed | Could not load lists | Impossible de charger les listes | new |
| lists.tickerCheckFailed | Could not check the ticker | Impossible de vérifier le ticker | new |
| lists.createFailed | Could not create the list | Impossible de créer la liste | new |
| lists.addFailed | Could not add the item | Impossible d'ajouter l'élément | new |
| lists.renameFailed | Could not rename the list | Impossible de renommer la liste | new |
| lists.deleteFailed | Could not delete | Impossible de supprimer | new |
| users.search | Search users | Rechercher un utilisateur | new |
| users.add | Add user | Ajouter un utilisateur | new |
| users.editTitle | Edit user | Modifier l'utilisateur | new |
| users.deleteTitle | Delete user | Suppression utilisateur | myCMS |
| users.name | Name | Nom | myCMS |
| users.position | Position | Poste | myCMS |
| users.email | Email | Adresse e-mail | myCMS |
| users.phone | Phone | N° de téléphone | myCMS |
| users.terms | Terms accepted | CGU acceptées le | myCMS |
| users.termsNo | No | Non | myCMS |
| users.confirmDelete | Are you sure you want to delete {{name}}? | Êtes-vous sûr de vouloir supprimer {{name}} ? | new |
| users.lastDailyRead | Last daily report read: {{date}} | Date de dernière lecture de daily report : {{date}} | myCMS |
| users.lastFlashRead | Last flash read: {{date}} | Date de dernière lecture de flash : {{date}} | myCMS |
| users.notAvailable | N/A | N/A | myCMS |
| users.loadFailed | Could not load users | Impossible de charger les utilisateurs | new |
| users.deleteFailed | Could not delete the user | Impossible de supprimer l'utilisateur | new |
| users.saveFailed | Could not save the user | Impossible d'enregistrer l'utilisateur | new |
| users.roleStandard | Standard | Standard | new |
| users.roleLimited | Limited access | Accès limité | new |
| imports.type | Type | Type | new |
| imports.choose | Choose a type | Choisir un type | myCMS |
| imports.chooseFile | Choose a file | Choisir un fichier | new |
| imports.import | Import a file | Importer un fichier | myCMS |
| imports.summary | {{ok}} of {{total}} rows imported | {{ok}} lignes sur {{total}} importées | new |
| imports.errorsHeading | Rows with errors | Lignes en erreur | new |
| imports.row | Row {{row}}: {{message}} | Ligne {{row}} : {{message}} | new |
| imports.loadFailed | Could not load the import types | Impossible de charger les types d'import | new |
| imports.failed | The import failed | L'import a échoué | new |
| factset.peers | FACTSET PEERS | PAIRS FACTSET | new |
| factset.multiples | MULTIPLES | MULTIPLES | new |
| factset.noPeers | No Factset peers yet. | Aucun pair Factset pour le moment. | new |
| factset.id | ID | ID | new |
| factset.addPeer | Add a new Factset peer | Ajouter un nouveau pair Factset | myCMS |
| factset.savePeers | Save peers | Enregistrer les pairs | new |
| factset.searchMultiples | Search multiples | Rechercher un multiple | new |
| factset.search | Search | Rechercher | myCMS |
| factset.saved | Saved successfully | Enregistrement effectué avec succès | myCMS |
| factset.loadFailed | Could not load Factset | Impossible de charger Factset | new |
| factset.saveFailed | Could not save | Impossible d'enregistrer | new |
| reports.title | Reports | Rapports | new |
| reports.tabCompanies | Companies | Valeurs | myCMS |
| reports.tabMarkets | Markets | Marchés | myCMS |
| reports.today | Today ({{date}}) | Aujourd'hui ({{date}}) | myCMS |
| reports.date | Date | Date | new |
| reports.search | Search reports | Rechercher un rapport | myCMS |
| reports.columnCompanies | Companies ({{n}}) | Valeurs ({{n}}) | myCMS |
| reports.columnLanguage | Language ({{n}}) | Langue ({{n}}) | myCMS |
| reports.columnLastModified | Last modified | Dernière modification | myCMS |
| reports.columnValidation | Validation | Validation | myCMS |
| reports.columnStatus | Status | Statut | myCMS |
| reports.validationTodo | ... | ... | myCMS |
| reports.validationDoing | To validate | À valider | myCMS |
| reports.validationDone | Validated | Validé | myCMS |
| reports.toSend | To send | À envoyer | myCMS |
| reports.sentAtMark | ✓ Sent at {{time}} | ✓ Envoyé à {{time}} | myCMS |
| reports.sentMark | ✓ Sent | ✓ Envoyé | new |
| reports.empty | No reports found. | Aucun rapport trouvé. | new |
| reports.listLoadFailed | Could not load reports | Impossible de charger les rapports | new |
| reports.languageFr | French | Français | new |
| reports.languageEn | English | Anglais | new |
| reports.writeReport | Write a report | Rédiger un rapport | myCMS |
| reports.writeMarketReport | Write a market report | Rédiger un rapport de marché | myCMS |
| reports.back | Back to reports | Retour aux rapports | new |
| reports.notFound | Report not found | Rapport introuvable | new |
| reports.loadFailed | Could not load the report | Impossible de charger le rapport | new |
| reports.sentAt | Sent at {{time}} | Envoyé à {{time}} | myCMS |
| reports.sent | Sent | Envoyé | new |
| reports.headingCompany | COMPANY | VALEUR | myCMS |
| reports.headingSector | SECTOR | SECTEUR | myCMS |
| reports.headingMarket | MARKET | MARCHÉ | myCMS |
| reports.headingShortPositions | SHORT POSITIONS | POSITIONS COURTES | myCMS |
| reports.view | View | Consulter | myCMS |
| reports.noMarketReport | No market report yet. | Pas encore de rapport de marché. | new |
| reports.companyDetails | Company details | Détails de la valeur | new |
| reports.detailName | Name | Nom | new |
| reports.detailRic | RIC | RIC | new |
| reports.detailMarket | Market | Marché | new |
| reports.detailSector | Sector | Secteur | new |
| reports.detailLanguage | Language | Langue | new |
| reports.placeholder | Enter your analysis here | Renseignez votre analyse ici | myCMS |
| reports.marketReportLabel | Market report | Rapport de marché | new |
| reports.noChart | No chart. | Aucun graphique. | new |
| reports.chartFile | Chart file | Fichier du graphique | new |
| reports.addChart | Add chart | Ajouter un graphique | new |
| reports.replaceChart | Replace | Remplacer | new |
| reports.chartType | Choose a PNG or JPEG image. | Choisissez une image PNG ou JPEG. | new |
| reports.chartSaveFailed | The chart could not be saved | Impossible d'enregistrer le graphique | new |
| reports.chartRemoveFailed | The chart could not be removed | Impossible de supprimer le graphique | new |
| reports.statistics | ECONOMIC STATISTICS | STATISTIQUES ÉCONOMIQUES | new |
| reports.statisticsFailed | The statistics could not be loaded. | Impossible de charger les statistiques. | new |
| reports.statisticsEmpty | No statistics for this day. | Aucune statistique pour ce jour. | new |
| reports.statZone | Zone | Zone | new |
| reports.statCountry | Country | Pays | new |
| reports.statIndicator | Indicator | Indicateur | new |
| reports.statPeriod | Period | Période | new |
| reports.statActual | Actual | Réel | new |
| reports.statExpected | Expected | Attendu | new |
| reports.statPrevious | Previous | Précédent | new |
| reports.statReleased | Released | Publié | new |
| reports.lastSaved | Last saved {{relative}} | Dernière sauvegarde {{relative}} | myCMS |
| reports.relativeJustNow | just now | à l'instant | new |
| reports.relativeMinutes_one | 1 minute ago | il y a 1 minute | new |
| reports.relativeMinutes_other | {{count}} minutes ago | il y a {{count}} minutes | new |
| reports.relativeAt | at {{time}} | à {{time}} | new |
| reports.requestValidation | Request validation | Demander la validation | myCMS |
| reports.validateContent | Validate content | Valider le contenu | myCMS |
| reports.contentValidated | Content validated | Contenu validé | myCMS |
| reports.validateWriting | Validate writing | Valider la rédaction | myCMS |
| reports.writingValidated | Writing validated | Rédaction validée | myCMS |
| reports.send | Send | Envoyer | myCMS |
| reports.save | Save | Sauvegarde | myCMS |
| reports.edit | Edit | Modifier | myCMS |
| reports.actionFailed | The action failed | L'action a échoué | new |
| reports.sendFailed | The report could not be sent | Impossible d'envoyer le rapport | new |
| reports.saveFailed | The report could not be saved | Impossible de sauvegarder le rapport | new |
| reports.autoSaveFailed | The report could not be saved. Your changes are kept on this page. | Impossible de sauvegarder le rapport. Vos modifications sont conservées sur cette page. | new |
| reports.lockFailed | This report could not be opened for editing. Try again later. | Impossible d'ouvrir ce rapport en modification. Merci de réessayer ultérieurement. | new |
| reports.sendTitle | Send the report | Envoyer le rapport | myCMS |
| reports.saveTitle | Save the report | Sauvegarder le rapport | new |
| reports.notValidated | The report content and writing have not been validated. | Le contenu et la rédaction du rapport n'ont pas été validés. | myCMS |
| reports.confirmSend | Are you sure you want to send the report to {{company}}? | Êtes-vous certain de vouloir envoyer le rapport à {{company}} ? | myCMS |
| reports.confirmSave | Are you sure you want to save the changes to the report for {{company}}? | Êtes-vous certain de vouloir sauvegarder les modifications du rapport de {{company}} ? | new |
| reports.confirmSendMarket | Are you sure you want to send the {{language}} market report? | Êtes-vous certain de vouloir envoyer le rapport de marché ({{language}}) ? | new |
| reports.confirmSaveMarket | Are you sure you want to save the changes to the {{language}} market report? | Êtes-vous certain de vouloir sauvegarder les modifications du rapport de marché ({{language}}) ? | new |
| reports.lockTitle | CONTENT BEING WRITTEN | CONTENU EN COURS DE RÉDACTION | myCMS |
| reports.lockedBy | The report is being written by {{name}} | Le rapport est en cours de rédaction par {{name}} | myCMS |
| reports.lockQuestion | Do you want to unlock access to this report? | Désirez-vous déverrouiller l'accès à ce rapport ? | myCMS |
| editor.bold | Bold | Gras | new |
| editor.italic | Italic | Italique | new |
| editor.heading2 | Heading 2 | Titre 2 | new |
| editor.heading3 | Heading 3 | Titre 3 | new |
| editor.underline | Underline | Souligné | new |
| editor.bulletList | Bullet list | Liste à puces | new |
| editor.numberedList | Numbered list | Liste numérotée | new |
| editor.link | Link | Lien | new |
| editor.insertTable | Insert table | Insérer un tableau | new |
| editor.image | Image | Image | new |
| editor.pastePlain | Paste as plain text | Coller en texte brut | new |
| editor.url | URL | URL | new |
| editor.apply | Apply | Appliquer | new |
| flashes.search | Search flashes | Rechercher un flash | myCMS |
| flashes.send | Send a flash | Envoyer un flash | myCMS |
| flashes.columns.sent | Sent | Date d'envoi | myCMS |
| flashes.columns.recipients | Recipients | Destinataire(s) | myCMS |
| flashes.columns.company | Company | Valeur | myCMS |
| flashes.columns.title | Title | Titre | myCMS |
| flashes.columns.type | Type | Type | myCMS |
| flashes.recipientCount_one | {{count}} company | {{count}} émetteur | new |
| flashes.recipientCount_other | {{count}} companies | {{count}} émetteurs | new |
| flashes.empty | No flashes found. | Aucun flash trouvé. | new |
| flashes.loadFailed | Could not load flashes | Impossible de charger les flashs | new |
| flashes.notFound | Flash not found | Flash introuvable | new |
| flashes.loadOneFailed | Could not load the flash | Impossible de charger le flash | new |
| flashes.deleteFailed | Could not delete the flash | Impossible de supprimer le flash | new |
| flashes.back | Back to flashes | Retour aux flashs | new |
| flashes.sentOn | Sent {{date}} | Envoyé le {{date}} | new |
| flashes.recipientsHeading | RECIPIENTS | DESTINATAIRE(S) | myCMS |
| flashes.contentHeading | CONTENT | CONTENU | myCMS |
| flashes.type | Type: {{type}} | Type : {{type}} | new |
| flashes.company | Company: {{company}} | Valeur : {{company}} | new |
| flashes.linksHeading | RELATED LINKS: | LIENS ASSOCIÉS : | myCMS |
| flashes.attachmentHeading | ATTACHMENT | PIÈCE-JOINTE | myCMS |
| flashes.downloadFailed | The attachment could not be downloaded. Try again later. | Impossible de télécharger la pièce jointe. Merci de réessayer ultérieurement. | new |
| flashes.emailCopy | Duplicate sent by email | Duplicata envoyé par email | myCMS |
| flashes.deleteTitle | Delete flash | Suppression d'un flash | myCMS |
| flashes.deleteQuestion | Are you sure you want to delete? | Êtes-vous sûr de vouloir supprimer ? | myCMS |
| flashes.deleteWarning | This action cannot be undone | Cette action est irréversible | myCMS |
| flashes.compose.sendFailed | Unable to create a flash right now. Please try again later. | Impossible de créer un flash pour le moment. Merci de réessayer ultérieurement. | myCMS |
| flashes.compose.recipients | Recipients | Destinataires | new |
| flashes.compose.sendToAll | Send to all companies | Envoyer à tous les émetteurs | myCMS |
| flashes.compose.companies | Companies | Émetteurs | new |
| flashes.compose.searchCompanies | Search companies | Rechercher un émetteur | myCMS |
| flashes.compose.recipientRequired | Please choose a recipient | Merci de saisir un destinataire | myCMS |
| flashes.compose.content | Content | Contenu | new |
| flashes.compose.subject | Subject | Objet | myCMS |
| flashes.compose.subjectRequired | Subject is required | L'objet est requis | myCMS |
| flashes.compose.company | Company | Valeur | myCMS |
| flashes.compose.companyRequired | Company is required | La valeur est requise | myCMS |
| flashes.compose.type | Type | Type | myCMS |
| flashes.compose.typeRequired | Type is required | Le type est requis | myCMS |
| flashes.compose.message | Message | Message | myCMS |
| flashes.compose.messageRequired | Message is required | Le message est requis | myCMS |
| flashes.compose.links | Related links | Liens associés | myCMS |
| flashes.compose.linksHint | One link per line | Merci de mettre un lien par ligne | myCMS |
| flashes.compose.attachment | Attachment | Pièce jointe | new |
| flashes.compose.alsoEmail | Also send by email | Envoyer aussi par email | myCMS |
| flashes.compose.submit | Send | Envoyer | myCMS |
| brokerNotes.search | Search broker notes | Rechercher une note de broker | myCMS |
| brokerNotes.send | Send a note | Envoyer une note | myCMS |
| brokerNotes.types.recoChange | Recommendation change | Changement de recommandation | myCMS |
| brokerNotes.types.initiation | Initiation | Initiation | myCMS |
| brokerNotes.types.sector | Sector | Secteur | myCMS |
| brokerNotes.columns.sentOn | Sent on | Date d'envoi | myCMS |
| brokerNotes.columns.company | Company | Valeur | myCMS |
| brokerNotes.columns.broker | Broker | Broker | myCMS |
| brokerNotes.columns.type | Type | Type | myCMS |
| brokerNotes.columns.target | Target | Objectif | myCMS |
| brokerNotes.columns.recommendation | Recommendation | Recommandation | myCMS |
| brokerNotes.columns.previousTarget | Previous target | Ancien Objectif | myCMS |
| brokerNotes.columns.previousRecommendation | Previous recommendation | Ancienne Recommandation | myCMS |
| brokerNotes.empty | No broker notes found. | Aucune note de broker trouvée. | new |
| brokerNotes.loadFailed | Could not load broker notes | Impossible de charger les notes de broker | new |
| brokerNotes.deleteFailed | Could not delete the note | Impossible de supprimer la note | new |
| brokerNotes.deleteTitle | Delete broker note | Suppression d'une note de broker | new |
| brokerNotes.deleteQuestion | Are you sure you want to delete? | Êtes-vous sûr de vouloir supprimer ? | myCMS |
| brokerNotes.deleteWarning | This action cannot be undone | Cette action est irréversible | myCMS |
| brokerNotes.compose.title | Send a broker note | Envoyer une note de broker | new |
| brokerNotes.compose.sendFailed | Unable to create a note right now. Please try again later. | Impossible de créer une note pour le moment. Merci de réessayer ultérieurement. | myCMS |
| brokerNotes.compose.company | Company | Émetteur | myCMS |
| brokerNotes.compose.searchCompanies | Search companies | Rechercher un émetteur | myCMS |
| brokerNotes.compose.companyRequired | Please enter a company | Merci de saisir un émetteur | myCMS |
| brokerNotes.compose.noteTitle | Note title | Titre de la note | myCMS |
| brokerNotes.compose.broker | Broker | Broker | myCMS |
| brokerNotes.compose.searchBrokers | Search brokers | Rechercher un broker | myCMS |
| brokerNotes.compose.brokerRequired | Please enter a broker | Merci de saisir un broker | myCMS |
| brokerNotes.compose.details | Note details | Informations de la note | myCMS |
| brokerNotes.compose.target | Target | Objectif | myCMS |
| brokerNotes.compose.targetRequired | Target is required | L'objectif est requis | myCMS |
| brokerNotes.compose.currency | Currency | Devise | new |
| brokerNotes.compose.recommendation | Recommendation | Recommandation | myCMS |
| brokerNotes.compose.typeRequired | Type is required | Le type est requis | myCMS |
| brokerNotes.compose.sector | Sector | Secteur | myCMS |
| brokerNotes.compose.initiation | Initiation | Initiation | myCMS |
| brokerNotes.compose.recoChange | Recommendation change | Changement de recommandation | myCMS |
| brokerNotes.compose.previousTarget | Previous target | Ancien objectif | myCMS |
| brokerNotes.compose.previousRecommendation | Previous recommendation | Ancienne recommandation | myCMS |
| brokerNotes.compose.attachments | Attachments | Pièces jointes | new |
| brokerNotes.compose.alsoEmail | Also send by email | Envoyer aussi par email | myCMS |
| brokerNotes.compose.submit | Send | Envoyer | myCMS |
| brokerNotes.compose.submitContinue | Send and continue | Envoyer et continuer | myCMS |
| brokerNotes.compose.sent | Broker note sent | Note de broker envoyée | new |
| attachments.inputLabel | Add an attachment input | Champ de pièce jointe | new |
| attachments.add | Add an attachment | Ajouter une pièce jointe | myCMS |
| attachments.empty | Attachment {{name}} is empty. | La pièce jointe {{name}} est vide. | new |
| attachments.tooLarge | Attachment {{name}} is larger than 10 MB. | La pièce jointe {{name}} dépasse 10 Mo. | new |
| attachments.totalTooLarge | Attachments must total 15 MB or less. | Les pièces jointes ne doivent pas dépasser 15 Mo au total. | new |
| attachments.size | {{kb}} KB | {{kb}} Ko | new |
| version.loadFailed | Could not load the version | Impossible de charger la version | new |
| version.publishFailed | The version could not be published | La version n'a pas pu être publiée | new |
| version.none | No version published yet | Aucune version publiée pour le moment | new |
| version.current | Current version | Version actuelle | myCMS |
| version.enter | Enter the new version: | Saisissez la nouvelle version : | myCMS |
| version.formatError | Format should be like this X.X.X | Le format doit être X.X.X | myCMS |
| version.force | Force users to update the application | Forcer l'utilisateur à mettre à jour l'application | myCMS |
| version.send | Send | Envoyer | new |
| version.added | Version added successfully | Version ajoutée avec succès | myCMS |
| monitoring.title | Disconnection monitoring | Monitoring des déconnexions | myCMS |
| monitoring.statsFailed | Could not load statistics | Impossible de charger les statistiques | new |
| monitoring.logsFailed | Could not load logs | Impossible de charger les logs | new |
| monitoring.period | Analysis period: | Période d'analyse : | myCMS |
| monitoring.days | {{n}} days | {{n}} jours | myCMS |
| monitoring.refresh | Refresh | Actualiser | myCMS |
| monitoring.overview | Overview | Vue d'ensemble | myCMS |
| monitoring.total | Total disconnections | Total des déconnexions | new |
| monitoring.analysis | Analysis | Analyses | myCMS |
| monitoring.byReason | Breakdown by disconnection reason | Répartition par cause de déconnexion | myCMS |
| monitoring.byPlatform | Breakdown by platform | Répartition par plateforme | myCMS |
| monitoring.allLogs | All disconnection logs | Tous les logs de déconnexion | myCMS |
| monitoring.filters.userEmail | User email | E-mail de l'utilisateur | new |
| monitoring.filters.from | From | Du | new |
| monitoring.filters.to | To | Au | new |
| monitoring.filters.platform | Platform | Plateforme | myCMS |
| monitoring.filters.reason | Reason | Raison | myCMS |
| monitoring.filters.allPlatforms | All platforms | Toutes les plateformes | new |
| monitoring.filters.allReasons | All reasons | Toutes les raisons | new |
| monitoring.filters.apply | Apply filters | Appliquer les filtres | new |
| monitoring.filters.clear | Clear filters | Effacer les filtres | new |
| monitoring.columns.date | Date | Date | myCMS |
| monitoring.columns.user | User | Utilisateur | myCMS |
| monitoring.columns.platform | Platform | Plateforme | myCMS |
| monitoring.columns.reason | Reason | Raison | myCMS |
| monitoring.columns.ip | IP address | Adresse IP | myCMS |
| monitoring.columns.agent | Browser/System | Navigateur/Système | myCMS |
| monitoring.columns.details | Details | Détails | myCMS |
| monitoring.empty | No disconnection logs found. | Aucun log de déconnexion trouvé. | myCMS |
| monitoring.loading | Loading logs... | Chargement des logs... | myCMS |
| monitoring.summary | {{total}} logs in total • Page {{page}} of {{pages}} | {{total}} logs au total • Page {{page}} sur {{pages}} | myCMS |
| monitoring.reasons.TOKEN_EXPIRED | Session expired | Session expirée | myCMS |
| monitoring.reasons.TOKEN_INVALID_SIGNATURE | Authentication compromised | Authentification compromise | myCMS |
| monitoring.reasons.TOKEN_REVOKED | Access revoked | Accès révoqué | myCMS |
| monitoring.reasons.USER_NOT_FOUND | User account deleted | Compte utilisateur supprimé | myCMS |
| monitoring.reasons.SESSION_CORRUPTED | Session corrupted | Session corrompue | myCMS |
| monitoring.reasons.TOKEN_REPLACED_BY_NEW_LOGIN | New login detected | Nouvelle connexion détectée | myCMS |
| monitoring.reasons.TOKEN_MALFORMED | Malformed token | Jeton malformé | new |
| monitoring.reasons.TOKEN_INVALID | Invalid token | Jeton invalide | new |
| monitoring.reasons.USER_DEACTIVATED | User account deactivated | Compte utilisateur désactivé | new |
| monitoring.reasons.INSUFFICIENT_ROLES | Insufficient roles | Rôles insuffisants | new |
| monitoring.reasons.MANUAL_LOGOUT | Manual sign-out | Déconnexion manuelle | new |
| monitoring.platforms.DESKTOP | Desktop app | Application bureau | myCMS |
| monitoring.platforms.MOBILE | Mobile app | Application mobile | myCMS |
