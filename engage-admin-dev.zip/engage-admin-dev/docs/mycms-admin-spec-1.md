# myCMS Admin (Back-Office) — Behavioural Build Specification

This document is a build specification for a team rebuilding the **admin / back-office system** of myCMS (internally called "Rothschild Martin Maurel CMS", or "Panoptes") on a new stack, with **no access to the source repository**. Every section says what the replacement must do, not how the current system is coded. No source code, class names or file paths are reproduced; user-facing text, field names, enum values, config keys and limits are quoted verbatim in quotes.

The repository analysed is `MyCMS-Plateform-AzureIaC`.

---

## 0. Context

**What this repo is.** A single monorepo containing, as Maven modules, a Java 17 / Spring Boot 3.5 REST API (the module that serves both the admin back office and a separate client-facing mobile/desktop app), a shared data/market-data library module, a notifications library module (email + push), and a Vite/TypeScript/React single-page application that **is** the admin back-office front end. The admin front end is **in this repo** (not a separate repository) and is served as static assets by the same Spring Boot application, behind the same web server, but reached through a different authentication mechanism than the API that the client mobile/desktop app uses (see below). A relational database (Microsoft SQL Server) holds all data, with schema managed by Liquibase migrations. Infrastructure (Azure App Services, SQL Database, Storage, Functions, Application Insights) is defined in Terraform for at least three Azure environments.

There is a second, **separate client-facing application** (a mobile/desktop "emitter" app used by the end client firm's own staff to read reports, flashes and broker notes) that consumes the same backend through a different, token-based API. That client app is explicitly **out of scope** per the brief and is only described here where it is necessary to explain admin behaviour (e.g. who receives a push, what an upload is for).

A set of small Azure Functions (written in TypeScript/Node.js) exists in the same repo, used to proxy and fetch market data (Factset formulas/time series, Refinitiv tokens and time series, VisibleAlpha consensus data). These are **data-ingestion / market-data proxies, not admin screens**, and are out of scope except where they feed data the admin screens display.

**Other repositories the rebuilding team must ask about.** This repo does not contain:
- Whatever produces the CMS team's "Fichier CMS" recommendation/target-price spreadsheet, or any tool that converts that spreadsheet into the JSON shape the backend accepts (see section 3). That transformation step is not present anywhere in this repository.
- "OWS", the system named in the spreadsheet title. The string "OWS" does not appear anywhere in this codebase (code, config, docs, infrastructure). Its relationship to myCMS cannot be determined from this repo.
- Any billing/invoicing system. No billing, invoice or export-for-billing code, table or screen exists in this repo.
- Any valuation-import endpoint. There is no endpoint at any path resembling `/api/import/valuation`, no "Valuation" entity, and no valuation-specific screen anywhere in this repo.
- A "Super Admin" user/role management system (a "Super Admin" concept is referenced only in two unused error-message strings – see section 13).

**Who uses the admin system, and how they sign in.** Two separate populations, with two separate authentication mechanisms, exist:

1. **The CMS team / internal back-office operators.** They use the React back-office front end (and, indirectly, the paths prefixed `/api-admin/...`). They sign in with **corporate single sign-on**: the back office is wired to Azure Active Directory via OpenID Connect/OAuth2 ("login with Microsoft"), not a username/password form owned by this application. After Azure AD authentication, the application reads the signed-in user's **Azure AD group memberships** from the token, keeps only the groups that appear in an allow-list (configured per environment; in development the allow-list is the literal values `Panoptes_MONITORING_OFFICER`, `Panoptes_MONITORING_OFFICER_ADMIN`, and two bare Azure AD group GUIDs, `cb656e47-1334-47bb-81fc-ff5ddd90714d` and `586d6d6d-7fa3-492e-9947-db2344dee8f0`), and turns each surviving group name into a Spring Security role by stripping an `APPROLE_` prefix if present and otherwise prepending `ROLE_`. If, after this filtering, the signed-in user has **no** matching role, authentication is rejected outright with an OAuth2 "access_denied" error (message: `"User does not have the required group membership."` or a very similar variant depending on which code path triggered it) — the user never reaches the application. **In short: "being an admin" means belonging to the right Azure AD security group** (named/approximately named `Panoptes_MONITORING_OFFICER` and/or `Panoptes_MONITORING_OFFICER_ADMIN`); there is no in-application admin-user table, no admin password, and no admin self-registration. The front end itself references a role literal `'ROLE_MONITORING_OFFICER'` in its type definitions, confirming this is the role the back office expects its signed-in operator to hold. The back-office session is a conventional server-side session (session cookie, 12-hour idle timeout configured at the web container level) plus a CSRF cookie (`XSRF-TOKEN`) that must be echoed on state-changing requests — except that **requests to `/api-admin/**` are explicitly exempted from CSRF checking**, i.e. the admin API itself does not require the CSRF token even though the session mechanism issues one.
2. **The end client firm's own staff ("collaborators")** use the separate client mobile/desktop app, authenticating with an email/password pair issued to them **by the CMS team** (see section 2) and a JWT bearer token. This is not the admin system, but admin screens create, edit and delete these accounts.

**Staging or dry-run mode.** No admin action in this codebase supports a preview/dry-run/simulate mode. Every create, update, delete, archive, send and import endpoint commits immediately; there is no two-phase "validate then confirm" step anywhere in the admin API.

---

## 1. Feature inventory

| # | Feature (as the admin sees it) | What it does | Status | Section |
|---|---|---|---|---|
| 1 | Reports (Valeurs / Marchés) | Write and send the daily "value" (per-company) and "market" end-of-day analysis reports, with a lock/validation/send workflow | **Live** | §4, §10 |
| 2 | Flashs | Compose and send a short rich-text news item ("flash") to one or more companies, optionally duplicated by email, optionally with an attachment | **Live** | §5, §10 |
| 3 | Notes de broker (Broker notes) | Compose and send a broker recommendation/target-price note for one company/one broker, with an optional "recommendation change" (old vs new) | **Live** | §7, §10 |
| 4 | Émetteurs (Emitters/companies) | Create, view, archive/unarchive companies; manage their market, sector, indices, peer lists and linked users | **Live** | §6, §7, §10 |
| 5 | Listes (ticker/peer lists per company) | Maintain named lists of related tickers ("peers") attached to a company, used for report/peer comparisons | **Live** (this is **not** a flash/report recipient list — see §6) | §6 |
| 6 | Utilisateurs (per-company user administration) | Create, edit, delete client-firm users attached to one company; one role per user | **Live** | §2, §10 |
| 7 | Imports (per-company Excel import) | Upload an Excel file of one of four kinds (stock, stock-lending, consensus, "Reco TP") scoped to a single company | **Live but narrow** — only covers one company's own RIC-matched rows, not the CMS team's cross-company recommendation spreadsheet | §3, §8 |
| 8 | Factset peers/multiples | Attach Factset identifiers and multiples to a company for valuation display | **Live** | §8 |
| 9 | Version management | Publish the mobile app's minimum/latest version number and force an update | **Live** | §8, §10 |
| 10 | Disconnection monitoring dashboard | View statistics and a searchable log of client-app login/disconnection events | **Live**, but its sidebar menu entry is **commented out** in the front end (the screen and its API still work if reached directly by URL) | §2, §10 |
| 11 | User administration (single user, assigned company) | Confirmed: users are added **one at a time**, each tied to exactly **one** company ("emitter") and **one** role | **Live** | §2 |
| 12 | Target price / recommendation spreadsheet upload | **Not implemented as an admin-UI screen.** The database schema it ultimately feeds (`ImportedBrokerNote`, i.e. ticker/value/sector/broker/old-new recommendation/old-new price/currency) exists, and can be bulk-loaded, but only via a generic, **unauthenticated**, JSON-only backend endpoint that nothing in the admin front end calls. See §3. | **Partially live / operated outside the UI** | §3 |
| 13 | End-of-day stock/sector/market summaries | Covered by the "Reports" feature (#1) for the written commentary, and by the same generic unauthenticated JSON import endpoint for bulk numeric feeds (economic statistics, traded volumes, monitoring blocks) | **Live**, operated partly outside the UI | §4 |
| 14 | Send lists | **Not found.** There is no reusable, named "distribution list of recipients" entity anywhere in the code. Flash/report/broker-note recipients are chosen directly, per send, from the list of companies (not from saved lists of individual users). The CMS team's belief that "send lists" exist as a feature most likely refers either to the per-company "Listes" (ticker/peer lists, item 5 above) or to the recipient multi-select shown on the flash/report compose screens. | **Not present / believed mismatch** | §6 |
| 15 | Editing broker names | **No dedicated screen or endpoint.** Broker names are only ever **read** by the admin front end (for a drop-down). The broker reference table can only be replaced in bulk via the same generic unauthenticated JSON import endpoint used for recommendation data; there is no create/rename/delete endpoint reachable from the UI. | **Dead / outside-UI only** | §7, §13 |
| 16 | The connection (login) audit trail | Confirmed live: item 10 above | **Live** | §2, §10 |
| 17 | The billing export | **Not found anywhere in this repo.** No billing/invoice entity, service, controller, screen, or scheduled job exists. | **Not present** | §8 |
| 18 | Unarchiving apps | Confirmed: this is **unarchiving a company ("emitter")**, not a mobile app install. See §8. | **Live** | §8 |
| 19 | Valuation import (`POST /api/import/valuation`) | **Does not exist.** No endpoint at this or any similar path, no "Valuation" entity. | **Not present** | §8 |
| 20 | "Les données !" (Data) placeholder page | A sidebar page that renders only the literal text `"Les données !"` and nothing else | **Dead / stub, never finished** | §10 |

---

## 2. Users and entitlements

These are the **client-firm end users** ("collaborators") who use the separate client app — the admin back office's "Utilisateurs" screens manage them.

### Creating a user

A user is always created **one at a time**, as a sub-resource of exactly one company ("emitter"). There is **no bulk/CSV/paste creation** anywhere in the code or the front end.

Fields on the creation form, with the verbatim labels shown on screen:

| Label (verbatim) | Required | Validation | Verbatim error if invalid/missing |
|---|---|---|---|
| `"Prénom"` (first name) | Yes | non-empty | `"Le prénom est requis"` (front end); backend message if missing: `"Please provide your first name."` / French: `"Veuillez renseigner votre prénom."` |
| `"Nom"` (last name) | Yes | non-empty | `"Le nom est requis"` / backend: `"Please provide your last name."` / `"Veuillez renseigner votre nom."` |
| `"Position"` (job title) | Yes on the front end (backend treats it as optional) | non-empty (front-end only) | not specified in the UI copy found |
| `"Adresse e-mail"` | Yes | must be a syntactically valid email address (pattern requires `name@domain.tld`, TLD 2–10 letters) | `"invalid email address"` (front end), or if left blank, `"L'email est requis"`; backend equivalents: `"Please provide valid email."` / `"Veuillez renseigner un email valide."` |
| `"Nº de téléphone"` | No | — | — |
| `"Role"` | Yes | must be one of the two valid role values (see below) | backend: `"Please provide at least one role."` / `"Veuillez renseigner au moins un rôle."` |

There is **no password field on the creation form.** The system auto-generates a 10-character password made of exactly 2 lower-case letters, 2 upper-case letters and 2 digits (no special characters, despite the special-character rule existing in the code for password changes — see below), and emails it to the new user in clear text (see §11 for the exact email). The newly created user record is also stamped with "must change password on first login" = true, and with four notification-tracking timestamps (last-flash-read, last-flash, last-daily-read, last-daily) all set to the creation instant, so the new user does not see every historical flash/report as "unread".

**A hard-coded bypass exists for test/demo accounts:** if the new user's email address starts with the literal string `"cms1"` or `"cms2"`, the system **skips the generated password entirely**, writes a fixed, hard-coded password hash into the account, marks terms-of-service as already accepted, and marks "must change password" as false — meaning any two email addresses starting with those prefixes share a single, hard-coded password. This is a real finding in the current code, not a hypothesis; it must **not** be carried over to the replacement (see §13).

If the email address is already in use by another account, creation fails with: English `"Email {0} is already used."` / French `"Le mail {0} est déjà utilisé."` (where `{0}` is the submitted email). If the creation email cannot be sent, creation still fails (the account is not left half-created) with: `"The creation email has not been sent. Cause :{0}"` / French `"L'email de création n'a pas pu être envoyé. Cause :{0}"`.

### Credential delivery and expiry

The generated password is delivered only by email (there is no "copy password" admin action and no forced password reset link shown in the UI at creation time). See §11 for the literal account-creation email subject and template reference. The password itself never expires. A **separate** "forgot password" flow exists (reachable from the client app, not from the admin screens) that emails a reset link; that reset key/link expires after **1 day** (configurable; the value found in every environment examined is 1 day). After expiry, attempting to use the link returns the error `"Expired reset key {0}"` / French `"la clé de réinitialisation {0} à expiré."`. An invalid/already-used key returns `"Reset key {0} is not valid"` / French `"La clé de réinitialisation {0} du mot de passe n'est pas valide"`.

### Entitlement model

**One company ("emitter") per user — not many.** Each user record has exactly one company reference; there is no many-to-many company assignment, no sector-based assignment, no client-firm-based assignment distinct from "company", and no content-type-based assignment. "Assigned company" in the entitlement model means: the user only ever sees content (flashes, daily/market reports, broker notes) that is addressed to their one assigned company. Changing a user's company re-points what content they are considered to belong to; the four notification-timestamp fields are not automatically reset on a company change (not confirmed in code either way beyond the fields existing).

### Roles

Exactly **two** roles exist in the whole system, both only ever used for the client-firm "collaborator" population (they are unrelated to the Azure-AD-group-based admin/back-office access described in §0):

| Role value | Short name | Confirmed meaning in code |
|---|---|---|
| `"ROLE_EMITTER"` | `"emitter"` | The normal/full collaborator role |
| `"ROLE_EMITTER_LIMITED"` | `"emitter_limited"` | A second role exists, but **no code anywhere checks for it specifically** — no endpoint, no business rule, no UI condition branches on `"ROLE_EMITTER_LIMITED"` differently from `"ROLE_EMITTER"`. In other words, the "limited access" role is defined but its restriction is not implemented anywhere found in this repo. If the CMS team believes it restricts something, that restriction either lives in logic not present in this repository or was never finished. |

No seed/fixture data in the repo demonstrates either role in a distinctive way beyond being assignable at account creation. A user's assigned roles are a simple set — one or both values can technically be assigned (the form only allows picking from a dropdown fed by the roles endpoint, which returns both values as options), but the normal case, per the CMS team's own description, is a single role per user.

### Editing a user

The edit form has the same six fields as creation (`"Prénom"`, `"Nom"`, `"Position"`, `"Adresse e-mail"`, `"Nº de téléphone"`, `"Role"`), plus (read-only, informational, shown above the form) two dates: `"Date de dernière lecture de daily report"` and `"Date de dernière lecture de flash"` (each shown as `dd/MM/yyyy` or `"N/A"` if never read). The update can also optionally set a brand-new password and a "must change password" flag directly (bypassing the emailed-password flow) — this capability exists in the underlying request shape, though whether the current UI exposes a password field is not fully confirmed from the front-end research; the endpoint accepts it regardless. A changed password must satisfy: **minimum 8 characters, at least one digit, at least one lower-case letter, at least one upper-case letter**; the verbatim rule text surfaced in error messages is **"The password must have a minimum of 8 characters and include a number, an uppercase letter, a lowercase letter."** (this single sentence is reused for every individual rule violation — digit, lower-case, upper-case, length, and even the special-character rule, even though the sentence itself does not mention special characters). Nothing in the user record is "locked" by editing; no session/token invalidation on edit was found.

### Deactivating, suspending, deleting, archiving

Only **two** distinct, confirmed mechanisms exist for a client-firm user:

1. **Soft deactivation** — a timestamp field is set on the user; while set, the user cannot authenticate at all (login is filtered to only consider users with no deactivation timestamp). It is reversible by clearing the timestamp. It does **not** invalidate an already-issued session token; a token issued before deactivation keeps working until it separately expires or is replaced by a new login. There is no separate "suspend" concept distinct from this.
2. **Hard deletion** — the account row is deleted outright from the database. This is **irreversible**. The confirmation dialog shown is: title `"Suppression utilisateur"`, message `"Êtes-vous sûr de vouloir supprimer {firstname} {lastname} ?"`, with buttons `"non"` and `"Oui"`.

There is no "archive a user" concept (archiving in this system applies to companies, not users — see §8). Two error-message strings referencing a protected "Super Admin" account (`"Unable to deactivate not found user with id {0}"` and `"Unable to deactivate the Super Admin"`) exist in the translation files, but **no code anywhere throws them and no "Super Admin" user/flag exists** — this is dead/unfinished code (see §13); do not build a "Super Admin cannot be deactivated" rule unless you independently decide you need one.

### Password reset by admin, unlocking, forced change, terms reset

- **Admin-triggered password reset**: there is no admin-specific "send this user a reset email" button found; the only reset-password trigger in the code is the user's own "forgot password" flow (email address only, publicly reachable, always returns success/204 even if the email does not match any account, to avoid revealing which emails exist).
- **Account locking after failed attempts**: **not implemented.** There is no failed-login counter, no temporary lockout, and no "unlock" endpoint.
- **Forced password change**: implemented as a boolean flag on the user ("must change password"), set to true on creation or whenever an admin resets the password, and cleared only when the user successfully changes their own password through the client app. The flag is **not enforced by the backend** — nothing blocks a user with the flag still set from doing anything; it is advisory data for the client app's UI to act on.
- **Resetting terms-of-service (CGU) acceptance**: a user can **accept** terms (an endpoint sets today's date on their record), but there is **no endpoint to un-accept/reset** terms acceptance for an admin to use. If the CMS team needs to force a user to re-accept terms, that would currently require a direct database edit.

### Searching, filtering, sorting, exporting the user list

Per-company user lists are searchable by free text matched against first name, last name and email (client-side filter in the front end, not a server-side search parameter) and rendered in a plain table with no column sort control and **no export** button anywhere in the admin front end.

### Connection (login) audit trail

Every time a user's session is ended for any reason, a record is written with: the user's email (as plain text, not a foreign key), which platform they were on (`"DESKTOP"` or `"MOBILE"`), why (see the reason list below), the caller's IP address, their browser/app user-agent string, a free-text "details" note, and — for debugging — both the token value the client presented and the token value the server had stored. The admin dashboard shows and can filter this list by user email, date range, platform and reason, sorted by creation time descending by default, with pagination.

The recognised reasons, and the exact French label the dashboard shows for each, are:

| Reason (code) | Displayed label (French) |
|---|---|
| `TOKEN_EXPIRED` | `"Session expirée"` |
| `TOKEN_INVALID_SIGNATURE` | `"Authentification compromise"` |
| `TOKEN_REVOKED` | `"Accès révoqué"` |
| `USER_NOT_FOUND` | `"Compte utilisateur supprimé"` |
| `SESSION_CORRUPTED` | `"Session corrompue"` |
| `TOKEN_REPLACED_BY_NEW_LOGIN` | `"Nouvelle connexion détectée"` |
| `TOKEN_MALFORMED` | *(not mapped to a dashboard label in the code reviewed)* |
| `TOKEN_INVALID` | *(not mapped)* |
| `USER_DEACTIVATED` | *(not mapped)* |
| `INSUFFICIENT_ROLES` | *(not mapped)* |
| `MANUAL_LOGOUT` | *(not mapped)* |

Platform labels shown: `DESKTOP` → `"Application bureau"`, `MOBILE` → `"Application mobile"`.

The dashboard's own page copy, verbatim: page title `"Monitoring des déconnexions"`; period selector label `"Période d'analyse :"` with options `"7 jours"`, `"30 jours"`, `"90 jours"`; refresh button `"Actualiser"`; section headings `"Vue d'ensemble"`, `"Analyses"`, `"Tous les logs de déconnexion"`; chart headings `"Répartition par cause de déconnexion"` and `"Répartition par plateforme"`; each bar shows `"{count} ({percentage}%)"`; table column headers `"Date"`, `"Utilisateur"`, `"Plateforme"`, `"Raison"`, `"Adresse IP"`, `"Navigateur/Système"`, `"Détails"`; empty state `"Aucun log de déconnexion trouvé."`; loading state `"Chargement des logs..."`; pagination caption `"{totalElements} logs au total • Page {currentPage} sur {totalPages}"`.

**Retention**: there is no retention/cleanup job and no maximum-age field found anywhere — logs accumulate indefinitely unless manually purged from the database. **Export**: no dedicated export (CSV/Excel) endpoint exists; the only access is the paginated on-screen table.

---

## 3. Target price and recommendation upload

This is the area with the biggest gap between what the CMS team believes exists and what this repository actually implements as an admin screen.

**What exists as a screen.** Inside a single company's detail page, an "Imports" tab lets the admin pick one of four import kinds from a dropdown (labelled, verbatim, `"Short BlackApp (fichier 10)"`, `"Consensus"`, `"Short Markit (fichier 9)"`, `"Reco TP"`) and upload **one Excel file for that one company only**. The button reads `"Import a file"`. There is **no multi-company spreadsheet upload screen** anywhere in the admin front end.

For the `"Reco TP"` kind specifically (the closest match to "target price and recommendation"):
- The workbook must contain a sheet literally named **`"Brute"`** (case-sensitive exact match); if it is missing, the whole upload is rejected with: `"L'onglet [Brute] n'a pas été trouvé dans le fichier Excel."` / English `"Tab [Brute] not found in Excel file"`.
- The first row is treated as a header and skipped; data is read starting at the second row.
- Only **two columns are read**: column 1 must equal — exactly, case-sensitively, with no trimming or normalisation — the RIC code already stored against **this one company**; column 2 is a free-text value. There is **no per-row ticker lookup across companies**, no fuzzy matching, and no handling at all for the different ticker formats (`"7201JP"`, `"SHA0 GR"`, `"TSLA"`, `"DSYFP"`) beyond literal string comparison against the single company's own RIC.
- A row whose ticker column does not equal the expected RIC is rejected individually with: `"Valeur [{ricCode}] était attendu pour le champ [Column]."` / English `"Value [{ricCode}] was expected for field [Column]."` — the row is skipped, the rest of the file still processes.
- A blank required cell is rejected individually with `"Le champ [{0}] ne doit pas être vide"` / English `"Field [{0}] shouldn't be empty"`; the row is skipped, the rest of the file still processes.
- The whole file is rejected (HTTP 400) if it is not a readable Excel file at all: `"Le fichier Excel est invalide."` / English `"Invalid Excel file"`.
- The response returned to the admin after upload reports, structurally: the total number of data rows, how many succeeded, and a map of row number → list of error messages for every row that failed — there is **no preview-before-commit step**; valid rows are saved immediately even if other rows in the same file failed.
- A query flag controls whether all of this company's existing rows of this import kind are deleted before the new rows are inserted (the default behaviour is to delete-then-insert); if that flag is turned off, new rows are appended alongside old ones with no de-duplication, so uploading the same file twice with the flag off **duplicates every row**.
- There is **no recommendation-value mapping table** found in this particular Excel import path — the two cells read for `"Reco TP"` are just "ticker" and a single free-text value, not separate "new recommendation" / "old recommendation" / "new price" / "old price" / "currency" columns. The richer, CMS-spreadsheet-shaped schema (see next paragraph) is **not** what this screen consumes.

**What the CMS team's actual spreadsheet shape maps onto.** A separate table in the database is shaped almost exactly like the spreadsheet described: it has fields for ticker, value/company name, sector, broker (short and long name), new recommendation, previous recommendation, new price, previous price, and currency. This table can only be bulk-loaded through a **generic, JSON-only, unauthenticated** data-import endpoint (`POST /api/import`) that accepts a JSON body naming a target data type by a key string (e.g. the key for this table is `"recommendation_change"`) and an array of row objects matching those fields, plus a flag for whether to wipe the table first. **Nothing in the admin front end calls this endpoint for this data type** — there is no file-upload screen anywhere that produces this JSON shape. In practice this means: whoever currently gets the CMS team's spreadsheet into myCMS must be converting the spreadsheet to JSON and calling this endpoint directly (by script, Postman, or similar), entirely **outside the admin web application**, and because the endpoint requires no authentication at all, anyone who can reach the API host can call it. This is almost certainly the "manual step the CMS team performs outside the UI" the brief asks about, and it is also a serious access-control gap that the replacement must **not** reproduce (see §13).

**Row handling rules for this generic JSON import** (confirmed in code, for every data type that goes through this endpoint, including the recommendation-change table): if the submitted JSON key does not match any recognised data type, the whole request fails with `"Not supported data key [{0}]"` / French `"Clé de données non supportée [{0}]"`; if a required key is altogether missing from the payload, it fails with `"Missing JSON key [{0}]"` / French `"Clé JSON manquante [{0}]"`; if the JSON cannot be parsed into the target shape at all, it fails with `"Provided JSON data are erroneous."` / French `"Les données JSON fournies sont erronées."`; if the database write itself fails, it fails with `"An error occured while altering the database."` / French `"Une erreur est intervenue pendant la modification de la base de données."`. There is **no row-level partial-success reporting** on this generic path (unlike the per-company Excel importer above) — it is all-or-nothing per request, and whether to wipe the table first is controlled by a flag in the payload (several data types, including recommendation changes, default to wiping the table first when the flag is left out).

**Recognised recommendation values.** No hard-coded list of recommendation strings (e.g. "Overweight"/"Underweight"/"- AUCUNE -") was found in the Java code; the set of valid recommendation values is itself **reference data** stored in a database table (seeded initially from a bundled configuration file) and can itself be replaced via the same generic unauthenticated import mechanism (key: `"type_recommendation_broker"`). This means the "recognised recommendation values" are whatever rows currently exist in that reference table in the live database at the time — this cannot be enumerated definitively from source code alone (see "Not determinable from this repo").

**Currency / GBp-pence handling.** No currency-conversion or pence-to-pounds ("GBp"/"GBX") normalisation logic was found anywhere in the import code; currency values are stored and passed through as submitted strings.

**Downstream effects.** Rows accepted by either import path are stored as plain reference/history rows; neither import path was found to automatically trigger a flash, a push notification, or an entry in the end-of-day report purely by virtue of the import — those are separate, manually-triggered admin actions (Flash, Broker note, Reports).

**Re-upload rules.** For the per-company Excel importer, whether re-uploading the same file is safe depends entirely on the purge flag described above; with purge on (the default), re-uploading is effectively "replace all". For the generic JSON import, the same applies per data type's own default. Neither path has any concept of "new row replaces matching old row by key" (true upsert) — it is always either delete-everything-then-insert, or append-with-possible-duplicates.

---

## 4. End-of-day report uploads: stock, sector and market summaries

The written commentary parts of the end-of-day report are **not file uploads** — they are composed directly in the admin screens described in §10 ("Reports" feature), one rich-text box for the company-level analysis and a second for the sector-level analysis (plus two further, unlabelled custom content boxes whose purpose could not be determined from the front-end code alone), and a separate single rich-text box for the market-level report, each per language/company/day. These are authored and saved like a document, not imported from a file.

The **numeric** feeds that would sit behind "stock summary" / "market summary" data (economic statistics, traded volumes, and an entity referred to only as a "monitoring block") exist as database tables that, like the recommendation-change table in §3, can only be bulk-loaded through the same generic, unauthenticated JSON import endpoint — there is **no file-upload screen** for any of them in the admin front end.

**Timing.** No cut-off time, timezone rule, or "late upload" handling was found in the reviewed code for either the written reports or the numeric feeds. The only time-based behaviour confirmed for the written reports is a same-day edit lock: a report becomes fully locked (no longer editable) once it has been marked sent, or once its date is in the past; while a report is open and not yet sent, whichever admin currently has it open holds a soft lock, and a second admin opening the same report sees a warning that it is `"Actuellement ouvert par [user name]"`, with the choice to keep that lock or take it over.

**Generation and delivery.** Nothing in the reviewed code automatically assembles or schedules sending of the end-of-day report — the admin must manually mark each report as sent via the compose screen (button `"Envoyer"`), after validating spelling/meaning for the analysis and content sections and marking a writing-status workflow as "done". No PDF generation, scheduled send, or "regenerate" action was found. Whether reports are additionally emailed or pushed to users on send, beyond simply becoming visible/marked "unread" in the client app, could not be confirmed from the admin-side code reviewed.

**Correction after sending.** There is no separate "amend a sent report" flow distinct from normal editing; whether the same edit screen remains reachable after a report is marked sent, and what (if anything) re-notifies readers, could not be fully confirmed.

---

## 5. Flash notes

**The editor.** A third-party rich-text editor component is used (the same component is reused for the report-writing screens). The toolbar explicitly removes the following capabilities, so they must **not** be offered by the replacement unless a conscious decision is made to add them back: colour/highlight ("brush"), generic file attachment from inside the editor itself, full-screen mode, "copy formatting", the eraser tool, and the "more options" overflow menu. It explicitly **keeps** (nothing in the configuration removes): headings, bold/italic/underline, ordered and unordered lists, links, and pasted tables. Pasting rich HTML or pasted Word content triggers a confirmation prompt before it is applied (configuration flags `askBeforePasteHTML` and `askBeforePasteWord`, both enabled). Images dropped or pasted into the editor are embedded directly as base64 data inside the saved content — there is **no separate image-upload-and-link workflow for in-body images**; only an explicit attachment (below) is a separate file. A custom toolbar button exists that pastes the current clipboard's text content into the editor, converting literal newline characters to line breaks.

**Stored format.** Flash body content is stored as free-form text (HTML produced by the editor is accepted as-is); there is **no server-side HTML sanitisation** found anywhere in the flash-creation path, and **no size limit is enforced before the database column limit** of roughly 30,000 characters. The replacement must decide for itself whether to sanitise user-authored HTML server-side — the current system does not.

**Attachments.** A flash may have zero or more attached files. The accepted file types are **not restricted** at all (no extension or MIME-type whitelist/blacklist found); whatever content-type the browser reports for the uploaded file is stored and later served back as-is. An empty (zero-byte) attachment is rejected with: `"Attachment [{0}] can not be empty."` / French `"La pièce jointe [{0}] ne peut être vide."`; a generic storage error produces: `"An error prevents to access or store the content of attachment [{0}]."` / French `"Une erreur a empêché l'accés au contenu de la pièce jointe [{0}]."`. File content is stored directly inside the relational database as binary data (not on a file share or blob store). The platform-wide multipart upload limits apply: **maximum 10 MB per individual file part, maximum 15 MB for the whole multipart request**. Attachments are served back through a dedicated authenticated "get attachment content" endpoint, with a one-hour browser cache header.

**Lifecycle.** There is **no draft state and no scheduled-send state**: creating a flash **is** sending it — the moment the admin submits the compose form, the record is saved, an optional duplicate email is sent, and a push notification is triggered, all in the same request. A flash **cannot be edited** after creation (no update endpoint exists for it at all). A flash **can be deleted**, which removes the record and its attachments from the database, but this does **not** recall anything already delivered — there is no "recall" concept; any push already sent or email already delivered stays delivered. The delete confirmation dialog reads: title `"Suppression d'un flash"`, body `"Êtes-vous sûr de vouloir supprimer ?"` with the bold sub-text `"Cette action est irreversible"`, buttons `"Annuler"` / `"Oui"`.

**Targeting.** Recipients are chosen directly on the compose screen as a set of **companies** ("émetteurs"), either hand-picked from a searchable multi-select, or by ticking `"Envoyer à tous les émetteurs"` to target every non-archived company at once. There is **no concept of a saved, reusable, named list of individual recipients** (see §6) — targeting is always a fresh choice of companies made at send time. Sending with zero companies selected is blocked client-side with the validation message `"Merci de saisir un destinataire"` before the request is even submitted; server-side behaviour for an empty recipient set was not found to be separately validated.

**Push notifications.** Every flash send attempts a push, to every user of every targeted company who has a non-empty push token recorded (users without a token are silently skipped — there is no separate mute/opt-out feature). The push title is built as `"{company} - {flash type}"` (e.g. "ACME Corp - Breaking News"); the push body is the flash's title field (not its full rich-text content); on Android the notification carries a fixed, hard-coded, non-localised summary line `"Nouveau flash disponible"` and a fixed notification channel/colour; on iOS it carries a fixed alert sound and a numeric badge equal to the recipient's combined count of unread flashes plus unread daily reports. A flash **cannot be sent without this push attempt** (there is no "send without push" option), and conversely there is **no way to send a bare push without creating a flash record** — the two are inseparable. If `"Envoyer aussi par email"` is also checked, a duplicate of the content is additionally emailed, with the flash's associated links appended as an HTML bullet list under the heading `"Associated links :"`.

**Full field list on the compose screen**, verbatim: section heading `"Destinataire(s)"` with checkbox `"Envoyer à tous les émetteurs"` (error if none chosen: `"Merci de saisir un destinataire"`); section heading `"Contenu"` with fields `"Objet"` (error if blank: `"L'object est requis"` — note the typo "object" instead of "objet" is in the live product), `"Valeur"` (error: `"La valeur est requise"`), `"Type"` (a dropdown of flash-type reference values — see below — error: `"Le type est requis"`), `"Message"` (the rich-text body — error: `"Le message est requis"`), and `"Liens associés"` (a free-text box, one URL per line, placeholder `"Merci de mettre un lien par ligne"`, optional); section heading `"Pièce jointe"` with the prompt `"Ajouter une pièce jointe"` when empty; and the checkbox `"Envoyer aussi par email"`. The submit button reads `"Envoyer"`. On a server error the whole form shows: `"Impossible de créer un flash pour le moment. Merci de réessayer ultérieurement."`

**Recognised flash types** (reference data, editable in principle through the same generic bulk-import mechanism as everything else, seeded with these eight values): `"Price movement"`, `"Pre-opening"`, `"Breaking News"`, `"Reco / TP"`, `"Sales traders' comments"`, `"Brokers Interests"`, `"Brokers Comments"`, `"Peer report"`. No code was found that restricts which of these are actually reachable from the UI versus merely present in the reference table, so all eight should be treated as live unless the rebuilding team's own UI testing shows otherwise.

**Company/ticker mentions inside the body.** No autocomplete or structured "mention a company/ticker" feature exists inside the flash editor; the "Valeur" field is a single free-text string, not a link to a company record.

---

## 6. Send lists

**This feature, as a persisted, named, reusable list of recipients, does not exist in this repository.** There is no entity, table, or endpoint anywhere that represents "a list of users/companies that can be saved under a name and reused across multiple sends." Searching broadly for list/distribution-list concepts in the codebase surfaces only one similar-sounding feature: a per-company "Listes" tab, which lets the admin create named groups of related **tickers** ("peers") attached to one company — used to show related instruments on a report/analysis screen, not to choose who receives a flash, broker note or report. Creating one of these ticker lists requires a title (validation error if blank: `"Required"`) and at least one ticker, each resolved by typing a RIC code into a type-ahead field (placeholder `"rechercher un pair"`) that must resolve to a known pair or shows `"Ce code RIC n'existe pas"`. Deleting a list or a single ticker inside it is immediate and is described in its confirmation dialog as irreversible (`"Cette action est irreversible"`). None of this has any relationship to who receives a flash, broker note, or report — those are always targeted directly at companies at send time (§5, §7).

**Recommendation for the rebuilding team:** confirm directly with the CMS team whether "send lists" means (a) this ticker/peer-list feature, (b) simply the recipient multi-select on the flash/broker-note compose screens, or (c) a feature that genuinely does not exist yet and that they want built for the first time. Do not assume a reusable recipient-list feature needs to be preserved — nothing in this codebase currently behaves that way.

---

## 7. Broker names and reference data

**Broker names.** The only admin-reachable broker operation found anywhere in the front end is reading the list of broker names to populate a drop-down when composing a broker note. There is **no create, rename or delete screen, and no corresponding endpoint**, reachable from the admin UI. The broker reference table's name field is itself the table's primary key (not a generated ID with a separate name column); other records (broker notes, the recommendation-change table) store the broker's name as a plain string, not as a foreign key to that primary key. Practically, this means: (a) there is no UI-driven way to rename a broker today, and (b) even if one were added naively, renaming the primary key would not automatically update every historical broker note or recommendation-change row that already stored the old name as free text — those would need an explicit, deliberate cascade/rewrite, or they would silently continue showing the old name. The only way the broker list can currently be changed at all is via the generic, unauthenticated bulk-JSON-import mechanism described in §3 (key `"brokers"`), which **defaults to wiping the entire broker table before inserting the new rows** — meaning the current "editing broker names" workflow, to the extent it is used at all, almost certainly happens by someone replacing the whole broker list in one shot, outside the admin UI, not by editing one name at a time.

**Every other reference table the admin UI reads from or writes to:**

| Reference data | Fields | Where maintained | Used by |
|---|---|---|---|
| Company ("émetteur") | name, RIC code (unique), archived flag, primary language, up to four "primary index" references, other indices, sectors, market, subscribed peer pairs | Admin UI (create/archive/unarchive/edit indices) | Reports, flashes, broker notes, user assignment, imports |
| Market | code (primary key), short name, full name, currency/"devise" code | Read-only in the admin UI (list endpoint only); bulk-replaceable via the generic import mechanism | Company creation form |
| Sector ("secteur"/"business segment") | name (primary key; sub-sectors are encoded as `"Parent/Child"` strings) | Read-only in the admin UI; bulk-replaceable via the generic import mechanism | Company creation form, company list filter |
| Index ("indice") | RIC code (primary key), name, a type classification | Read-only in the admin UI; separate liquibase migrations have updated this table's shape over time | Company's "primary index 1–4" fields |
| Ticker/peer ("pair") | RIC code, name | Created implicitly by typing a RIC into any of the RIC look-up fields across the UI (company creation, ticker lists, Factset linking) | Companies' subscribed-pairs set, per-company ticker lists |
| Flash type | name (primary key) | Read-only in the admin UI; bulk-replaceable via the generic import mechanism | Flash "Type" dropdown |
| Broker-note recommendation type | name (primary key) | Read-only in the admin UI; bulk-replaceable via the generic import mechanism | Broker-note "Recommandation" dropdown, and the old/new recommendation comparison |

---

## 8. Billing export, unarchiving and the rest

**Billing export.** **Not present.** No entity, service, controller, scheduled job, or UI screen related to billing, invoicing, or any periodic usage export exists anywhere in this repository.

**Unarchiving apps.** Confirmed: "app" here means a **company record ("émetteur")**, not a mobile application install. A company has a simple true/false archived flag. Archiving sets it true; unarchiving sets it false; both are plain, immediate, reversible toggles with no side effects beyond filtering: archived companies are excluded from the default company list (unless the admin ticks `"Afficher les émetteurs archivés"`), and are excluded from "send to all" targeting for flashes and from end-of-day report generation. On the company detail screen, archiving is offered via a button labelled `"Archiver"`; once archived, the screen shows a warning banner `"Attention ! Émetteur archivé"` and a `"Désarchiver"` button to reverse it. No data is deleted by archiving; it is purely a visibility/eligibility flag.

**Valuation import.** **Not present.** No endpoint at `POST /api/import/valuation` or any similarly-named path exists, and no "valuation" entity exists. If a valuation-import feature is required in the rebuild, it must be designed fresh — nothing here can be used as a reference implementation.

**Other screens/endpoints not covered elsewhere, at the same depth:**

- **App version management** — a single screen lets the admin view the current published app version and publish a new one. Fields: a bold label `"Current Version"` showing the latest published version; an input labelled `"Enter the new version:"` that must match the pattern `X.X.X` (three dot-separated numbers) or shows `"Format should be like this X.X.X"`; a checkbox `"Force to the user to update the application"`; a submit button `"Envoyer"`. Publishing a version number that already exists is rejected with `"A version {0} already exists."` / French `"Une version {0} existe déjà."` On success the admin sees a toast `"Version ajoutée avec succès"`. This drives the client mobile app's own "please update" prompt; the exact client-side behaviour of the "force" flag lives in the separate client app, not in this repository.
- **Factset linking** — per company, the admin can attach named Factset peer identifiers and search/select which Factset "multiples" are available for that company, used to populate valuation figures shown to client-app users. Saving multiples shows the toast `"Enregistrement effectué avec succès"`.

---

## 9. Admin API

All paths below are relative to the back-office host. Everything under `/api-admin/**` is reached through the Azure-AD-backed, session/cookie-based authentication described in §0 (CSRF checking is explicitly turned off for this path prefix even though the session mechanism issues a CSRF cookie). No endpoint in this repository was found to carry a specific per-role authorization check beyond "is authenticated" — the two "collaborator" roles (`ROLE_EMITTER`, `ROLE_EMITTER_LIMITED`) govern the separate client-facing API, not the admin API. A small number of account-management endpoints are additionally gated by a configuration switch that can disable them per environment (seen enabled in every environment examined).

Standard envelope for validation failures (HTTP 400): a structured "problem" body containing a `type`, `title`, `status`, a human-readable `message`, the request `path`, and — for field-level validation failures — a `fieldErrors` array of `{objectName, field, code, message}`. Business-rule failures (e.g. "email already in use") return the same shape with just a `message`. Authentication failures on protected paths return a plain `{"error":"unauthorized","message":"Authentication required"}` body with HTTP 401.

Multipart uploads (flash and broker-note creation) are capped at **10 MB per file part / 15 MB per request**; there is no documented upload timeout beyond the platform default. List endpoints that return a page use standard page/size/sort query parameters; there is no documented rate limit.

### Accounts (client-firm users)

**GET `/api-admin/accounts-management/emitter/{emitterId}`** — list every user of one company.
- Auth: admin session.
- Success (200): array of user objects, each with id, email, phone, first name, last name, job title, terms-acceptance date, deactivation date (if any), the company summary, roles, "must change password", and the four notification timestamps.
- Errors: 400 bad request, 401 unauthorized.

**PUT `/api-admin/accounts-management/account`** — create a user.
- Auth: admin session.
- Request example:
```json
{
  "email": "jane.doe@example.com",
  "firstName": "Jane",
  "lastName": "Doe",
  "phone": "+33 6 12 34 56 78",
  "jobFunction": "Investor Relations Manager",
  "emitterId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "roles": ["ROLE_EMITTER"]
}
```
- Success: **201 Created**, empty body, with a `Location` header pointing at the new account's "get one" URL.
- Errors: **400** with message `"Email {0} is already used."` (email already taken) or `"The creation email has not been sent. Cause :{0}"` (email delivery failed — account is not created); **400** with field errors if required fields are blank; **401** unauthorized.

**POST `/api-admin/accounts-management/account/{accountId}`** — update a user (can also set a new password).
- Auth: admin session.
- Request example:
```json
{
  "email": "jane.doe@example.com",
  "firstName": "Jane",
  "lastName": "Doe",
  "phone": "+33 6 12 34 56 78",
  "jobFunction": "Investor Relations Manager",
  "emitterId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "newPassword": "Str0ngP@ssw0rd!",
  "passwordChangeRequired": false,
  "roles": ["ROLE_EMITTER"]
}
```
- Success (200): the updated user object.
- Errors: **400** (validation, or password not meeting the 8-char/digit/upper/lower rule — message: `"The password must have a minimum of 8 characters and include a number, an uppercase letter, a lowercase letter."`); **401**; **404** if the account id does not exist.

**GET `/api-admin/accounts-management/account/{accountId}`** — fetch one user. 200 / 400 / 401 / 404.

**DELETE `/api-admin/accounts-management/account/delete/{accountId}`** — hard-delete a user. 204 No Content on success; 400 with `"No account with UUID: {0}"` if not found; 401.

**GET `/api-admin/accounts-management/roles`** — list the two assignable roles. 200, body: `["ROLE_EMITTER", "ROLE_EMITTER_LIMITED"]`.

### Companies ("emitters")

**GET `/api-admin/emitters-management/emitter`** — list every company (summary rows: name, RIC, sectors, associated-user count, archived flag). 200 / 401.

**POST `/api-admin/emitters-management/emitters`** — filtered/paginated company list (request body carries free-text name/RIC, market and sector filters; standard pagination). 200 / 401.

**PUT `/api-admin/emitters-management/emitter`** — create a company, optionally with its indices, linked peers, and an initial batch of users in one call.
- Request example:
```json
{
  "name": "Acme Corp",
  "ric": "ACME.PA",
  "marketCode": "EPA",
  "languageCode": "fr-FR",
  "sector": "Industrials",
  "subSector": "Industrials/Capital Goods",
  "national1IndiceRic": ".FCHI",
  "sector1IndiceRic": ".SXNP",
  "pairs": [{"name": "Acme Peer 1", "ric": "PEER1.PA"}],
  "collaborators": [
    {"email": "jane.doe@example.com", "firstName": "Jane", "lastName": "Doe", "jobFunction": "IR", "phone": "+33612345678"}
  ]
}
```
- Success: **201 Created** with the created company and, where applicable, the created users.
- Errors: **400** with `"An emitter with same RIC code already exists"` / French `"Un émetteur avec un code RIC identique existe déjà"`; 401.

**GET `/api-admin/emitters-management/emitter/{emitterId}`** — fetch one company's full detail. 200 / 400 / 401 / 404.

**PUT `/api-admin/emitters-management/emitter/{emitterId}/archive`** — archive. 204 / 400 / 401 / 404.

**PUT `/api-admin/emitters-management/emitter/{emitterId}/unarchive`** — unarchive. 204 / 400 / 401 / 404.

**DELETE `/api-admin/emitters-management/emitter/{emitterId}/unlink/{pairId}`** — detach a subscribed peer pair from the company. 204 / 401.

**PUT `/api-admin/emitters-management/emitter/indice/{emitterId}`** — replace the company's four index references in one call. Request example:
```json
{ "national_1_indice": ".FCHI", "sector_1_indice": ".SXNP", "national_2_indice": null, "sector_2_indice": null }
```
204 / 400 / 401 / 404.

### Ticker ("peer") lists per company

**PUT `/api-admin/tickers`** — create a named ticker list. 201, or 400 with `"A list with name [{}] already exists for the emitter."` / French `"Un site avec le nom [{}] existe déjà pour l'émetteur."`

**GET `/api-admin/tickers/by-emitter/{emitterId}`** — paginated lists for a company. 200.

**PUT `/api-admin/tickers/{listId}/ticker`** — add a ticker to a list. 201.

**PUT `/api-admin/tickers/{listId}`** — rename a list. 200/204.

**DELETE `/api-admin/tickers/{id}`** — delete a whole list. 204.

**DELETE `/api-admin/tickers/ticker/{id}`** — delete one ticker from a list. 204.

**GET `/api-admin/pairs-management/pairs/ric/{search}`** — look up a RIC for the type-ahead fields; 200 with the match, or an empty/not-found result that the front end renders as `"Ce code RIC n'existe pas"`.

### Flashes

**GET `/api-admin/flashs?q={text}`** — paginated, searchable list (search matches type, company, description and title). 200 / 401.

**GET `/api-admin/flashs/{id}`** — one flash. 200 / 401 / 404.

**DELETE `/api-admin/flashs/{id}`** — delete. 204 / 401 / 404.

**POST `/api-admin/flashs`** — create and immediately send. Multipart request with one part named `flash` containing this JSON:
```json
{
  "title": "Q3 results beat expectations",
  "value": "Acme Corp",
  "description": "<p>Acme Corp posted...</p>",
  "type": "Breaking News",
  "links": ["https://example.com/press-release"],
  "emittersUUID": ["3fa85f64-5717-4562-b3fc-2c963f66afa6"],
  "sendByEmail": false,
  "sendToAll": false
}
```
plus zero or more file parts named `attachments`.
- Success: **201 Created**, `Location` header, body = the created flash (id, title, type, company, description, links, attachment metadata, recipient companies, created/updated timestamps).
- Errors: **400** on validation failure (structured field errors); **401** unauthorized. On the front end, any failure is shown generically as: `"Impossible de créer un flash pour le moment. Merci de réessayer ultérieurement."`

**GET `/api-admin/referential/types/flash`** — the flash-type dropdown options. 200, array of the eight strings listed in §5.

### Broker notes

**POST `/api-admin/broker-note`** — create and send. Multipart request, one part named `note`:
```json
{
  "emitterId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "title": "Target price revision",
  "broker": "Example Securities",
  "currency": "€",
  "currentObjective": "45.00",
  "currentRecommendation": "Overweight",
  "sectorNote": false,
  "initiationNote": false,
  "recoChange": true,
  "previousObjective": "40.00",
  "previousRecommendation": "Neutral",
  "sendByEmail": false
}
```
plus optional `attachments` file parts.
- Success: **201 Created**, `Location` header, created broker note.
- Errors: **400**/**401**. Front-end generic failure copy: `"Impossible de créer une note pour le moment. Merci de réessayer ultérieurement."`

**GET `/api-admin/broker-note?q={text}`** — paginated, searchable list. 200 / 401.

**GET `/api-admin/broker-note/{id}`** — one note. 200 / 401.

**GET `/api-admin/broker-note/lastOfEmitter/{id}`** — most recent note for a company. 200 / 401.

**DELETE `/api-admin/broker-note/{id}`** — delete. 204 / 401 / 404.

**GET `/api-admin/referential/broker`** — broker name list for the dropdown. 200, array of strings. *(No corresponding write endpoint exists — see §7.)*

**GET `/api-admin/referential/types/broker-note`** — recommendation-type dropdown options. 200, array of strings (content is whatever is currently seeded in the reference table; cannot be enumerated exhaustively from code alone).

### Reports (value/company-level and market-level)

**GET `/api-admin/reports`**, **GET `/api-admin/reports/{date}`** (date as `dd-MM-yyyy`), **GET `/api-admin/reports/byId/{analysisId}`** — list/fetch. 200 / 401.

**POST `/api-admin/reports/{emitterId}`** — create an empty report for a company for today. 201.

**PUT `/api-admin/reports/{analysisId}/content`** — save the rich-text content fields. 200/201.

**PUT `/api-admin/reports/{analysisId}/validation/analysis`**, **PUT `/api-admin/reports/{analysisId}/validation/content`** — mark spelling/meaning validation done for each section. 200/201.

**PUT `/api-admin/reports/{analysisId}/writing_status`** — advance the writing-status workflow. 200/201.

**PUT `/api-admin/reports/{analysisId}/sent`** — mark as sent (irreversible in the UI; see §4). 200/201.

**PUT `/api-admin/reports/{analysisId}/lock`** / **PUT `/api-admin/reports/{analysisId}/unlock`** — the soft "who's editing this" lock described in §4. 200.

The market-report family mirrors every one of the above one-for-one under `/api-admin/reports/market/...`, keyed by language id instead of company id, plus a single `content` field instead of the multi-box layout.

**GET `/api-admin/reports/statistics/economic`** — economic statistics feed for the report screens. 200 / 401.

### Per-company Excel import

**GET `/api-admin/import/excel-types`** — the four import-kind options described in §3. 200.

**POST `/api-admin/emitter/{emitterId}/import/{kind}`** (`kind` ∈ `stock`, `stock-lending`, `reco-tp`, `consensus`) — multipart upload, one `file` part; query flag controls delete-before-insert (defaults to true).
- Success (200): `{"totalRows": 150, "okRows": 148, "rowErrors": {"101": ["Field [Value] shouldn't be empty"], "117": ["Value [ACME.PA] was expected for field [RIC]"]}}`
- Errors: **400** `"Invalid Excel file"` / `"Le fichier Excel est invalide."`; **400** `"Tab [Brute] not found in Excel file"` / `"L'onglet [Brute] n'a pas été trouvé dans le fichier Excel."`; **400** `"Invalid type [{0}]"` / `"Le type [{0}] est invalide."`; **401**; **404** if the company id does not exist.

### Generic bulk JSON import (publicly reachable — see §13)

**POST `/api/import`** — **no authentication required** (explicitly whitelisted in the security configuration for every environment examined). Body:
```json
{ "key": "recommendation_change", "purge": true, "data": [ { "ticker": "ACME.PA", "value": "Acme Corp", "sector": "Industrials", "broker_short": "EXS", "broker": "Example Securities", "reco_new": "Overweight", "reco_last": "Neutral", "price_new": "45.00", "price_last": "40.00", "currency": "EUR" } ] }
```
- Success: 200, empty body.
- Errors: 200-status endpoint, but business failures are: `"Not supported data key [{0}]"` / `"Clé de données non supportée [{0}]"` (unrecognised `key`); `"Missing JSON key [{0}]"` / `"Clé JSON manquante [{0}]"`; `"Provided JSON data are erroneous."` / `"Les données JSON fournies sont erronées."`; `"An error occured while altering the database."` / `"Une erreur est intervenue pendant la modification de la base de données."` The controller itself is explicitly documented in its own description as **"Temporary endpoint"**.
- Other recognised `key` values found: `"agenda"`, `"brokers"`, `"cumulated_volume"`, `"economic_statistics"`, `"indices"`, `"languages"`, `"markets"`, `"most_active_brokers"`, `"recalculed_indices"`, `"sectors"`, `"traded_volumes"`, `"type_flash"`, `"type_recommendation_broker"`, `"unissued_pairs"`, `"push_notifications"`, `"stock_lending"`, `"stock"`, `"short_sellers"`, `"monitoring_block"`, `"reco_tp_brokers"`, `"consensus"`.

### Disconnection monitoring

**GET `/api-admin/disconnections`** — paginated, filterable (by `userEmail`, `startDate`/`endDate`, `platform`, `reason`) log list, default sort newest-first. 200 / 401.

**GET `/api-admin/disconnections/stats?days={n}`** — dashboard statistics for the last *n* days (default 7). 200 / 401.

### App version

**GET `/api-admin/app-version`** — latest published version. 200, or 204 if none exist yet.

**POST `/api-admin/app-version`** — publish a new version.
```json
{ "version": "3.4.1", "forceUpdate": true }
```
201, or 400 `"A version {0} already exists."` / `"Une version {0} existe déjà."`

### Factset

**GET `/api-admin/factset/emitter/{emitterId}`**, **POST `/api-admin/factset/emitter/{emitterId}/peers`**, **GET `/api-admin/factset/emitter/{emitterId}/multiples`**, **PUT `/api-admin/factset/emitter/{emitterId}/multiples`** — attach/search/save Factset identifiers and multiples for a company. 200/204 / 401.

### Reference data (read-only from the admin UI's point of view)

**GET `/api-admin/referential/market`**, **GET `/api-admin/referential/sectors`**, **GET `/api-admin/referential/indices`** — dropdown sources for the company-creation wizard. 200 / 401.

### Attachments (shared with the client-facing API)

**GET `/api/attachment/{id}/content`** — streams a stored attachment's bytes with its original content-type and a one-hour cache header; this single endpoint serves both admin-authored flash/broker-note attachments and anything the client app itself can attach, and sits on the allow-listed, unauthenticated path group alongside `/api/auth/**` and `/api/import` in the security configuration — **access to attachment content by id does not require login**, by id guessing alone. 200 / 404.

---

## 10. Screens

**Reports** (`Rapports`) — list screen with two tabs, `"Valeurs"` and `"Marchés"`; a date picker (default label `"Aujourd'hui ({weekday} {day} {month} {year})"`); a search box, placeholder `"Rechercher un rapport"`; table columns `"VALEURS (N)"`/`"LANGUE (N)"`, `"Dernière modification"`, `"Validation"` (states `"..."`, `"À valider"`, `"Validé"`), and `"Statut"` (states `"À envoyer"`, `"✓ Envoyé à HH:mm"`). Clicking a row opens the write screen: per-company screens show two or more rich-text boxes with validation checkboxes (`"Vérifier l'orthographe"`, `"Vérifier le sens"`) and buttons `"Valider l'analyse"`, `"Valider le contenu"`, `"Marquer comme rédigé"`, `"Marquer comme fait"`, `"Envoyer"`; market screens show a single rich-text box under the heading `"Rédiger un rapport de marché"`. A "last saved" caption reads `"Dernière sauvegarde {relative time}"`; editing auto-saves a few seconds after the last keystroke. If someone else has the report open, a dialog states the report is `"Actuellement ouvert par [user name]"` with options to keep or take the lock.

**Flashs** — list screen, search placeholder `"Rechercher un flash"`, button `"Envoyer un flash"`; table columns `"Date d'envoi"`, `"Destinataire(s)"`, `"Valeur"`, `"Titre"`, `"Type"`. Compose screen as described in §5. Detail screen shows section headings `"DESTINATAIRE(S)"`, `"CONTENU"`, `"LIENS ASSOCIÉS:"`, `"PIÈCE-JOINTE"`, a note `"Duplicata envoyé par email"` when relevant, and a `"Supprimer"` action with the confirmation dialog quoted in §5.

**Notes de broker** — list screen, search placeholder `"Rechercher une note de broker"`, button `"Envoyer une note"`; a legend explaining the three type icons: `"Changement de recommandation"`, `"Initiation"`, `"Secteur"`; table columns `"Date d'envoi"`, `"Valeur"`, `"Broker"`, `"Type"`, `"Objectif"`, `"Recommandation"`, `"Ancien Objectif"`, `"Ancienne Recommandation"`. Compose screen fields: `"Émetteur"` (search placeholder `"Rechercher un émetteur"`, error `"Merci de saisir un émetteur"`), `"Titre de la note"` (optional), `"Broker"` (search placeholder `"Rechercher un broker"`, error `"Merci de saisir un broker"`), under the heading `"Informations de la note"`: `"Objectif"` (placeholder `"0.00"`, currency selector `"€"`/`"$"`/`"£"`/`"p"`/`"SFr"`, error `"L'objectif est requis"`) and `"Recommandation"` (error `"Le type est requis"`), checkboxes `"Secteur"` and `"Initiation"`; under the heading `"Changement de recommandation"`, a toggle of the same name revealing `"Ancien objectif"` and `"Ancienne recommandation"` (same error copy as the current-value equivalents when the toggle is on); checkbox `"Envoyer aussi par email"`; buttons `"Envoyer"` and `"Envoyer et continuer"` (the latter resets the form to compose another note immediately).

**Émetteurs** — list screen, search placeholder `"Rechercher un émetteur"`, checkbox `"Afficher les émetteurs archivés"`, button `"Ajouter un émetteur"`; table columns `"Valeurs"`, `"Id ric"`, `"Secteur"`, `"Utilisateurs associés"`, `"Statut"` (`"Actif"`/`"Archivé"`). Creation is a three-step wizard: step `"1. Informations"` (fields `"ID RIC"` with live look-up and error `"Ce code RIC n'existe pas"`, `"Nom"`, `"Langue"` as radio buttons `"Français"`/`"Anglais"`, `"Marché"`, `"Secteur"`, `"Sous-secteur"`); step `"2. Indices"` (`"Indice 1"`–`"Indice 4"`, all optional, each excluding whatever is already picked in the others); step `"3. Utilisateurs"` (repeatable blocks labelled `"Utilisateur {N}"`, each with `"Prénom"`, `"Nom"`, `"Poste"`, `"E-mail"` (regex-validated, error `"L'email est requis"` / `"Format d'email invalide"`), and a country-code-prefixed `"Téléphone"`). Navigation buttons `"Précédent"` / `"Suivant"` / `"Ajouter"`.

Company detail screen: tabs `"Informations"`, `"Listes"`, `"Utilisateurs"`, `"Imports"`, `"Factset"`; an `"Archiver"`/`"Désarchiver"` control with the warning banner `"Attention ! Émetteur archivé"` when archived. Informations tab shows read-only `"ID RIC"`, `"Nom"`, `"Langue"`, `"Marché"`, `"Secteur"`, `"Sous-secteur"`, and an `"INDICES"` block with an edit link `"Modifier"` opening a modal `"Modifier les indices"`. Listes tab: collapsible named lists each showing `"{N} éléments"`/`"{N} élément"`, with modals `"Créer une liste"`, `"Ajout d'un élément"`, `"Modifier une liste"`, and a delete confirmation titled `"Suppression d'un element"` (sic). Utilisateurs tab: table columns `"Nom"`, `"Poste"`, `"Adresse e-mail"`, `"N° de téléphone"`, `"CGU acceptées le"` (or `"Non"`), with edit/delete actions; the delete dialog is titled `"Suppression utilisateur"`. Imports tab: a type dropdown (placeholder `"Choose a type"`) and button `"Import a file"`. Factset tab: a left list of named Factset peers with `"Nom"`/`"ID"` fields and a `"Ajouter un nouveau pair Factset"` button, and a right-hand search/select panel for multiples with a `"Rechercher"` button, a list of checkboxes, and a `"Enregistrer"` button that shows the toast `"Enregistrement effectué avec succès"` on success.

**Disconnection monitoring** — see the verbatim copy already listed in full in §2.

**Admin home** (`"Administration"`) — a single card: title `"Monitoring des déconnexions"`, description `"Surveillez et analysez les déconnexions utilisateur en temps réel"`, linking to the disconnection screen.

**Version** — see §8 for the verbatim copy.

**"Les données !"** — a stub page under the `"Datas"` sidebar/route entry that renders only that literal sentence; this is clearly unfinished and should be treated as **dead** unless the rebuilding team has separate requirements for it.

**Global navigation (sidebar), verbatim, in order:** `"Rapports"`, `"Flashs"`, `"N. de brokers"`, `"Émetteurs"`, `"Version"`. A sixth item, a `"Monitoring"` entry pointing at the disconnection screen, exists in the code but is **commented out** of the menu — the screen is reachable only by direct URL.

**Toasts/global notifications** are rendered in the bottom-right corner and auto-dismiss.

---

## 11. Emails, notifications and scheduled jobs

**Account-creation email.** Sent synchronously from the account-creation endpoint. Subject, verbatim: **"Création de votre compte"**. The email is composed by an external email-template service (identified only by a numeric template id per environment — development/sandbox uses one id, production uses a different id configured in the cloud infrastructure, confirming the exact HTML body is **not** part of this repository and cannot be quoted here) and is filled with: the recipient's full name, their newly generated plain-text password, and the configured front-end website URL. Sender identity, every environment examined: from name **"Corporate Market Services"**, from/reply-to address **"rothschildandcocms@rothschildandco.com"**, sent via a third-party transactional email provider's API.

**Password-reset email.** Subject, verbatim: **"Réinitialisation de votre mot de passe"**. Filled with the recipient's full name and a reset link built as the configured front-end URL + a configured reset-password path + the one-time reset key. Same sender identity as above. The reset key/link, as stated in §2, is valid for **1 day**.

Both templates' actual visual HTML content lives only inside the third-party email-template service's own template editor (referenced only by numeric id from this codebase) and is therefore **not determinable from this repo**.

**Push notifications.** Sent through a dedicated mobile-push provider, triggered only as a side effect of sending a flash (see §5 for the exact title/body/sound/channel/badge rules). No other admin action (report sending, broker-note sending, version publishing) was found to trigger a push.

**Scheduled jobs.** No in-application scheduled job (no cron-style job defined in the Spring Boot application itself) was found anywhere in this repository for: end-of-day report generation/sending, audit-log cleanup/retention, or billing. The only scheduled automation found in the whole repository is **infrastructure-level, not business-logic**: two deployment pipeline schedules that restart the web application container — production restarts daily at **03:00**, the development environment restarts daily at **03:15** (both interpreted in whatever timezone the pipeline runner uses; not confirmed to be any particular business timezone). Any other recurring admin job (sending the end-of-day report on a timer, running the recommendation-spreadsheet import, exporting for billing) must presently be a **manual action performed by a person**, outside this application, and outside this repository.

---

## 12. Localisation

The admin front end's visible UI text is **entirely French**, hard-coded directly in the interface (no translation-key/value file was found for the admin screens — every label quoted in this document is the literal, only string shown; there is no English admin UI). The company-creation wizard does let the admin pick a company's own content language as `"Français"` (value `"fr-FR"`) or `"Anglais"` (value `"en-EN"`), but that choice governs the **client-facing** content language for that company's end users, not the admin tool's own interface language.

The backend validation/error message catalogue exists in two languages — a French bundle and an English bundle, with the key/value pairs already quoted verbatim throughout this document (§2, §3, §5, and the error tables above) — but because the admin front end never surfaces the English bundle in its own copy, the practical, user-visible admin experience is French-only. The rebuilding team should treat the backend's English strings as a reference for meaning, not as evidence that an English admin UI currently exists.

---

## 13. Foibles, workarounds and edge cases

- **An unauthenticated, data-mutating bulk-import endpoint exists in production-reachable configuration.** `POST /api/import` requires no login in every environment's security configuration examined (it sits on the same explicit allow-list as the login endpoint itself), accepts a JSON payload naming any of twenty-plus reference/data tables by key, and can be told to **wipe the target table before inserting** (several tables, including the broker list and the recommendation-change table, default to wiping first). Its own code comment describes it as **"Temporary endpoint"**. **Recommendation: the replacement must never expose an unauthenticated data-mutating endpoint; this is a straightforward broken-access-control defect (OWASP A01) and should be rebuilt as an authenticated, audited, idempotent import with per-row reporting**, matching the better-behaved per-company Excel import pattern rather than this one.
- **A hard-coded password/credential bypass for specific email prefixes.** Any new account whose email starts with `"cms1"` or `"cms2"` is given a fixed, hard-coded password hash (shared across every such account) instead of a generated one, and has terms-of-service and "must change password" silently pre-satisfied. **Recommendation: do not reproduce this. If demo/test accounts are needed, provision them through the same path as real accounts, with unique generated credentials.**
- **Attachment content is served without authentication.** The endpoint that streams a stored attachment's bytes by id sits on the same unauthenticated allow-list as login and the bulk import endpoint. Anyone who can guess or observe an attachment id can retrieve its content without being logged in. **Recommendation: require authentication (and ideally an authorization check that the caller is entitled to the related flash/broker-note/company) before serving attachment content.**
- **Two authentication realms, easy to confuse.** The admin back office authenticates via corporate SSO/session; the client-facing API authenticates via long-lived JWTs (validity configured at **two years**, with automatic refresh while more than roughly seven hundred days of other configured lifetime remain — i.e. tokens are effectively renewed almost immediately and rarely truly expire in normal use). A rebuild must keep these conceptually separate: "being an admin" is Azure AD group membership, not anything stored in the application's own user/role table.
- **The Azure AD group→role mapping code is defensive to the point of being fragile**: it has to handle at least three different shapes the identity provider might send the user's group membership in (a flat list of strings, a single nested list, or a single JSON-encoded string that itself needs re-parsing), with several fallbacks and broad exception swallowing. **Recommendation: pin down and document the exact, single shape the identity provider actually sends in each environment, and replace this defensive multi-shape parsing with one well-tested path.**
- **A typo is live in production copy**: the flash-compose "Subject" field's required-field error reads `"L'object est requis"` (missing the circumflex/should be "objet"). Decide deliberately whether to fix this in the rebuild or preserve it for continuity with support documentation/screenshots the CMS team may already have.
- **Dead/unfinished error strings referencing a "Super Admin" and account-deactivation-not-found scenario exist in the translation catalogue but are never thrown by any code path.** Do not build a "protect the Super Admin from deactivation" rule based on this — there is no Super Admin concept actually implemented.
- **A "limited access" role exists in name only.** `ROLE_EMITTER_LIMITED` is assignable but no code branches on it anywhere found; if the CMS team wants an actual reduced-permission role, it must be designed from scratch, not reverse-engineered from this repository.
- **The per-company ticker-matching logic used for Excel imports is exact-string-match only, with no normalisation** — different real-world ticker notations for the same instrument will not match unless they are byte-identical to the stored RIC, and nothing trims whitespace or case before comparing.
- **No audit-log retention policy exists** — the login/disconnection log table has no cleanup job and will grow without bound; plan retention deliberately in the rebuild.
- **The "limited access"/role distinction aside, there is effectively no row-level or feature-level authorization inside the admin API** — once a caller is authenticated (has a valid admin session with at least one allowed Azure AD group), every admin endpoint examined is reachable; there is no finer-grained "can this particular admin archive companies / only view reports" split.
- **Report locking is purely cooperative, not enforced**: the "someone else has this open" warning can be overridden by the second user choosing to take the lock; there is no server-side enforcement preventing two admins from editing concurrently and one silently overwriting the other's unsaved changes.
- **Several reference datasets (recommendation types, flash types, market list, sector list, broker list, index list) have no admin-UI create/edit/delete screen at all** — they are either fixed at initial deployment or only changeable through the unauthenticated bulk-import endpoint described above. The rebuilding team should treat "manage reference data" as a feature to design properly, not one to copy.

---

## Not determinable from this repo

- **"OWS"**: what it is, and the exact mechanics of how the CMS team's recommendation/target-price spreadsheet becomes the JSON payload accepted by the generic import endpoint. No conversion tool, script, or documentation for this step exists in this repository.
- **The actual visual content of the account-creation and password-reset emails** — both are rendered by a third-party email-template service and referenced here only by a numeric template id per environment; the template bodies themselves are not in this repository.
- **Whether sending the end-of-day report, beyond marking it "sent" in the database, does anything further (email digest, push, PDF generation)** — no such code was found in the areas reviewed, but a scheduled job or a part of the system not covered by this review cannot be ruled out with certainty.
- **The exact current contents of several reference tables** (recognised recommendation values, market list, sector list, index list, broker list) — these are rows in the live database, seeded once from bundled configuration files and subsequently only ever bulk-replaced; their present contents cannot be read from source code alone.
- **Any billing/invoicing process** — entirely absent from this repository; if it exists at all, it lives in a different system.
- **Any dedicated valuation-import feature** — entirely absent from this repository.
- **A reusable, named "send list" of recipients** — entirely absent from this repository; see §6 for the closest related feature found.
- **Whether a user's notification-tracking timestamps are reset when their assigned company changes** — the fields exist but no code path that mutates them on a company change was found or ruled out definitively.
- **Whether the client app enforces the "must change password" flag at login** — that enforcement, if any, lives in the separate client application, not in this repository.
- **The full, current list of Azure AD group names that grant admin access in the production environment** — only the development environment's allow-list values were found in configuration examined directly; production's equivalent values are supplied by the cloud infrastructure configuration and were only partially visible.

## Questions the Engage team should ask next

1. What system is "OWS", and can we see the script/process (if any exists) that turns the CMS team's spreadsheet into the JSON payload currently posted to the generic import endpoint? Who runs it, and how often?
2. Is the unauthenticated bulk-import endpoint actually reachable from outside the corporate network today, or is it protected by a network perimeter not visible in this repository (e.g. a firewall rule, VPN-only exposure)? This materially changes the severity of the finding in §13.
3. Can we see the actual rendered HTML of the account-creation and password-reset emails (export them from the third-party email-template service), so the rebuild can match them exactly rather than approximate them from the variable names alone?
4. Is `ROLE_EMITTER_LIMITED` meant to restrict anything today, or is it simply unused? If it is meant to restrict something, what, specifically?
5. What does the CMS team mean by "send lists" — is it the per-company ticker/peer lists, the ad-hoc recipient multi-select on flash/report screens, or a feature they want built fresh?
6. Is there a billing export or valuation-import feature that lives in a different repository/system entirely, and if so, which one, so it can be scoped into this rebuild or explicitly excluded?
7. What exactly should happen when the end-of-day report is marked "sent" — is there an expected email/push/PDF step that simply was not found in the areas of code reviewed, or does "sent" purely mean "now visible in the client app"?
8. Who currently has the authority (and the means) to change the broker list, market list, sector list, recommendation-type list, or flash-type list, given there is no admin-UI screen for any of them today? Is this done by a developer running a script, or by someone on the CMS team directly against the database?
9. What is the intended retention period for the login/disconnection audit log, for compliance purposes?
10. Are the "cms1"/"cms2" hard-coded demo accounts still in active use anywhere (training, demos, testing), and is there a safe way to decommission them during the rebuild?

---

## 14. Completeness checklist

- [x] Every admin feature listed with live / unused / dead status — §1
- [x] User creation, entitlement model and every role documented as rules — §2
- [x] Initial credential delivery and every email template quoted verbatim — §2, §11 (template IDs and variables given; visual HTML body itself is external and flagged under "Not determinable from this repo")
- [x] Target price upload: accepted format, every row-handling rule, re-upload rules — §3
- [x] OWS relationship and the data path to the client app explained — §0, §3 (flagged as not determinable where the trail runs out)
- [x] End-of-day summaries: format, timing, generation and delivery — §4
- [x] Flash editor stored format and allowed formatting specified exactly — §5
- [x] Flash lifecycle and push rules covered — §5
- [x] Every admin endpoint defined swagger-style with all errors — §9
- [x] Every screen covered with verbatim copy and validation — §10 (and inline within §2–§8 where screens are discussed alongside their business rules)
- [x] Scheduled jobs and manual steps listed — §11
- [x] Foibles section written, with a recommendation per item — §13
- [x] No source code or file paths anywhere in the file
- [x] "Not determinable from this repo" and "Questions to ask next" present — above
