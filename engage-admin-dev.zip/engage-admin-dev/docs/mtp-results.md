# MTP results

Verified by: 🤖 UI/integration test · 🕹️ agent-driven · 🧑 manual (owner). Result: PASS / FAIL / NOT TESTED.

| MTP-ID | Verified by | Date run | Result | Notes |
|---|---|---|---|---|
| MTP-ADMF-001 | | | NOT TESTED | manual, needs a real Entra tenant. Waived for acceptance by owner decision 2026-10-12 (plan Increment); stand-in covered by 022 to 024 |
| MTP-ADMF-002 | | | NOT TESTED | manual, needs a real Entra tenant. Waived for acceptance by owner decision 2026-10-12 (plan Increment); stand-in covered by 022 to 024 |
| MTP-ADMF-003 | 🤖 | 2026-10-12 | PASS | e2e/shell.spec.ts |
| MTP-ADMF-004 | 🤖 | 2026-10-12 | PASS | e2e/shell.spec.ts |
| MTP-ADMF-005 | 🤖 | 2026-10-12 | PASS | e2e/shell.spec.ts |
| MTP-ADMF-006 | 🤖 | 2026-10-12 | PASS | Mock half only (e2e/shell.spec.ts). Entra half covered against the stand-in by MTP-ADMF-024; real-tenant pass waits with 001 and 002 |
| MTP-ADMF-007 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-008 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-009 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-010 | 🤖 | 2026-10-12 | PASS | e2e/addCompany.spec.ts |
| MTP-ADMF-011 | 🤖 | 2026-10-12 | PASS | e2e/addCompany.spec.ts |
| MTP-ADMF-012 | 🤖 | 2026-10-12 | PASS | e2e/addCompany.spec.ts |
| MTP-ADMF-013 | 🤖 | 2026-10-12 | PASS | e2e/addCompany.spec.ts |
| MTP-ADMF-014 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-015 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-016 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-017 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-018 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-019 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-020 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-021 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-ADMF-022 | 🤖 | 2026-10-12 | PASS | e2e/entraMock.spec.ts |
| MTP-ADMF-023 | 🤖 | 2026-10-12 | PASS | e2e/entraMock.spec.ts |
| MTP-ADMF-024 | 🤖 | 2026-10-12 | PASS | e2e/entraMock.spec.ts |
| MTP-REP-001 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-002 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-003 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-004 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-005 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts; reload step covered by reopening in-app (mock writes reset on reload), real reload needs a manual pass against the gateway |
| MTP-REP-006 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts; reload step covered by reopening in-app |
| MTP-REP-007 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-008 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-009 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-010 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-011 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-012 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-REP-013 | 🤖 | 2026-10-12 | PASS | e2e/reports.spec.ts |
| MTP-FLS-001 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-002 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-003 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-004 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-005 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-006 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-007 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-008 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-FLS-009 | 🤖 | 2026-10-12 | PASS | e2e/flashes.spec.ts |
| MTP-BRN-001 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-002 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-003 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-004 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-005 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-006 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-007 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-008 | 🤖 | 2026-10-12 | PASS | e2e/brokerNotes.spec.ts |
| MTP-BRN-009 | 🤖 | 2026-10-12 | PASS | src/screens/BrokerNotes/SendBrokerNoteScreen.test.tsx |
| MTP-CTAB-001 | 🤖 | 2026-10-12 | PASS | e2e/companyLists.spec.ts |
| MTP-CTAB-002 | 🤖 | 2026-10-12 | PASS | e2e/companyLists.spec.ts |
| MTP-CTAB-003 | 🤖 | 2026-10-12 | PASS | e2e/companyLists.spec.ts |
| MTP-CTAB-004 | 🤖 | 2026-10-12 | PASS | e2e/companyLists.spec.ts |
| MTP-CTAB-005 | 🤖 | 2026-10-12 | PASS | e2e/companyLists.spec.ts |
| MTP-CTAB-006 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-CTAB-007 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-CTAB-008 | 🤖 | 2026-10-12 | PASS | e2e/companies.spec.ts |
| MTP-VMON-001 | 🤖 | 2026-10-12 | PASS | e2e/version.spec.ts |
| MTP-VMON-002 | 🤖 | 2026-10-12 | PASS | e2e/version.spec.ts |
| MTP-VMON-003 | 🤖 | 2026-10-12 | PASS | e2e/version.spec.ts |
| MTP-VMON-004 | 🤖 | 2026-10-12 | PASS | e2e/monitoring.spec.ts |
| MTP-VMON-005 | 🤖 | 2026-10-12 | PASS | e2e/monitoring.spec.ts |
| MTP-VMON-006 | 🤖 | 2026-10-12 | PASS | e2e/monitoring.spec.ts |
| MTP-VMON-007 | 🤖 | 2026-10-12 | PASS | e2e/monitoring.spec.ts |
| MTP-VMON-008 | 🤖 | 2026-10-12 | PASS | e2e/monitoring.spec.ts |
| MTP-GWA-001 |  | 2026-10-13 | WITHDRAWN | Withdrawn 2026-10-13: myCMS has no such control. |
| MTP-GWA-002 | 🤖 | 2026-10-13 | PASS | e2e/companies.spec.ts |
| MTP-GWA-003 | 🤖 | 2026-10-13 | PASS | e2e/companies.spec.ts |
| MTP-GWA-004 | 🤖 | 2026-10-13 | PASS | e2e/reports.spec.ts |
| MTP-GWA-005 | 🤖 | 2026-10-13 | PASS | e2e/reports.spec.ts |
| MTP-LANG-001 | 🤖 | 2026-10-13 | PASS | e2e/language.spec.ts MTP-LANG-001 |
| MTP-LANG-002 | 🤖 | 2026-10-13 | PASS | e2e/language.spec.ts MTP-LANG-002 (French and English browser) |
| MTP-LANG-003 | 🤖 | 2026-10-13 | PASS | e2e/entraMock.spec.ts MTP-LANG-003 |
| MTP-LANG-004 | 🤖 | 2026-10-13 | PASS | e2e/language.spec.ts MTP-LANG-004 |
| MTP-LANG-005 | 🤖 | 2026-10-13 | PASS | e2e/language.spec.ts MTP-LANG-005 |
| MTP-LANG-006 | 🤖 | 2026-10-13 | PASS | e2e/language.spec.ts MTP-LANG-006 |
| MTP-LANG-007 | 🤖 | 2026-10-13 | PASS | e2e/language.spec.ts MTP-LANG-007 |
| MTP-GWC-001 | 🤖 | 2026-10-13 | PASS | e2e/addCompany.spec.ts MTP-GWC-001 |
| MTP-GWC-002 | 🤖 | 2026-10-13 | PASS | e2e/flashes.spec.ts MTP-GWC-002 |
| MTP-HOST-001 | 🕹️ | 2026-10-14 | PASS | docker:build then docker:run (engage-admin:local). curl: / and /engage-admin both 301 to http://localhost:8080/engage-admin/. Headless Chromium: landed on /engage-admin/companies, "Local Admin" and the LVMH row visible. |
| MTP-HOST-002 | 🕹️ | 2026-10-14 | PASS | Same container. /engage-admin/companies and /engage-admin/companies/c1 return 200 with index.html; in Chromium both reloads show data (LVMH, LVMH.PA) and the Companies sidebar link. |
| MTP-HOST-003 | 🕹️ | 2026-10-14 | PASS | docker run -e ENTRA_MOCK=1. config.js served as window.__ENGAGE_ADMIN_CONFIG__ = {"entraMock": "1"}; Chromium shows the "Sign in with Microsoft" button and no Local Admin. |
| MTP-HOST-004 | | | NOT TESTED | |
