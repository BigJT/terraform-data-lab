# Hosting plan

- Slug: hosting
- MTP prefix: HOST
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-14

## What we're building

Engage Admin packaged for Azure Kubernetes Service, so John and the DevOps team can deploy it to the Engage namespace in AKS dev.

1. The app is served under `/engage-admin/` (like Engage-Web under `/engage/`). Visiting `/` or `/engage-admin` redirects to `/engage-admin/`. Deep links such as `/engage-admin/companies` load on refresh.
2. One Docker image works in every environment. The gateway address and the Entra ids are read when the container starts, from environment variables, not baked in at build. With no gateway address the image runs on the built-in sample data, which is enough for a first deployment.
3. An Azure DevOps pipeline (`azure-pipelines.yml`) builds, tests, pushes the image and applies a Kubernetes manifest (`deploy/aks.yaml`). Values only DevOps know are clearly marked blanks.

Developers keep `npm run dev`, `npm run dev:entra-mock`, the tests and `.env.local` exactly as now.

## API research

Checked 2026-10-14.

- **Image tags** (Docker Hub tag listing, 2026-10-14): `node:22.22.3-alpine3.24` (the repo's `engines` asks for Node >= 22) and `nginx:1.31.6-alpine`. Engage-Web pins older tags (`node:20.20.2-alpine3.23`, `nginx:1.31.2-alpine`); we take the current ones.
- **Official nginx image:** runs every executable `*.sh` in `/docker-entrypoint.d/` before starting nginx. Our config-writing script goes there, so no custom entrypoint is needed.
- **Vite `base`:** `base: '/engage-admin/'` prefixes built asset URLs and exposes the value as `import.meta.env.BASE_URL` (`'/engage-admin/'`) in code. The dev server also serves under the base. Files in `public/` are served at `{base}{file}`.
- **MSW:** `worker.start({ serviceWorker: { url } })` sets the worker script URL; it must be `${import.meta.env.BASE_URL}mockServiceWorker.js` once the app is under a base path.
- **React Router:** `<BrowserRouter basename>` takes the base without the trailing slash: `'/engage-admin'`.
- **Assumed:** a classic `<script src="/config.js">` in `index.html` is rewritten by Vite to `/engage-admin/config.js` at build. HOST-T01 checks this in `dist/index.html`; if Vite does not rewrite it, use `%BASE_URL%config.js` instead (Vite's HTML constant replacement).

## Code survey

- `vite.config.ts`: no `base`; dev port 5174; Vitest env sets `VITE_GATEWAY_URL: 'http://gateway.test'`.
- `src/main.tsx`: `startMocks()` starts the msw worker when `import.meta.env.VITE_GATEWAY_URL` is empty; `worker.start({ onUnhandledFrame: 'bypass' })` with the default worker URL.
- Settings read today, each straight from `import.meta.env`: `src/main.tsx:7` (`VITE_GATEWAY_URL`), `src/data/GatewayProvider.tsx:11` (`VITE_GATEWAY_URL`), `src/auth/entraAuth.ts:31-36` (`VITE_ENTRA_MOCK`, `VITE_ENTRA_TENANT_ID`, `VITE_ENTRA_CLIENT_ID`, `VITE_API_SCOPE`), `src/app/App.tsx:17` (`VITE_ENTRA_MOCK`).
- `src/auth/entraAuth.ts:42`: `redirectUri: window.location.origin`.
- Root-relative navigations: `src/auth/fakeMsal.ts:7` `mockSignInPath = '/mock-entra-sign-in'`, `:54` `browserLocation.assign(mockSignInPath)`, `:60` `browserLocation.replace('/')`; `src/auth/mockAuth.ts:12` and `src/screens/MockEntraSignIn/MockEntraSignInScreen.tsx:11` `browserLocation.replace('/')`; `src/app/App.tsx:17` compares `window.location.pathname === mockSignInPath`.
- `src/app/App.tsx:36`: `<BrowserRouter>` without basename.
- `index.html`: loads `/src/main.tsx` only. `public/` holds `mockServiceWorker.js` only.
- `playwright.config.ts`: `baseURL` `http://localhost:5174` (chromium) and `http://localhost:5175` (entra-mock); `webServer` urls the same. 72 `page.goto('/...')` calls across 10 spec files, and `toHaveURL(/\/companies$/)`-style checks in 7 files.
- `.env.example` lists `VITE_GATEWAY_URL`, `VITE_ENTRA_TENANT_ID`, `VITE_ENTRA_CLIENT_ID`, `VITE_API_SCOPE`, `VITE_ENTRA_MOCK`.
- References: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Web/Dockerfile` and `nginx.conf`; `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Automation-Demo/azure-pipelines.yml` and `deploy/aks.yaml`.
- **Will break:** every Playwright `page.goto('/x')` (absolute paths drop the base) and the URL assertions; unit tests that assert `browserLocation.replace('/')` or `assign('/mock-entra-sign-in')`; the Entra redirect URI test if any. HOST-T01 reconciles them.

Seams and coverage:
- Seam A, unit: the config reader `appConfig()` (window config wins, env fallback, empty gateway means mock mode). Automated.
- Seam B, Vitest running the config script with `sh` against a temp directory (values written, quotes and backslashes escaped, unset variables omitted). Automated.
- Seam C, the existing Playwright suite under `/engage-admin/`. Automated.
- Building and running the image (`docker build`, `docker run`): manual MTP, because the headless build loop cannot rely on a Docker daemon. Owner runs it.
- The pipeline and manifest in AKS dev: manual MTP for John and DevOps, because they need the registry, cluster and service connections.

## Implementation approach / decisions

Owner decisions, 2026-10-14:

1. **Azure DevOps pipeline like Engage Flow** (`azure-pipelines.yml`, stages Verify, Image, Deploy). No GitHub Actions.
2. **Served under `/engage-admin/`.**
3. **Settings read at container start, one image for every environment.**
4. **Include a Kubernetes manifest** `deploy/aks.yaml` (Deployment, Service, Ingress).

Pinned for the build:

5. **Base path in the app.** `vite.config.ts` `base: '/engage-admin/'`. `<BrowserRouter basename="/engage-admin">`. msw `worker.start({ onUnhandledFrame: 'bypass', serviceWorker: { url: `${import.meta.env.BASE_URL}mockServiceWorker.js` } })`. Root-relative navigations become base-relative: `mockSignInPath` becomes `` `${import.meta.env.BASE_URL}mock-entra-sign-in` `` (`/engage-admin/mock-entra-sign-in`), and every `browserLocation.replace('/')` becomes `browserLocation.replace(import.meta.env.BASE_URL)`. Entra `redirectUri` becomes `` `${window.location.origin}${import.meta.env.BASE_URL}` ``.
6. **Entra redirect URIs to register** (single-page application platform): `http://localhost:5174/engage-admin/` and `http://localhost:5175/engage-admin/` for local work, plus `https://<host>/engage-admin/` per deployed environment.
7. **Runtime config.** `public/config.js` contains exactly `window.__ENGAGE_ADMIN_CONFIG__ = {}` and `index.html` loads it with `<script src="/config.js"></script>` in `<head>`, before the app script (see the assumption in API research). New module `src/config.ts` exports `type AppConfig = {gatewayUrl: string, entraTenantId: string, entraClientId: string, apiScope: string, entraMock: boolean}` and `appConfig(): AppConfig`. Each field is taken from `window.__ENGAGE_ADMIN_CONFIG__` when that key is a non-empty string, otherwise from `import.meta.env` (`VITE_GATEWAY_URL`, `VITE_ENTRA_TENANT_ID`, `VITE_ENTRA_CLIENT_ID`, `VITE_API_SCOPE`), otherwise `''`. `entraMock` is true when the window key `entraMock` is `'1'`, else when `VITE_ENTRA_MOCK === '1'`. Declare the window property in `src/vite-env.d.ts`. All five current `import.meta.env` reads (code survey) go through `appConfig()`. Empty `gatewayUrl` means mock mode, as today.
8. **Window config keys and container variables.** Keys: `gatewayUrl`, `entraTenantId`, `entraClientId`, `apiScope`, `entraMock`. Container environment variables, one per key: `GATEWAY_URL`, `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, `API_SCOPE`, `ENTRA_MOCK`.
9. **Config script** `docker/40-engage-admin-config.sh` (POSIX `sh`, executable), copied to `/docker-entrypoint.d/` in the image. It writes `${CONFIG_FILE:-/usr/share/nginx/html/engage-admin/config.js}` as `window.__ENGAGE_ADMIN_CONFIG__ = {...}` with one `"key": "value"` pair per set, non-empty variable, in the order above, separated by `, `. Values are JSON-escaped: backslash becomes `\\`, double quote becomes `\"`, and any carriage return or newline is removed. Unset or empty variables are left out, so no variables gives `window.__ENGAGE_ADMIN_CONFIG__ = {}`. Exit 0.
10. **Dockerfile** (repo root), two stages. Build: `FROM node:22.22.3-alpine3.24 AS builder`, `WORKDIR /app`, copy `package.json` and `package-lock.json`, `RUN npm ci`, copy the rest, `RUN npm run build`. Serve: `FROM nginx:1.31.6-alpine`, copy `nginx.conf` to `/etc/nginx/conf.d/default.conf`, `RUN rm -f /usr/share/nginx/html/index.html`, copy `/app/dist` to `/usr/share/nginx/html/engage-admin`, copy `docker/40-engage-admin-config.sh` to `/docker-entrypoint.d/40-engage-admin-config.sh` and `chmod +x` it, `EXPOSE 80`, `CMD ["nginx", "-g", "daemon off;"]`. `.dockerignore`: `node_modules`, `dist`, `test-results`, `playwright-report`, `.git`, `.githooks`, `.env*`, `docs`, `e2e`.
11. **nginx.conf** (repo root): `listen 80`, `root /usr/share/nginx/html`, `absolute_redirect off`; `location = / { return 301 /engage-admin/; }`; `location = /engage-admin { return 301 /engage-admin/; }`; `location /engage-admin/assets/ { add_header Cache-Control "public, max-age=31536000, immutable"; }`; `location = /engage-admin/config.js { add_header Cache-Control "no-store"; }`; `location /engage-admin/ { add_header Cache-Control "no-cache"; try_files $uri $uri/ /engage-admin/index.html; }`.
12. **npm scripts:** `"docker:build": "docker build -t engage-admin:local ."` and `"docker:run": "docker run --rm -p 8080:80 engage-admin:local"`.
13. **Pipeline** `azure-pipelines.yml`, modelled on Flow's: trigger on `main`; variables block with comments: `containerRegistry: REGISTRY.azurecr.io # the registry's login server`, `imageName: engage-admin`, `hostName: HOST # the hostname DevOps assigns`, `azureServiceConnection: AZURE_SERVICE_CONNECTION # Azure Resource Manager service connection with AcrPush on the registry`, `kubernetesServiceConnection: KUBERNETES_SERVICE_CONNECTION # Kubernetes service connection to the namespace`, `namespace: engage # to confirm with John`. Stage Verify: Node `22.x`, `npm ci`, `npx playwright install --with-deps chromium`, `npm run verify`. Stage Image: build and push `$(containerRegistry)/$(imageName)` tagged `$(Build.BuildId)` and `latest`. Stage Deploy: apply `deploy/aks.yaml` to `$(namespace)` with the image set to the `$(Build.BuildId)` tag and `HOST` replaced by `$(hostName)`.
14. **Manifest** `deploy/aks.yaml`: header comment "Replace REGISTRY with the container registry and HOST with the hostname DevOps assigns. Set the env values per environment; leave GATEWAY_URL empty to run on sample data." Deployment `engage-admin` (1 replica, image `REGISTRY/engage-admin:latest`, containerPort 80, env `GATEWAY_URL`, `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, `API_SCOPE` each `value: ""`, readinessProbe `httpGet` path `/engage-admin/` port 80, resources requests cpu `50m` memory `64Mi`, limits cpu `250m` memory `128Mi`); Service `engage-admin` port 80 to targetPort 80; Ingress `engage-admin` host `HOST`, path `/engage-admin` pathType `Prefix` to service `engage-admin` port 80.
15. **Docs.** README gains a "Deploying" section: the image, the five container variables, the redirect URIs from decision 6, `npm run docker:build` / `docker:run`, and the pipeline blanks. CLAUDE.md notes the base path, `src/config.ts` as the only place settings are read, and that `.env.example` names stay for local work.

## Manual test plan (definition of done)

MTP-HOST-001 to MTP-HOST-004 (rows in `docs/manual-test-plan.md`, execution in `docs/mtp-results.md`). All four are manual: 001 to 003 need a Docker daemon (owner), 004 needs AKS (John and DevOps). The base path itself is covered by the full Playwright suite running under `/engage-admin/`.

## Out of scope / open questions

Out of scope: GitHub Actions, TLS and DNS, the &Co repository move, the Entra registrations themselves.

Open (none block the build): the AKS namespace name (assumed `engage`), the registry, host name and service connections (John); whether the ingress controller needs annotations (DevOps).

## Review notes

- 2026-10-14 (`/feature-review`, headless): the Image stage used `Docker@2` with the Azure Resource Manager connection, but `Docker@2` takes a Docker registry service connection. Switched to Flow's `AzureCLI@2` + `az acr build`, which uses the ARM connection as the variable comment describes. Not accepted yet: MTP-HOST-001 to 004 are manual and still NOT TESTED.
