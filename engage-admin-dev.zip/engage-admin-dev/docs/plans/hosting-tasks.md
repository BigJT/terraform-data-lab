# Hosting tasks

- Plan: docs/plans/hosting-plan.md
- MTP prefix: HOST
- Branch: commit directly on `dev`, push as each task lands. No worktree, no PR.
- MTP rows live in `docs/manual-test-plan.md`; record results in `docs/mtp-results.md`. Every task ends with `npm run verify` green.

## HOST-T01: Serve under /engage-admin/ and read settings at start-up
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: none
- Satisfies: none of the manual rows directly; prerequisite for MTP-HOST-001 to 003 (base path covered by the whole Playwright suite)
- Test approach: unit test at seam A for `appConfig()` (window value wins over env; env used when the window key is missing or empty; all empty gives `gatewayUrl: ''`; `entraMock` true from window `'1'`, else from `VITE_ENTRA_MOCK === '1'`, else false); unit tests for the base-relative redirects (`browserLocation.replace('/engage-admin/')`, `assign('/engage-admin/mock-entra-sign-in')`) and the Entra `redirectUri` (`http://localhost:3000/engage-admin/` under jsdom's origin, or whatever `window.location.origin` is); full Playwright suite green under the new base; after `npm run build`, a check that `dist/index.html` references `/engage-admin/config.js`.
- Model:
- What to build:
  - `vite.config.ts`: `base: '/engage-admin/'`.
  - `src/app/App.tsx`: `<BrowserRouter basename="/engage-admin">`.
  - `src/main.tsx`: `worker.start({ onUnhandledFrame: 'bypass', serviceWorker: { url: `${import.meta.env.BASE_URL}mockServiceWorker.js` } })`; mock mode decided by `appConfig().gatewayUrl === ''`.
  - New `src/config.ts`: `export type AppConfig = { gatewayUrl: string; entraTenantId: string; entraClientId: string; apiScope: string; entraMock: boolean }` and `export function appConfig(): AppConfig`. Each string field from `window.__ENGAGE_ADMIN_CONFIG__?.<key>` when it is a non-empty string, else from `import.meta.env` (`gatewayUrl` from `VITE_GATEWAY_URL`, `entraTenantId` from `VITE_ENTRA_TENANT_ID`, `entraClientId` from `VITE_ENTRA_CLIENT_ID`, `apiScope` from `VITE_API_SCOPE`), else `''`. `entraMock`: window key `entraMock === '1'`, else `import.meta.env.VITE_ENTRA_MOCK === '1'`. Declare `interface Window { __ENGAGE_ADMIN_CONFIG__?: Partial<Record<'gatewayUrl' | 'entraTenantId' | 'entraClientId' | 'apiScope' | 'entraMock', string>> }` in `src/vite-env.d.ts`.
  - Replace every direct settings read with `appConfig()`: `src/main.tsx:7`, `src/data/GatewayProvider.tsx:11`, `src/auth/entraAuth.ts:31-36`, `src/app/App.tsx:17`. No `import.meta.env.VITE_` read may remain outside `src/config.ts`.
  - Base-relative navigation: `src/auth/fakeMsal.ts` `mockSignInPath = `${import.meta.env.BASE_URL}mock-entra-sign-in``; every `browserLocation.replace('/')` (`src/auth/fakeMsal.ts:60`, `src/auth/mockAuth.ts:12`, `src/screens/MockEntraSignIn/MockEntraSignInScreen.tsx:11`) becomes `browserLocation.replace(import.meta.env.BASE_URL)`. `src/auth/entraAuth.ts` `redirectUri: `${window.location.origin}${import.meta.env.BASE_URL}``.
  - `public/config.js` with exactly `window.__ENGAGE_ADMIN_CONFIG__ = {}`; `index.html` gets `<script src="/config.js"></script>` in `<head>` before the module script. Build and check `dist/index.html` contains `/engage-admin/config.js`; if Vite left it as `/config.js`, change the tag to `<script src="%BASE_URL%config.js"></script>` and check again.
  - Playwright: `baseURL` becomes `http://localhost:5174/engage-admin/` and `http://localhost:5175/engage-admin/`, and both `webServer.url` values gain `/engage-admin/`. In every spec, `page.goto('/x')` becomes `page.goto('x')` and `page.goto('/')` becomes `page.goto('')`, so paths resolve under the base. URL assertions that anchor on the path (e.g. `toHaveURL(/\/companies$/)`) keep working; fix any that assume the path starts at `/`.
  - Update unit tests that assert the old root redirects or redirect URI.
  - `.env.example` keeps its five `VITE_` names for local work.
- Acceptance: the whole existing suite passes under `/engage-admin/`; no `VITE_` read outside `src/config.ts`.
- Commit: cf98841

## HOST-T02: Docker image, nginx and the start-up config script
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: HOST-T01
- Satisfies: MTP-HOST-001, MTP-HOST-002, MTP-HOST-003
- Test approach: integration test at seam B: a Vitest file that runs `sh docker/40-engage-admin-config.sh` with `CONFIG_FILE` pointing into a temp directory and asserts the file content for (a) no variables: `window.__ENGAGE_ADMIN_CONFIG__ = {}`; (b) `GATEWAY_URL=https://gw.example` and `ENTRA_MOCK=1`: `window.__ENGAGE_ADMIN_CONFIG__ = {"gatewayUrl": "https://gw.example", "entraMock": "1"}`; (c) a value containing `"` and `\` comes out escaped as `\"` and `\\`; (d) an empty `API_SCOPE=` is left out. Rows 001 to 003 are manual MTP only (need a Docker daemon; owner runs them).
- Model: sonnet
- What to build:
  - `docker/40-engage-admin-config.sh` (POSIX `sh`, mode 755): writes `${CONFIG_FILE:-/usr/share/nginx/html/engage-admin/config.js}` as `window.__ENGAGE_ADMIN_CONFIG__ = {` + pairs + `}`; pairs, in this order, only for set and non-empty variables: `GATEWAY_URL` as `"gatewayUrl"`, `ENTRA_TENANT_ID` as `"entraTenantId"`, `ENTRA_CLIENT_ID` as `"entraClientId"`, `API_SCOPE` as `"apiScope"`, `ENTRA_MOCK` as `"entraMock"`; each pair `"key": "value"`, joined with `, `; values escaped (backslash to `\\`, `"` to `\"`, carriage returns and newlines removed). Exits 0.
  - `Dockerfile` at the repo root: stage `FROM node:22.22.3-alpine3.24 AS builder`, `WORKDIR /app`, `COPY package.json package-lock.json ./`, `RUN npm ci`, `COPY . .`, `RUN npm run build`; stage `FROM nginx:1.31.6-alpine`, `COPY nginx.conf /etc/nginx/conf.d/default.conf`, `RUN rm -f /usr/share/nginx/html/index.html`, `COPY --from=builder /app/dist /usr/share/nginx/html/engage-admin`, `COPY docker/40-engage-admin-config.sh /docker-entrypoint.d/40-engage-admin-config.sh`, `RUN chmod +x /docker-entrypoint.d/40-engage-admin-config.sh`, `EXPOSE 80`, `CMD ["nginx", "-g", "daemon off;"]`. Comment each stage as Engage-Web does.
  - `.dockerignore`: `node_modules`, `dist`, `test-results`, `playwright-report`, `.git`, `.githooks`, `.env*`, `docs`, `e2e`.
  - `nginx.conf` at the repo root: `server { listen 80; server_name _; root /usr/share/nginx/html; index index.html; absolute_redirect off; location = / { return 301 /engage-admin/; } location = /engage-admin { return 301 /engage-admin/; } location /engage-admin/assets/ { add_header Cache-Control "public, max-age=31536000, immutable"; } location = /engage-admin/config.js { add_header Cache-Control "no-store"; } location /engage-admin/ { add_header Cache-Control "no-cache"; try_files $uri $uri/ /engage-admin/index.html; } }`, commented like Engage-Web's.
  - `package.json` scripts: `"docker:build": "docker build -t engage-admin:local ."`, `"docker:run": "docker run --rm -p 8080:80 engage-admin:local"`.
  - Make sure Prettier and ESLint ignore or accept the new files (add `docker/` to the relevant ignore lists only if a check fails on them).
- Acceptance: the script tests pass; the owner runs MTP-HOST-001 to 003.
- Commit: 3726b2e

## HOST-T03: Azure DevOps pipeline, Kubernetes manifest and deployment docs
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: HOST-T02
- Satisfies: MTP-HOST-004
- Test approach: manual MTP only (needs the registry, AKS cluster and service connections; John and DevOps run it). In the loop, check both YAML files parse (`node -e` with the `yaml` package if already installed, otherwise `npx --yes yaml@2 valid < file`; skip silently is not allowed: if neither works, state it in the task notes).
- Model: sonnet
- What to build:
  - `azure-pipelines.yml`, modelled on `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Automation-Demo/azure-pipelines.yml`: header comment "Builds Engage Admin, pushes the image and applies the Kubernetes manifest. Fill in the variables marked below."; `trigger: branches: include: [main]`; variables `containerRegistry: REGISTRY.azurecr.io # the registry's login server`, `imageName: engage-admin`, `hostName: HOST # the hostname DevOps assigns`, `azureServiceConnection: AZURE_SERVICE_CONNECTION # Azure Resource Manager service connection with AcrPush on the registry`, `kubernetesServiceConnection: KUBERNETES_SERVICE_CONNECTION # Kubernetes service connection to the namespace`, `namespace: engage # to confirm with John`. Stage `Verify` (vmImage `ubuntu-latest`): `NodeTool@0` versionSpec `22.x`, `npm ci`, `npx playwright install --with-deps chromium`, `npm run verify`. Stage `Image` (dependsOn Verify): `Docker@2` buildAndPush with `containerRegistry: $(azureServiceConnection)`, repository `$(imageName)`, tags `$(Build.BuildId)` and `latest`. Stage `Deploy` (dependsOn Image): replace `HOST` with `$(hostName)` and `REGISTRY` with `$(containerRegistry)` in `deploy/aks.yaml`, then `KubernetesManifest@1` deploy to `$(namespace)` via `$(kubernetesServiceConnection)` with containers `$(containerRegistry)/$(imageName):$(Build.BuildId)`.
  - `deploy/aks.yaml`: header comment "Engage Admin on Kubernetes: one nginx pod behind an ingress. Replace REGISTRY with the container registry and HOST with the hostname DevOps assigns. Set the env values per environment; leave GATEWAY_URL empty to run on sample data." Deployment `engage-admin` (labels `app: engage-admin`, replicas 1, container `web`, image `REGISTRY/engage-admin:latest`, containerPort 80, env `GATEWAY_URL`, `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, `API_SCOPE` each with `value: ""`, readinessProbe `httpGet` path `/engage-admin/` port 80, resources requests cpu `50m` memory `64Mi`, limits cpu `250m` memory `128Mi`). Service `engage-admin`, selector `app: engage-admin`, port 80 targetPort 80. Ingress `engage-admin`, rule host `HOST`, path `/engage-admin` pathType `Prefix`, backend service `engage-admin` port 80.
  - README: a "Deploying" section listing the image (`npm run docker:build`, `npm run docker:run`, then http://localhost:8080/engage-admin/), the five container variables `GATEWAY_URL`, `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, `API_SCOPE`, `ENTRA_MOCK` and what each does, the Entra redirect URIs `http://localhost:5174/engage-admin/`, `http://localhost:5175/engage-admin/` and `https://<host>/engage-admin/` (single-page application platform), and the pipeline variables to fill in.
  - CLAUDE.md: note the base path `/engage-admin/`, that `src/config.ts` is the only place settings are read (window config first, then `VITE_` env), and that `.env.example` names stay for local development.
- Acceptance: both YAML files parse; MTP-HOST-004 is run by John and DevOps.
- Commit: ddc8a4b

## Automation status
<!-- Filled by /feature-implement: one line per automated MTP row, e.g. "MTP-HOST-001: 🤖 <spec file and test name>" -->
