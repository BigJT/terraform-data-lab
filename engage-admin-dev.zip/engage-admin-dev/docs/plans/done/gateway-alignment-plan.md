# Gateway alignment plan

- Slug: gateway-alignment
- MTP prefix: GWA
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

Pradeep checked our endpoint list against the myCMS back end (2026-10-12). This feature lines the page up with what he found:

1. **Two paths fixed.** Renaming a ticker list is `POST /api-admin/tickers/{listId}` (was PUT). Fetching one market report is `GET /api-admin/reports/market/{language_id}/{analysisMarket_id}` (was `.../market/byId/{id}`).
2. **Who is signed in.** The page asks `GET /api-admin/user/me` and decides itself whether the caller holds a report's lock, instead of relying on a `lockedByCaller` field.
3. **Password change required.** The user edit form gains the switch myCMS has, labelled "Password change required".
4. **Factset tab** on the company page (was "Coming soon"): a peers list (Name, ID) saved in one go, and a multiples picker with search and Save.
5. **Short-positions chart** on the company report: attach a PNG or JPEG, replace or remove it.
6. **Economic statistics** under the company report, full width, for the report's date.

No design changes beyond these. Everything else stays as built.

## API research

All from Pradeep's reading of the myCMS back end, 2026-10-12. Confirmed by him unless marked assumed.

| Endpoint | Shape |
|---|---|
| `GET /api-admin/user/me` | Returns `MonOffUserInfo`, holding the caller's `name`, the same value stored in a report's `lockedBy`. **Assumed:** we use only `{name: string}`. |
| `POST /api-admin/tickers/{listId}` | Rename; body as before `{title}`. |
| `GET /api-admin/reports/market/{language_id}/{analysisMarket_id}` | One market report. **Assumed:** `language_id` is the language code (`fr-FR` / `en-EN`). |
| `GET /api-admin/factset/emitter/{emitterId}` | `{peersBloomIds: [{factsetName, factsetId}], multiples: [{key, label}], availableMultiples: [{key, label}]}` |
| `PUT /api-admin/factset/emitter/{emitterId}/multiples` | Body `string[]` of multiple keys; 200 empty. |
| `POST /api-admin/factset/emitter/{emitterId}/peers` | Body `{emitterBloomIds: [{factsetName, factsetId}]}` (the whole list); 200 empty. |
| `POST /api-admin/reports/{analysisId}/graph-position` | Multipart, part named `graph-position`, one file. Returns the report with `graphPosition: {id, filename, type}`. |
| `DELETE /api-admin/reports/{analysisId}/graph-position` | No body. Returns the report with `graphPosition: null`. |
| `GET /api-admin/reports/statistics/economic?date=yyyy-MM-dd` | Array of `{zone, country, object, period, actual, expected, previous, released, createdAt, updated_at}`, all strings except the two dates. |

Also confirmed: import labels "Short BlackApp (file 10)" = `stock`, "Short Markit (file 9)" = `stock-lending` (already built that way); the myCMS user edit screen has no password field but does have the `passwordChangeRequired` switch.

## Code survey

- `src/data/gatewayClient.ts`: `renameTickerList(listId, title)` (used by `src/screens/CompanyDetail/ListsTab.tsx:250`) sends PUT; `getMarketReport(id)` calls `.../market/byId/{id}` (used by `src/screens/Reports/MarketReportScreen.tsx:68`).
- `src/data/types.ts:164`: `ReportDetail` / `MarketReportDetail` carry `lockedByCaller: boolean`; `src/screens/Reports/useReportLock.ts:8,30` reads it (`report.lockedBy === null || report.lockedByCaller`).
- `src/mocks/handlers.ts`: `lockedByCaller: row.lockedBy === localAdmin` (line 171); market by-id GET at line 287 (`${reports}/market/byId/:id`); ticker rename handler is a PUT.
- Routes (`src/app/AppRoutes.tsx`): `reports/market/:id`. Links to it: `ReportsScreen.tsx:104` (market row) and `ReportScreen.tsx:300` (MARKET "View").
- `src/screens/CompanyDetail/UserFormDialog.tsx`: add and edit share this dialog; `User.passwordChangeRequired` exists in `types.ts:36`, the update body type has `passwordChangeRequired?` (`types.ts:107`).
- `src/screens/CompanyDetail/CompanyDetailScreen.tsx:20,182`: Factset tab renders "Coming soon".
- `src/screens/Reports/ReportScreen.tsx`: boxes COMPANY, SECTOR, CUSTOM CONTENT 1, CUSTOM CONTENT 2, then MARKET (line ~300), right column COMPANY DETAILS. `reportMode` gives `past | sent | editable`; Edit mode on sent reports.
- Shared DS: `Panel`, `SafeHtml`, `RichTextEditor`, `AttachmentPicker`; multipart helper `form<T>(method, path, body: FormData)` in the gateway client.
- **Will break:** tests asserting `lockedByCaller` (useReportLock and ReportScreen tests, mock handler), tests and e2e that navigate to `/reports/market/{id}` (MTP-REP-003, REP-012), the ListsTab rename test checking PUT, and the company detail test and e2e expecting Factset "Coming soon" (MTP-ADMF-017, CTAB rows). Each task reconciles the ones it breaks.

Seams and coverage: seam A (client against msw node server) for every changed or new call; seam B (Testing Library) for the lock decision, the switch, the Factset tab, the chart section and the statistics table; seam C (Playwright, mock mode) for GWA-001 to GWA-005. All automated.

## Implementation approach / decisions

Owner decisions, 2026-10-12:

1. Build all of: the two path fixes, the switch, Factset, chart, statistics.
2. **Page uses `GET /api-admin/user/me`.** Remove `lockedByCaller` from the types, the contract and the mocks. Fetch `me` once after sign-in (client function `getMe(): Promise<{name: string}>`, held in a small context `useMe()`), and treat a lock as the caller's when `lockedBy === me.name`. Mock `GET /api-admin/user/me` returns `{"name": "Local Admin"}`.
3. **Switch label "Password change required"**, an MUI `Switch` on the edit form only (not add), preset from `user.passwordChangeRequired`, always sent as `passwordChangeRequired` in the update body. The mock stores it.
4. **Factset: one Save for the peers list.**
5. **Chart: PNG or JPEG only, file name shown, no preview** (preview waits for Pradeep to say which endpoint serves the file).
6. **Statistics: full width below the report**, under the MARKET block.
7. Unused back-end endpoints Pradeep listed are not built; they are listed as "not used yet" in the endpoints doc and Pradeep is asked which myCMS screens call them.

Pinned for the build:

8. **Market route** becomes `/reports/market/:language/:id` (`:language` = `fr-FR` or `en-EN`). Market list rows and the MARKET "View" link build it from the report's `languageCode`. `getMarketReport(language, id)` calls `GET /api-admin/reports/market/{language}/{id}`. Mock handler at `${reports}/market/:language/:id` (GET only), the old `byId` handler removed.
9. **Ticker rename** sends `POST /api-admin/tickers/{listId}` with the same body; mock handler switched to POST.
10. **Factset tab** (`/companies/:id/factset`), two Panels side by side:
    - Left, heading "FACTSET PEERS": one row per peer with text fields "Name" and "ID" and an icon button "Remove"; button "Add a new Factset peer" appends an empty row; button "Save peers" sends the whole list (`POST .../peers` with `{emitterBloomIds}`), disabled while any row has an empty Name or ID; success toast "Saved successfully". Empty list text: "No Factset peers yet."
    - Right, heading "MULTIPLES": a search box (placeholder "Search multiples") and a "Search" button that filter `availableMultiples` by label, case-insensitive substring; one checkbox per multiple labelled with its `label`, ticked when its key is in `multiples`; button "Save" sends the ticked keys (`PUT .../multiples`); success toast "Saved successfully".
    - Any failure shows the gateway `message` in an error alert in that panel.
    - Mock data. `c1` LVMH: peers `[{factsetName: "Hermes International", factsetId: "HRMS-FR"}, {factsetName: "Kering", factsetId: "PRTP-FR"}]`, multiples `PE`, `EV_EBITDA`. Every other company: no peers, no multiples. `availableMultiples` for all: `PE` "P/E", `EV_EBITDA` "EV/EBITDA", `EV_SALES` "EV/Sales", `PB` "P/B", `DIV_YIELD` "Dividend yield", `FCF_YIELD` "FCF yield".
11. **Short-positions chart** on the company report only, a block headed "SHORT POSITIONS" between CUSTOM CONTENT 2 and MARKET. `ReportDetail` gains `graphPosition: {id, filename, type} | null`. Editable mode (and Edit mode on sent reports): no chart shows button "Add chart"; a chart shows its file name and buttons "Replace" and "Remove". A hidden file input accepts `image/png,image/jpeg`; any other type shows "Choose a PNG or JPEG image." and sends nothing. Add and Replace send `POST /api-admin/reports/{id}/graph-position` (part `graph-position`); Remove sends `DELETE`. Read-only modes: the file name, or "No chart.". Failures show the gateway `message` under the block. Mock: no report has a chart at first; POST stores `{id: crypto.randomUUID(), filename, type}`; DELETE clears it.
12. **Economic statistics** on the company report only, a full-width Panel headed "ECONOMIC STATISTICS" below MARKET, loaded with `GET /api-admin/reports/statistics/economic?date={report date as yyyy-MM-dd}`. Columns "Zone", "Country", "Indicator" (`object`), "Period", "Actual", "Expected", "Previous", "Released", values as given. Empty: "No statistics for this day." Failure: "The statistics could not be loaded." Mock rows for today only (any other date returns `[]`): Europe, France, "CPI (YoY)", "Sep", "1.2%", "1.3%", "1.4%", "08:45"; Europe, Germany, "ZEW Economic Sentiment", "Oct", "12.5", "10.0", "9.8", "11:00"; Americas, United States, "Retail Sales (MoM)", "Sep", "0.4%", "0.3%", "0.1%", "14:30".
13. **Contract** `docs/api/engage-admin-api.yaml`: rename to POST, new market GET path, `lockedByCaller` removed, and new operations `GET /api-admin/user/me`, the three Factset operations, the two graph-position operations and the statistics operation, each with the shapes above and "Confirmed by Pradeep 2026-10-12" (or "Assumed" for the two assumed points).

## Manual test plan (definition of done)

MTP-GWA-001 to MTP-GWA-005 (rows in `docs/manual-test-plan.md`, execution in `docs/mtp-results.md`), all automated in Playwright against mock mode. The path fixes and `user/me` change no visible behaviour; they are covered by seam A tests and by the existing rows MTP-REP-003, REP-010, REP-012 and CTAB-005 still passing.

## Out of scope / open questions

Out of scope: the unused back-end endpoints (pairs-management extras, `POST /api-admin/emitters-management/emitters`, pair unlink, `GET /api-admin/tickers/{id}`, `GET /api-admin/accounts-management/account/{accountId}`, cumulated volumes, index prices, pairs and tickers, charts, quote); a chart preview; the API scope and `Admin` role, which must be created on the gateway's Entra registration.

Open (none block the build): which myCMS screens call the unused endpoints (likely the report side panel's market data); the exact `MonOffUserInfo` shape; what `language_id` is; which endpoint serves the chart file.
