# Version and monitoring plan

- Slug: version-monitoring
- MTP prefix: VMON
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

The Version and Monitoring sidebar entries, which currently show "Coming soon". One feature, two slices (owner decision, 2026-10-12).

1. **Version** (`/version`). Shows the mobile app's latest published version and lets the admin publish a new one in the form X.X.X, optionally forcing users to update. A duplicate version shows the gateway's message verbatim; success shows a toast.
2. **Monitoring** (`/monitoring`). The disconnection dashboard: a period choice (7, 30 or 90 days) driving an overview and two breakdowns (by reason and by platform), a Refresh button, and a filterable, paginated table of every disconnection log.

Behaviour recreates myCMS as described in `docs/mycms-admin-spec-1.md` sections 2 (Connection audit trail), 8, 9 (Disconnection monitoring, App version) and 10. English copy only.

## API research

No new libraries. MUI 9 `Snackbar` + `Alert` for the toast (bottom-right, auto-dismiss), `Pagination` for paging, `LinearProgress` (variant `determinate`) for the breakdown bars, native `<input type="date">` via `TextField type="date"` for the date filters. All already shipped in `@mui/material` 9.5.0.

Assumed (to confirm with Pradeep): every response shape below; the spec gives paths, query names and messages only.

## Code survey

- `src/app/AppRoutes.tsx`: `version` and `monitoring` routes render `PlaceholderScreen`. Replace with `VersionScreen` and `MonitoringScreen` in new folders `src/screens/Version` and `src/screens/Monitoring`.
- `src/screens/ScreenTitle.tsx`: the page heading (h1) used by other screens.
- `src/data/gatewayClient.ts`: `json`, `empty`, private `send`; `send` throws on non-2xx but returns a 204 response normally, so "no version yet" is read by checking `response.status === 204` before parsing.
- `src/mocks/fixtures.ts` / `handlers.ts`: module-state `db`, `resetFixtures()`, `*` path prefix, `bad(message)`.
- Tests this feature breaks and must reconcile: `e2e/shell.spec.ts` "MTP-ADMF-005" (loops placeholder entries including Version and Monitoring); `src/app/AppRoutes.test.tsx` "navigates to the $label placeholder" (`it.each` over entries other than Companies); row MTP-ADMF-005 in `docs/manual-test-plan.md`. Other features may already have removed their own entries from these loops by the time this runs.

Seams: A, gateway client vs msw node server; B, screens with Testing Library in theme, router, signed-in auth, msw; C, Playwright on `npm run dev` (mock mode, port 5174).

Coverage: all automated. Version validation, 204 empty state, duplicate error and toast at seam B, MTP rows at C (the 204 case at C uses `page.route` to answer 204). Monitoring percentages, labels, filters, paging and the loading and empty copy at seam B; MTP rows at C.

## Implementation approach / decisions

1. **One feature, two slices** (owner, 2026-10-12).
2. **Contract additions** to `docs/api/engage-admin-api.yaml`, each with `x-confirm-with: Pradeep`:
   - `GET /api-admin/app-version` → 200 `AppVersion` = `{version: string, forceUpdate: boolean, createdAt: date-time}`, or 204 when none exists.
   - `POST /api-admin/app-version` body `{version: string, forceUpdate: boolean}` → 201 `AppVersion`; 400 `{message: "A version {version} already exists."}`.
   - `GET /api-admin/disconnections/stats?days={n}` (n 7, 30 or 90; default 7) → 200 `{days: integer, total: integer, byReason: [{reason, count}], byPlatform: [{platform, count}]}`.
   - `GET /api-admin/disconnections?page={p}&size={s}&sort=createdAt,desc&userEmail=&startDate=YYYY-MM-DD&endDate=YYYY-MM-DD&platform=&reason=` (all filters optional) → 200 `{content: DisconnectionLog[], totalElements: integer, totalPages: integer, number: integer, size: integer}`; `DisconnectionLog` = `{id, createdAt: date-time, userEmail, platform: 'DESKTOP' | 'MOBILE', reason, ipAddress, userAgent, details}`.
   - Reason codes: `TOKEN_EXPIRED`, `TOKEN_INVALID_SIGNATURE`, `TOKEN_REVOKED`, `USER_NOT_FOUND`, `SESSION_CORRUPTED`, `TOKEN_REPLACED_BY_NEW_LOGIN`, `TOKEN_MALFORMED`, `TOKEN_INVALID`, `USER_DEACTIVATED`, `INSUFFICIENT_ROLES`, `MANUAL_LOGOUT`.
3. **Version copy.** Heading "Version". Label "Current version" with the version in bold; when the gateway answers 204, "No version published yet". Field "Enter the new version:"; error "Format should be like this X.X.X" when the value does not match `^\d+\.\d+\.\d+$` (empty included). Checkbox "Force users to update the application", unticked by default. Button "Send", disabled while sending. Success: toast "Version added successfully" (bottom-right, auto-dismiss after 4 seconds), the current version updates and the form resets. 400: error alert above the form with the message verbatim.
4. **Monitoring copy.** Heading "Disconnection monitoring". Period label "Analysis period:" with options "7 days", "30 days", "90 days" (default 7 days). Button "Refresh" (reloads stats and the current log page). Sections "Overview", "Analysis", "All disconnection logs". Overview: three figures "Total disconnections", "Desktop app", "Mobile app" with their counts for the period. Analysis: headings "Breakdown by disconnection reason" and "Breakdown by platform"; one bar per entry with a count above zero, sorted by count descending then label ascending, each labelled with the English label and "{count} ({percentage}%)", percentage = count / total × 100 to one decimal place. Table columns "Date" (dd/MM/yyyy HH:mm, local time), "User", "Platform", "Reason", "IP address", "Browser/System", "Details". Empty: "No disconnection logs found." Loading: "Loading logs...". Pagination caption "{totalElements} logs in total • Page {currentPage} of {totalPages}" with currentPage = number + 1; page size 20; MUI `Pagination` below.
5. **Labels.** Reasons: TOKEN_EXPIRED "Session expired"; TOKEN_INVALID_SIGNATURE "Authentication compromised"; TOKEN_REVOKED "Access revoked"; USER_NOT_FOUND "User account deleted"; SESSION_CORRUPTED "Session corrupted"; TOKEN_REPLACED_BY_NEW_LOGIN "New login detected"; TOKEN_MALFORMED "Malformed token"; TOKEN_INVALID "Invalid token"; USER_DEACTIVATED "User account deactivated"; INSUFFICIENT_ROLES "Insufficient roles"; MANUAL_LOGOUT "Manual sign-out". Platforms: DESKTOP "Desktop app"; MOBILE "Mobile app". An unknown code shows the code itself.
6. **Filters.** Above the table: "User email" (text), "From" and "To" (dates), "Platform" (options "All platforms", "Desktop app", "Mobile app"), "Reason" (options "All reasons" then the eleven labels in the order of decision 2), buttons "Apply filters" and "Clear filters". Apply sends the filled filters and goes to page 1; Clear empties them and reloads page 1. The period does not filter the table.
7. **Mock fixtures.** Version history `[{version: '3.4.0', forceUpdate: false, createdAt: '2026-09-01T09:00:00Z'}]`; GET returns the last entry (204 if empty); POST rejects an existing version. 45 disconnection logs built at module load for i = 0 to 44: `id` `d{i+1}`; `createdAt` = now minus (i × 2 days + 1 hour); `userEmail` cycling by i mod 5 through claire.martin@lvmh.example, sophie.laurent@danone.example, james.walker@diageo.example, camille.roux@accor.example, elodie.petit@kering.example; `platform` DESKTOP for even i, MOBILE for odd; `reason` = the code at index i mod 11 in decision 2's order; `ipAddress` `10.0.0.{i+1}`; `userAgent` "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Engage Desktop/2.3.0" for DESKTOP, "Engage/3.4.0 (iPhone; iOS 26.5)" for MOBILE; `details` "Mock disconnection {i+1}". Stats count logs whose `createdAt` is within the last `days` days: 7 days gives 4, 30 gives 15, 90 gives 45. List handler: newest first; `userEmail` case-insensitive substring; `startDate`/`endDate` inclusive on the UTC date of `createdAt`; `platform` and `reason` exact; paged by `page` and `size`.

## Manual test plan (definition of done)

MTP-VMON-001 to MTP-VMON-008. Rows in `docs/manual-test-plan.md`; execution in `docs/mtp-results.md`. All automated with Playwright against mock mode.

## Out of scope / open questions

- Log export, retention and the myCMS "Administration" home card.
- Confirm with Pradeep: every shape in decision 2, the email filter's matching rule (substring here), and whether dates filter in UTC.
