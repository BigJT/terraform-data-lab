# Admin features tasks

One build queue for five features, built in this order. Each task names its own plan; the per-feature "shared facts" sections apply to every task with that prefix.

- Branch: commit directly on `dev`, push as each task lands. No worktree, no PR.
- MTP rows live in `docs/manual-test-plan.md`; record results in `docs/mtp-results.md`.
- Plans: `docs/plans/reports-plan.md` (REP), `docs/plans/flashes-plan.md` (FLS), `docs/plans/broker-notes-plan.md` (BRN), `docs/plans/company-tabs-plan.md` (CTAB), `docs/plans/version-monitoring-plan.md` (VMON).
- Acceptance: one `/feature-review` over all five once every task is done; it moves this file and the five plans to `docs/plans/done/`.

## Reports shared facts (apply to every REP task)

- Plan: docs/plans/reports-plan.md
- the plan's decisions 9 to 18 (routes, contract, client names, fixtures, copy, read-only, auto-save, lock, editor, colours) are binding and repeated in the tasks that use them. Every task ends with `npm run verify` green and its rows marked in `docs/mtp-results.md`.

## REP-T01: Report contract, client, mock data and Reports list
- Plan: docs/plans/reports-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: none
- Satisfies: MTP-REP-001, MTP-REP-002, MTP-REP-003
- Test approach: integration test at seam A (each list function's URL: null date hits `/api-admin/reports`, `2026-10-05` hits `/api-admin/reports/05-10-2026`; market equivalents); seam B for the list (labels, statuses, counts, search, tab and date from the URL, archived never shown); Playwright at seam C for 001 to 003.
- Model: sonnet
- What to build:
  - Install `@mui/x-date-pickers@9.15.0` and `dayjs@1.11.23`.
  - Append to `docs/api/engage-admin-api.yaml` every operation and schema in plan decision 10, both company and market families, with a description "To confirm with Pradeep" on each report operation.
  - Add to `src/data/types.ts`: `WorkStatus`, `ReportSummary`, `MarketReportSummary`, `ReportDetail`, `MarketReportDetail`, `ReportContent {analysis, sectorAnalysis, customContent1, customContent2}`, `MarketReportContent {content}` exactly as plan decision 10.
  - Add every client function in plan decision 11 to `createGatewayClient`, with seam A tests for the URLs and bodies.
  - Fixtures and handlers exactly as plan decision 12 (today's five company rows, the two market rows, on-the-fly rows for other dates, archived never returned, `lockedByCaller` computed against `"Local Admin"`), plus handlers for every write in decision 10 applying its rules (writing_status sets writing done and analysis, content and overall validation doing; validate analysis/content rules; `updatedAt` now on every write; lock sets `lockedBy` to `"Local Admin"`; unlock clears it). `resetFixtures()` reseeds reports too.
  - `src/screens/Reports/ReportsScreen.tsx` at `/reports` (replace the placeholder route): copy from decision 13 "List". Query `tab` (`companies` default, `markets`) and `date` (`YYYY-MM-DD`, default today) kept in the URL; the date picker (label "Date", format `DD/MM/YYYY`, inside `LocalizationProvider` with `AdapterDayjs`) writes `date`. Today calls `listReports(null)` / `listMarketReports(null)`; other dates pass `YYYY-MM-DD`, converted to `dd-MM-yyyy` by the client. Date line "Today (Monday 12 October 2026)" style for today, "Monday 5 October 2026" style otherwise. Columns, states, sorting, `{n}` = rows shown, "No reports found.", "To validate" in amber and "Validated" and "✓ Sent at HH:mm" in green. Company row click goes to `/reports/{id}`, market row to `/reports/market/{id}` (routes may render a placeholder heading "Write a report" / "Write a market report" until T02 and T06).
  - Reconcile the tests that treat Reports as a placeholder: remove Reports from the placeholder lists in `e2e/shell.spec.ts` (MTP-ADMF-005) and `src/app/AppRoutes.test.tsx`; the sidebar order check stays.
- Acceptance: the listed MTP rows pass; ADMF rows still pass.
- Commit: 99061bb

## REP-T02: Company report screen read view, read-only rules and HTML cleaning
- Plan: docs/plans/reports-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: REP-T01
- Satisfies: MTP-REP-004, MTP-REP-011, MTP-REP-013
- Test approach: seam B (layout, headings, company details, MARKET block with View link and "No market report yet.", past date gives read-only with no action bar and no Edit, sent gives read-only with "Sent at HH:mm"; `SafeHtml` unit tests: `<script>` removed, `onerror` removed, `<strong>`, table and `img` with `data:` src kept); Playwright at seam C for 004, 011, 013 (013 asserts `window.__xss` stays undefined on LVMH and "Desk note" shows bold).
- Model: sonnet
- What to build:
  - Install `dompurify@3.4.17`. `src/ds/components/SafeHtml.tsx` (exported from `src/ds/components/index.ts`; Flashes reuses it) props `{html: string}`, renders `DOMPurify.sanitize(html, {USE_PROFILES: {html: true}})` through `dangerouslySetInnerHTML`; the only place stored HTML is rendered.
  - `src/screens/Reports/ReportScreen.tsx` at `/reports/:id` using `getReport`: heading "Write a report", sub-heading company name, link "Back to reports" to `/reports?tab=companies&date={report date}`. Left column (about 70%): headings "COMPANY", "SECTOR", "CUSTOM CONTENT 1", "CUSTOM CONTENT 2", each showing its stored HTML via `SafeHtml` (editors arrive in T03); then "MARKET" with the language name ("French"/"English"), link "View" to `/reports/market/{marketReportId}`, the market text via `SafeHtml`, or "No market report yet." when `marketContent` is null or empty. Right column Panel "COMPANY DETAILS" with label/value lines Name, RIC, Market (`emitter.market.fullName`), Sector (`emitter.sector`), Language.
  - Read-only state, decided in one function `reportMode(report, today)` returning `'past' | 'sent' | 'editable'`: `date` before today local gives `past` (no action bar, no Edit); `sent` gives `sent` (caption "Sent at HH:mm" from `sentAt`, local time; the Edit button arrives in T04); else `editable`. Unit test every branch.
  - 404 shows "Report not found".
- Acceptance: the listed MTP rows pass.
- Commit: 3167577

## REP-T03: Shared rich-text editor and auto-save
- Plan: docs/plans/reports-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: REP-T02
- Satisfies: MTP-REP-005, MTP-REP-006
- Test approach: seam B for `useAutoSave` with fake timers (saves once 3000 ms after the last of several changes, not before; no save when disabled; no save triggered by a blanked box, but the blank goes out with the next save; failure shows the alert and the next change retries), for `isRichTextEmpty` (blank, whitespace-only paragraphs, image-only) and for the full editor's image paste handler with a fake `ClipboardEvent` carrying a PNG `File` (inserts `img` with a `data:image/png;base64,` src); Playwright at seam C for 005 and 006 (typing, waiting, caption, reload keeps text; custom box saves only after leaving it; toolbar button sets per box; Insert table; pasting HTML containing a data-URL image keeps the image).
- Model:
- What to build:
  - Install `@tiptap/react@3.31.4`, `@tiptap/pm@3.31.4`, `@tiptap/starter-kit@3.31.4`, `@tiptap/extension-table@3.31.4`, `@tiptap/extension-image@3.31.4`.
  - `src/ds/components/RichTextEditor.tsx`, exported from `src/ds/components/index.ts` (Flashes reuses it unchanged), props `{label: string, value: string (HTML), onChange: (html: string) => void, toolbar: 'basic' | 'full', error?: string, readOnly?: boolean, placeholder?: string, onBlur?: () => void}`, and exported helper `isRichTextEmpty(html: string): boolean` (true when the text content is blank and there is no `<img>`). Basic toolbar: "Bold", "Italic". Full toolbar: "Heading 2", "Heading 3", "Bold", "Italic", "Underline", "Bullet list", "Numbered list", "Link", "Insert table", "Image", "Paste as plain text". Full extensions: StarterKit (link `openOnClick: false`), `TableKit`, `Image.configure({allowBase64: true, inline: true})`, `editorProps.handlePaste` and `handleDrop` reading image `File`s with `FileReader.readAsDataURL` and inserting them. Link opens an MUI popover (no browser dialogs) with a text box "URL" and buttons "Cancel", "Apply" (empty URL unsets the link). Insert table: 3 rows by 3 columns with a header row. Image: hidden file input accepting `image/*`, inserted as a data URL. Paste as plain text: `navigator.clipboard.readText()`, line breaks become hard breaks. Toolbar buttons are MUI icon buttons with `aria-label` equal to these names and show pressed state. `error` shows under the box in `colors.red`.
  - In `ReportScreen`, editable mode renders COMPANY and SECTOR as basic editors with placeholder "Enter your analysis here", counted as changed on every `onChange`; CUSTOM CONTENT 1 and 2 as full editors without placeholder, whose latest HTML is kept from `onChange` but only counted as changed on `onBlur`. Non-editable modes keep `SafeHtml`.
  - `src/screens/Reports/useAutoSave.ts`: saves 3000 ms after the last change when enabled (editable and unsent) and the changed value non-empty; always sends all four fields via `saveReportContent`; updates `updatedAt` from the answer. Failure shows the error alert "The report could not be saved. Your changes are kept on this page." above the boxes; the next change retries.
  - Caption from `updatedAt`, refreshed every 30 s: "Last saved just now" (< 60 s), "Last saved 1 minute ago" / "Last saved {n} minutes ago" (< 60 min), else "Last saved at HH:mm".
- Acceptance: the listed MTP rows pass.
- Commit: 029284a

## REP-T04: Sign-off actions, Send, and Edit and Save on sent reports
- Plan: docs/plans/reports-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: REP-T03
- Satisfies: MTP-REP-007, MTP-REP-008, MTP-REP-009
- Test approach: seam B (button labels and disabled states per status; each button calls its client function; send dialog with and without the warning line; Cancel sends nothing; Yes sends then shows "Sent at HH:mm" and "Edit"; Edit enables editors and shows "Save"; Save dialog Yes calls `saveReportContent` only, never `sendReport`; no auto-save in Edit mode); Playwright at seam C for 007 to 009.
- Model: sonnet
- What to build:
  - Action bar in `editable` mode: "Request validation" (`requestReportValidation`, disabled once `writingStatus` is done), "Validate content" (`validateReportContent`; disabled and labelled "Content validated" once `contentValidation` is done), "Validate writing" (`validateReportAnalysis`; disabled and labelled "Writing validated" once `analysisValidation` is done), "Send". Each action re-renders from the returned detail. No other guards (copy myCMS).
  - Send dialog title "Send the report": if `writingStatus` is not done, first line "The report content and writing have not been validated."; then "Are you sure you want to send the report to {company name}?"; buttons "Cancel", "Yes". Yes calls `sendReport`, closes, mode becomes `sent`.
  - `sent` mode shows "Sent at HH:mm" and "Edit". Edit enables the editors (no auto-save) with a bottom button "Save" in place of Send; Save opens dialog "Save the report", "Are you sure you want to save the changes to the report for {company name}?", buttons "Cancel", "Yes"; Yes calls `saveReportContent` with all four fields and returns to `sent` read-only. Past reports never show Edit.
- Acceptance: the listed MTP rows pass.
- Commit: 4e6ff83

## REP-T05: Editing lock
- Plan: docs/plans/reports-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: REP-T04
- Satisfies: MTP-REP-010
- Test approach: seam B (unlocked or own-lock today report calls `lockReport` on open; foreign lock shows the dialog and calls nothing until Yes; Cancel leaves read-only with no lock call; Yes calls `lockReport` and enables editing; unmount of a held, unsent, editable report calls `unlockReport`; sent and past reports never call lock or unlock; a `pagehide` event calls `unlockReport`); Playwright at seam C for 010 (Kering).
- Model: sonnet
- What to build:
  - In `ReportScreen`, for mode `editable`: if `lockedBy` is null or `lockedByCaller` is true, call `lockReport` at once; otherwise show the dialog titled "CONTENT BEING WRITTEN" with the lines "The report is being written by {lockedBy}" and "Do you want to unlock access to this report?", and buttons "Cancel" (screen stays read-only via `SafeHtml`, no action bar, no auto-save) and "Yes" (call `lockReport`, then editable).
  - Release: on unmount and on the window `pagehide` event, if this page holds the lock and the report is still unsent and editable, call `unlockReport` and ignore the result. Put the logic in a hook `useReportLock({report, lock, unlock})` so T06 reuses it with the market functions.
- Acceptance: the listed MTP row passes.
- Commit: 7e0a882

## REP-T06: Market report writing screen
- Plan: docs/plans/reports-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: REP-T05
- Satisfies: MTP-REP-012
- Test approach: seam B (layout, full toolbar, auto-save calls `saveMarketReportContent` with `{content}`, send and save dialog copy for markets, lock via `useReportLock` with the market functions); Playwright at seam C for 012 (edit English market text, wait for auto-save, open Diageo's report, its MARKET block shows the new text).
- Model: sonnet
- What to build:
  - `src/screens/Reports/MarketReportScreen.tsx` at `/reports/market/:id` using `getMarketReport`: heading "Write a market report", sub-heading the language name, link "Back to reports" to `/reports?tab=markets&date={report date}`, one `RichTextEditor` with `toolbar="full"` counted as changed on every `onChange`, no heading or placeholder; the same last-saved caption, `reportMode`, auto-save (`saveMarketReportContent({content})`), action bar (market client functions), Edit and Save for sent, and `useReportLock` with `lockMarketReport` / `unlockMarketReport`.
  - Market copy: send dialog "Send the report" with the warning line rule and "Are you sure you want to send the {language} market report?"; save dialog "Save the report" with "Are you sure you want to save the changes to the {language} market report?"; languages "French" / "English".
  - Reuse the T03 to T05 pieces through props rather than copying them; generalise `useAutoSave` and the action bar over a small adapter `{save, requestValidation, validateAnalysis, validateContent, send}` so both screens use one implementation.
- Acceptance: the listed MTP row passes; REP-001 to 011 and 013 still pass.
- Commit: 995f4fa

## Flashes shared facts (apply to every FLS task)

- Plan: docs/plans/flashes-plan.md

- Repo root: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Admin`. Read `CLAUDE.md` first. English copy only; all copy below is exact.
- Conventions: screens in `src/screens/Flashes/`; `ScreenTitle` from `@/screens/ScreenTitle`; `Panel` from `@/ds/components`; `colors` from `@/ds/theme`; `useGateway()` from `@/data/gatewayContext`; types in `src/data/types.ts`; client in `src/data/gatewayClient.ts` (`createGatewayClient`, private `send`/`json`/`empty`, `GatewayError {status, message, fieldErrors?}`); mocks in `src/mocks/fixtures.ts` (module state `db`, `resetFixtures()`) and `src/mocks/handlers.ts` (`*`-prefixed paths, `notFound()`, `bad(message)`); tests with `renderWithTheme` from `src/test/renderWithTheme.tsx` and the msw node server (`server.use` for overrides); Playwright specs in `e2e/` against port 5174 in mock mode.
- Mock companies: `c1` LVMH, `c2` Danone, `c3` Kering, `c4` Accor, `c5` Diageo (all active), `c6` Worldline (archived).
- Dates display as dd/MM/yyyy HH:mm in local time.
- Render stored HTML only through `SafeHtml` from `src/ds/components` (props `{html: string}`, renders `DOMPurify.sanitize(html, {USE_PROFILES: {html: true}})` via `dangerouslySetInnerHTML`, dompurify 3.4.17), built by Reports (REP-T02). Create it with exactly that shape and export it from `src/ds/components/index.ts` if it does not exist; reuse it if it does.
- Each task ends with `npm run verify` green and its MTP rows marked in `docs/mtp-results.md`.

## FLS-T01: Flash contract, client, mock data and Flashes list
- Plan: docs/plans/flashes-plan.md
- Kind: slice
- Blocking: yes
- Status: done (99f8e24)
- Blocked by: REP-T06
- Satisfies: MTP-FLS-001, MTP-FLS-002
- Test approach: integration test at seam A (`listFlashes` sends `q`, `page`, `size`; `getFlash`, `deleteFlash`, `listFlashTypes` hit the right paths; 404 becomes `GatewayError`); seam B for the list (columns, order, search refetch, paging, row click navigates); Playwright `e2e/flashes.spec.ts` for 001 and 002.
- Model: sonnet
- What to build:
  - `docs/api/engage-admin-api.yaml`: add, with `bearerAuth`, request and response schemas and a description line "To confirm with Pradeep":
    - `GET /api-admin/flashs` query `q` (optional string), `page` (integer from 0, default 0), `size` (integer, default 20) → 200 `FlashPage {content: Flash[], totalElements, totalPages, number, size}`, newest first; `q` matches title, value, type and description, case-insensitive substring.
    - `GET /api-admin/flashs/{id}` → 200 `Flash`; 404.
    - `DELETE /api-admin/flashs/{id}` → 204; 404.
    - `POST /api-admin/flashs` `multipart/form-data`: part `flash` (`application/json`) `CreateFlash {title, value, description, type, links: string[], emittersUUID: string[], sendByEmail: boolean, sendToAll: boolean}` and zero or more parts `attachments` (binary) → 201 `Flash` with header `Location: /api-admin/flashs/{id}`; 400 `{message, fieldErrors?}`.
    - `GET /api-admin/referential/types/flash` → 200 string array.
    - `GET /api/attachment/{id}/content` → 200 bytes with the stored content type; 404.
    - `Flash` = `{id, title, value, description, type, links: string[], sendByEmail: boolean, sendToAll: boolean, emitters: [{id, name}], attachments: Attachment[], createdAt: date-time, updatedAt: date-time}`.
  - Types `Flash`, `FlashPage`, `CreateFlashRequest` and the shared `Attachment` (`{id: string, fileName: string, contentType: string, size: number}`; reuse it if it already exists) in `src/data/types.ts`. Client methods: `listFlashes({q, page, size})`, `getFlash(id)`, `deleteFlash(id)`, `listFlashTypes()`, `getAttachmentContent(id): Promise<Blob>` (bearer header sent), and `createFlash(request, files: File[]): Promise<Flash>` that posts FormData with part `flash` = `new Blob([JSON.stringify(request)], {type: 'application/json'})` and one `attachments` part per file, through a new private helper `form<T>(method: string, path: string, body: FormData): Promise<T>` in `src/data/gatewayClient.ts` that sets only the `Authorization` header (the browser sets the multipart boundary) and applies the same 401/403 and error handling as `send`. Broker notes reuses this helper unchanged, so keep the name and signature exactly.
  - Fixtures `db.flashes` (reset by `resetFixtures()`), `updatedAt` = `createdAt`:
    - `f1` 2026-10-12T07:45:00Z, title "LVMH Q3 revenue ahead of consensus", value "LVMH", type "Breaking News", emitters c1, links ["https://www.lvmh.com/investors"], sendByEmail true, sendToAll false, no attachments, description `<p>LVMH reported Q3 organic revenue growth of 3%, ahead of the 1% consensus.</p>`
    - `f2` 2026-10-11T15:20:00Z, "Danone shares up 2.4% in early trade", "Danone", "Price movement", c2, no links, false, false, none, `<p>Danone is trading up 2.4% after a broker upgrade.</p>`
    - `f3` 2026-10-10T06:55:00Z, "Pre-opening: European luxury sector", "Kering", "Pre-opening", c1 and c3, no links, false, false, attachment `{id: 'a1', fileName: 'luxury-preopen.pdf', contentType: 'application/pdf', size: 2048}` (bytes: `%PDF-1.4` then spaces to 2048 bytes), `<p>Futures point to a firmer open for luxury names.</p>`
    - `f4` 2026-10-09T12:10:00Z, "Diageo: brokers' comments after trading update", "Diageo", "Brokers Comments", c5, links ["https://www.diageo.com/en/investors", "https://www.londonstockexchange.com"], true, false, none, `<p>Brokers broadly positive on the trading update.</p>`
    - `f5` 2026-10-08T09:30:00Z, "Peer report: hospitality", "Accor", "Peer report", c1 to c5, no links, false, sendToAll true, none, `<p>Weekly hospitality peer comparison.</p>`
    - Flash types: "Price movement", "Pre-opening", "Breaking News", "Reco / TP", "Sales traders' comments", "Brokers Interests", "Brokers Comments", "Peer report".
  - Handlers for all six operations. List filters and pages as the contract says. Create: new id `crypto.randomUUID()`, `createdAt` now, emitters = every non-archived company when `sendToAll`, else the given ids (with names); stores each attachment's name, type, size and bytes under a new id; returns 201 with `Location`; returns 500 `{message: "Mock failure"}` when `title` is exactly "Mock server error". Get/delete return 404 for an unknown id. Attachment content serves the stored bytes with their content type, 404 otherwise.
  - List screen at `/flashes` (replace the placeholder route in `src/app/AppRoutes.tsx`): heading "Flashes"; search box placeholder "Search flashes" that refetches with `q` (300 ms after the last keystroke, back to page 0); button "Send a flash" (navigates to `/flashes/new`, a placeholder until FLS-T03); Panel with a table, columns "Sent" (createdAt as dd/MM/yyyy HH:mm), "Recipients" (emitter names joined by ", "), "Company" (`value`), "Title", "Type"; rows newest first; empty state "No flashes found."; MUI `TablePagination` with 20 rows per page and `rowsPerPageOptions={[]}`; clicking a row navigates to `/flashes/{id}` (placeholder until FLS-T02).
- Acceptance: the listed MTP rows pass.
- Commit: 99f8e24

## FLS-T02: Flash detail, attachment download and delete
- Plan: docs/plans/flashes-plan.md
- Kind: slice
- Blocking: yes
- Status: done (e233aad)
- Blocked by: FLS-T01
- Satisfies: MTP-FLS-003, MTP-FLS-004
- Test approach: seam B (detail sections for f1 and f3, empty sections hidden, "Flash not found" on 404, attachment click calls `getAttachmentContent`, message rendered through `SafeHtml` so a `<script>` and an `onerror` attribute in a description are removed while `<strong>` stays; delete dialog Cancel keeps, Yes calls delete and navigates to `/flashes`); Playwright for 003 and 004.
- Model: sonnet
- What to build:
  - Route `/flashes/:id`. Heading = flash title; caption "Sent {dd/MM/yyyy HH:mm}"; link "Back to flashes" to `/flashes`. Panel with sections:
    - "RECIPIENTS": emitter names, one per line.
    - "CONTENT": "Type: {type}", "Company: {value}", then the message rendered with `<SafeHtml html={description} />`.
    - "RELATED LINKS:": each link as an anchor with `target="_blank"` and `rel="noopener noreferrer"`; hidden when there are none.
    - "ATTACHMENT": one button per attachment labelled with its file name; clicking calls `getAttachmentContent(id)`, makes an object URL and downloads it under the file name, then revokes the URL; hidden when there are none.
    - Note "Duplicate sent by email" when `sendByEmail` is true.
  - Button "Delete" opens a dialog titled "Delete flash", body "Are you sure you want to delete?" with bold sub-text "This action cannot be undone", buttons "Cancel" (closes) and "Yes" (calls `deleteFlash`, then navigates to `/flashes`; on error shows the message in an error alert inside the dialog).
  - 404 shows "Flash not found".
  - Add dompurify 3.4.17 and `src/ds/components/SafeHtml.tsx` if not already present (see shared facts).
- Acceptance: the listed MTP rows pass.
- Commit: e233aad

## FLS-T03: Compose and send a flash
- Plan: docs/plans/flashes-plan.md
- Kind: slice
- Blocking: yes
- Status: done (27b2e8d)
- Blocked by: FLS-T02
- Satisfies: MTP-FLS-005, MTP-FLS-006, MTP-FLS-008, MTP-FLS-009
- Test approach: seam B (empty Send shows all five errors; Type offers the eight types; recipients exclude archived companies; "Send to all companies" disables the picker and clears the recipient error; links split and trimmed; successful send posts the multipart `flash` part with the expected JSON and navigates to the new detail; server failure shows the alert and keeps the values); a unit test for the editor's empty check; Playwright for 005, 006, 008, 009.
- Model:
- What to build:
  - Rich-text editor. If `src/ds/components/RichTextEditor.tsx` exists (built by the Reports feature), use it as it is; if its props differ from those below, adapt the compose screen to its props and do not change the component. If it does not exist, create it and export it from `src/ds/components/index.ts`: props `{label: string, value: string (HTML), onChange: (html: string) => void, toolbar: 'basic' | 'full', error?: string, readOnly?: boolean, placeholder?: string, onBlur?: () => void}`; packages `@tiptap/react`, `@tiptap/pm`, `@tiptap/starter-kit`, `@tiptap/extension-table`, `@tiptap/extension-image`, all 3.31.4; `toolbar: 'basic'` = Bold, Italic; `toolbar: 'full'` = Heading 2, Heading 3, Bold, Italic, Underline, Bullet list, Numbered list, Link (opens an MUI popover with a text box "URL" and buttons "Cancel", "Apply"; empty URL removes the link; no browser dialogs), Insert table (inserts a 3 by 3 table with a header row), Image (pick a file, inserted as a data URL), Paste as plain text (`navigator.clipboard.readText()`, line breaks become hard breaks); extensions StarterKit (link `openOnClick: false`), `TableKit` from `@tiptap/extension-table`, `Image.configure({allowBase64: true, inline: true})`. Image extension with `allowBase64: true`; pasting an image file inserts it inline as a data URL via `editorProps.handlePaste`. Toolbar buttons are MUI icon buttons with `aria-label` equal to the names above. The error text shows under the box in `colors.red`. Export a helper `isRichTextEmpty(html: string): boolean` (true when the text content is blank and there is no `<img>`).
  - Route `/flashes/new` (replace the T01 placeholder). Heading "Send a flash". Panel sections:
    - "Recipients": checkbox "Send to all companies"; MUI `Autocomplete` multiple labelled "Companies", placeholder "Search companies", options = non-archived companies from `listCompanies()` by name, disabled while "Send to all companies" is ticked.
    - "Content": "Subject" (text), "Company" (free text, myCMS "Valeur"), "Type" (select from `listFlashTypes()`), "Message" (`RichTextEditor` with `toolbar="full"`), "Related links" (multi-line text, placeholder "One link per line", optional).
    - "Attachment": button "Add an attachment" (attachment rules arrive in FLS-T04; in this task the button may be absent).
    - Checkbox "Also send by email".
    - Button "Send".
  - Validation on Send: "Please choose a recipient" (no company chosen and "Send to all companies" unticked), "Subject is required", "Company is required", "Type is required", "Message is required" (`isRichTextEmpty`). Each error under its field; nothing is sent while any remain.
  - Send calls `createFlash({title: Subject, value: Company, description: message HTML, type, links: lines split on "\n", trimmed, blanks dropped, emittersUUID: chosen ids or [] when sending to all, sendByEmail, sendToAll}, files)`. On success navigate to `/flashes/{id}`. On any failure show the error alert "Unable to create a flash right now. Please try again later." above the form and keep every value.
- Acceptance: the listed MTP rows pass.
- Commit: 27b2e8d

## FLS-T04: Flash attachments
- Plan: docs/plans/flashes-plan.md
- Kind: slice
- Blocking: yes
- Status: done (5b581ca)
- Blocked by: FLS-T03
- Satisfies: MTP-FLS-007
- Test approach: seam B on `AttachmentPicker` (empty file refused, file over 10 MB refused, total over 15 MB refused, a valid file listed and removable) and on compose (chosen files sent as `attachments` parts); Playwright for 007 (create test files with `setInputFiles` buffers: `empty.txt` 0 bytes, `big.bin` 10 × 1024 × 1024 + 1 bytes, `part1.bin` and `part2.bin` 8 × 1024 × 1024 bytes each, `notes.txt` 12 bytes).
- Model: sonnet
- What to build:
  - Create `src/ds/components/AttachmentPicker.tsx`, exported from `src/ds/components/index.ts`, with props exactly `{files: File[], onChange: (files: File[]) => void, label: string}`. It renders the section heading `label`, a button "Add an attachment" (hidden file input, `multiple`, any type), one line per file with its name, its size in KB and a "Remove" button, and errors in an error `Alert` under it. Broker notes reuses it unchanged, so keep the name and props exactly.
  - Rules checked when files are chosen; a refused file is not added: a 0-byte file gives "Attachment {file name} is empty."; a file over 10 MB (10 485 760 bytes) gives "Attachment {file name} is larger than 10 MB."; a file that would take the total over 15 MB (15 728 640 bytes) gives "Attachments must total 15 MB or less.".
  - In the compose screen, replace the "Attachment" section with `<AttachmentPicker label="Attachment" ... />`. Send passes the files to `createFlash` as `attachments` parts. The new flash's detail shows them under "ATTACHMENT".
- Acceptance: the listed MTP row passes; MTP-FLS-008 still passes.
- Commit:

## Broker notes shared facts (apply to every BRN task)

- Plan: docs/plans/broker-notes-plan.md

- Repo root: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Admin`. English copy only; all copy below is exact.
- Seams: A = gateway client against the msw node server; B = Testing Library screens inside theme, `MemoryRouter`, signed-in auth and msw; C = Playwright against `npm run dev` (mock mode, port 5174). Name each Playwright test "MTP-BRN-NNN: ...". Specs go in `e2e/brokerNotes.spec.ts`.
- Every task ends with `npm run verify` green and its MTP rows recorded in `docs/mtp-results.md`.
- Screens: `ScreenTitle` from `@/screens/ScreenTitle`, `Panel` from `@/ds/components`, colours only from `@/ds/theme` tokens.
- Companies in the mock: `c1` LVMH `LVMH.PA`, `c2` Danone `DANO.PA`, `c3` Kering `PRTP.PA`, `c4` Accor `ACCP.PA`, `c5` Diageo `DGE.L`, `c6` Worldline `WLN.PA` (archived).
- Types: `Attachment` = `{id: string, fileName: string, contentType: string, size: number}`; `BrokerNote` = `{id: string, emitter: {id: string, name: string, ric: string}, title: string | null, broker: string, currency: string, currentObjective: string, currentRecommendation: string, sectorNote: boolean, initiationNote: boolean, recoChange: boolean, previousObjective: string | null, previousRecommendation: string | null, sendByEmail: boolean, attachments: Attachment[], createdAt: string}`; `BrokerNoteRequest` = `{emitterId: string, title?: string, broker: string, currency: string, currentObjective: string, currentRecommendation: string, sectorNote: boolean, initiationNote: boolean, recoChange: boolean, previousObjective?: string, previousRecommendation?: string, sendByEmail: boolean}`; `Page<T>` = `{content: T[], totalElements: number, totalPages: number, number: number, size: number}`. All in `src/data/types.ts`.

## BRN-T01: Broker notes list with search, paging and delete
- Plan: docs/plans/broker-notes-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: FLS-T04
- Satisfies: MTP-BRN-001, MTP-BRN-002, MTP-BRN-003
- Test approach: integration test at seam A (list with and without `q`, page and size passed, delete, both referential calls, 401/403 handling unchanged); seam B for the list (columns and cell formats from fixtures, icons with their aria-labels, empty state, search sends `q` after 300 ms and resets to page 0, paging requests `page=1` when an msw override returns `totalElements: 45`, delete dialog Cancel keeps and Yes removes); Playwright at seam C for 001, 002, 003.
- Model: sonnet
- What to build:
  - Install `@mui/icons-material` pinned to `9.5.0` (same as `@mui/material`).
  - `docs/api/engage-admin-api.yaml`: add schemas `Attachment`, `BrokerNote`, `BrokerNoteRequest`, `BrokerNotePage` (`{content: BrokerNote[], totalElements, totalPages, number, size}`) and these operations, each with `bearerAuth`, 401 `Unauthorized` and `x-confirm: Pradeep`: `POST /api-admin/broker-note` (`multipart/form-data`: part `note` of type `application/json` holding `BrokerNoteRequest`, zero or more binary parts `attachments`) → 201 `BrokerNote` with header `Location: /api-admin/broker-note/{id}`, 400 `{message, fieldErrors?}`; `GET /api-admin/broker-note` (query `q` optional string, `page` integer default 0, `size` integer default 20) → 200 `BrokerNotePage`, newest first; `GET /api-admin/broker-note/{id}` → 200 `BrokerNote`, 404; `GET /api-admin/broker-note/lastOfEmitter/{emitterId}` → 200 `BrokerNote`, 204 when none; `DELETE /api-admin/broker-note/{id}` → 204, 404; `GET /api-admin/referential/broker` → 200 `string[]`; `GET /api-admin/referential/types/broker-note` → 200 `string[]`.
  - `src/data/gatewayClient.ts`: `listBrokerNotes({q, page, size}: {q?: string, page: number, size: number})` → `Page<BrokerNote>` (omit `q` from the query string when empty), `getBrokerNote(id)`, `getLastBrokerNote(emitterId)` → `BrokerNote | null` (null on 204), `deleteBrokerNote(id)`, `listBrokers()` → `string[]`, `listRecommendations()` → `string[]`.
  - Fixtures (`src/mocks/fixtures.ts`): `brokers` = Barclays, BofA, CIC Market Solutions, Citi, IDMidcaps, Oddo BHF, RBC Capital, Redburn Atlantic, Seaport Global, Zacks; `recommendations` = BUY, NEUTRAL, OUTPERFORM, OVERWEIGHT, HOLD, UNDERWEIGHT, SELL, EQUALWEIGHT; `db.brokerNotes` reset by `resetFixtures()`, seeded (all `sendByEmail: false`, `attachments: []` unless stated, `emitter` built from the company's id, name and ric):
    - `bn1` c1 LVMH, Barclays, title "Target price raised after Q3", currency "€", currentObjective "720.00", currentRecommendation "OVERWEIGHT", recoChange true, previousObjective "680.00", previousRecommendation "NEUTRAL", sectorNote false, initiationNote false, createdAt 2026-10-09T07:45:00Z
    - `bn2` c5 Diageo, Citi, title "Initiating coverage", "p", "3100.00", "BUY", initiationNote true, other flags false, previous null, createdAt 2026-10-08T08:10:00Z
    - `bn3` c2 Danone, Oddo BHF, title null, "€", "64.00", "HOLD", sectorNote true, other flags false, previous null, createdAt 2026-10-07T09:30:00Z
    - `bn4` c3 Kering, BofA, title "Downgrade on China demand", "€", "290.00", "UNDERWEIGHT", recoChange true, previousObjective "340.00", previousRecommendation "NEUTRAL", createdAt 2026-10-06T06:55:00Z
    - `bn5` c4 Accor, RBC Capital, title "Hotels upcycle intact", "€", "48.00", "OUTPERFORM", all flags false, previous null, attachments `[{id: 'att-bn5', fileName: 'accor-rbc.pdf', contentType: 'application/pdf', size: 245760}]`, createdAt 2026-10-05T07:00:00Z
  - Handlers (`src/mocks/handlers.ts`, `*` path prefix): list filters case-insensitively by substring of `emitter.name`, `broker`, `title` and `currentRecommendation`, sorts `createdAt` descending, then pages with `page` (default 0) and `size` (default 20); get and delete return 404 for an unknown id (delete removes from `db.brokerNotes`); `lastOfEmitter` returns that company's newest note or 204; the two referential handlers return the fixture arrays.
  - Screen `src/screens/BrokerNotes/BrokerNotesScreen.tsx` at route `broker-notes` (replace the placeholder in `src/app/AppRoutes.tsx`): `ScreenTitle` "Broker notes"; a row with a search field (placeholder "Search broker notes") and a button "Send a note" (navigates to `/broker-notes/new`, a "Coming soon" placeholder titled "Send a broker note" until T02); a legend line showing `SwapVertIcon` "Recommendation change", `NewReleasesOutlinedIcon` "Initiation", `CategoryOutlinedIcon` "Sector" (icons from `@mui/icons-material`, colour `textSecondary`, 13px text). In a `Panel`, a table with columns "Sent on", "Company", "Broker", "Type", "Target", "Recommendation", "Previous target", "Previous recommendation" and a last unlabelled column holding a text button "Delete". Cells: Sent on = `createdAt` as dd/MM/yyyy HH:mm local time; Company = `emitter.name`; Type = one icon per true flag in the order recoChange, initiationNote, sectorNote, each with `aria-label` and `title` equal to its legend label; Target = "{currentObjective} {currency}"; Previous target = "{previousObjective} {currency}" and Previous recommendation = `previousRecommendation`, both empty when `recoChange` is false. Empty result shows "No broker notes found." in the table body. Search is sent 300 ms after the last keystroke and resets to page 0. MUI `TablePagination` under the table: `rowsPerPage` 20, `rowsPerPageOptions={[]}`, `count` = `totalElements`, `page` = current page.
  - Delete dialog: title "Delete broker note", body "Are you sure you want to delete?", then bold "This action cannot be undone", buttons "Cancel" (closes, nothing sent) and "Yes" (calls `deleteBrokerNote`, closes, reloads the current page; on error shows the `GatewayError` message in an error `Alert` inside the dialog).
- Acceptance: the listed MTP rows pass.
- Commit: 1803afb

## BRN-T02: Send a broker note
- Plan: docs/plans/broker-notes-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: BRN-T01
- Satisfies: MTP-BRN-004, MTP-BRN-005, MTP-BRN-006, MTP-BRN-007, MTP-BRN-009
- Test approach: seam A (create posts `multipart/form-data` with part `note` as JSON and no `Content-Type` header set by the client; returns the created note); seam B (each required error, optional title, currency options and default, company options exclude archived Worldline, recommendation-change switch shows/hides and validates its two fields, request body sent for a valid note with and without the switch, Send navigates to `/broker-notes`, Send and continue resets and shows the snackbar, a 500 from an msw override shows the failure message and keeps values); Playwright at seam C for 004, 005, 006, 007. MTP-BRN-009 is covered by the seam B test only.
- Model: sonnet
- What to build:
  - `src/data/gatewayClient.ts`: if `form<T>(method: string, path: string, body: FormData): Promise<T>` does not already exist (the Flashes feature may have added it), add it as a private helper beside `json`: same as `send` but sets only `Authorization: Bearer {token}` (no `Content-Type`), same 401/403 handling and `toError` mapping, returns the parsed JSON body. Then `createBrokerNote(note: BrokerNoteRequest, files: File[])` builds a `FormData` with `note` = `new Blob([JSON.stringify(note)], {type: 'application/json'})` and one `attachments` entry per file, and calls `form<BrokerNote>('POST', '/api-admin/broker-note', data)`.
  - Mock create handler: `await request.formData()`, parse part `note` (read the blob as text then `JSON.parse`), find the company by `emitterId` (400 `{message: 'Unknown company'}` if missing), store a new note with `id: crypto.randomUUID()`, `createdAt: new Date().toISOString()`, `emitter` from the company, null for absent `title`/`previousObjective`/`previousRecommendation`, and attachment metadata per `attachments` part (`id: crypto.randomUUID()`, `fileName: file.name`, `contentType: file.type || 'application/octet-stream'`, `size: file.size`); respond 201 with the note and header `Location: /api-admin/broker-note/{id}`.
  - Screen `src/screens/BrokerNotes/SendBrokerNoteScreen.tsx` at route `broker-notes/new` (replacing T01's placeholder): `ScreenTitle` "Send a broker note", form in a `Panel`:
    - "Company": MUI `Autocomplete`, placeholder "Search companies", options = non-archived companies from `listCompanies()` sorted by name, label "{name} ({ric})"; error "Please enter a company".
    - "Note title": text, optional; sent only when non-blank.
    - "Broker": `Autocomplete`, placeholder "Search brokers", options from `listBrokers()` in returned order; error "Please enter a broker".
    - Heading "Note details": "Target" text (placeholder "0.00", `inputMode="decimal"`, error "Target is required"; free text, required only) beside a select labelled "Currency" with options "€", "$", "£", "p", "SFr", default "€"; "Recommendation" select from `listRecommendations()`, error "Type is required"; checkboxes "Sector" (`sectorNote`) and "Initiation" (`initiationNote`).
    - Heading "Recommendation change": a `Switch` labelled "Recommendation change" (`recoChange`). When on, show "Previous target" (placeholder "0.00", error "Target is required") and "Previous recommendation" (select of the same options, error "Type is required"); when off they are hidden and not sent.
    - Checkbox "Also send by email" (`sendByEmail`).
    - Buttons "Send" and "Send and continue". Errors appear on submit only. Values sent trimmed.
    - On success, "Send" navigates to `/broker-notes`; "Send and continue" resets every field to its default (empty, currency "€", switch and checkboxes off) and shows a MUI `Snackbar` anchored bottom-right with the message "Broker note sent", `autoHideDuration` 4000.
    - On any `GatewayError`, an error `Alert` above the form reads "Unable to create a note right now. Please try again later." and the values stay.
    - Files: pass an empty array until T03.
- Acceptance: the listed MTP rows pass; 001 to 003 still pass.
- Commit: 2536f06

## BRN-T03: Attachments on a broker note
- Plan: docs/plans/broker-notes-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: BRN-T02
- Satisfies: MTP-BRN-008
- Test approach: unit test at seam B for `AttachmentPicker` (adds files, shows name and size in KB, Remove, empty file refused, file over 10 485 760 bytes refused, total over 15 728 640 bytes refused, refused files not passed to `onChange`); seam B on the compose screen (files sent as `attachments` parts, reset clears them); Playwright at seam C for 008 using `setInputFiles` with in-memory buffers (1 KB, 0 bytes, 10 485 761 bytes, and two of 8 MB).
- Model: sonnet
- What to build:
  - If `src/ds/components/AttachmentPicker.tsx` does not already exist (the Flashes feature may have added it), create it and export it from `src/ds/components/index.ts`: props `{files: File[], onChange: (files: File[]) => void, label: string}`. Renders `label` as a section heading, a button "Add an attachment" wired to a hidden `<input type="file" multiple>`, and one line per file: the file name, its size as "{size in KB, rounded up} KB", and a text button "Remove". Checks each chosen file in order: 0 bytes → error "Attachment {file name} is empty."; over 10 485 760 bytes → "Attachment {file name} is larger than 10 MB."; would bring the total over 15 728 640 bytes → "Attachments must total 15 MB or less." Refused files are not added; errors show in an error `Alert` under the list and are cleared on the next successful add or remove. Any file type is accepted.
  - Compose screen: an `AttachmentPicker` with label "Attachments" between the recommendation-change block and "Also send by email"; its files go to `createBrokerNote`; "Send and continue" clears them.
- Acceptance: the listed MTP row passes; 001 to 007 still pass.
- Commit: efd2cf2

## Company tabs shared facts (apply to every CTAB task)

- Plan: docs/plans/company-tabs-plan.md

- Repo root: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Admin`. English copy only; all copy below is exact.
- Gateway client: `src/data/gatewayClient.ts` (`createGatewayClient`, private `send`, `json`, `empty`, `GatewayError`); types in `src/data/types.ts`; mock data in `src/mocks/fixtures.ts` (`db`, `pairs`, `resetFixtures()`); handlers in `src/mocks/handlers.ts` (paths prefixed `*`, helpers `notFound()`, `bad(message)`).
- Company detail: `src/screens/CompanyDetail/CompanyDetailScreen.tsx` renders the tab named in `companies/:id/:tab?`; non-Information tabs other than Users currently render a "Coming soon" box. Copy dialog and alert patterns from `UsersTab.tsx` and `UserFormDialog.tsx`. Content inside `Panel` from `src/ds`.
- Mock companies: `c1` LVMH `LVMH.PA`, `c2` Danone `DANO.PA`, `c3` Kering `PRTP.PA`, `c4` Accor `ACCP.PA`, `c5` Diageo `DGE.L`, `c6` Worldline `WLN.PA` (archived).
- RIC lookup: existing client call `lookupRic(search)` on `GET /api-admin/pairs-management/pairs/ric/{search}`; 404 means unknown.
- Seams: A = gateway client vs msw node server (`src/data/gatewayClient.test.ts`); B = Testing Library inside theme, `MemoryRouter`, signed-in auth, msw; C = Playwright on `npm run dev` (port 5174, mock mode). Each task ends with `npm run verify` green and its rows marked in `docs/mtp-results.md` (🤖 when Playwright-covered).
- Every new contract operation carries `x-confirm-with: Pradeep`.

## CTAB-T01: Ticker lists contract, mock and Lists tab view and create
- Plan: docs/plans/company-tabs-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: BRN-T03
- Satisfies: MTP-CTAB-001, MTP-CTAB-002, MTP-CTAB-003
- Test approach: integration test at seam A (`listTickerLists`, `createTickerList` happy path and the 400 duplicate surfacing as `GatewayError` with the message); seam B for `ListsTab` (lists with counts, expand, empty state, create validation: "Required", "Add at least one ticker", "This RIC code does not exist", "This ticker is already in the list", successful create, duplicate message shown verbatim and dialog stays open); Playwright at seam C for 001 to 003.
- Model: sonnet
- What to build:
  - Contract in `docs/api/engage-admin-api.yaml` for ALL eight company-tabs operations (lists and imports), each with `x-confirm-with: Pradeep`:
    1. `GET /api-admin/tickers/by-emitter/{emitterId}` query `page` (default 0), `size` (default 100) → 200 `{content: TickerList[], totalElements: integer, totalPages: integer, number: integer, size: integer}`.
    2. `PUT /api-admin/tickers` body `{emitterId: string, name: string, tickers: string[]}` → 201 `TickerList`; 400 `{message: "A list with name [{name}] already exists for the emitter."}`.
    3. `PUT /api-admin/tickers/{listId}/ticker` body `{ric: string}` → 201 `Ticker`; 404 `{message}`.
    4. `PUT /api-admin/tickers/{listId}` body `{name: string}` → 200 `TickerList`; 400 duplicate message as 2; 404.
    5. `DELETE /api-admin/tickers/{id}` → 204; 404.
    6. `DELETE /api-admin/tickers/ticker/{id}` → 204; 404.
    7. `GET /api-admin/import/excel-types` → 200 array of `{kind: 'stock' | 'stock-lending' | 'reco-tp' | 'consensus', label: string}`; add the note "Label to kind mapping is an assumption: Short BlackApp (file 10) = stock, Short Markit (file 9) = stock-lending."
    8. `POST /api-admin/emitter/{emitterId}/import/{kind}` query `purge` boolean (the screen always sends true), multipart body with one part `file` → 200 `{totalRows: integer, okRows: integer, rowErrors: object (row number string → string[])}`; 400 `{message}` ("Invalid Excel file", "Tab [Brute] not found in Excel file", "Invalid type [{kind}]"); 404.
    - Schemas `TickerList` = `{id, emitterId, name, tickers: Ticker[]}`, `Ticker` = `{id, ric, name}`, `ImportType` = `{kind, label}`, `ImportResult` = `{totalRows, okRows, rowErrors}`. All responses also list 401 and 403 like the existing operations.
  - Types `TickerList`, `Ticker`, `TickerListPage`, `CreateTickerListRequest` in `src/data/types.ts`. Client functions `listTickerLists(emitterId)` (page 0, size 100, returns `content`) and `createTickerList(request)`.
  - Fixtures: `db.tickerLists`, reset in `resetFixtures()`, seeded: `l1` emitterId `c1` "Luxury peers" tickers `t1` HRMS.PA Hermes International, `t2` CDI.PA Christian Dior, `t3` PRTP.PA Kering; `l2` `c1` "European consumer" `t4` OREP.PA L'Oreal; `l3` `c2` "Food peers" `t5` NESN.S Nestle, `t6` ULVR.L Unilever. Handlers for operations 1 to 6 now (3 to 6 are used by T02 but handled here so the contract and mock land together): new ids `crypto.randomUUID()`; ticker names from `pairs`; a RIC not in `pairs` → 404 `{message: "No pair with RIC [{ric}]"}`; duplicate names compared case-insensitively within the same `emitterId` → 400 with the message in 2 (filling `{name}` with the submitted name); unknown list or ticker id → 404.
  - `src/screens/CompanyDetail/ListsTab.tsx`, rendered for the `lists` tab. Button "Create a list". Empty state "No lists yet". One collapsible row per list in gateway order: name, "{N} items" ("1 item" when N is 1, "0 items" when 0), and buttons "Add an item", "Rename", "Delete" (render only; T02 wires them). Expanding shows one row per ticker with "{ric}", "{name}" and a "Delete" button (render only).
  - Create dialog, title "Create a list": field "Title" (error "Required" when blank after trim); field "Ticker" with placeholder "Search for a peer" and an "Add" button that calls `lookupRic` (404 → "This RIC code does not exist" under the field; a RIC already chosen, compared case-insensitively → "This ticker is already in the list"; found → appended as a removable chip "{ric}" and the field clears); on Save with no chips → "Add at least one ticker". Buttons "Cancel", "Save". Save sends operation 2 with the chips' RICs as returned by the lookup; 201 closes and reloads the lists; 400 keeps the dialog open with the server `message` verbatim in an error alert at its top.
  - Reconcile: in `src/screens/CompanyDetail/CompanyDetailScreen.test.tsx` the "shows Coming soon on the other tabs" test and in `e2e/companies.spec.ts` the "MTP-ADMF-017" test, drop Lists from the loop (keep Imports and Factset). In `docs/manual-test-plan.md` change MTP-ADMF-017 to Steps "Open Imports and Factset." Expected "Each tab shows "Coming soon"."
- Acceptance: the listed MTP rows pass; MTP-ADMF-014 to 021 still pass.
- Commit: b344f78

## CTAB-T02: Add item, rename, delete item and delete list
- Plan: docs/plans/company-tabs-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: CTAB-T01
- Satisfies: MTP-CTAB-004, MTP-CTAB-005
- Test approach: seam A for `addTicker`, `renameTickerList`, `deleteTickerList`, `deleteTicker`; seam B for each dialog (validation, server message verbatim, Cancel keeps, Yes removes, counts update); Playwright at seam C for 004 and 005.
- Model: sonnet
- What to build:
  - Client functions `addTicker(listId, ric)`, `renameTickerList(listId, name)`, `deleteTickerList(listId)`, `deleteTicker(tickerId)` on operations 3 to 6 (paths `PUT /api-admin/tickers/{listId}/ticker`, `PUT /api-admin/tickers/{listId}`, `DELETE /api-admin/tickers/{id}`, `DELETE /api-admin/tickers/ticker/{id}`). Handlers already exist from T01.
  - "Add an item" opens a dialog titled "Add an item" with the same "Ticker" field, placeholder "Search for a peer", lookup and errors as T01's create dialog ("This RIC code does not exist"; "This ticker is already in the list" when the list already holds that RIC). Buttons "Cancel", "Save"; Save with no RIC checked yet runs the lookup first. 201 closes and reloads.
  - "Rename" opens a dialog titled "Rename a list" with field "Title" prefilled, error "Required", buttons "Cancel", "Save"; 200 closes and reloads; 400 shows the server message verbatim in the dialog.
  - List "Delete" opens a dialog titled "Delete a list", body "Are you sure you want to delete {name}?" then a bold line "This action cannot be undone", buttons "Cancel" (closes, nothing changes) and "Yes" (operation 5, closes, reloads). Ticker "Delete" opens "Delete an item", body "Are you sure you want to delete {ric}?" plus the same bold line and buttons (operation 6). A failure shows the server message verbatim in an error alert in the dialog.
  - Every confirm/save button is disabled while its request is in flight (no double sends).
- Acceptance: the listed MTP rows pass.
- Commit: 0401312

## CTAB-T03: Imports tab
- Plan: docs/plans/company-tabs-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: CTAB-T01
- Satisfies: MTP-CTAB-006, MTP-CTAB-007, MTP-CTAB-008
- Test approach: seam A for `listImportTypes` and `importFile` (multipart part named `file`, query `purge=true`, no hand-set `Content-Type`, 400 message surfaced); seam B for `ImportsTab` (four options in order, button disabled states, success line, row-error list order and copy, whole-file errors, result cleared on new choice); Playwright at seam C for 006 to 008 using `setInputFiles` with buffers named `consensus.xlsx`, `stock-errors.xlsx`, `invalid.xlsx`, `no-brute.xlsx`.
- Model: sonnet
- What to build:
  - Extend the private `send` in `gatewayClient.ts`: when `body` is a `FormData`, pass it as the body unchanged and do not set `Content-Type`. Client functions `listImportTypes()` (`GET /api-admin/import/excel-types`) and `importFile(emitterId, kind, file)` (`POST /api-admin/emitter/{emitterId}/import/{kind}?purge=true`, `FormData` with `file`), returning `ImportResult`.
  - Fixture `importTypes` in this order: `{kind: 'stock', label: 'Short BlackApp (file 10)'}`, `{kind: 'consensus', label: 'Consensus'}`, `{kind: 'stock-lending', label: 'Short Markit (file 9)'}`, `{kind: 'reco-tp', label: 'Reco TP'}`. Handlers: types list returns them; upload reads `await request.formData()`, takes the `file` entry's name lower-cased: contains `invalid` → 400 `{message: "Invalid Excel file"}`; contains `no-brute` → 400 `{message: "Tab [Brute] not found in Excel file"}`; contains `errors` → 200 `{totalRows: 150, okRows: 148, rowErrors: {"101": ["Field [Value] shouldn't be empty"], "117": ["Value [{that company's RIC}] was expected for field [RIC]."]}}`; otherwise 200 `{totalRows: 20, okRows: 20, rowErrors: {}}`. A kind not in the four → 400 `{message: "Invalid type [{kind}]"}`; unknown company → 404.
  - `src/screens/CompanyDetail/ImportsTab.tsx`, rendered for the `imports` tab: select labelled "Type" with placeholder "Choose a type" listing the gateway labels in order; a "Choose a file" button opening a hidden file input (`accept=".xlsx,.xls"`) and showing the chosen file's name; button "Import a file", disabled until a type and a file are chosen and while the upload runs. Result: `rowErrors` empty → success alert "{okRows} of {totalRows} rows imported"; otherwise a warning alert with the same line, then a heading "Rows with errors" and one line per message, rows in ascending numeric order, "Row {n}: {message}". Any 400/404 → error alert with the server message verbatim. Changing the type or the file clears the previous result.
  - Reconcile: drop Imports from the placeholder loops in `CompanyDetailScreen.test.tsx` and `e2e/companies.spec.ts` (only Factset remains, still "Coming soon"); in `docs/manual-test-plan.md` change MTP-ADMF-017 to Steps "Open Factset." Expected "The tab shows "Coming soon"."
- Acceptance: the listed MTP rows pass; MTP-ADMF-017 still passes for Factset.
- Commit: a5db7df

## Version and monitoring shared facts (apply to every VMON task)

- Plan: docs/plans/version-monitoring-plan.md

- Repo root: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Admin`. English copy only; all copy below is exact.
- Gateway client: `src/data/gatewayClient.ts` (`createGatewayClient`, private `send`, `json`, `empty`, `GatewayError`); types in `src/data/types.ts`; mock data in `src/mocks/fixtures.ts` (`db`, `resetFixtures()`); handlers in `src/mocks/handlers.ts` (paths prefixed `*`, helper `bad(message)`).
- Routes in `src/app/AppRoutes.tsx`: `version` and `monitoring` currently render `PlaceholderScreen`. Page heading via `src/screens/ScreenTitle.tsx`. Content inside `Panel` from `src/ds`; colours from `src/ds` tokens only.
- Seams: A = gateway client vs msw node server (`src/data/gatewayClient.test.ts`); B = Testing Library inside theme, `MemoryRouter`, signed-in auth, msw; C = Playwright on `npm run dev` (port 5174, mock mode). Each task ends with `npm run verify` green and its rows marked in `docs/mtp-results.md` (🤖 when Playwright-covered).
- Every new contract operation carries `x-confirm-with: Pradeep`.
- Reason codes, in this order, with labels: TOKEN_EXPIRED "Session expired"; TOKEN_INVALID_SIGNATURE "Authentication compromised"; TOKEN_REVOKED "Access revoked"; USER_NOT_FOUND "User account deleted"; SESSION_CORRUPTED "Session corrupted"; TOKEN_REPLACED_BY_NEW_LOGIN "New login detected"; TOKEN_MALFORMED "Malformed token"; TOKEN_INVALID "Invalid token"; USER_DEACTIVATED "User account deactivated"; INSUFFICIENT_ROLES "Insufficient roles"; MANUAL_LOGOUT "Manual sign-out". Platforms: DESKTOP "Desktop app"; MOBILE "Mobile app". Unknown codes show the code itself.
- Placeholder reconcile rule (both tasks): remove the entry this task replaces from the placeholder list in `e2e/shell.spec.ts` ("MTP-ADMF-005") and from the `it.each` placeholder test in `src/app/AppRoutes.test.tsx`, and drop its name from the Steps of MTP-ADMF-005 in `docs/manual-test-plan.md`. Other features may already have removed theirs. If no placeholder entries remain, replace the ADMF-005 Playwright test with one that clicks every sidebar entry and asserts "Coming soon" never shows, delete the `it.each` placeholder unit test, and set MTP-ADMF-005 to Steps "Click every sidebar entry in turn." Expected "No entry shows "Coming soon". The address bar changes per entry."

## VMON-T01: Contract, mock and Version screen
- Plan: docs/plans/version-monitoring-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: CTAB-T03
- Satisfies: MTP-VMON-001, MTP-VMON-002, MTP-VMON-003
- Test approach: seam A for `getAppVersion` (200 returns the version, 204 returns `null`) and `publishAppVersion` (400 surfaces the message); seam B for `VersionScreen` (current version, "No version published yet" with an msw 204 override, format error for "3.5", "abc" and empty, success toast and refresh, duplicate message); Playwright at seam C for 001 to 003 (the 204 case via `page.route('**/api-admin/app-version', ...)` answering 204 on GET).
- Model: sonnet
- What to build:
  - Contract in `docs/api/engage-admin-api.yaml` for ALL four feature operations, each `x-confirm-with: Pradeep`, each also listing 401 and 403:
    1. `GET /api-admin/app-version` → 200 `AppVersion` `{version: string, forceUpdate: boolean, createdAt: date-time}`; 204 when no version exists.
    2. `POST /api-admin/app-version` body `{version: string, forceUpdate: boolean}` → 201 `AppVersion`; 400 `{message: "A version {version} already exists."}`.
    3. `GET /api-admin/disconnections/stats` query `days` integer (7, 30 or 90; default 7) → 200 `DisconnectionStats` `{days: integer, total: integer, byReason: [{reason: string, count: integer}], byPlatform: [{platform: 'DESKTOP' | 'MOBILE', count: integer}]}`.
    4. `GET /api-admin/disconnections` query `page` (default 0), `size` (default 20), `sort` (default `createdAt,desc`), optional `userEmail`, `startDate` and `endDate` (`YYYY-MM-DD`, inclusive), `platform`, `reason` → 200 `{content: DisconnectionLog[], totalElements: integer, totalPages: integer, number: integer, size: integer}`; `DisconnectionLog` = `{id: string, createdAt: date-time, userEmail: string, platform: 'DESKTOP' | 'MOBILE', reason: string, ipAddress: string, userAgent: string, details: string}`; list the eleven reason codes as the documented values of `reason`.
  - Types and client functions `getAppVersion(): Promise<AppVersion | null>` (204 → `null`, check `response.status` before parsing) and `publishAppVersion(request)`.
  - Fixture `db.appVersions` = `[{version: '3.4.0', forceUpdate: false, createdAt: '2026-09-01T09:00:00Z'}]`, reset in `resetFixtures()`. Handlers: GET returns the last entry or 204 when empty; POST rejects a version already in the list with 400 `{message: "A version {version} already exists."}`, else appends `{version, forceUpdate, createdAt: now}` and returns it with 201.
  - `src/screens/Version/VersionScreen.tsx` on route `/version`: heading "Version"; label "Current version" with the version in bold, or "No version published yet" on 204; field "Enter the new version:"; checkbox "Force users to update the application" (unticked); button "Send". On Send, a value not matching `^\d+\.\d+\.\d+$` (empty included) shows "Format should be like this X.X.X" under the field and sends nothing. Send is disabled while the request runs. 201: MUI `Snackbar` bottom-right with a success `Alert` "Version added successfully", `autoHideDuration` 4000; reload the current version; clear the field and untick the checkbox. 400: error alert above the form with the message verbatim.
  - Reconcile the Version placeholder per the shared rule.
- Acceptance: the listed MTP rows pass; MTP-ADMF-004 and 005 still pass.
- Commit: d11b560

## VMON-T02: Monitoring screen
- Plan: docs/plans/version-monitoring-plan.md
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: VMON-T01
- Satisfies: MTP-VMON-004, MTP-VMON-005, MTP-VMON-006, MTP-VMON-007, MTP-VMON-008
- Test approach: seam A for `getDisconnectionStats(days)` and `listDisconnections(query)` (query string built from filled filters only); seam B for `MonitoringScreen` (overview figures per period, bar labels and one-decimal percentages, ordering, "0 (0.0%)" never shown because zero counts are hidden, table columns and date format, pagination caption, filters apply and clear, "Loading logs..." while pending via a delayed msw handler, "No disconnection logs found."); unit test at the mock handler level for the date-range filter with fixed dates; Playwright at seam C for 004 to 008.
- Model: sonnet
- What to build:
  - Client functions `getDisconnectionStats(days)` (`GET /api-admin/disconnections/stats?days={days}`) and `listDisconnections({page, size, userEmail?, startDate?, endDate?, platform?, reason?})` (`GET /api-admin/disconnections`, always `sort=createdAt,desc`, omitting empty filters).
  - Fixtures built at module load (and rebuilt by `resetFixtures()`), 45 logs for i = 0 to 44: `id` `d{i+1}`; `createdAt` = now minus (i × 2 days + 1 hour), ISO string; `userEmail` by i mod 5: claire.martin@lvmh.example, sophie.laurent@danone.example, james.walker@diageo.example, camille.roux@accor.example, elodie.petit@kering.example; `platform` DESKTOP when i is even, MOBILE when odd; `reason` = the code at index i mod 11 in the shared order; `ipAddress` `10.0.0.{i+1}`; `userAgent` "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Engage Desktop/2.3.0" (DESKTOP) or "Engage/3.4.0 (iPhone; iOS 26.5)" (MOBILE); `details` "Mock disconnection {i+1}". Stats handler counts logs with `createdAt` within the last `days` days (7 → 4, 30 → 15, 90 → 45), grouping by reason and platform, omitting zero counts. List handler: newest first; `userEmail` case-insensitive substring; `startDate`/`endDate` inclusive against the UTC date (`YYYY-MM-DD`) of `createdAt`; `platform` and `reason` exact; then paged by `page` and `size`.
  - `src/screens/Monitoring/MonitoringScreen.tsx` on route `/monitoring`: heading "Disconnection monitoring"; "Analysis period:" select with "7 days", "30 days", "90 days" (default 7 days; changing it reloads stats); button "Refresh" (reloads stats and the current log page). Section "Overview": three figures labelled "Total disconnections", "Desktop app", "Mobile app" for the period. Section "Analysis": "Breakdown by disconnection reason" and "Breakdown by platform", one `LinearProgress` (determinate, value = percentage) per entry with a count above zero, sorted by count descending then label ascending, each labelled "{label}" and "{count} ({percentage}%)" with percentage = count / total × 100 to one decimal place. Section "All disconnection logs": filters "User email" (text), "From" and "To" (`TextField type="date"`), "Platform" ("All platforms", "Desktop app", "Mobile app"), "Reason" ("All reasons" then the eleven labels in order), buttons "Apply filters" (sends the filled filters, page 1) and "Clear filters" (empties them, page 1). Table columns "Date" (dd/MM/yyyy HH:mm, local time), "User", "Platform" (label), "Reason" (label), "IP address", "Browser/System" (`userAgent`), "Details". While loading: "Loading logs...". No rows: "No disconnection logs found." Caption "{totalElements} logs in total • Page {number + 1} of {totalPages}" (when `totalPages` is 0 show "0 logs in total • Page 1 of 1"); MUI `Pagination` with `count` = `totalPages`, page size 20.
  - Reconcile the Monitoring placeholder per the shared rule (MTP-VMON-008 asserts neither Version nor Monitoring shows "Coming soon").
- Acceptance: the listed MTP rows pass; MTP-ADMF-004 and 005 still pass.
- Commit: 16b7a02

## REP-T07: Keep edits made just before leaving a report, and decide what a failed lock does
- Plan: docs/plans/reports-plan.md
- Kind: bugfix
- Blocking: yes
- Status: done
- Blocked by: none (owner decided 2026-10-12)
- References: MTP-REP-005, MTP-REP-010, MTP-REP-012 (from /feature-review 2026-10-12)
- Test approach: hook-level test for `useAutoSave` with fake timers (pending values saved on unmount and on `pagehide`, before `unlock`); seam B for the failed-lock state; Playwright for leave-within-3 s on the company and market screens.
- Model: sonnet
- What to build:
  - Data loss: `useAutoSave` clears its timer on unmount without saving, so typing then leaving within 3 s ("Back to reports", the MARKET "View" link, a sidebar entry) drops the edit. CUSTOM CONTENT 1 and 2 always lose it when the next click is a link, because their countdown only starts on blur. Owner decision: when any value has changed since the last save (including unblurred custom-box text), save all fields at once on unmount and on `pagehide`, and only then send `unlock`. Applies to the company and market screens; does not apply in Edit mode on sent reports (explicit Save only).
  - Failed lock: if the first `lock` call fails, `useReportLock` still reports `held`, so editors and auto-save stay on and `unlock` is sent on exit. Owner decision: on a failed `lock`, the report stays read-only (no editors, no action bar, no auto-save, no `unlock` on exit) and an error alert above the boxes reads "This report could not be opened for editing. Try again later." Same on the market screen.
- Acceptance: the new tests pass; MTP-REP-005, 010 and 012 still pass.
- Commit: c802efc

## FLS-T05: Show an error when an attachment download fails
- Plan: docs/plans/flashes-plan.md
- Kind: gap
- Blocking: yes
- Status: done
- Blocked by: none (owner decided 2026-10-12)
- References: MTP-FLS-003 (from /feature-review 2026-10-12)
- Test approach: seam B with an msw 404 and 500 override on the attachment content endpoint, RED first.
- Model: sonnet
- What to build: `FlashDetailScreen` calls `download()` with `void` and no catch, so a failed `getAttachmentContent` shows nothing and leaves an unhandled rejection. Catch it and show an error `Alert` above the attachments reading "The attachment could not be downloaded. Try again later." (owner decision 2026-10-12).
- Acceptance: the new tests pass; MTP-FLS-003 still passes.
- Commit: cfcffde

## VMON-T03: Decide whether Apply and Clear always reload the logs
- Plan: docs/plans/version-monitoring-plan.md
- Kind: polish
- Blocking: yes
- Status: done
- Blocked by: none (owner decided 2026-10-12)
- References: MTP-VMON-007 (from /feature-review 2026-10-12)
- Test approach: seam B counting list requests on a repeat Apply and on Clear with no filters set.
- Model: sonnet
- What to build: with nothing changed and on page 1, a second "Apply filters" or a "Clear filters" sends no request, because the applied filters object and page are unchanged. Owner decision: both buttons always reload page 1 of the list, even when nothing changed; bump a reload counter in both handlers.
- Acceptance: the new test passes; MTP-VMON-007 still passes.
- Commit: 962cf5a

## Automation status
<!-- Filled by /feature-implement: one line per automated MTP row, e.g. "MTP-REP-001: 🤖 <spec file and test name>" -->
- MTP-REP-001, MTP-REP-002, MTP-REP-003: e2e/reports.spec.ts (one test each)
- MTP-REP-004, MTP-REP-011, MTP-REP-013: e2e/reports.spec.ts (one test each)
- MTP-REP-005, MTP-REP-006: e2e/reports.spec.ts (one test each; partial: "reload" is an in-app reopen, mock writes do not survive a page reload)
- MTP-REP-007, MTP-REP-008, MTP-REP-009: e2e/reports.spec.ts (one test each)
- MTP-CTAB-006, MTP-CTAB-007, MTP-CTAB-008: e2e/companies.spec.ts (Imports tab, one test each)
- MTP-FLS-005, MTP-FLS-006, MTP-FLS-007, MTP-FLS-008, MTP-FLS-009: e2e/flashes.spec.ts (one test each)
- MTP-BRN-001, MTP-BRN-002, MTP-BRN-003: e2e/brokerNotes.spec.ts (one test each)
- MTP-BRN-004, MTP-BRN-005, MTP-BRN-006, MTP-BRN-007: e2e/brokerNotes.spec.ts (one test each)
- MTP-BRN-008: e2e/brokerNotes.spec.ts (one test)
- MTP-BRN-009: SendBrokerNoteScreen.test.tsx ("shows the failure message and keeps the values on a 500")
- MTP-CTAB-001, MTP-CTAB-002, MTP-CTAB-003: e2e/companyLists.spec.ts (one test each)
- MTP-CTAB-004, MTP-CTAB-005: e2e/companyLists.spec.ts (one test each)
- MTP-VMON-001, MTP-VMON-002, MTP-VMON-003: e2e/version.spec.ts (one test each)
- MTP-VMON-004, MTP-VMON-005, MTP-VMON-006, MTP-VMON-007, MTP-VMON-008: e2e/monitoring.spec.ts (one test each)
- REP-T07: e2e/reports.spec.ts ("typing then leaving within 3 s keeps the edit, custom boxes included", "typing a market report then leaving within 3 s keeps the edit"); MTP-REP-005, 010, 012 specs still pass
- FLS-T05: FlashDetailScreen.test.tsx ("shows an error when the attachment download fails with 404/500"); MTP-FLS-003 spec (e2e/flashes.spec.ts) still passes
- VMON-T03: MonitoringScreen.test.tsx ("reloads the list on a repeat Apply and on Clear with nothing changed"); MTP-VMON-007 spec still passes
