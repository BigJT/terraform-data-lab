# Language toggle plan

- Slug: language-toggle
- MTP prefix: LANG
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-13

## What we're building

An "EN | FR" switch at the bottom of the sidebar. Choosing FR turns every piece of text the admin reads into French at once, without a reload: sidebar, sign-in, no-access and stand-in sign-in pages, every screen, form, dialog, validation error, toast, table header, empty and loading text. Server `message` values and stored content (report text, flash bodies, company and user names) stay as they are.

The first visit follows the browser (French if its language starts with "fr", else English). The choice is remembered in that browser. Weekday and month names (the Reports date line) follow the language; numeric dates (dd/MM/yyyy, HH:mm) do not change.

French wording comes from myCMS where the specs give it, with its typos fixed; everything else is our own translation, listed in `docs/i18n-review.md` for the CMS team to check.

## API research

Confirmed 2026-10-13 with `npm view`.

| Package | Version | Notes |
|---|---|---|
| i18next | 26.4.4 | Peer `typescript ^5 \|\| ^6 \|\| ^7` (we use 6.0.3). `i18next.init({resources, lng, fallbackLng, interpolation: {escapeValue: false}})`; `i18next.changeLanguage(lng)`; interpolation `{{name}}`; plurals via `_one` / `_other` key suffixes with `count`. |
| react-i18next | 17.0.16 | Peers react >= 16.8, i18next >= 26.2.0. `initReactI18next` plugin, `useTranslation()` returns `{t, i18n}`; components re-render on `changeLanguage`. |
| dayjs | 1.11.23 (installed) | French locale at `dayjs/locale/fr` (present in node_modules). `dayjs.locale('fr')` gives "lundi 12 octobre 2026" for `dddd D MMMM YYYY`. |
| eslint-plugin-i18next | 6.1.5 | Considered for the guard and rejected: no declared peers, compatibility with ESLint 10 flat config unconfirmed. The guard is a Vitest test instead (decision 9). |

## Code survey

- `src/app/AppShell.tsx`: sidebar on `colors.chrome` with `navEntries` (Reports, Flashes, Broker notes, Companies, Version, Monitoring), "Engage Admin" at the top, then the bottom block with the signed-in name and a "Sign out" link. The switch goes at the top of that bottom block.
- `src/app/App.tsx` wraps theme, auth, gateway and router; `src/main.tsx` starts msw then renders. i18n is initialised by importing `src/i18n/index.ts` from `main.tsx` before render.
- `src/test/setup.ts`: msw server, `resetFixtures()`, fails any test that logs `console.error`. i18n is imported and forced to English here.
- Screens with text: `src/screens/{SignIn, NoAccess, MockEntraSignIn, Placeholder, Companies, AddCompany, CompanyDetail (Lists, Users, Imports, Factset, UserFormDialog, EditIndicesDialog), Reports, Flashes, BrokerNotes, Version, Monitoring}`, `src/screens/validation.ts`, `src/screens/Monitoring/labels.ts`, plus copy inside `src/ds/components` (RichTextEditor toolbar names, AttachmentPicker errors).
- Date helpers: dayjs in `src/screens/Reports/*` (date line, `lastSaved.ts`); `formatDate` in `UsersTab.tsx`; `formatSent` in `src/screens/Flashes/formatSent.ts`; `formatSentOn` in `BrokerNotesScreen.tsx`. Only the Reports date line and "Last saved" text contain words.
- `playwright.config.ts`: projects `chromium` (port 5174) and `entra-mock` (port 5175).
- **Will break:** nothing if unit tests are forced to English and Playwright stays English by default. Tests that look up the sidebar by text keep working.

Seams and coverage:
- Seam B (Testing Library): the switch, detection, remembering, `<html lang>`, and per-screen French rendering checks (a few keys per screen with `i18n.changeLanguage('fr')` inside the test). Automated.
- Guard tests (decision 9): key parity and no literal JSX text. Automated.
- Seam C (Playwright): MTP-LANG-001 to 007, French via `test.use({ locale: 'fr-FR' })` or by clicking FR. Automated.

## Implementation approach / decisions

Owner decisions, 2026-10-13:

1. **Scope:** everything the admin reads switches language. Server `message` values and stored content do not.
2. **First visit** follows `navigator.language` (starts with "fr" gives French, anything else English). The choice is remembered in `localStorage` under `engage-admin.language` (`"en"` or `"fr"`), every read and write wrapped in try/catch (falls back to detection). `document.documentElement.lang` is set to `"en"` or `"fr"` on start and on every change.
3. **Switch:** a small two-part control at the bottom of the sidebar, above the name and Sign out: a group with `aria-label` "Language" (FR: "Langue") holding two buttons "EN" and "FR" with `aria-pressed`. Current language: background `colors.panel`, text `colors.textPrimary`; the other: transparent background, text `colors.onChrome`, 1px border `colors.onChrome`. 12px, weight 600, height 24px, radius 2.
4. **French wording:** myCMS's where the specs give it, typos fixed ("L'object est requis" becomes "L'objet est requis", "étés" becomes "été", "dévérouiller" becomes "déverrouiller", "Suppression d'un element" becomes "Suppression d'un élément", "irreversible" becomes "irréversible"); otherwise our own translation. Every key goes in `docs/i18n-review.md` (columns Key, English, French, Source "myCMS" or "new").

Pinned for the build:

5. **Setup.** `src/i18n/index.ts` initialises i18next with `initReactI18next`, one namespace `translation`, resources from `src/i18n/en.json` and `src/i18n/fr.json`, `fallbackLng: 'en'`, `interpolation: {escapeValue: false}`, `lng` from decision 2. Exports `setLanguage(lng: 'en' | 'fr')` (calls `i18next.changeLanguage`, writes localStorage, sets `<html lang>`, calls `dayjs.locale(lng)`) and `detectLanguage(): 'en' | 'fr'`. Import `dayjs/locale/fr` there.
6. **Keys** are grouped by screen, camelCase, nested: `shell.*`, `signIn.*`, `noAccess.*`, `mockSignIn.*`, `placeholder.*`, `common.*` (Cancel, Save, Yes, No, Delete, Edit, Search, "Coming soon", "Saved successfully"), `validation.*`, `companies.*`, `addCompany.*`, `companyDetail.*`, `users.*`, `lists.*`, `imports.*`, `factset.*`, `reports.*`, `flashes.*`, `brokerNotes.*`, `version.*`, `monitoring.*`, `editor.*`, `attachments.*`. Interpolation `{{name}}`; plurals `_one` / `_other`.
7. **Components** use `const { t } = useTranslation()`; non-component helpers (`validation.ts`, `labels.ts`) return keys or take `t`. Values that are data (reason codes, roles, languages) map to keys, e.g. `monitoring.reason.TOKEN_EXPIRED`.
8. **Tests.** `src/test/setup.ts` imports `@/i18n` and runs `setLanguage('en')` in `beforeEach` (and clears the localStorage key), so existing tests stay English. Playwright default `locale` stays `en-US`; French rows use `test.use({ locale: 'fr-FR' })` in their own `describe` with fresh context storage.
9. **Guard** (`src/i18n/i18n.test.ts`, last task): (a) `en.json` and `fr.json` have identical key sets and no empty values; (b) a scan of every `src/**/*.tsx` file except `*.test.tsx`, `src/mocks/**` and `src/test/**` finds no JSX text node containing a letter (regex on the source for `>` followed by optional spaces, a letter, then text up to `<` or `{`), listing offenders; allowed: the brand "Engage Admin" and "EN" / "FR". (c) every key in `en.json` appears as a row in `docs/i18n-review.md`.
10. **Dates.** `dayjs.locale` follows the language, so the Reports date line reads "Aujourd'hui (lundi 12 octobre 2026)" / "lundi 5 octobre 2026". "Last saved" texts are keys with interpolation. dd/MM/yyyy and HH:mm stay as they are.

### Glossary: myCMS French from the specs (use these; typos fixed)

| English (current) | French |
|---|---|
| Reports / Flashes / Broker notes / Companies / Version | Rapports / Flashs / N. de brokers / Émetteurs / Version |
| Monitoring | Monitoring |
| Search companies / Show archived companies / Add company | Rechercher un émetteur / Afficher les émetteurs archivés / Ajouter un émetteur |
| Company, RIC, Sector, Users, Status (list columns) | Valeurs, Id ric, Secteur, Utilisateurs associés, Statut |
| Active / Archived | Actif / Archivé |
| 1. Information / 2. Indices / 3. Users | 1. Informations / 2. Indices / 3. Utilisateurs |
| RIC / Name / Language / French / English / Market / Sector / Sub-sector | ID RIC / Nom / Langue / Français / Anglais / Marché / Secteur / Sous-secteur |
| This RIC code does not exist | Ce code RIC n'existe pas |
| Index 1 to Index 4 | Indice 1 à Indice 4 |
| User {n} / First name / Last name / Position / Email / Phone | Utilisateur {{n}} / Prénom / Nom / Poste / E-mail / Téléphone |
| Email is required / Invalid email format | L'email est requis / Format d'email invalide |
| Back / Next / Add | Précédent / Suivant / Ajouter |
| Tabs Information, Lists, Users, Imports, Factset | Informations, Listes, Utilisateurs, Imports, Factset |
| Archive / Unarchive / This company is archived | Archiver / Désarchiver / Attention ! Émetteur archivé |
| INDICES / Edit / Edit indices | INDICES / Modifier / Modifier les indices |
| {n} items / {n} item | {{count}} éléments / {{count}} élément |
| Create list / Add item / Edit list / Delete item | Créer une liste / Ajout d'un élément / Modifier une liste / Suppression d'un élément |
| Search pair (placeholder) / Required | rechercher un pair / Requis |
| Users columns Name, Position, Email, Phone, Terms accepted / No | Nom, Poste, Adresse e-mail, N° de téléphone, CGU acceptées le / Non |
| Delete user | Suppression utilisateur |
| Last daily report read / Last flash read / N/A | Date de dernière lecture de daily report / Date de dernière lecture de flash / N/A |
| Choose a type / Import a file | Choisir un type / Importer un fichier |
| Add a new Factset peer / Search / Save / Saved successfully | Ajouter un nouveau pair Factset / Rechercher / Enregistrer / Enregistrement effectué avec succès |
| Reports tabs Companies / Markets | Valeurs / Marchés |
| Today ({date}) / Search reports | Aujourd'hui ({{date}}) / Rechercher un rapport |
| Companies ({n}) / Language ({n}) / Last modified / Validation / Status | Valeurs ({{n}}) / Langue ({{n}}) / Dernière modification / Validation / Statut |
| ... / To validate / Validated / To send / ✓ Sent at HH:mm | ... / À valider / Validé / À envoyer / ✓ Envoyé à {{time}} |
| Write a report / Write a market report | Rédiger un rapport / Rédiger un rapport de marché |
| COMPANY / SECTOR / MARKET / View | VALEUR / SECTEUR / MARCHÉ / Consulter |
| SHORT POSITIONS | POSITIONS COURTES |
| Enter your analysis here | Renseignez votre analyse ici |
| Last saved {relative} | Dernière sauvegarde {{relative}} |
| Request validation / Validate content / Content validated / Validate writing / Writing validated | Demander la validation / Valider le contenu / Contenu validé / Valider la rédaction / Rédaction validée |
| Send / Save / Edit / Sent at | Envoyer / Sauvegarde / Modifier / Envoyé à |
| Send the report / The report content and writing have not been validated. / Are you sure you want to send the report to {company}? / Cancel / Yes | Envoyer le rapport / Le contenu et la rédaction du rapport n'ont pas été validés. / Êtes-vous certain de vouloir envoyer le rapport à {{company}} ? / Annuler / Oui |
| CONTENT BEING WRITTEN / The report is being written by {name} / Do you want to unlock access to this report? | CONTENU EN COURS DE RÉDACTION / Le rapport est en cours de rédaction par {{name}} / Désirez-vous déverrouiller l'accès à ce rapport ? |
| Search flashes / Send a flash | Rechercher un flash / Envoyer un flash |
| Flash list columns Sent, Recipients, Company, Title, Type | Date d'envoi, Destinataire(s), Valeur, Titre, Type |
| RECIPIENTS / CONTENT / RELATED LINKS / ATTACHMENT | DESTINATAIRE(S) / CONTENU / LIENS ASSOCIÉS : / PIÈCE-JOINTE |
| Also sent by email | Duplicata envoyé par email |
| Send to all companies / Please choose a recipient | Envoyer à tous les émetteurs / Merci de saisir un destinataire |
| Subject / Subject is required / Company is required / Type is required / Message / Message is required | Objet / L'objet est requis / La valeur est requise / Le type est requis / Message / Le message est requis |
| Related links / One link per line | Liens associés / Merci de mettre un lien par ligne |
| Add an attachment / Also send by email | Ajouter une pièce jointe / Envoyer aussi par email |
| Flash could not be created message | Impossible de créer un flash pour le moment. Merci de réessayer ultérieurement. |
| Delete flash dialog: title, body, sub-text, buttons | Suppression d'un flash / Êtes-vous sûr de vouloir supprimer ? / Cette action est irréversible / Annuler / Oui |
| Search broker notes / Send a note | Rechercher une note de broker / Envoyer une note |
| Recommendation change / Initiation / Sector | Changement de recommandation / Initiation / Secteur |
| Note columns Sent, Company, Broker, Type, Target, Recommendation, Previous target, Previous recommendation | Date d'envoi, Valeur, Broker, Type, Objectif, Recommandation, Ancien Objectif, Ancienne Recommandation |
| Company / Search companies / Please choose a company | Émetteur / Rechercher un émetteur / Merci de saisir un émetteur |
| Note title / Broker / Search brokers / Please choose a broker | Titre de la note / Broker / Rechercher un broker / Merci de saisir un broker |
| Note information / Target / Target is required / Recommendation / Type is required | Informations de la note / Objectif / L'objectif est requis / Recommandation / Le type est requis |
| Previous target / Previous recommendation | Ancien objectif / Ancienne recommandation |
| Send and continue | Envoyer et continuer |
| Note could not be created message | Impossible de créer une note pour le moment. Merci de réessayer ultérieurement. |
| Current Version / Enter the new version: / Format should be like this X.X.X / Force the user to update the application / Version added successfully | Version actuelle / Saisissez la nouvelle version : / Le format doit être X.X.X / Forcer l'utilisateur à mettre à jour l'application / Version ajoutée avec succès |
| A version {v} already exists. (server message, shown as sent) | Une version {0} existe déjà. |
| Disconnection monitoring / Analysis period: / 7 days / 30 days / 90 days / Refresh | Monitoring des déconnexions / Période d'analyse : / 7 jours / 30 jours / 90 jours / Actualiser |
| Overview / Analysis / All disconnection logs | Vue d'ensemble / Analyses / Tous les logs de déconnexion |
| By disconnection reason / By platform | Répartition par cause de déconnexion / Répartition par plateforme |
| Log columns Date, User, Platform, Reason, IP address, Browser/System, Details | Date, Utilisateur, Plateforme, Raison, Adresse IP, Navigateur/Système, Détails |
| No disconnection logs found. / Loading logs... / {total} logs in total • Page {n} of {pages} | Aucun log de déconnexion trouvé. / Chargement des logs... / {{total}} logs au total • Page {{page}} sur {{pages}} |
| Reasons TOKEN_EXPIRED, TOKEN_INVALID_SIGNATURE, TOKEN_REVOKED, USER_NOT_FOUND, SESSION_CORRUPTED, TOKEN_REPLACED_BY_NEW_LOGIN | Session expirée, Authentification compromise, Accès révoqué, Compte utilisateur supprimé, Session corrompue, Nouvelle connexion détectée |
| Platforms DESKTOP / MOBILE | Application bureau / Application mobile |

Where the English on screen today differs slightly from the left column, keep today's English text unchanged in `en.json`; the left column is only there to match rows. "Version ajoutée avec succès", the "Forcer..." and "Saisissez..." lines are translations of myCMS's English copy on that screen (myCMS showed English there), so they are "new" in `docs/i18n-review.md`. The reasons myCMS left unmapped (TOKEN_MALFORMED, TOKEN_INVALID, USER_DEACTIVATED, INSUFFICIENT_ROLES, MANUAL_LOGOUT) get own translations.

## Manual test plan (definition of done)

MTP-LANG-001 to MTP-LANG-007 (rows in `docs/manual-test-plan.md`, execution in `docs/mtp-results.md`), all automated in Playwright.

## Out of scope / open questions

Out of scope: translating server messages or stored content; a third language; French e-mails or push texts (gateway side).

Open (none block the build): the CMS team to check every "new" row in `docs/i18n-review.md`.
