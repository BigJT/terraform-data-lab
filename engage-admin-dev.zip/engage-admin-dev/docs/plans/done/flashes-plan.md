# Flashes plan

- Slug: flashes
- MTP prefix: FLS
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

The Flashes area of Engage Admin, replacing myCMS "Flashs". A flash is a short rich-text news item sent to one or more companies. Creating a flash is sending it: no draft, no scheduled send, no edit afterwards. It can be deleted, which does not recall anything already delivered (push and email are the gateway's job, not the page's).

From the admin's point of view:

1. **List** at `/flashes`: sent flashes newest first, columns Sent, Recipients, Company, Title, Type; a search box; a "Send a flash" button; 20 rows per page.
2. **Detail** at `/flashes/:id`: title, sent time, recipients, content (type, company, message), related links, attachments (downloadable), a note when it was also emailed, and Delete with a confirmation dialog.
3. **Compose** at `/flashes/new`: recipients (pick companies or "Send to all companies"), subject, company, type, rich-text message, related links (one per line), attachments, "Also send by email", Send.

Behaviour recreates myCMS as `docs/mycms-admin-spec-1.md` section 5, the Flashes part of section 9 and the Flashs part of section 10 describe, in English.

## API research

Confirmed on npm 2026-10-12:

| Library | Version | Notes |
|---|---|---|
| @tiptap/react, @tiptap/pm, @tiptap/starter-kit | 3.31.4 | StarterKit 3 already includes bold, italic, underline, link, headings, bullet and ordered lists |
| @tiptap/extension-table | 3.31.4 | Tables (`TableKit`) |
| @tiptap/extension-image | 3.31.4 | Inline images; set `allowBase64: true` so data URLs are kept |
| dompurify | 3.4.17 | Cleans stored HTML before display; keeps `data:` image sources on `img` by default |

Assumed (to confirm with Pradeep): the five flash operations and their shapes below. The specs give the paths, the create payload and the error copy, not the list, detail or attachment shapes; this plan defines them.

## Code survey

- `src/data/gatewayClient.ts`: `createGatewayClient` with private `send`, `json`, `empty`; every call JSON. Flash create needs multipart: Flashes adds the private helper `form<T>(method: string, path: string, body: FormData): Promise<T>` (only the `Authorization` header set; same 401/403 and error handling as `send`). Broker notes, built after Flashes, reuses it unchanged. Types live in `src/data/types.ts`. `GatewayError {status, message, fieldErrors?}`.
- `src/mocks/fixtures.ts`: module state `db` (`companies`, `users`), `resetFixtures()` called before each test from `src/test/setup.ts`. Companies `c1` LVMH, `c2` Danone, `c3` Kering, `c4` Accor, `c5` Diageo, `c6` Worldline (archived).
- `src/mocks/handlers.ts`: handlers on `*`-prefixed paths, helpers `notFound()` and `bad(message)`.
- `src/app/AppRoutes.tsx`: `flashes` route is `<PlaceholderScreen title="Flashes" />` today; it is replaced.
- Screen conventions: `ScreenTitle`, `Panel` from `@/ds/components`, `colors` from `@/ds/theme`, `useGateway()` from `@/data/gatewayContext`, MUI tables (see `src/screens/Companies/CompaniesScreen.tsx`), dialogs (see `src/screens/CompanyDetail/UserFormDialog.tsx`).
- Tests: Vitest + Testing Library with `renderWithTheme`, msw node server (`server.use` for overrides); Playwright specs in `e2e/` against `npm run dev` on port 5174.
- Rich-text editor: the Reports feature (built first) is expected to create `src/ds/components/RichTextEditor.tsx`. If it exists, Flashes reuses it; otherwise the compose task creates it with the props below.

**Seams and coverage:**

- Seam A, gateway client against the msw node server: list (query and paging parameters), get, delete, types, multipart create (part names, JSON part content), attachment download. Automated.
- Seam B, screens with Testing Library and msw: list, search, paging, detail, delete dialog, compose validation, recipients, attachment rules, send, server error, HTML cleaning. Automated.
- Seam C, Playwright in mock mode: every MTP-FLS row. Automated.
- Push, email duplicate and attachment storage happen in the gateway: out of scope for the page, nothing to test here.

## Implementation approach / decisions

Owner decisions, 2026-10-12:

1. **Copy myCMS behaviour**, English copy only. The typo "L'object est requis" becomes "Subject is required".
2. **Editor:** TipTap 3.31.4, full toolbar for the flash message: headings (H2, H3), bold, italic, underline, bullet list, numbered list, link, table, image. Pasted image files are inserted inline as data URLs. No colour, highlight, full-screen, copy-format or eraser tools (myCMS removes them).
3. **Clean HTML on display** with dompurify 3.4.17 (`DOMPurify.sanitize(html, {USE_PROFILES: {html: true}})`), through the shared component `src/ds/components/SafeHtml.tsx` (props `{html: string}`, renders `DOMPurify.sanitize(html, {USE_PROFILES: {html: true}})` via `dangerouslySetInnerHTML`), created by Reports (REP-T02). Create it with exactly that shape if it does not exist.
4. **Attachments:** zero or more files of any type, picked with the shared component `src/ds/components/AttachmentPicker.tsx` (props `{files: File[], onChange: (files: File[]) => void, label: string}`), which Flashes creates and Broker notes reuses unchanged. Checked in the browser; a refused file is not added: empty gives "Attachment {file name} is empty.", over 10 MB (10 485 760 bytes) gives "Attachment {file name} is larger than 10 MB.", a total over 15 MB (15 728 640 bytes) gives "Attachments must total 15 MB or less.".
5. **Create = send.** No draft, no edit. Delete with confirmation.
6. **Recipients:** a searchable multi-select of non-archived companies, or the checkbox "Send to all companies" (which disables the picker and sends `sendToAll: true`, `emittersUUID: []`).
7. **Flash types** come from the gateway; the mock returns the eight myCMS values: "Price movement", "Pre-opening", "Breaking News", "Reco / TP", "Sales traders' comments", "Brokers Interests", "Brokers Comments", "Peer report".

**Contract** (added to `docs/api/engage-admin-api.yaml`, all `bearerAuth`, all to confirm with Pradeep):

- `GET /api-admin/flashs?q={text}&page={n}&size={n}` (page from 0, size default 20) → 200 `FlashPage {content: Flash[], totalElements, totalPages, number, size}`, newest first. `q` matches title, value, type and description, case-insensitive substring.
- `GET /api-admin/flashs/{id}` → 200 `Flash`; 404.
- `DELETE /api-admin/flashs/{id}` → 204; 404.
- `POST /api-admin/flashs` multipart: part `flash` (`application/json`) `{title, value, description, type, links: string[], emittersUUID: string[], sendByEmail: boolean, sendToAll: boolean}`, plus zero or more parts `attachments` (files) → 201 `Flash` with `Location: /api-admin/flashs/{id}`; 400 `{message, fieldErrors?}`.
- `GET /api-admin/referential/types/flash` → 200 string array.
- `GET /api/attachment/{id}/content` → 200 file bytes with the stored content type; 404. The page sends the bearer token.
- `Flash` = `{id, title, value, description, type, links: string[], sendByEmail, sendToAll, emitters: [{id, name}], attachments: Attachment[], createdAt: date-time, updatedAt: date-time}`.

**Copy, pinned:**

- List: heading "Flashes"; search placeholder "Search flashes"; button "Send a flash"; columns "Sent" (dd/MM/yyyy HH:mm local), "Recipients" (company names joined by ", "), "Company" (`value`), "Title", "Type"; empty state "No flashes found."; MUI `TablePagination` with 20 rows per page and no rows-per-page choice.
- Detail: heading = flash title; caption "Sent {dd/MM/yyyy HH:mm}"; link "Back to flashes"; section headings "RECIPIENTS", "CONTENT", "RELATED LINKS:", "ATTACHMENT"; content lines "Type: {type}", "Company: {value}", then the cleaned message; links open in a new tab; attachment shown as a button with the file name that downloads it; note "Duplicate sent by email" when `sendByEmail`; button "Delete". RELATED LINKS and ATTACHMENT sections are hidden when empty. Not found shows "Flash not found".
- Delete dialog: title "Delete flash"; body "Are you sure you want to delete?"; bold sub-text "This action cannot be undone"; buttons "Cancel", "Yes". Yes deletes and returns to `/flashes`.
- Compose: heading "Send a flash"; section "Recipients" with checkbox "Send to all companies" and a multi-select labelled "Companies" (placeholder "Search companies"), error "Please choose a recipient"; section "Content" with "Subject" (error "Subject is required"), "Company" (free text, error "Company is required"), "Type" (select, error "Type is required"), "Message" (rich text, error "Message is required"), "Related links" (multi-line, placeholder "One link per line", optional); section "Attachment" (the `AttachmentPicker` with label "Attachment": button "Add an attachment", each file listed with name, size in KB and a "Remove" button); checkbox "Also send by email"; button "Send". Server failure: error alert "Unable to create a flash right now. Please try again later." above the form, values kept. On success navigate to `/flashes/{id}`.
- Related links are split on new lines, trimmed, blank lines dropped.
- A message counts as empty when its text content is blank and it holds no image.

**Mock fixtures** (in `db.flashes`, reset by `resetFixtures()`):

| id | createdAt (UTC) | title | value | type | recipients | links | sendByEmail | attachments | description |
|---|---|---|---|---|---|---|---|---|---|
| f1 | 2026-10-12T07:45:00Z | LVMH Q3 revenue ahead of consensus | LVMH | Breaking News | c1 | https://www.lvmh.com/investors | true | none | `<p>LVMH reported Q3 organic revenue growth of 3%, ahead of the 1% consensus.</p>` |
| f2 | 2026-10-11T15:20:00Z | Danone shares up 2.4% in early trade | Danone | Price movement | c2 | none | false | none | `<p>Danone is trading up 2.4% after a broker upgrade.</p>` |
| f3 | 2026-10-10T06:55:00Z | Pre-opening: European luxury sector | Kering | Pre-opening | c1, c3 | none | false | `a1` luxury-preopen.pdf, application/pdf, 2048 bytes | `<p>Futures point to a firmer open for luxury names.</p>` |
| f4 | 2026-10-09T12:10:00Z | Diageo: brokers' comments after trading update | Diageo | Brokers Comments | c5 | https://www.diageo.com/en/investors, https://www.londonstockexchange.com | true | none | `<p>Brokers broadly positive on the trading update.</p>` |
| f5 | 2026-10-08T09:30:00Z | Peer report: hospitality | Accor | Peer report | c1, c2, c3, c4, c5 (sendToAll true) | none | false | none | `<p>Weekly hospitality peer comparison.</p>` |

`updatedAt` = `createdAt`. Attachment `a1` content: 2048 bytes of a minimal PDF header followed by spaces. Mock create: new id `crypto.randomUUID()`, `createdAt` now, recipients = all non-archived companies when `sendToAll`, else the given ids; attachments stored with name, type, size and bytes; returns 500 `{message: "Mock failure"}` when `title` is exactly "Mock server error" (a test hook for the failure path).

## Manual test plan (definition of done)

MTP-FLS-001 to MTP-FLS-009. Rows in `docs/manual-test-plan.md`; execution in `docs/mtp-results.md`. All automated with Playwright in mock mode.

## Out of scope / open questions

Out of scope: editing a flash, drafts, scheduled sends, push and email content (gateway), reference-data management for flash types.

Open, not blocking: Pradeep to confirm the list, detail and attachment shapes and the paging parameters; whether `GET /api/attachment/{id}/content` stays unauthenticated in the gateway (the page sends a token either way).
