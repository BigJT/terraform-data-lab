# Admin foundation tasks

- Plan: docs/plans/done/admin-foundation-plan.md
- MTP prefix: ADMF
- Branch: commit directly on `dev`, push as each task lands. No worktree, no PR.
- MTP rows live in `docs/manual-test-plan.md`; record results in `docs/mtp-results.md`.

## Shared facts (apply to every task)

- Repo root: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Admin`. English copy only. All copy below is exact (case and punctuation).
- Design system source: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Automation-Demo/client/src/ds` (`theme/tokens.ts`, `theme/fonts.ts`, `theme/theme.ts`, `components/Panel.tsx`, `fonts/SourceSans3-{Bold,Light,Medium,Regular,Semibold}.otf`). Copied verbatim into `src/ds`.
- Tokens: canvas `#EBEDF1`, panel `#FFFFFF`, rule `#D2D7DF`, textPrimary `#1C355E`, textSecondary `#706E6C`, textMuted `#949291`, chrome `#495D7E`, onChrome `#F8F9FA`, green `#34C759`, amber `#EDA100`, red `#FF383C`, strip `#F8F9FA`; font `'Source Sans 3', sans-serif`. MUI theme: primary = chrome, border radius 2, no shadows, buttons 28px high, 13px, weight 600, no uppercase.
- New components go in `src/ds/components` only when used by two screens; otherwise in the screen folder.
- Tooling source: `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Web` (eslint, prettier, tsconfig split, playwright config, vite config with the `@/` alias to `src`, `.githooks` pre-commit, `src/test/setup.ts`, `src/test/renderWithTheme.tsx`).
- Layout: `src/ds`, `src/data`, `src/auth`, `src/mocks`, `src/screens`, `src/app`, `src/test`, `e2e`.
- Mock mode = `VITE_GATEWAY_URL` unset: `main.tsx` starts the msw browser worker before rendering. Gateway base address = `VITE_GATEWAY_URL ?? ''`. Handlers match paths with a `*` prefix (e.g. `*/api-admin/referential/market`) so they serve both relative (dev) and absolute (tests) URLs. Browser worker uses `onUnhandledRequest: 'bypass'`.
- Dates render as dd/MM/yyyy in the browser's local time.
- Email rule (wizard and user form): `^[^\s@]+@[^\s@]+\.[A-Za-z]{2,10}$`. Phone optional, free text.
- Search: client-side, case-insensitive substring.
- Three test levels: seam A = gateway client against msw node server; seam B = Testing Library screens inside theme, router (`MemoryRouter`) and a signed-in auth context, msw behind the client; seam C = Playwright against `npm run dev` in mock mode on port 5174.
- Each task ends with `npm run verify` green and its MTP rows marked in `docs/mtp-results.md` (🤖 for Playwright-covered rows).

## ADMF-T01: Scaffold, design system, mock sign-in, shell and placeholder screens
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: none
- Satisfies: MTP-ADMF-003, MTP-ADMF-004, MTP-ADMF-005, MTP-ADMF-006
- Test approach: unit test at seam B (shell renders six entries in order, routes, placeholders, sign-out calls `window.location.replace('/')`); Playwright at seam C for 003, 004, 005, 006 (mock half).
- Model:
- What to build:
  - Vite + React + TypeScript app. Exact versions: react and react-dom 19.3.0, typescript 6.0.3 (not 7), vite 8.3.4, @vitejs/plugin-react 6.1.2, @mui/material 9.5.0 with @mui/material-pigment-css ^9.5.0, @emotion/react and @emotion/styled latest 11.x, react-router 8.4.0 (`BrowserRouter` + `Routes` API, no data router), msw 3.0.3, vitest 5.0.3 (jsdom), @testing-library/react, @testing-library/jest-dom, @testing-library/user-event latest, @playwright/test 1.64.0, eslint 10.12, typescript-eslint 8.71, prettier 3.9. `@azure/msal-browser` 5.25.0 installed now (used in T02).
  - Scripts as Engage-Web: `prepare` (`git config core.hooksPath .githooks || true`), `dev` (port 5174), `build` (`tsc -b && vite build`), `lint`, `preview`, `typecheck`, `test`, `test:watch`, `test:e2e`, `format`, `format:check`, `verify` (`npm run build && npm run lint && npm run format:check && npm run test && npm run test:e2e`). Playwright config starts `npm run dev` itself on port 5174 with no `VITE_*` settings.
  - Copy the design system verbatim into `src/ds` (see shared facts); fonts wired through `fonts.ts`.
  - `src/mocks/handlers.ts` (empty array for now, shared by both setups), `src/mocks/browser.ts` (`setupWorker` from `msw/browser`), `src/mocks/server.ts` (`setupServer` from `msw/node`, started in `src/test/setup.ts`); `npx msw init public` so the worker script is served.
  - `src/auth`: `AuthProvider` + `useAuth()` exposing `{status: 'loading' | 'signedOut' | 'noAccess' | 'signedIn', name, getToken, signIn, signOut}`. In this task only mock mode: status `signedIn` at once, name "Local Admin", roles `["Admin"]`, `getToken` resolves `'mock-token'`, `signOut` calls `window.location.replace('/')`. Shape it so T02 adds Entra mode beside it.
  - Shell: left sidebar (background chrome, text onChrome, selected entry panel background with textPrimary text), "Engage Admin" at the top, six entries in this order with these routes: Reports `/reports`, Flashes `/flashes`, Broker notes `/broker-notes`, Companies `/companies`, Version `/version`, Monitoring `/monitoring`. Bottom of sidebar: signed-in name and a "Sign out" link. Content area on canvas. `/` redirects to `/companies`.
  - Placeholder screen for Reports, Flashes, Broker notes, Version, Monitoring: heading = the sidebar label, body "Coming soon". Companies route shows a placeholder heading "Companies" until T03.
  - Repo `CLAUDE.md`: stack, scripts, `src` layout, "English only", "copy the DS from src/ds", "mock mode is the default", "direct commits on dev". README: replace the stack line with the versions above (MUI 9, React Router 8) and add a scripts table.
- Acceptance: the listed MTP rows pass.
- Commit: 2ea0165

## ADMF-T02: Entra sign-in, no-access screen, 401/403 handling
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T01
- Satisfies: MTP-ADMF-001, MTP-ADMF-002
- Test approach: unit test at seam B with a fake `PublicClientApplication` (account with `idTokenClaims.roles: ['Admin']` gives signedIn; with `[]` or no `roles` gives noAccess; no account gives signedOut; sign-in button calls `loginRedirect`; sign-out calls `logoutRedirect`; a 401 response sets signedOut and a 403 sets noAccess). Rows 001 and 002 stay manual MTP only (need a real Entra tenant and accounts; owner runs them).
- Model:
- What to build:
  - Entra mode when `VITE_ENTRA_TENANT_ID`, `VITE_ENTRA_CLIENT_ID` and `VITE_API_SCOPE` are all set; otherwise mock mode as in T01. Follow the pattern in `/Users/ashleymills/Projects/Xcode-Projects/Client/Engage-Automation-Demo/client/src/data/signIn.ts`.
  - Standalone `@azure/msal-browser` 5.25.0 (no msal-react): `PublicClientApplication` with authority `https://login.microsoftonline.com/{VITE_ENTRA_TENANT_ID}`, clientId `VITE_ENTRA_CLIENT_ID`, `redirectUri: window.location.origin`. On load: `initialize()`, then `handleRedirectPromise()`, set the active account. Status `loading` until done.
  - Role check: `account.idTokenClaims.roles` includes `'Admin'` → signedIn; otherwise noAccess. Name = `account.name`.
  - `signIn` = `loginRedirect({scopes: [VITE_API_SCOPE]})`. `getToken` = `acquireTokenSilent({scopes: [VITE_API_SCOPE], account})`, returning `accessToken`. `signOut` = `logoutRedirect()`.
  - Screens: loading shows nothing but the canvas; signedOut shows a centred panel with the wordmark "Engage Admin" and one button "Sign in with Microsoft", nothing else reachable; noAccess shows a full-page message "You do not have access to Engage Admin." and a "Sign out" button, no sidebar, no data calls.
  - Add a small `onAuthError(status: 401 | 403)` hook on the auth context: 401 → signedOut, 403 → noAccess. T03's gateway client calls it.
  - Add the three `VITE_ENTRA_*` names and `VITE_GATEWAY_URL` to `.env.example` with empty values and to the README.
- Acceptance: unit tests green; MTP-ADMF-001 and 002 left NOT TESTED for the owner with note "manual, needs Entra".
- Commit: 4e1367e

## ADMF-T03: Gateway client, API contract, mock data, Companies list
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T01
- Satisfies: MTP-ADMF-007, MTP-ADMF-008, MTP-ADMF-009
- Test approach: integration test at seam A (client functions against msw node server, bearer header sent, 401 and 403 call `onAuthError`, 400 bodies surface as typed errors carrying `message` and `fieldErrors`); seam B for the list (archived hidden, toggle, search on name and RIC); Playwright at seam C for 007, 008, 009.
- Model: sonnet
- What to build:
  - `docs/api/engage-admin-api.yaml`: OpenAPI 3.1, server URL `{gatewayUrl}`, `bearerAuth` security scheme on every operation, these fifteen operations (the plan says fourteen but lists fifteen) with request and response schemas:
    1. `GET /api-admin/emitters-management/emitter` → 200 array of `{id, name, ric, sectors: string[], associatedUsers: number, archived: boolean}`
    2. `PUT /api-admin/emitters-management/emitter` body `{name, ric, marketCode, languageCode, sector, subSector?, national1IndiceRic?, sector1IndiceRic?, national2IndiceRic?, sector2IndiceRic?, pairs: [], collaborators: [{email, firstName, lastName, jobFunction, phone?}]}` → 201 company detail; 400 `{message: "An emitter with same RIC code already exists"}`
    3. `GET /api-admin/emitters-management/emitter/{emitterId}` → 200 `{id, name, ric, archived, languageCode, market: {code, shortName, fullName, currency}, sector, subSector, national1Indice?, sector1Indice?, national2Indice?, sector2Indice? (each {ric, name}), collaborators: User[]}`; 404
    4. `PUT /api-admin/emitters-management/emitter/{emitterId}/archive` → 204; 404
    5. `PUT /api-admin/emitters-management/emitter/{emitterId}/unarchive` → 204; 404
    6. `PUT /api-admin/emitters-management/emitter/indice/{emitterId}` body `{national_1_indice, sector_1_indice, national_2_indice, sector_2_indice}` (RIC strings or null) → 204; 404
    7. `GET /api-admin/pairs-management/pairs/ric/{search}` → 200 `{ric, name}`; 404
    8. `GET /api-admin/referential/market` → 200 array of `{code, shortName, fullName, currency}`
    9. `GET /api-admin/referential/sectors` → 200 array of strings (sub-sectors as `"Parent/Child"`)
    10. `GET /api-admin/referential/indices` → 200 array of `{ric, name, type}`, type `national` or `sector`
    11. `GET /api-admin/accounts-management/emitter/{emitterId}` → 200 User[]
    12. `PUT /api-admin/accounts-management/account` body `{email, firstName, lastName, phone?, jobFunction, emitterId, roles: string[]}` → 201 with header `Location: /api-admin/accounts-management/account/{id}`; 400 `{message: "Email {email} is already used."}` or `{message: "The creation email has not been sent. Cause :{cause}"}` or `{message, fieldErrors: [{objectName, field, code, message}]}`
    13. `POST /api-admin/accounts-management/account/{accountId}` body as 12 without `emitterId`, plus optional `newPassword`, `passwordChangeRequired` → 200 User; 400; 404
    14. `DELETE /api-admin/accounts-management/account/delete/{accountId}` → 204; 400 `{message: "No account with UUID: {id}"}`
    15. `GET /api-admin/accounts-management/roles` → 200 `["ROLE_EMITTER", "ROLE_EMITTER_LIMITED"]`
    - `User` = `{id, email, phone?, firstName, lastName, jobFunction, cgu?: date-time, deactivationDate?: date-time, roles: string[], passwordChangeRequired: boolean, lastFlashRead?: date-time, lastFlash?: date-time, lastDailyRead?: date-time, lastDaily?: date-time}`.
    - Errors on every operation: 401 `{error: "unauthorized", message: "Authentication required"}`; 403 for a caller without the Admin role.
  - `src/data/gatewayClient.ts`: typed functions for all operations above over `fetch`, base `VITE_GATEWAY_URL ?? ''`, header `Authorization: Bearer {await getToken()}`, 401/403 → `onAuthError`, other non-2xx → thrown `GatewayError {status, message, fieldErrors?}` parsed from the body. Provided to screens through a React context.
  - `src/mocks/fixtures.ts`, held in module state (mutations persist until reload), with a `resetFixtures()` called from `src/test/setup.ts` before each test:
    - Markets: `{code: 'EPA', shortName: 'EPA', fullName: 'Euronext Paris', currency: 'EUR'}`, `{code: 'LSE', shortName: 'LSE', fullName: 'London Stock Exchange', currency: 'GBp'}`.
    - Sectors: `Luxury`, `Luxury/Fashion`, `Food`, `Food/Dairy`, `Hospitality`, `Beverages`, `Payments`, `Industrials`, `Industrials/Capital Goods`.
    - Indices: `.FCHI` "CAC 40" national, `.FTSE` "FTSE 100" national, `.STOXX50E` "Euro Stoxx 50" national, `.SXNP` "Stoxx Europe 600 Industrials" sector, `.SXQP` "Stoxx Europe 600 Personal & Household Goods" sector, `.SX3P` "Stoxx Europe 600 Food & Beverage" sector.
    - Pairs lookup (RIC, name): LVMH.PA LVMH Moet Hennessy Louis Vuitton; DANO.PA Danone; PRTP.PA Kering; ACCP.PA Accor; DGE.L Diageo; WLN.PA Worldline; OREP.PA L'Oreal; HRMS.PA Hermes International; CDI.PA Christian Dior; NESN.S Nestle; ULVR.L Unilever; PERP.PA Pernod Ricard; ABI.BR Anheuser-Busch InBev; IHG.L InterContinental Hotels Group; WTB.L Whitbread; ADYEN.AS Adyen; NEXI.MI Nexi; SIEGn.DE Siemens; SGEF.PA Vinci; AIR.PA Airbus. Lookup is case-insensitive exact match on RIC.
    - Companies (id, name, ric, language, market, sector, subSector, Index 1 national1 / Index 2 sector1 / Index 3 national2 / Index 4 sector2, archived): `c1` LVMH `LVMH.PA` fr-FR EPA Luxury Fashion .FCHI/.SXQP/.STOXX50E/none active; `c2` Danone `DANO.PA` fr-FR EPA Food Dairy .FCHI/.SX3P/none/none active; `c3` Kering `PRTP.PA` fr-FR EPA Luxury (none) .FCHI/.SXQP/none/none active; `c4` Accor `ACCP.PA` fr-FR EPA Hospitality (none) .FCHI/none/none/none active; `c5` Diageo `DGE.L` en-EN LSE Beverages (none) .FTSE/.SX3P/none/none active; `c6` Worldline `WLN.PA` fr-FR EPA Payments (none) none/none/none/none archived.
    - List `sectors` field: `["{sector}/{subSector}"]` when a sub-sector is set, else `["{sector}"]`. `associatedUsers` = that company's user count.
    - Users (id, company, first, last, jobFunction, email, phone, roles, cgu). Unless stated, `passwordChangeRequired: false`, `lastDaily: 2026-10-09T06:00:00Z`, `lastDailyRead: 2026-10-09T08:00:00Z`, `lastFlash: 2026-10-08T14:00:00Z`, `lastFlashRead: 2026-10-08T14:30:00Z`.
      - `u1` c1 Claire Martin, Head of Investor Relations, claire.martin@lvmh.example, +33 1 44 13 22 22, ROLE_EMITTER, cgu 2025-03-14T09:00:00Z
      - `u2` c1 Julien Bernard, Investor Relations Analyst, julien.bernard@lvmh.example, no phone, ROLE_EMITTER_LIMITED, no cgu, no lastDailyRead, no lastFlashRead (the "No" and "N/A" case)
      - `u3` c2 Sophie Laurent, Investor Relations Director, sophie.laurent@danone.example, +33 1 44 35 20 20, ROLE_EMITTER, cgu 2024-11-02T10:00:00Z
      - `u4` c2 Marc Dubois, Finance Manager, marc.dubois@danone.example, no phone, ROLE_EMITTER_LIMITED, cgu 2025-06-20T10:00:00Z
      - `u5` c3 Elodie Petit, Investor Relations Manager, elodie.petit@kering.example, +33 1 45 64 61 00, ROLE_EMITTER, cgu 2025-01-10T10:00:00Z
      - `u6` c3 Thomas Moreau, Head of Communications, thomas.moreau@kering.example, no phone, ROLE_EMITTER, cgu 2025-09-01T10:00:00Z
      - `u7` c4 Camille Roux, Investor Relations Director, camille.roux@accor.example, +33 1 45 38 86 00, ROLE_EMITTER, cgu 2025-02-18T10:00:00Z
      - `u8` c4 Hugo Lefevre, Treasury Analyst, hugo.lefevre@accor.example, no phone, ROLE_EMITTER_LIMITED, cgu 2025-05-05T10:00:00Z
      - `u9` c5 James Walker, Head of Investor Relations, james.walker@diageo.example, +44 20 8978 6000, ROLE_EMITTER, cgu 2024-12-12T10:00:00Z
      - `u10` c5 Emma Clarke, Investor Relations Manager, emma.clarke@diageo.example, no phone, ROLE_EMITTER_LIMITED, cgu 2025-07-07T10:00:00Z
      - `u11` c5 Oliver Hughes, Company Secretary, oliver.hughes@diageo.example, no phone, ROLE_EMITTER, cgu 2025-08-19T10:00:00Z
      - `u12` c6 Nicolas Garnier, Investor Relations Manager, nicolas.garnier@worldline.example, +33 1 34 34 95 95, ROLE_EMITTER, cgu 2024-10-01T10:00:00Z
  - `src/mocks/handlers.ts`: handlers for all fifteen operations with this behaviour: create company rejects a RIC already used by any company (case-insensitive) with 400 `{message: "An emitter with same RIC code already exists"}`, new ids `crypto.randomUUID()`; archive/unarchive/indices/detail return 404 for an unknown id; create account rejects an email already used by any user (case-insensitive) with 400 `{message: "Email {email} is already used."}`; delete of an unknown id returns 400 `{message: "No account with UUID: {id}"}`. All write handlers mutate the fixtures.
  - Companies screen at `/companies` inside a Panel: columns Company, RIC, Sector (`sectors.join(', ')`), Users (`associatedUsers`), Status ("Active" / "Archived"); search box placeholder "Search companies" matching name or RIC; checkbox "Show archived companies", off by default (archived rows hidden when off); button "Add company" (navigates to `/companies/new`, a placeholder until T06). Clicking a row navigates to `/companies/{id}` (placeholder until T04). Rows sorted by name.
- Acceptance: the listed MTP rows pass.
- Commit: 89c9beb

## ADMF-T04: Company detail with Information tab and placeholder tabs
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T03
- Satisfies: MTP-ADMF-014, MTP-ADMF-017
- Test approach: seam B (tabs, Information values for LVMH and for Accor's "None" indices, French/English, market full name, placeholder tabs); Playwright at seam C for 014 and 017.
- Model: sonnet
- What to build:
  - Route `/companies/:id`, data from operation 3. Header: company name and an "Archive" button (shown as "Unarchive" when archived; the action itself lands in T05, render the button only). Not found (404) shows "Company not found".
  - Tabs in order: Information, Lists, Users, Imports, Factset, selected tab in the URL as `/companies/:id/{information|lists|users|imports|factset}`, default information. Lists, Imports and Factset show "Coming soon". Users shows "Coming soon" until T07.
  - Information tab, read-only label/value pairs: RIC, Name, Language ("French" for fr-FR, "English" for en-EN), Market (`market.fullName`), Sector, Sub-sector (empty shows "None"). Then a block headed "INDICES" listing Index 1 (`national1Indice`), Index 2 (`sector1Indice`), Index 3 (`national2Indice`), Index 4 (`sector2Indice`), each shown as "{ric} {name}" or "None", and an "Edit" link (opens the dialog in T05; render the link only).
- Acceptance: the listed MTP rows pass.
- Commit: 5be977a

## ADMF-T05: Edit indices dialog, archive and unarchive
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T04
- Satisfies: MTP-ADMF-015, MTP-ADMF-016
- Test approach: seam B (dialog pickers exclude each other's choices, Save sends operation 6 and refreshes the block, Cancel discards; Archive sends operation 4, shows banner, toggles to Unarchive and back via operation 5); Playwright at seam C for 015 and 016.
- Model: sonnet
- What to build:
  - "Edit" opens a dialog titled "Edit indices" with four pickers Index 1 to Index 4, preset to the current values. Every picker lists all six indices from operation 10 (any type) as "{ric} {name}" plus a "None" option, minus the indices chosen in the other three pickers. Buttons "Cancel" (closes, discards) and "Save" (sends operation 6 with `national_1_indice` = Index 1, `sector_1_indice` = Index 2, `national_2_indice` = Index 3, `sector_2_indice` = Index 4, RIC or null; closes and reloads the detail). Put the exclusion logic in a shared function the wizard (T06) reuses.
  - "Archive" sends operation 4, then reloads the detail: a warning banner "This company is archived" appears above the tabs and the button reads "Unarchive". "Unarchive" sends operation 5 and reverses both. The Companies list reflects the change (hidden unless "Show archived companies" is ticked, where Status reads "Archived").
- Acceptance: the listed MTP rows pass.
- Commit: 8d0b955

## ADMF-T06: Add-company wizard
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T05
- Satisfies: MTP-ADMF-010, MTP-ADMF-011, MTP-ADMF-012, MTP-ADMF-013
- Test approach: seam B for each step's validation and navigation, RIC lookup found and not found, index exclusion, user block add/remove, zero users allowed, successful create, duplicate-RIC 400; Playwright at seam C for 010 to 013 (new company uses RIC `OREP.PA`; duplicate uses `LVMH.PA`).
- Model:
- What to build:
  - Route `/companies/new`, a three-step wizard with a step header "1. Information", "2. Indices", "3. Users". Buttons "Back" (hidden on step 1), "Next" (steps 1 and 2), "Add" (step 3). Values persist across Back/Next.
  - Step 1 fields: RIC (text), Name (text), Language (radio "French" value `fr-FR` / "English" value `en-EN`, default French), Market (select from operation 8, label `fullName`, value `code`), Sector (select of the sector strings without "/"), Sub-sector (optional select of the "Parent/Child" strings whose parent is the chosen Sector, shown as the child part, sent as the child part; cleared when Sector changes; disabled when none exist). Errors on Next when empty: "RIC is required", "Name is required", "Market is required", "Sector is required". RIC lookup via operation 7 on blur and before Next: 404 shows "This RIC code does not exist" under RIC and blocks Next; a found RIC clears the error and fills nothing else.
  - Step 2: Index 1 to Index 4 pickers, all optional, same options and mutual exclusion as T05's dialog (reuse its function). Next works with none chosen.
  - Step 3: button "Add user" appends a block headed "User {n}" (n from 1, renumbered after removals) with fields First name, Last name, Position, Email, Phone, and a "Remove" button. Zero blocks is allowed. On Add, each block validates: "First name is required", "Last name is required", "Position is required", "Email is required", and "Invalid email format" for an email failing the shared regex. Phone optional. Add is blocked until every block is valid.
  - Add sends operation 2: `{name, ric, marketCode, languageCode, sector, subSector?, national1IndiceRic: Index 1, sector1IndiceRic: Index 2, national2IndiceRic: Index 3, sector2IndiceRic: Index 4, pairs: [], collaborators: [{email, firstName, lastName, jobFunction: Position, phone?}]}`, omitting unset optionals. The mock creates the company and one user per collaborator (roles `["ROLE_EMITTER"]`, `passwordChangeRequired: true`, no cgu). On 201 navigate to `/companies/{id}/information`. On 400 return to step 1 and show the server `message` verbatim in an error alert above the form; nothing is created.
- Acceptance: the listed MTP rows pass.
- Commit: 81c4d39

## ADMF-T07: Users tab with search and add user
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T04
- Satisfies: MTP-ADMF-018, MTP-ADMF-019, MTP-ADMF-020
- Test approach: seam B (table columns and formats incl. "No", search on first name, last name, email; form required errors, "bob@x" invalid, role options; successful add appears; server 400 message shown verbatim, `fieldErrors` mapped to fields, row not added); Playwright at seam C for 018, 019, 020 (duplicate uses `claire.martin@lvmh.example` on LVMH).
- Model: sonnet
- What to build:
  - Users tab (`/companies/:id/users`), data from operation 11, inside a Panel. Columns: Name ("{firstName} {lastName}"), Position (`jobFunction`), Email, Phone (empty when absent), Terms accepted (`cgu` as dd/MM/yyyy or "No"). Each row has "Edit" and "Delete" actions (render only; behaviour in T08). Search box placeholder "Search users" filtering on first name, last name and email. Button "Add user".
  - User form (a dialog titled "Add user", built so T08 reuses it for edit): fields First name, Last name, Position, Email, Phone, Role. Role is a single select with options "Standard" (`ROLE_EMITTER`) and "Limited access" (`ROLE_EMITTER_LIMITED`), no default. Errors on Save: "First name is required", "Last name is required", "Position is required", "Email is required", "Invalid email address" (shared regex), "Role is required". Phone optional. Buttons "Cancel", "Save".
  - Save sends operation 12 with `roles: [chosenRole]` and `emitterId`. On 201 close the dialog and reload the table (new user appears at once). On 400 keep the dialog open, show `message` verbatim in an error alert above the form, and map any `fieldErrors[].field` (`firstName`, `lastName`, `jobFunction`, `email`, `phone`, `roles`) to that field's error text using `fieldErrors[].message`.
- Acceptance: the listed MTP rows pass.
- Commit: 3dceed9

## ADMF-T08: Edit and delete user
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: ADMF-T07
- Satisfies: MTP-ADMF-021
- Test approach: seam B (edit prefilled with six fields, read-only dates and "N/A" for Julien Bernard, Save sends operation 13 and updates the row, server error shown; delete dialog copy, No keeps the row, Yes sends operation 14 and removes it, 400 message shown); Playwright at seam C for 021.
- Model: sonnet
- What to build:
  - "Edit" opens the T07 form as a dialog titled "Edit user", prefilled with First name, Last name, Position, Email, Phone, Role (first entry of `roles`). Below the fields two read-only lines: "Last daily report read" (`lastDailyRead`) and "Last flash read" (`lastFlashRead`), each dd/MM/yyyy or "N/A". No password field. Save sends operation 13 with `{email, firstName, lastName, phone?, jobFunction, roles: [role]}`; on 200 close and reload the table; on 400/404 show `message` verbatim above the form and map `fieldErrors` as in T07.
  - "Delete" opens a dialog titled "Delete user", body "Are you sure you want to delete {firstName} {lastName}?", buttons "No" (closes, row stays) and "Yes" (sends operation 14, closes, reloads; on 400 shows `message` verbatim in an error alert in the dialog).
- Acceptance: the listed MTP row passes.
- Commit: 9950ff1

## ADMF-T09: Gateway payload format for cleared phone and sub-sector
- Kind: bugfix
- Blocking: yes
- Status: done
- Blocked by: none (owner decided 2026-10-12)
- References: MTP-ADMF-021, MTP-ADMF-013
- Test approach: unit test at seam B for each case, RED first; MTP-ADMF-013 and 021 Playwright specs still pass.
- Model: sonnet
- What to build:
  - Cleared phone on edit: when the Phone field is blank on Save in the "Edit user" form, send `phone: ""` in the operation 13 body (never omit it). The mock update handler stores `""` as no phone, so the Users table then shows an empty Phone cell. Add-user (operation 12) is unchanged: omit `phone` when blank. To confirm with Pradeep later; record it under "Open" in the plan.
  - Sub-sector on create: the wizard sends `subSector` as the full `"Parent/Child"` string exactly as operation 9 returns it (e.g. `"Industrials/Capital Goods"`), per `docs/mycms-admin-spec-1.md` line 336. The Sub-sector select still shows only the child part as its label. Fixtures store `subSector` in the full form (LVMH `"Luxury/Fashion"`, Danone `"Food/Dairy"`); the mock create handler stores what it receives and builds the list `sectors` as `[subSector]` when set, else `[sector]`. The detail page's Sub-sector line shows the child part only (text after the "/"), or "None". Update any tests asserting the old child-only payload or fixture values in this task.
- Acceptance: both seam B tests pass; MTP-ADMF-013 and 021 still pass.
- Commit: 037d7ff

## ADMF-T10: Stand-in Microsoft sign-in
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: none
- Satisfies: MTP-ADMF-022, MTP-ADMF-023, MTP-ADMF-024
- Test approach: unit test at seam B (fake client: picking an account stores it and `handleRedirectPromise` returns it once; reload keeps it via `getActiveAccount`; `logoutRedirect` clears both keys and calls `browserLocation.replace('/')`; through `AuthProvider`, Admin User gives signedIn and Standard User gives noAccess); Playwright at seam C on port 5175 for 022, 023, 024.
- Model: sonnet
- What to build:
  - Setting `VITE_ENTRA_MOCK=1` makes `entraSettingsFromEnv()` in `src/auth/entraAuth.ts` return `{client: <fake>, scope: 'api://mock/access_as_user'}`, taking precedence over the three real `VITE_ENTRA_*` settings. The fake (new file `src/auth/fakeMsal.ts`) implements the existing `MsalClient` type: `initialize` resolves; `loginRedirect` calls `window.location.assign('/mock-entra-sign-in')` (route it through `browserLocation`, adding an `assign` method beside `replace`); `handleRedirectPromise` returns `{account}` and removes the redirect key when `sessionStorage['engage-admin.mock-entra.redirect'] === '1'`, else `null`; `getActiveAccount` and `getAllAccounts` return the account stored under `sessionStorage['engage-admin.mock-entra.account']` (`[]`/`null` when none); `setActiveAccount` is a no-op; `acquireTokenSilent` resolves `{accessToken: 'mock-entra-token'}`; `logoutRedirect` removes both keys and calls `browserLocation.replace('/')`.
  - Accounts: Admin `{homeAccountId: 'mock-admin', localAccountId: 'mock-admin', environment: 'mock', tenantId: 'mock', username: 'admin.user@example.com', name: 'Admin User', idTokenClaims: {roles: ['Admin']}}`; Standard `{homeAccountId: 'mock-standard', localAccountId: 'mock-standard', environment: 'mock', tenantId: 'mock', username: 'standard.user@example.com', name: 'Standard User', idTokenClaims: {roles: []}}`. The account key stores the `homeAccountId`.
  - Stand-in page (`src/screens/MockEntraSignIn/MockEntraSignInScreen.tsx`): when `VITE_ENTRA_MOCK=1` and `window.location.pathname === '/mock-entra-sign-in'`, `App` renders it inside the theme instead of `AuthProvider`/`AuthGate`. Centred Panel on canvas: heading "Stand-in Microsoft sign-in", text "Pick an account. This page stands in for Microsoft until an Entra tenant is set up.", buttons "Admin User" and "Standard User". Clicking one sets the account key to its `homeAccountId`, sets the redirect key to `1`, then `browserLocation.replace('/')`.
  - The existing sign-in page, no-access page, sidebar name and Sign out work unchanged with the fake.
  - `package.json` script `dev:entra-mock`: `VITE_ENTRA_MOCK=1 vite --port 5175 --strictPort`. `playwright.config.ts`: `webServer` becomes an array adding `{command: 'npm run dev:entra-mock', url: 'http://localhost:5175', reuseExistingServer: !process.env.CI}`; add project `entra-mock` (`Desktop Chrome`, baseURL `http://localhost:5175`, `testMatch: 'entraMock.spec.ts'`); the `chromium` project gets `testIgnore: 'entraMock.spec.ts'`. Specs in `e2e/entraMock.spec.ts`, one test per row named "MTP-ADMF-022: ...", "MTP-ADMF-023: ...", "MTP-ADMF-024: ...".
  - Add `VITE_ENTRA_MOCK=` to `.env.example`; README scripts table gains `dev:entra-mock` and a line on the setting; CLAUDE.md notes the stand-in mode.
- Acceptance: the listed MTP rows pass; MTP-ADMF-003 to 021 still pass.
- Commit: 5adffb7

## Automation status
<!-- Filled by /feature-implement: one line per automated MTP row, e.g. "MTP-ADMF-003: 🤖 <spec file and test name>" -->
- MTP-ADMF-003: 🤖 e2e/shell.spec.ts "MTP-ADMF-003: mock mode opens the shell signed in as Local Admin with mock data"
- MTP-ADMF-004: 🤖 e2e/shell.spec.ts "MTP-ADMF-004: the sidebar lists six entries, the name and Sign out, opening on Companies"
- MTP-ADMF-005: 🤖 e2e/shell.spec.ts "MTP-ADMF-005: each placeholder entry shows its title and Coming soon"
- MTP-ADMF-006: 🤖 (partial, mock half) e2e/shell.spec.ts "MTP-ADMF-006: Sign out in mock mode reloads the shell as Local Admin"; Entra half manual
- MTP-ADMF-001, MTP-ADMF-002: manual only (need a real Entra tenant); src/auth/AuthProvider.test.tsx covers the logic with a fake MSAL client
- MTP-ADMF-007: 🤖 e2e/companies.spec.ts "MTP-ADMF-007: the Companies list shows the columns, controls and active rows only"
- MTP-ADMF-008: 🤖 e2e/companies.spec.ts "MTP-ADMF-008: ticking Show archived companies reveals Worldline as Archived"
- MTP-ADMF-009: 🤖 e2e/companies.spec.ts "MTP-ADMF-009: search narrows by name or RIC, case-insensitively, and clears"
- MTP-ADMF-014: 🤖 e2e/companies.spec.ts "MTP-ADMF-014: a company opens with five tabs, read-only Information and an Archive button"
- MTP-ADMF-017: 🤖 e2e/companies.spec.ts "MTP-ADMF-017: Lists, Imports and Factset show Coming soon"
- MTP-ADMF-015: 🤖 e2e/companies.spec.ts "MTP-ADMF-015: Edit indices excludes chosen indices, Save updates the block, Cancel discards"
- MTP-ADMF-016: 🤖 e2e/companies.spec.ts "MTP-ADMF-016: Archive shows the banner, hides the company from the list, Unarchive reverses it"
- MTP-ADMF-010: 🤖 e2e/addCompany.spec.ts "MTP-ADMF-010: step 1 shows required errors, French by default, and checks the RIC"
- MTP-ADMF-011: 🤖 e2e/addCompany.spec.ts "MTP-ADMF-011: step 2 excludes chosen indices, allows none, and Back keeps step 1"
- MTP-ADMF-012: 🤖 e2e/addCompany.spec.ts "MTP-ADMF-012: step 3 user blocks validate, block Add, and can be removed"
- MTP-ADMF-013: 🤖 e2e/addCompany.spec.ts "MTP-ADMF-013: finishing the wizard opens the new company; a used RIC shows the server message"
- MTP-ADMF-018: 🤖 e2e/companies.spec.ts "MTP-ADMF-018: the Users tab shows the table, search and Add user"
- MTP-ADMF-019: 🤖 e2e/companies.spec.ts "MTP-ADMF-019: the user form validates and offers both roles"
- MTP-ADMF-020: 🤖 e2e/companies.spec.ts "MTP-ADMF-020: a valid user is added at once; a duplicate email shows the server message"
- MTP-ADMF-021: 🤖 e2e/companies.spec.ts "MTP-ADMF-021: a user can be edited and deleted"
- MTP-ADMF-022: 🤖 e2e/entraMock.spec.ts "MTP-ADMF-022: the sign-in page leads to the stand-in Microsoft page"
- MTP-ADMF-023: 🤖 e2e/entraMock.spec.ts "MTP-ADMF-023: Standard User gets the no-access page and Sign out returns to sign-in"
- MTP-ADMF-024: 🤖 e2e/entraMock.spec.ts "MTP-ADMF-024: Admin User opens the shell, survives a reload, and Sign out ends the session"
