# Gateway contract tasks

- Plan: docs/plans/gateway-contract-plan.md
- MTP prefix: GWC
- Branch: commit directly on `dev`, push as each task lands. No worktree, no PR.
- MTP rows live in `docs/manual-test-plan.md`; record results in `docs/mtp-results.md`. Every task ends with `npm run verify` green.

## Shared facts (apply to every GWC task)

- The contract is `docs/api/gateway-swagger.json` (Pradeep's C# gateway). Page types (`src/data/types.ts`), client (`src/data/gatewayClient.ts`) and mock (`src/mocks/fixtures.ts`, `src/mocks/handlers.ts`) follow it exactly; mock ids such as `c1`, `u1`, `f1` may stay.
- Every create and delete returns **200** (deletes with an empty body). Mocks return 200; no test may assert 201, 204 or a `Location` header. Errors: 401 `{error, message}`, 403 `{message}`, 400 `{message, fieldErrors}`. Not found stays a 404 status.
- The language-toggle feature runs alongside: **keep any translation calls already present**; new visible text goes through the same mechanism when `src/i18n/en.json` exists (add English and French keys, and record new French in `docs/i18n-review.md` with source "new").
- Each task reconciles the unit tests, msw overrides and e2e in its area that use old field names, paths or status codes, in the same task.

## GWC-T01: Companies, wizard and indices on the gateway contract
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: none
- Satisfies: MTP-GWC-001
- Test approach: seam A (list, detail, create, indices, RIC lookup, markets, indices referential: paths, bodies, 200s); seam B (companies list, detail Information tab with sector "Luxury/Fashion" giving Sector "Luxury" and Sub-sector "Fashion", wizard body, failures warning); Playwright for GWC-001 and existing MTP-ADMF-007 to 017 still passing.
- Model: sonnet
- What to build:
  - Types and client: `EmitterListItemDto {id, name, isArchived, ric, devise, sectors: {name, createdAt, updated_at}[], associatedAccountsCount}` replaces `CompanySummary` (`archived` -> `isArchived`, `associatedUsers` -> `associatedAccountsCount`, `sectors: string[]` -> objects). `EmitterDto {id, name, ric, sector, isArchived, market, pairs, importedPairs, primaryIndice1, primaryIndice2, primaryIndice3, primaryIndice4, otherIndices, languageCode, tickers}` replaces `CompanyDetail` (`national1Indice` -> `primaryIndice1`, `sector1Indice` -> `primaryIndice2`, `national2Indice` -> `primaryIndice3`, `sector2Indice` -> `primaryIndice4`; no `subSector`, no `collaborators`). `IndiceDto {name, codeRIC, type, createdAt, updated_at}` (`ric` -> `codeRIC`; `type` any string). `MarketDto {name, fullName, code, devise, createdAt, updated_at}` (`shortName` -> `name`, `currency` -> `devise`). `RicQuote {ric, name, isin, currency}`.
  - Companies list: Sector column `sectors.map(s => s.name).join(', ')`; Users `associatedAccountsCount`; Status from `isArchived`; show-archived filter on `isArchived`.
  - Company detail: Archive state from `isArchived`; Information tab Sector = part of `sector` before "/", Sub-sector = part after "/" or "None"; Market `market.fullName`; INDICES Index 1 to 4 from `primaryIndice1` to `primaryIndice4` as "{codeRIC} {name}" or "None". Edit indices dialog and wizard pickers read `codeRIC`. `PUT /api-admin/emitters-management/emitter/indice/{emitterId}` body `{primaryIndiceRic1, primaryIndiceRic2, primaryIndiceRic3, primaryIndiceRic4}` (RIC or null), 200 empty. Archive and unarchive 200.
  - Wizard: Market select label `fullName`, value `code`. `PUT /api-admin/emitters-management/emitter` body `{ric, name, marketCode, sector, subSector, primaryIndiceRic1, primaryIndiceRic2, primaryIndiceRic3, primaryIndiceRic4, otherIndicesRic: [], collaborators, languageCode}` (no `pairs`; unset optionals omitted; `subSector` the full "Parent/Child"); each collaborator `{email, firstName, lastName, phone?, jobFunction, roles: ["ROLE_EMITTER"]}`. Response `{emitter: EmitterDto, failures: {collaborator, message}[]}` 200: navigate to `/companies/{emitter.id}/information` with `failures` in router state. Duplicate RIC 400 behaviour unchanged.
  - Failures warning on the company page (when router state `failures` is non-empty): a warning alert above the tabs headed "Some users could not be created:" with one line per failure "{collaborator}: {message}". French "Certains utilisateurs n'ont pas pu être créés :" when translations exist.
  - Mock: fixtures and handlers return these shapes. LVMH `sector` "Luxury/Fashion", Danone "Food/Dairy", Kering "Luxury", Accor "Hospitality", Diageo "Beverages", Worldline "Payments"; list `sectors` `[{name: <sector>}]`. Markets `{name: "EPA", fullName: "Euronext Paris", code: "EPA", devise: "EUR"}`, `{name: "LSE", fullName: "London Stock Exchange", code: "LSE", devise: "GBp"}`. Create: a collaborator whose email is already used by any user is not created and adds `{collaborator: <email>, message: "Email <email> is already used."}` to `failures`; the others are created (roles from the request, `passwordChangeRequired: true`).
  - Reconcile the tests and e2e for companies, wizard, detail and indices.
- Acceptance: MTP-GWC-001 passes; MTP-ADMF-007 to 017 and MTP-CTAB rows still pass.
- Commit: 91c933d

## GWC-T02: Users on the gateway contract
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWC-T01
- References: MTP-ADMF-018, MTP-ADMF-019, MTP-ADMF-020, MTP-ADMF-021
- Test approach: seam A (list, create 200 with `AccountDto` and no Location, update body with `emitterId` and `passwordChangeRequired`, delete 200); seam B (Users tab columns and edit prefill from the renamed fields); existing Playwright rows still pass.
- Model: sonnet
- What to build:
  - `AccountDto {id, email, phone, firstname, lastname, jobFunction, cgu, deactivationDate, emitter, authorities, passwordChangeRequired, lastFlashReadDate, lastFlashDate, lastDailyReadDate, lastDailyDate}` replaces `User` (`firstName` -> `firstname`, `lastName` -> `lastname`, `roles` -> `authorities`, `lastFlashRead` -> `lastFlashReadDate`, `lastFlash` -> `lastFlashDate`, `lastDailyRead` -> `lastDailyReadDate`, `lastDaily` -> `lastDailyDate`; new nested `emitter`).
  - Users tab: Name "{firstname} {lastname}"; search on `firstname`, `lastname`, `email`; Terms accepted from `cgu`; edit prefill First name `firstname`, Last name `lastname`, Role `authorities[0]`; read-only lines from `lastDailyReadDate` and `lastFlashReadDate`; delete dialog names "{firstname} {lastname}".
  - Requests: create `PUT /api-admin/accounts-management/account` `{email, firstName, lastName, phone?, jobFunction, emitterId, roles}` returns 200 `AccountDto`; update `POST /api-admin/accounts-management/account/{accountId}` `{email, firstName, lastName, phone, jobFunction, emitterId: <company id>, passwordChangeRequired: <user's current value>, roles}` returns 200 `AccountDto`; delete 200. 400 messages and `fieldErrors` handling unchanged.
  - Mock users in the `AccountDto` shape with `emitter` set to the company's `EmitterDto`.
  - Reconcile the users tests and e2e.
- Acceptance: MTP-ADMF-018 to 021 still pass.
- Commit: 02a0a73

## GWC-T03: Reports and market reports on the gateway contract
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWC-T02
- References: MTP-REP-001 to MTP-REP-013, MTP-GWA-004, MTP-GWA-005
- Test approach: seam A (summary and detail shapes, content body `{sector, value, customContent1, customContent2}`, market `byId` path, market `validation/content` body `{content}`); seam B (date from `createdAt`, read-only rule, validation labels from `validation`, lock decision from `lockedByCaller`, company details from `getCompany`, chart file name from `fileName`); existing Playwright rows still pass.
- Model:
- What to build:
  - Types: `ReportSummaryDto {id, emitterId, companyName, ric, languageCode, writingStatus, validation: {writing, content, status}, sent, sentAt, lockedBy, lockedByCaller, marketReportId, createdAt, updatedAt}`; `ReportDetailDto` adds `sector, value, customContent1, customContent2, marketContent, graphPosition: {id, fileName, contentType, size} | null` (renames: `emitterName` -> `companyName`, `emitterRic` -> `ric`, `analysis` -> `value`, `sectorAnalysis` -> `sector`, `analysisValidation` -> `validation.writing`, `contentValidation` -> `validation.content`, `validationStatus` -> `validation.status`; nested `emitter` and `date` removed). `MarketReportSummaryDto {id, languageId, languageCode, languageName, writingStatus, validation, sent, lockedBy, lockedByCaller, createdAt, updatedAt}`, `MarketReportDetailDto` adds `content` (no `sentAt`).
  - Report date everywhere (past-date read-only rule, list rows, date line, "Back to reports" link) = the local date of `createdAt`.
  - Content save `PUT /api-admin/reports/{analysisId}/content` body `{sector, value, customContent1, customContent2}`, all four always sent. "Validate writing" state from `validation.writing`, "Validate content" from `validation.content`, list Validation from `validation.status`.
  - COMPANY DETAILS panel: call `getCompany(emitterId)` (`EmitterDto`): Name `name`, RIC `ric`, Market `market.fullName`, Sector (part of `sector` before "/"), Language from `languageCode`.
  - Chart block reads `graphPosition.fileName`.
  - Market: client `getMarketReport(marketReportId)` calls `GET /api-admin/reports/market/byId/{marketReportId}`; route back to `reports/market/:id`; list row and MARKET "View" links `/reports/market/{id}`. Language label from `languageName`. Market `validation/content` sends `{content: <current content>}`. Market reports have no `sentAt`: list Status "✓ Sent" and screen caption "Sent" without a time.
  - Lock: `useReportLock` treats the lock as free when `lockedBy === null || lockedByCaller`. Remove `getMe`, `MeProvider`, `useMe`, the mock `GET /api-admin/user/me` handler, the alert "Your account could not be loaded, so this report is read-only." with "Try again" on both report screens, and their tests.
  - Mock: report and market report fixtures in these shapes; `createdAt` = the report's day at 05:00 local; `lockedByCaller = lockedBy === "Local Admin"`; market `languageId` `6f1c2a1e-0000-4000-8000-000000000001` (fr-FR, `languageName` "French") and `6f1c2a1e-0000-4000-8000-000000000002` (en-EN, "English"); `validation/analysis` sets `validation.writing` done and, when `validation.content` is done, `validation.status` done; `validation/content` mirrors it; `graph-position` stores `{id, fileName, contentType, size}`. All writes 200 with the detail.
  - Reconcile the reports tests and e2e (including the old `/reports/market/{language}/{id}` URLs and any `lockedByCaller`/`me` mocks).
- Acceptance: MTP-REP-001 to 013 and MTP-GWA-004, 005 still pass.
- Commit: 36ea10f

## GWC-T04: Flashes and broker notes on the gateway contract
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWC-T03
- Satisfies: MTP-GWC-002
- Test approach: seam A (list page shapes, detail shapes, create 200, delete 200); seam B (Recipients count text for 1 and 2; detail recipients from `relatedCompanies`; broker note columns from `company`, `recommendationChange`, number objectives); Playwright for GWC-002 and existing FLS and BRN rows.
- Model: sonnet
- What to build:
  - Flashes: list `{content: FlashSummaryDto[], totalElements, totalPages, number, size}` with `FlashSummaryDto {id, title, company, type, description, sendByEmail, attachmentCount, relatedCompanyCount, createdAt}`. Recipients column "1 company" when `relatedCompanyCount` is 1, else "{n} companies" (French "1 émetteur" / "{n} émetteurs" when translations exist). Company column `company` (was `value`). Detail `FlashDetailDto {id, title, company, type, description, links, sendByEmail, attachments, relatedCompanies: {id, name, ric}[], createdAt}`: recipients from `relatedCompanies` names, Company from `company`. Create keeps the `flash` part JSON `{title, value, description, type, links, emittersUUID, sendByEmail, sendToAll}` and `attachments` parts; 200 `FlashDetailDto`. Delete 200.
  - Broker notes: `BrokerNoteSummaryDto {id, title, broker, company: {id, name, ric}, currency, currentObjective: number|null, currentRecommendation, previousObjective: number|null, previousRecommendation, recommendationChange, sectorNote, initiationNote, monitoringOfficer, attachmentCount, createdAt}`; detail adds `attachments`, `sendByMail` and drops `attachmentCount` (renames `emitter` -> `company`, `recoChange` -> `recommendationChange`, `sendByEmail` -> `sendByMail`). Objectives shown with two decimals. Create keeps the `note` part JSON; 200 `BrokerNoteDetailDto`. Delete 200.
  - Mock flashes and broker notes in these shapes (`relatedCompanyCount` = number of recipients; LVMH Q3 flash 1, "Pre-opening: European luxury sector" 2; `monitoringOfficer` null).
  - Reconcile the flashes and broker notes tests and e2e.
- Acceptance: MTP-GWC-002 passes; MTP-FLS and MTP-BRN rows still pass.
- Commit: f782384

## GWC-T05: Lists, Factset, version and monitoring on the contract; swagger becomes the contract
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWC-T04
- References: MTP-CTAB-001 to 008, MTP-GWA-002, MTP-GWA-003, MTP-VMON-001 to 008
- Test approach: seam A for every changed call; seam B for the Lists tab, Version and Monitoring reading the renamed fields; existing Playwright rows still pass.
- Model: sonnet
- What to build:
  - Lists: `GET /api-admin/tickers/by-emitter/{emitterId}` returns `{criteria, emitterId, resultPage: {content: TickerListDto[], totalElements, totalPages, number, size}}`; `TickerListDto {id, name, comments, tickers: {id, ricCode, name}[], createdAt, updatedAt}` (`ric` -> `ricCode`, no `emitterId`). Create `PUT /api-admin/tickers` `{emitterId, name, comments: "", tickers: [{ric, name}]}` (name from the RIC lookup). Add ticker `PUT /api-admin/tickers/{listId}/ticker` `{ric, name}` returns `TickerListDto`. Rename `POST /api-admin/tickers/{listId}` `{name, comments}` keeping current comments. Deletes 200. Duplicate-name 400 handling unchanged. Imports unchanged.
  - Factset: peers `{id, factsetName, factsetId}`, multiples `{id, key, label}` (mock ids peers 1, 2; multiples `PE` 1, `EV_EBITDA` 2, `EV_SALES` 3, `PB` 4, `DIV_YIELD` 5, `FCF_YIELD` 6); saves 200 empty; screen unchanged.
  - Version: `AppVersionDto {version, forceUpdate}`, GET always 200; `version` null or "" shows the existing "No version published yet"; publish returns 200 `AppVersionDto`; remove any use of `createdAt`.
  - Monitoring: stats `{days, from, to, totalDisconnections, last24hDisconnections, reasonBreakdown: {reason, count}[], platformBreakdown: {platform, count}[], topDisconnectedUsers: {userEmail, disconnectionCount}[]}` (`total` -> `totalDisconnections`, `byReason` -> `reasonBreakdown`, `byPlatform` -> `platformBreakdown`); extras not shown; mock fills them (`last24hDisconnections` 3, `topDisconnectedUsers` `[{userEmail: "claire.martin@lvmh.example", disconnectionCount: 4}]`). Log unchanged.
  - Contract switch: delete `docs/api/engage-admin-api.yaml`; in `CLAUDE.md` and `README.md` name `docs/api/gateway-swagger.json` as the gateway contract (Pradeep's C# gateway; the page and mock follow it exactly). Grep that no `engage-admin-api.yaml` reference remains.
  - Reconcile the lists, factset, version and monitoring tests and e2e.
- Acceptance: the referenced rows still pass; full `npm run verify` green.
- Commit: 674d601

## Automation status
<!-- Filled by /feature-implement: one line per automated MTP row, e.g. "MTP-GWC-001: 🤖 <spec file and test name>" -->
- MTP-GWC-001: 🤖 e2e/addCompany.spec.ts, "MTP-GWC-001: a user whose email is already used is reported on the new company page"
- MTP-GWC-002: 🤖 e2e/flashes.spec.ts, "MTP-GWC-002: the Recipients column counts companies and the detail names them"
