# Gateway alignment tasks

- Plan: docs/plans/gateway-alignment-plan.md
- MTP prefix: GWA
- Branch: commit directly on `dev`, push as each task lands. No worktree, no PR.
- MTP rows live in `docs/manual-test-plan.md`; record results in `docs/mtp-results.md`. Every task ends with `npm run verify` green.

## GWA-T01: Fix the two paths and use `user/me` for the lock
- Kind: bugfix
- Blocking: yes
- Status: done
- Blocked by: none
- References: MTP-REP-003, MTP-REP-010, MTP-REP-012, MTP-CTAB-005
- Test approach: integration test at seam A (`renameTickerList` sends POST to `/api-admin/tickers/{listId}`; `getMarketReport('fr-FR', id)` calls `/api-admin/reports/market/fr-FR/{id}`; `getMe()` returns `{name}`); seam B for `useReportLock` (lock free when `lockedBy` is null or equals `me.name`, foreign otherwise); existing Playwright rows REP-003, REP-010, REP-012 and CTAB-005 still pass.
- Model: sonnet
- What to build:
  - Ticker rename: `renameTickerList` sends `POST /api-admin/tickers/{listId}` (same body); mock handler switched from PUT to POST; update the ListsTab test that asserted PUT.
  - Market report fetch: `getMarketReport(language: string, id: string)` calls `GET /api-admin/reports/market/{language}/{id}`. Route `reports/market/:id` becomes `reports/market/:language/:id` in `src/app/AppRoutes.tsx`; `MarketReportScreen` reads both params. The market row link in `ReportsScreen` and the MARKET "View" link in `ReportScreen` build `/reports/market/{languageCode}/{id}` (company report: its `languageCode` and `marketReportId`). Mock: replace the `${reports}/market/byId/:id` GET handler with `${reports}/market/:language/:id` (GET only). Update tests and e2e that used the old URL.
  - Who is signed in: client `getMe(): Promise<{name: string}>` calling `GET /api-admin/user/me`; a `MeProvider` inside `GatewayProvider` fetches it once and `useMe()` returns `{name} | null` (null while loading). Mock handler returns `{"name": "Local Admin"}`. Remove `lockedByCaller` from `ReportDetail` and `MarketReportDetail` in `src/data/types.ts`, from the mock (`handlers.ts` line ~171) and from the contract. `useReportLock` treats the lock as free when `lockedBy === null || lockedBy === me.name`, and waits (no lock call, no dialog) until `me` has loaded. Update the tests that set `lockedByCaller`.
  - Contract `docs/api/engage-admin-api.yaml`: rename is POST; market GET path is `/api-admin/reports/market/{language_id}/{analysisMarket_id}` (description "Assumed: language_id is the language code"); `lockedByCaller` removed; add `GET /api-admin/user/me` returning `{name: string}` (description "Returns MonOffUserInfo; only name is used. Confirmed by Pradeep 2026-10-12").
- Acceptance: the referenced rows still pass; no `lockedByCaller` or `byId` for market reports remains in `src` or the contract.
- Commit: 095cf99

## GWA-T02: Password change required switch
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWA-T01
- Satisfies: MTP-GWA-001
- Test approach: seam B (edit dialog shows the switch preset from the user, add dialog does not; Save sends `passwordChangeRequired` true or false); Playwright for 001.
- Model: sonnet
- What to build:
  - In `UserFormDialog`, edit mode only: an MUI `Switch` labelled "Password change required", placed after Role and before the two read-only date lines, preset from `user.passwordChangeRequired`. The update body (`POST /api-admin/accounts-management/account/{accountId}`) always includes `passwordChangeRequired` with the switch value.
  - Mock update handler stores `passwordChangeRequired` from the body when present.
- Acceptance: MTP-GWA-001 passes; MTP-ADMF-021 still passes.
- Commit: a7e08a7

## GWA-T03: Factset tab
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWA-T02
- Satisfies: MTP-GWA-002, MTP-GWA-003
- Test approach: integration test at seam A for the three calls; seam B for both panels (rows, add, remove, Save peers disabled with an empty field, body sent; search filters by label; ticked keys sent; toast; error alert); Playwright for 002 and 003.
- Model: sonnet
- What to build:
  - Client: `getFactset(emitterId)` → `GET /api-admin/factset/emitter/{emitterId}` returning `{peersBloomIds: {factsetName, factsetId}[], multiples: {key, label}[], availableMultiples: {key, label}[]}`; `saveFactsetPeers(emitterId, peers)` → `POST .../peers` with body `{emitterBloomIds: peers}`; `saveFactsetMultiples(emitterId, keys: string[])` → `PUT .../multiples` with the array as body. Contract entries with these shapes, "Confirmed by Pradeep 2026-10-12".
  - Mock: `c1` LVMH peers `[{factsetName: "Hermes International", factsetId: "HRMS-FR"}, {factsetName: "Kering", factsetId: "PRTP-FR"}]`, multiples keys `PE`, `EV_EBITDA`; every other company no peers and no multiples. `availableMultiples` for all: `PE` "P/E", `EV_EBITDA` "EV/EBITDA", `EV_SALES` "EV/Sales", `PB` "P/B", `DIV_YIELD` "Dividend yield", `FCF_YIELD` "FCF yield". POST peers replaces the list; PUT multiples replaces the keys; both return 200 empty. `resetFixtures()` resets them.
  - `src/screens/CompanyDetail/FactsetTab.tsx` replacing "Coming soon" on the Factset tab, two Panels side by side:
    - Left, heading "FACTSET PEERS": a row per peer with text fields "Name" and "ID" and an icon button with `aria-label` "Remove"; button "Add a new Factset peer" appends an empty row; button "Save peers" sends the whole list and is disabled while any row has an empty Name or ID; on success a toast "Saved successfully". No rows: "No Factset peers yet."
    - Right, heading "MULTIPLES": search box (placeholder "Search multiples") and "Search" button filtering `availableMultiples` by label, case-insensitive substring (empty search shows all); one checkbox per multiple labelled with `label`, ticked when its key is in `multiples`; button "Save" sends the ticked keys (ticked state kept for multiples hidden by the search); on success the toast "Saved successfully".
    - Failure in either panel: the gateway `message` in an error alert inside that panel.
  - Reconcile the tests and e2e that expect Factset to show "Coming soon" (MTP-ADMF-017 and the company tabs tests): only Lists and Imports were placeholders before CTAB; now no tab shows "Coming soon".
- Acceptance: MTP-GWA-002 and 003 pass; MTP-ADMF-014 and the CTAB rows still pass.
- Commit: 3e46a7a

## GWA-T04: Short-positions chart on the company report
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWA-T03
- Satisfies: MTP-GWA-004
- Test approach: integration test at seam A (`attachReportChart` sends multipart with part `graph-position`; `removeReportChart` sends DELETE); seam B (block per mode: editable no chart, editable with chart, sent read-only, sent in Edit mode, past; non-image refused with the message and no request; failure message); Playwright for 004.
- Model: sonnet
- What to build:
  - `ReportDetail` gains `graphPosition: {id: string, filename: string, type: string} | null`; contract updated. Client `attachReportChart(reportId, file: File)` → `POST /api-admin/reports/{reportId}/graph-position` via `form<T>` with the file in part `graph-position`, returns `ReportDetail`; `removeReportChart(reportId)` → `DELETE /api-admin/reports/{reportId}/graph-position`, returns `ReportDetail`. Contract entries "Confirmed by Pradeep 2026-10-12".
  - Mock: every report starts with `graphPosition: null`; POST stores `{id: crypto.randomUUID(), filename: <uploaded file name>, type: <uploaded content type>}` and returns the detail; DELETE sets null and returns the detail.
  - In `ReportScreen`, a block headed "SHORT POSITIONS" between CUSTOM CONTENT 2 and MARKET. Editable mode and Edit mode on sent reports: with no chart, a button "Add chart"; with a chart, its file name and buttons "Replace" and "Remove". A hidden file input `accept="image/png,image/jpeg"`; a chosen file whose type is not `image/png` or `image/jpeg` shows "Choose a PNG or JPEG image." under the block and sends nothing. Add and Replace call `attachReportChart`, Remove calls `removeReportChart`; the screen takes the returned detail. Read-only modes (past, sent without Edit, foreign lock declined): the file name, or "No chart.". A failed call shows the gateway `message` under the block. The market report screen gets no chart block.
- Acceptance: MTP-GWA-004 passes; MTP-REP-004 to REP-011 still pass.
- Commit: 11fe718

## GWA-T05: Economic statistics under the company report
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: GWA-T04
- Satisfies: MTP-GWA-005
- Test approach: integration test at seam A (`listEconomicStatistics('2026-10-12')` calls `/api-admin/reports/statistics/economic?date=2026-10-12`); seam B (columns, values, empty text, failure text); Playwright for 005.
- Model: sonnet
- What to build:
  - Type `EconomicStatistic = {zone, country, object, period, actual, expected, previous, released: string, createdAt: string, updated_at: string}`; client `listEconomicStatistics(date: string)` (date `yyyy-MM-dd`) → `GET /api-admin/reports/statistics/economic?date={date}`. Contract entry "Confirmed by Pradeep 2026-10-12".
  - Mock: for today's date only, three rows: Europe, France, "CPI (YoY)", "Sep", "1.2%", "1.3%", "1.4%", "08:45"; Europe, Germany, "ZEW Economic Sentiment", "Oct", "12.5", "10.0", "9.8", "11:00"; Americas, United States, "Retail Sales (MoM)", "Sep", "0.4%", "0.3%", "0.1%", "14:30" (`createdAt` and `updated_at` today 06:00 local). Any other date returns `[]`.
  - In `ReportScreen` (company report only), a full-width Panel headed "ECONOMIC STATISTICS" below the MARKET block, loaded for the report's `date`. Columns "Zone", "Country", "Indicator" (`object`), "Period", "Actual", "Expected", "Previous", "Released", values shown as given, in the order returned. No rows: "No statistics for this day." Failed load: "The statistics could not be loaded." Shown in every mode, never editable.
- Acceptance: MTP-GWA-005 passes; MTP-REP rows still pass.
- Commit: ebc1fc3

## GWA-T06: Show a message and retry when `user/me` fails
- Kind: gap
- Blocking: yes
- Status: done
- Blocked by: none (owner decided 2026-10-13)
- References: MTP-REP-005, MTP-REP-009, MTP-REP-010, MTP-REP-012 (from /feature-review 2026-10-13)
- Test approach: seam B with an msw 500 override on `GET /api-admin/user/me`, rendering an editable company report and an editable market report, RED first: the alert shows, the report stays read-only (no editors, no action bar, no lock call); clicking "Try again" with the endpoint now succeeding re-fetches, the alert goes, and the normal lock flow runs. Also a `MeProvider` test for the error state and retry.
- Model: sonnet
- What to build: `MeProvider` currently swallows a failed `getMe()`, so `useMe()` stays null and every editable report opens read-only with no message. Owner decision: `useMe()` returns `{me: {name} | null, failed: boolean, retry: () => void}` (adjust the existing callers). When `failed` is true, the company report screen and the market report screen stay read-only (as now) and show an error alert above the boxes reading "Your account could not be loaded, so this report is read-only." with a button "Try again" inside the alert. "Try again" calls `retry()`, which clears `failed` and calls `getMe()` again; on success the alert disappears and `useReportLock` proceeds as normal (lock at once, or the takeover dialog). A failed retry shows the alert again.
- Acceptance: the new tests pass; MTP-REP-005, 009, 010 and 012 still pass.
- Commit: b56333d

## Automation status
<!-- Filled by /feature-implement: one line per automated MTP row, e.g. "MTP-GWA-001: 🤖 <spec file and test name>" -->
MTP-GWA-001: 🤖 e2e/companies.spec.ts, "MTP-GWA-001: the edit form has a Password change required switch that is kept; add has none"
MTP-GWA-002: 🤖 e2e/companies.spec.ts, "MTP-GWA-002: Factset peers list, add, remove and save"
MTP-GWA-003: 🤖 e2e/companies.spec.ts, "MTP-GWA-003: Factset multiples search, tick and save"
MTP-GWA-004: 🤖 e2e/reports.spec.ts, "MTP-GWA-004: short-positions chart add, refuse, replace, remove and read-only"
MTP-GWA-005: 🤖 e2e/reports.spec.ts, "MTP-GWA-005: economic statistics table for today and none for yesterday"
