# Reports plan

- Slug: reports
- MTP prefix: REP
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

The Reports area of Engage Admin, replacing the myCMS "Rapports" screens: the Corporate Market Services team's daily work (11,248 reports in the last twelve months).

1. **Reports list** at `/reports` (replaces the placeholder). Tabs Companies and Markets, a date line ("Today (Monday 12 October 2026)" or "Monday 5 October 2026"), a date picker, a search box. Companies tab: one row per non-archived company for that day; Markets tab: one row per language. A row opens its writing screen.
2. **Company report writing screen** at `/reports/:id`: boxes COMPANY, SECTOR, CUSTOM CONTENT 1, CUSTOM CONTENT 2, a read-only MARKET block with a "View" link, a right column of company details, auto-save, sign-off actions, Send with confirmation, Edit and Save for sent reports, read-only for past dates.
3. **Editing lock**: opening an unsent report takes the lock; if someone else holds it, a dialog offers takeover or read-only; leaving releases it on a best-effort basis.
4. **Market report writing screen** at `/reports/market/:id`: one box, full toolbar, same lock, auto-save, sign-off and send.

Copies myCMS per `docs/mycms-admin-spec-1.md` §4, §9 Reports, §10; spec-2 §3; spec-3 §1. Where spec-3 §1.5 differs from spec-1 §10, spec-3 wins. Every value is pinned below.

## API research

Confirmed 2026-10-12 with `npm view` and by unpacking the published packages.

| Library | Version | Notes |
|---|---|---|
| @tiptap/react, @tiptap/pm, @tiptap/starter-kit | 3.31.4 | Peers React 17 to 19. StarterKit 3 bundles Bold, Italic, Underline, Link, Heading, BulletList, OrderedList, HardBreak (its dependency list), so no separate underline or link packages. |
| @tiptap/extension-table | 3.31.4 | Exports `TableKit` (Table, TableRow, TableCell, TableHeader). Use `TableKit`. |
| @tiptap/extension-image | 3.31.4 | `Image` with option `allowBase64`; set true so pasted images stay inline as data URLs. |
| dompurify | 3.4.17 | `DOMPurify.sanitize(html)` default config strips scripts, event-handler attributes, `javascript:` URLs; keeps tables, links, `img` with `data:` src. Own types. |
| @mui/x-date-pickers | 9.15.0 | Peers `@mui/material ^7.3.0 \|\| ^9.0.0`, `dayjs ^1.10.7`. `LocalizationProvider` + `AdapterDayjs` (`@mui/x-date-pickers/AdapterDayjs`) + `DatePicker`. |
| dayjs | 1.11.23 | English locale default; `dddd D MMMM YYYY` gives "Monday 12 October 2026". |

Assumed, to confirm with Pradeep: every report payload in the contract below (the specs give paths only).

## Code survey

- `src/data/gatewayClient.ts`: `createGatewayClient({baseUrl, getToken, onAuthError})` returns typed functions over private `json<T>(method, path, body?)` and `empty(method, path, body?)`; non-2xx throws `GatewayError {status, message, fieldErrors?}`; 401/403 call `onAuthError`. Screens use `useGateway()` (`src/data/gatewayContext.ts`, `GatewayProvider`).
- `src/data/types.ts`: shared types (`Market`, `CompanyDetail`, ...). Report types go here.
- `src/mocks/fixtures.ts`: module state `db = { companies, users }`, `resetFixtures()` run before each test by `src/test/setup.ts`. Companies `c1` LVMH (fr-FR, EPA, Luxury), `c2` Danone (fr-FR, EPA, Food), `c3` Kering (fr-FR, EPA, Luxury), `c4` Accor (fr-FR, EPA, Hospitality), `c5` Diageo (en-EN, LSE, Beverages), `c6` Worldline (archived).
- `src/mocks/handlers.ts`: `*`-prefixed paths, helpers `notFound()`, `bad(message)`.
- `src/app/AppRoutes.tsx`: `/reports` renders `PlaceholderScreen title="Reports"`; sidebar in `src/app/AppShell.tsx`.
- `src/screens/ScreenTitle.tsx`; `CompanyDetailScreen.tsx` has a private `Field` label/value helper (copy the pattern; promote to `src/ds/components` only once used twice).
- Tests: `renderWithTheme` inside `MemoryRouter` + `GatewayProvider`, msw node server (pattern: `src/screens/Companies/CompaniesScreen.test.tsx`); setup fails a test on any `console.error`. Playwright in `e2e/`, mock mode, port 5174, test names start with the MTP id.
- `docs/api/engage-admin-api.yaml`: OpenAPI 3.1 with `components/schemas` and shared `Unauthorized` / `Forbidden` responses.
- **Will break:** `e2e/shell.spec.ts` (MTP-ADMF-005) and `src/app/AppRoutes.test.tsx` treat Reports as a placeholder; T01 removes Reports from their placeholder lists.

Seams and coverage:
- Seam A, client vs msw node server: every new function, URL, body. Automated.
- Seam B, Testing Library: list labels, search, tab/date from URL, read-only rules, dialogs, lock decisions, unlock on unmount, sign-off button states, `SafeHtml`, `useAutoSave` with fake timers, the editor's image paste handler with a fake `ClipboardEvent`. Automated.
- Seam C, Playwright mock mode: REP-001 to REP-013, including typing into editors (jsdom `contenteditable` support is partial, so typing is covered here), toolbars, tables, pasted HTML with a data-URL image, the XSS check.

## Implementation approach / decisions

Owner decisions, 2026-10-12:
1. Copy myCMS behaviour; English copy only; the typos "étés" and "dévérouiller" are not carried over.
2. One editor library (TipTap 3.31.4), two toolbars. COMPANY and SECTOR: Bold, Italic. CUSTOM CONTENT 1, CUSTOM CONTENT 2, market box (and flashes): Heading 2, Heading 3, Bold, Italic, Underline, Bullet list, Numbered list, Link, Insert table, Image, Paste as plain text; pasted or dropped images inline as `data:` URLs.
3. Clean stored HTML before read-only display with DOMPurify 3.4.17.
4. Send without sign-off allowed; the confirmation shows the not-validated warning when writing status is not done.
5. Archived companies never appear in the Reports list, for any date.
6. Short-positions chart attachment left out (open item).
7. Right column: company details only (Name, RIC, Market full name, Sector, Language); economic statistics left out (open item).
8. Date picker `@mui/x-date-pickers` 9.15.0 with dayjs 1.11.23.

Pinned for the build:

9. **Routes.** `/reports` with query `tab=companies|markets` (default companies) and `date=YYYY-MM-DD` (default today), both kept in the URL; `/reports/:id`; `/reports/market/:id`.
10. **Contract** (appended to `docs/api/engage-admin-api.yaml`; to confirm with Pradeep). Base `/api-admin/reports`, path dates `dd-MM-yyyy`; every write returns the updated detail.
    - `WorkStatus` = `"todo" | "doing" | "done"`.
    - `ReportSummary` = `{id, emitterId, emitterName, emitterRic, languageCode: "fr-FR"|"en-EN", date: "YYYY-MM-DD", updatedAt, validationStatus, sent, sentAt?}`.
    - `MarketReportSummary` = `{id, languageCode, date, updatedAt, validationStatus, sent, sentAt?}`.
    - `ReportDetail` = `{id, date, languageCode, emitter: {id, name, ric, sector, subSector, languageCode, market: Market}, analysis, sectorAnalysis, customContent1, customContent2 (strings), writingStatus, analysisValidation, contentValidation, validationStatus, sent, sentAt?, lockedBy: string|null, lockedByCaller: boolean, updatedAt, marketReportId: string|null, marketContent: string|null}`.
    - `MarketReportDetail` = `{id, date, languageCode, content, writingStatus, analysisValidation, contentValidation, validationStatus, sent, sentAt?, lockedBy, lockedByCaller, updatedAt}`.
    - `GET /api-admin/reports` (today), `GET /api-admin/reports/{date}` → `ReportSummary[]`, never archived companies, missing rows created empty on the fly. `GET /api-admin/reports/byId/{analysisId}` → `ReportDetail` or 404. `POST /api-admin/reports/{emitterId}` → 201 `ReportDetail` (documented, unused by the UI). `PUT /api-admin/reports/{analysisId}/content` body `{analysis, sectorAnalysis, customContent1, customContent2}` (all four always sent; server overwrites all four) → 200. `PUT .../validation/analysis`, `.../validation/content`, `.../writing_status` (no body: writing done; analysis, content and overall validation doing), `.../sent`, `.../lock` (holder = caller), `.../unlock` (clears holder) → 200 detail.
    - Market mirror: `GET /api-admin/reports/market`, `GET /api-admin/reports/market/{date}` → `MarketReportSummary[]` (one per language, created on the fly); `GET /api-admin/reports/market/byId/{marketReportId}`; `POST /api-admin/reports/market/{languageCode}` → 201; `PUT /api-admin/reports/market/{marketReportId}/content` body `{content}`; `validation/analysis`, `validation/content`, `writing_status`, `sent`, `lock`, `unlock` as above.
    - 401/403 as elsewhere; 404 unknown id. Rules: validate analysis sets `analysisValidation` done and, if `contentValidation` is done, `validationStatus` done; content is the mirror; no guards; every write sets `updatedAt` now; sent cannot be undone.
    - `lockedByCaller` is new (not in myCMS): comparing names on the page is unreliable because the Entra account name may differ from the gateway's stored holder.
11. **Client functions:** `listReports(date: string | null)` (null = today path, else `dd-MM-yyyy`), `getReport`, `saveReportContent`, `requestReportValidation` (writing_status), `validateReportAnalysis`, `validateReportContent`, `sendReport`, `lockReport`, `unlockReport`; market: `listMarketReports`, `getMarketReport`, `saveMarketReportContent`, `requestMarketReportValidation`, `validateMarketReportAnalysis`, `validateMarketReportContent`, `sendMarketReport`, `lockMarketReport`, `unlockMarketReport`.
12. **Mock fixtures.** `db.reports`, `db.marketReports`, seeded relative to the local date at seed time; ids `r-{companyId}-{YYYY-MM-DD}`, `m-{languageCode}-{YYYY-MM-DD}`; mock caller `"Local Admin"`, `lockedByCaller = lockedBy === "Local Admin"`. Today:
    - `c1` LVMH: analysis `<p><strong>LVMH</strong> shares rose 1.2% after the Q3 update.</p>`, sectorAnalysis `<p>Luxury names traded higher across Europe.</p>`, customContent1 `<p><strong>Desk note</strong></p><script>window.__xss = 1</script><img src="x" onerror="window.__xss = 2">`, customContent2 `""`; all statuses done; sent at today 07:45 local; lockedBy null; updatedAt today 07:45.
    - `c2` Danone: analysis `<p>Danone was flat in a quiet session.</p>`, sectorAnalysis `<p>Food producers lagged the index.</p>`, customs `""`; writing done, analysis/content/overall doing; unsent; updatedAt 07:30.
    - `c3` Kering: analysis `<p>Kering slipped 0.8%.</p>`, others `""`; all todo; unsent; lockedBy `"jean.martin@rothschildandco.com"`; updatedAt 07:20.
    - `c4` Accor: all four `""`; all todo; unsent; updatedAt 07:00.
    - `c5` Diageo: analysis `<p>Diageo gained 0.5% in London.</p>`, others `""`; all todo; unsent; updatedAt 07:10.
    - No row for `c6` Worldline; the list handlers filter archived companies for any date.
    - Market `fr-FR`: `<p>European markets closed higher, led by luxury stocks.</p>`, all statuses done, unsent, updatedAt 06:50. Market `en-EN`: `""`, all todo, unsent, updatedAt 06:40.
    - Other dates: list handlers create empty rows on first request for every non-archived company and both languages (all todo, unsent, lockedBy null, updatedAt that date 00:00 local). A company report's `marketReportId` is the same-language market report for its date (created if missing); `marketContent` its content.
13. **Copy (English).**
    - List: heading "Reports"; tabs "Companies", "Markets"; date line "Today ({dddd D MMMM YYYY})" for today, else "{dddd D MMMM YYYY}"; date picker label "Date", format `DD/MM/YYYY`; search placeholder "Search reports" (companies: name or RIC; markets: language name; case-insensitive substring). Company columns "Companies ({n})", "Last modified", "Validation", "Status"; market columns "Language ({n})", "Last modified", "Validation", "Status"; `{n}` = rows shown. Last modified `dd/MM/yyyy HH:mm`. Validation todo "...", doing "To validate", done "Validated". Status unsent "To send", sent "✓ Sent at HH:mm". Languages `fr-FR` "French", `en-EN` "English". Companies sorted by name; markets French then English. No match: "No reports found."
    - Company screen: heading "Write a report", sub-heading company name, link "Back to reports" to `/reports?tab=companies&date={report date}`. Headings "COMPANY", "SECTOR", "CUSTOM CONTENT 1", "CUSTOM CONTENT 2"; placeholder "Enter your analysis here" in COMPANY and SECTOR only. Block "MARKET": language name, link "View" to `/reports/market/{marketReportId}`, market text, or "No market report yet." when null or empty. Right panel "COMPANY DETAILS": Name, RIC, Market, Sector, Language.
    - Last saved (from `updatedAt`, refreshed every 30 s): "Last saved just now" (< 60 s), "Last saved 1 minute ago" / "Last saved {n} minutes ago" (< 60 min), else "Last saved at HH:mm".
    - Action bar (unsent, editable): "Request validation" (disabled once writing done), "Validate content" (becomes disabled "Content validated" once content validation done; calls `validation/content`), "Validate writing" (becomes disabled "Writing validated" once analysis validation done; calls `validation/analysis`), "Send".
    - Send dialog title "Send the report"; if writing status is not done, first line "The report content and writing have not been validated."; then "Are you sure you want to send the report to {company name}?" (market: "Are you sure you want to send the {language} market report?"); buttons "Cancel", "Yes".
    - Sent: caption "Sent at HH:mm", button "Edit". In Edit mode the bottom button is "Save"; it opens dialog "Save the report", text "Are you sure you want to save the changes to the report for {company name}?" (market: "Are you sure you want to save the changes to the {language} market report?"), buttons "Cancel", "Yes"; Yes saves content only (no send call) and returns to read-only.
    - Lock dialog title "CONTENT BEING WRITTEN", lines "The report is being written by {lockedBy}" and "Do you want to unlock access to this report?", buttons "Cancel" (read-only), "Yes" (take over).
    - Market screen: heading "Write a market report", sub-heading language name, "Back to reports" to `/reports?tab=markets&date={report date}`, one box with no heading or placeholder.
    - Editor toolbar accessible names: "Bold", "Italic", "Underline", "Heading 2", "Heading 3", "Bullet list", "Numbered list", "Link", "Insert table", "Image", "Paste as plain text". Link opens an MUI popover (no browser dialogs) with a text box "URL" and buttons "Cancel", "Apply" (empty URL removes the link). Insert table: 3 by 3 with header row. Image: file picker, inserted as a data URL. Paste as plain text: `navigator.clipboard.readText()`, line breaks become hard breaks.
    - Auto-save failure alert: "The report could not be saved. Your changes are kept on this page."
14. **Read-only** when sent and not in Edit mode; when report `date` is before today local (no Edit, no action bar); or when the lock belongs to someone else and the admin chose Cancel. Read-only boxes render via `SafeHtml` (DOMPurify), not an editor; MARKET always via `SafeHtml`. (spec-3 says last-updated date; the report date is used because a today report always has a today update.)
15. **Auto-save:** `useAutoSave` saves 3000 ms after the last change when unsent, editable and the changed box non-empty (a blanked box is written with the next save). Every save sends all four fields (market: `content`). COMPANY and SECTOR report on every change; CUSTOM CONTENT 1 and 2 report on blur (the screen keeps their latest HTML from `onChange` and only marks them changed in the editor's `onBlur`). Sent reports never auto-save. On failure show the alert and retry on the next change.
16. **Lock:** opening an unsent today report calls `lock` at once if `lockedBy` is null or `lockedByCaller`, otherwise shows the lock dialog. On unmount and on window `pagehide`, if this page holds the lock and the report is unsent and editable, call `unlock` and ignore the result. Sent or past reports never lock.
17. **Editor** is shared with Flashes, so it lives in the design system: `src/ds/components/RichTextEditor.tsx`, exported from `src/ds/components/index.ts`, props `{label: string, value: string (HTML), onChange: (html: string) => void, toolbar: 'basic' | 'full', error?: string, readOnly?: boolean, placeholder?: string, onBlur?: () => void}`, plus helper `isRichTextEmpty(html: string): boolean` (true when the text content is blank and there is no `<img>`). Basic: StarterKit, toolbar Bold and Italic. Full: StarterKit (link `openOnClick: false`) + `TableKit` + `Image.configure({allowBase64: true, inline: true})` + `editorProps.handlePaste`/`handleDrop` reading image files to data URLs and inserting them; toolbar as decision 13. Toolbar buttons are MUI icon buttons with `aria-label` equal to the names, showing pressed state. The error text shows under the box in `colors.red`.
18. No new tokens: panels on canvas, headings `textPrimary`, captions `textSecondary`, "Validated" and the sent tick `green`, "To validate" `amber`.

## Manual test plan (definition of done)

MTP-REP-001 to MTP-REP-013 (rows in `docs/manual-test-plan.md`, execution in `docs/mtp-results.md`), all automated in Playwright against mock mode.

## Out of scope / open questions

Out of scope: short-positions chart attachment, economic statistics (`GET /api-admin/reports/statistics/economic`), French copy, back end, push on send (gateway side).

Not built, noted for the CMS team: spec-1 §10 mentions "Check spelling" / "Check meaning" checkboxes with no behaviour, and spec-3's screen walk-through omits them; myCMS asks before pasting HTML or Word, TipTap pastes without asking.

Open (none block the build): confirm every report payload, `lockedByCaller` and archived exclusion with Pradeep; chart attachment and economic statistics endpoints for a later feature; whether client-app users should keep receiving the lock holder's name and validation states (spec-3 §1.6); the purpose and real labels of CUSTOM CONTENT 1 and 2 (filled in 306 and 17 reports in twelve months).
