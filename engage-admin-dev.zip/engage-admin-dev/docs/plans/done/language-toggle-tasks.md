# Language toggle tasks

- Plan: docs/plans/language-toggle-plan.md
- MTP prefix: LANG
- Branch: commit directly on `dev`, push as each task lands. No worktree, no PR.
- MTP rows live in `docs/manual-test-plan.md`; record results in `docs/mtp-results.md`. Every task ends with `npm run verify` green.

## Shared facts (apply to every task)

- Libraries: i18next 26.4.4, react-i18next 17.0.16, dayjs 1.11.23 with `dayjs/locale/fr`.
- Files: `src/i18n/index.ts` (init, `setLanguage`, `detectLanguage`), `src/i18n/en.json`, `src/i18n/fr.json`, one namespace `translation`, keys nested by screen in camelCase (`shell`, `signIn`, `noAccess`, `mockSignIn`, `placeholder`, `common`, `validation`, `companies`, `addCompany`, `companyDetail`, `users`, `lists`, `imports`, `factset`, `reports`, `flashes`, `brokerNotes`, `version`, `monitoring`, `editor`, `attachments`). Interpolation `{{name}}`; plurals with `_one` / `_other` and `count`.
- Components use `const { t } = useTranslation()`; helpers outside components return keys or take `t`; data values (reasons, roles, platforms, languages) map to keys.
- `en.json` holds today's English text exactly, so English screens do not change.
- French: myCMS wording as listed in each task (typos fixed); anything not listed is our own translation. Every key a task adds gets a row in `docs/i18n-review.md` (table columns Key, English, French, Source), Source "myCMS" for listed wording, "new" otherwise.
- Not translated: server `message` values, stored content (report text, flash bodies, names), the brand "Engage Admin", the switch labels "EN" / "FR".
- Unit tests run in English (`setLanguage('en')` in `src/test/setup.ts` `beforeEach`). Each task adds a seam B test per screen it converts: render, `act(() => setLanguage('fr'))`, assert two or three French strings from its list. French Playwright rows use `test.use({ locale: 'fr-FR' })` in their own `describe`.

## LANG-T00: Remove the "Password change required" switch
- Kind: bugfix
- Blocking: yes
- Status: done
- Blocked by: none
- References: MTP-GWA-001, MTP-ADMF-021
- Test approach: seam B (the edit dialog has no "Password change required" switch; Save sends the user's existing `passwordChangeRequired` value unchanged); MTP-ADMF-021 Playwright still passes.
- Model: sonnet
- What to build: Pradeep confirmed on 2026-10-13 that myCMS has no such control; its edit form keeps `passwordChangeRequired` in state and sends it back unchanged. Owner decision 2026-10-13: remove the switch built in GWA-T02. In `UserFormDialog` delete the switch; the update body still includes `passwordChangeRequired`, set to the user's current value. Keep the mock storing it. Delete the GWA-001 Playwright test and the switch's unit tests; in `docs/manual-test-plan.md` replace the MTP-GWA-001 row's Steps and Expected with "Withdrawn 2026-10-13: myCMS has no such control." and in `docs/mtp-results.md` set its Result to "WITHDRAWN" with that note.
- Acceptance: no "Password change required" text remains in `src` or `e2e`; MTP-ADMF-021 passes.
- Commit: 8e548c2

## LANG-T01: i18n setup, EN | FR switch, detection, and the shell screens
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: none
- Satisfies: MTP-LANG-001, MTP-LANG-002, MTP-LANG-003
- Test approach: unit tests for `detectLanguage` (navigator "fr-FR" gives fr, "en-GB" gives en, stored "en" beats a French browser, localStorage throwing falls back to the browser) and `setLanguage` (writes `engage-admin.language`, sets `document.documentElement.lang`, sets dayjs locale); seam B for the switch (pressed state, click FR changes sidebar labels at once) and the shell screens in French; Playwright for 001 to 003.
- Model:
- What to build:
  - Install `i18next@26.4.4` and `react-i18next@17.0.16`. Create `src/i18n/index.ts`: `i18next.use(initReactI18next).init({resources: {en: {translation: en}, fr: {translation: fr}}, lng: detectLanguage(), fallbackLng: 'en', interpolation: {escapeValue: false}})`; `detectLanguage()` reads localStorage key `engage-admin.language` (`"en"` or `"fr"`, in try/catch), else `navigator.language.toLowerCase().startsWith('fr') ? 'fr' : 'en'`; `setLanguage(lng)` calls `i18next.changeLanguage(lng)`, writes the key (try/catch), sets `document.documentElement.lang = lng` and `dayjs.locale(lng)`. On start also set `lang` and the dayjs locale. Import `dayjs/locale/fr`. Import `@/i18n` in `src/main.tsx` before rendering, and in `src/test/setup.ts`, where `beforeEach` clears the key and calls `setLanguage('en')`.
  - Switch in `src/app/AppShell.tsx`, at the top of the bottom block above the name and "Sign out": a group with `role="group"` and `aria-label` `t('shell.language')` ("Language" / "Langue") holding buttons "EN" and "FR" with `aria-pressed`. Pressed: background `colors.panel`, text `colors.textPrimary`; other: transparent, text `colors.onChrome`, 1px border `colors.onChrome`; 12px, weight 600, height 24px, radius 2. Clicking calls `setLanguage`.
  - Translate the shell and the screens outside it. French: sidebar "Rapports", "Flashs", "N. de brokers", "Émetteurs", "Version", "Monitoring"; "Sign out" "Se déconnecter" (new); sign-in button "Sign in with Microsoft" "Se connecter avec Microsoft" (new); "You do not have access to Engage Admin." "Vous n'avez pas accès à Engage Admin." (new); stand-in page "Stand-in Microsoft sign-in" "Connexion Microsoft simulée", "Pick an account. This page stands in for Microsoft until an Entra tenant is set up." "Choisissez un compte. Cette page remplace Microsoft en attendant la configuration d'un tenant Entra.", "Admin User" and "Standard User" unchanged (account names); placeholder "Coming soon" "Bientôt disponible" (all new). The placeholder heading uses the sidebar key.
  - Create `docs/i18n-review.md` with a one-line intro ("French wording for the CMS team to check; Source myCMS means taken from myCMS, new means our translation.") and the table, filled for this task's keys.
- Acceptance: the listed MTP rows pass; all existing tests pass in English.
- Commit: 3a840df

## LANG-T02: Companies, company detail, wizard, users, lists, imports and Factset in French
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: LANG-T01
- Satisfies: MTP-LANG-004
- Test approach: seam B per screen in French (two or three strings each, including one validation error and one plural); Playwright for 004.
- Model: sonnet
- What to build: move every literal on `src/screens/Companies`, `AddCompany`, `CompanyDetail` (all tabs, `UserFormDialog`, `EditIndicesDialog`), `src/screens/validation.ts` and `src/screens/indexOptions.ts` labels into keys. myCMS French to use: list "Rechercher un émetteur", "Afficher les émetteurs archivés", "Ajouter un émetteur"; columns "Valeurs", "Id ric", "Secteur", "Utilisateurs associés", "Statut"; "Actif" / "Archivé"; wizard steps "1. Informations", "2. Indices", "3. Utilisateurs"; fields "ID RIC", "Nom", "Langue", "Français", "Anglais", "Marché", "Secteur", "Sous-secteur", "Indice 1" to "Indice 4", "Utilisateur {{n}}", "Prénom", "Nom", "Poste", "E-mail", "Téléphone"; errors "Ce code RIC n'existe pas", "L'email est requis", "Format d'email invalide"; buttons "Précédent", "Suivant", "Ajouter"; detail tabs "Informations", "Listes", "Utilisateurs", "Imports", "Factset"; "Archiver", "Désarchiver", banner "Attention ! Émetteur archivé"; "INDICES", "Modifier", dialog "Modifier les indices"; lists "{{count}} éléments" / "{{count}} élément", "Créer une liste", "Ajout d'un élément", "Modifier une liste", "Suppression d'un élément", placeholder "rechercher un pair", "Requis"; users columns "Nom", "Poste", "Adresse e-mail", "N° de téléphone", "CGU acceptées le", "Non"; "Suppression utilisateur"; "Date de dernière lecture de daily report", "Date de dernière lecture de flash", "N/A"; imports "Choisir un type", "Importer un fichier"; Factset "Ajouter un nouveau pair Factset", "Rechercher", "Enregistrer", toast "Enregistrement effectué avec succès". Everything else (e.g. "Search users", "Add user", "Password change required", "Role", "Standard", "Limited access", "Save peers", "No Factset peers yet.", "Company not found") is own translation. Common buttons "Cancel" "Annuler", "Save" "Enregistrer", "Yes" "Oui", "No" "Non", "Delete" "Supprimer", "Edit" "Modifier" go in `common.*`. Rows in `docs/i18n-review.md`.
- Acceptance: MTP-LANG-004 passes; existing ADMF, CTAB and GWA tests pass.
- Commit: e9f5888

## LANG-T03: Reports in French, including the date line
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: LANG-T02
- Satisfies: MTP-LANG-005
- Test approach: seam B for the list, company report, market report and dialogs in French; unit test that the date line for 2026-10-12 in French reads "Aujourd'hui (lundi 12 octobre 2026)" when today, "lundi 12 octobre 2026" otherwise, and the "Last saved" texts in French; Playwright for 005.
- Model: sonnet
- What to build: move every literal in `src/screens/Reports/*` (list, `ReportScreen`, `MarketReportScreen`, `ReportActionBar`, `LastSavedLine`, `lastSaved.ts`, `MeFailedAlert`, chart and statistics blocks) and the editor toolbar names and link popover in `src/ds/components/RichTextEditor.tsx` into keys. myCMS French: tabs "Valeurs", "Marchés"; "Aujourd'hui ({{date}})"; "Rechercher un rapport"; columns "Valeurs ({{n}})", "Langue ({{n}})", "Dernière modification", "Validation", "Statut"; states "...", "À valider", "Validé", "À envoyer", "✓ Envoyé à {{time}}"; "Rédiger un rapport", "Rédiger un rapport de marché"; headings "VALEUR", "SECTEUR", "MARCHÉ", "POSITIONS COURTES", link "Consulter"; placeholder "Renseignez votre analyse ici"; "Dernière sauvegarde {{relative}}"; "Demander la validation", "Valider le contenu", "Contenu validé", "Valider la rédaction", "Rédaction validée", "Envoyer", "Sauvegarde", "Modifier", "Envoyé à {{time}}"; send dialog "Envoyer le rapport", "Le contenu et la rédaction du rapport n'ont pas été validés.", "Êtes-vous certain de vouloir envoyer le rapport à {{company}} ?", "Annuler", "Oui"; lock dialog "CONTENU EN COURS DE RÉDACTION", "Le rapport est en cours de rédaction par {{name}}", "Désirez-vous déverrouiller l'accès à ce rapport ?". "CUSTOM CONTENT 1" and "CUSTOM CONTENT 2" stay as they are in both languages (myCMS shows them in English). Everything else (e.g. "No reports found.", "Back to reports", "COMPANY DETAILS", "ECONOMIC STATISTICS" and its columns, "Add chart", "No chart.", the market dialog texts, the relative times "à l'instant", "il y a 1 minute", "il y a {{n}} minutes", "à {{time}}", toolbar names) is own translation. The date line uses dayjs `dddd D MMMM YYYY` with the current locale. Rows in `docs/i18n-review.md`.
- Acceptance: MTP-LANG-005 passes; existing REP and GWA tests pass.
- Commit: b0123df

## LANG-T04: Flashes and broker notes in French
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: LANG-T03
- Satisfies: MTP-LANG-006
- Test approach: seam B for the flash list, detail, compose, the broker note list and compose, and the attachment picker errors in French; Playwright for 006.
- Model: sonnet
- What to build: move every literal in `src/screens/Flashes/*`, `src/screens/BrokerNotes/*` and `src/ds/components/AttachmentPicker.tsx` into keys. myCMS French: "Rechercher un flash", "Envoyer un flash"; columns "Date d'envoi", "Destinataire(s)", "Valeur", "Titre", "Type"; detail "DESTINATAIRE(S)", "CONTENU", "LIENS ASSOCIÉS :", "PIÈCE-JOINTE", "Duplicata envoyé par email"; compose "Envoyer à tous les émetteurs", "Merci de saisir un destinataire", "Objet", "L'objet est requis", "Valeur", "La valeur est requise", "Type", "Le type est requis", "Message", "Le message est requis", "Liens associés", "Merci de mettre un lien par ligne", "Ajouter une pièce jointe", "Envoyer aussi par email", "Envoyer", "Impossible de créer un flash pour le moment. Merci de réessayer ultérieurement."; delete "Suppression d'un flash", "Êtes-vous sûr de vouloir supprimer ?", "Cette action est irreversible", "Annuler", "Oui". Broker notes: "Rechercher une note de broker", "Envoyer une note"; legend "Changement de recommandation", "Initiation", "Secteur"; columns "Date d'envoi", "Valeur", "Broker", "Type", "Objectif", "Recommandation", "Ancien Objectif", "Ancienne Recommandation"; compose "Émetteur", "Rechercher un émetteur", "Merci de saisir un émetteur", "Titre de la note", "Broker", "Rechercher un broker", "Merci de saisir un broker", "Informations de la note", "Objectif", "L'objectif est requis", "Recommandation", "Le type est requis", "Ancien objectif", "Ancienne recommandation", "Envoyer aussi par email", "Envoyer", "Envoyer et continuer", "Impossible de créer une note pour le moment. Merci de réessayer ultérieurement.". Everything else (e.g. "Delete broker note" dialog, "Broker note sent", attachment size errors, empty-list texts, "Flash not found") is own translation. Flash type and recommendation values are data and stay as they are. Rows in `docs/i18n-review.md`.
- Acceptance: MTP-LANG-006 passes; existing FLS and BRN tests pass.
- Commit: 48cbc0f

## LANG-T05: Version and monitoring in French, and the untranslated-text guard
- Kind: slice
- Blocking: yes
- Status: done
- Blocked by: LANG-T04
- Satisfies: MTP-LANG-007
- Test approach: seam B for both screens in French; the guard tests in `src/i18n/i18n.test.ts` (below), written RED first against a deliberately left literal, then GREEN once all screens are done; Playwright for 007.
- Model: sonnet
- What to build:
  - Move every literal in `src/screens/Version/*` and `src/screens/Monitoring/*` (including `labels.ts`) into keys. French: "Version actuelle", "Saisissez la nouvelle version :", "Le format doit être X.X.X", "Forcer l'utilisateur à mettre à jour l'application", "Version ajoutée avec succès" (all new: myCMS showed English there); monitoring (myCMS): "Monitoring des déconnexions", "Période d'analyse :", "7 jours", "30 jours", "90 jours", "Actualiser", "Vue d'ensemble", "Analyses", "Tous les logs de déconnexion", "Répartition par cause de déconnexion", "Répartition par plateforme", columns "Date", "Utilisateur", "Plateforme", "Raison", "Adresse IP", "Navigateur/Système", "Détails", "Aucun log de déconnexion trouvé.", "Chargement des logs...", "{{total}} logs au total • Page {{page}} sur {{pages}}"; reasons TOKEN_EXPIRED "Session expirée", TOKEN_INVALID_SIGNATURE "Authentification compromise", TOKEN_REVOKED "Accès révoqué", USER_NOT_FOUND "Compte utilisateur supprimé", SESSION_CORRUPTED "Session corrompue", TOKEN_REPLACED_BY_NEW_LOGIN "Nouvelle connexion détectée"; platforms "Application bureau", "Application mobile". Own translations: the other five reasons, filter labels, buttons, the "{count} ({percentage}%)" format kept as is.
  - Guard `src/i18n/i18n.test.ts`: (a) `en.json` and `fr.json` have identical nested key sets and no empty string values; (b) read every `src/**/*.tsx` except `*.test.tsx`, `src/mocks/**`, `src/test/**`, and fail listing file and text for any JSX text node containing a letter, found with the regex `/>\s*([^<>{}\n]*[A-Za-zÀ-ÿ][^<>{}\n]*)</g` after removing `{/* ... */}` comments, allowing only "Engage Admin", "EN", "FR", "CUSTOM CONTENT 1", "CUSTOM CONTENT 2"; (c) every leaf key in `en.json` has a row in `docs/i18n-review.md`. Fix any literal it finds anywhere in the app.
  - Complete `docs/i18n-review.md` for all keys.
- Acceptance: MTP-LANG-007 passes; the guard passes; all existing tests pass.
- Commit: e0550a5

## LANG-T06: English gateway error text in French mode (owner decision first)
- Kind: snag (gap, found by /feature-review 2026-10-13)
- Blocking: yes
- Status: done (877de69)
- Blocked by: none
- Satisfies: decision 1 ("everything the admin reads switches")
- Finding: `src/data/gatewayClient.ts:87, 102, 123` build the error from `response.statusText` or `Request failed (${status})` when the body has no `message`, and a network failure surfaces the browser's English "Failed to fetch". Screens show `failure.message` when it is an Error, so the translated fallbacks (e.g. `companies.loadFailed`) almost never show and French mode shows English.
- Owner decision 2026-10-13: status texts and network errors are NOT server messages. When the gateway body has no `message` (status-text fallback, `Request failed (...)`, or a network failure such as "Failed to fetch"), every screen shows its own translated fallback message instead; a `message` the gateway wrote is still shown word for word. Mark such errors in the client (e.g. a `GatewayError` flag `fromServer: false`) so screens can tell them apart. Seam B test per error path (body message shown verbatim; no-message error shows the translated fallback in French).

## LANG-T07: Errors already on screen keep the old language after switching (owner decision first)
- Kind: snag (gap, found by /feature-review 2026-10-13)
- Blocking: no
- Status: done
- Blocked by: none
- Satisfies: decision 1 ("at once, without a reload")
- Finding: error and validation text is stored in state as translated strings (e.g. `ListsTab.tsx:55-77, 171-198`, `AddCompanyScreen.tsx:132, 216`, `ReportScreen.tsx:289`), so a message shown before pressing EN / FR stays in the old language until it is raised again.
- Owner decision 2026-10-13: accepted as is, no change. The next error raised shows in the new language.

## Automation status
<!-- Filled by /feature-implement: one line per automated MTP row, e.g. "MTP-LANG-001: 🤖 <spec file and test name>" -->
- MTP-LANG-001: 🤖 e2e/language.spec.ts "MTP-LANG-001: the EN | FR switch turns the page French at once, survives a reload, and switches back"
- MTP-LANG-002: 🤖 e2e/language.spec.ts "MTP-LANG-002: a French browser" and "MTP-LANG-002: an English browser"
- MTP-LANG-003: 🤖 e2e/entraMock.spec.ts "MTP-LANG-003: with French selected, the sign-in, stand-in and no-access pages are French"
- MTP-LANG-004: 🤖 e2e/language.spec.ts "MTP-LANG-004: companies, detail tabs and the wizard are French"
- MTP-LANG-005: 🤖 e2e/language.spec.ts "MTP-LANG-005: reports, the date line and the send dialog are French"
- MTP-LANG-006: 🤖 e2e/language.spec.ts "MTP-LANG-006: flashes and broker notes are French"
- MTP-LANG-007: 🤖 e2e/language.spec.ts "MTP-LANG-007: version and monitoring are French"
