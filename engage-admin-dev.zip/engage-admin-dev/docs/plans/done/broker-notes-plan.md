# Broker notes plan

- Slug: broker-notes
- MTP prefix: BRN
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

The Broker notes section of Engage Admin, replacing myCMS "Notes de broker". Front end only, against the Engage Gateway (mock data until Pradeep's endpoints exist). From the admin's point of view:

1. **List** at `/broker-notes` (sidebar entry "Broker notes", today a "Coming soon" placeholder). A table of sent notes, newest first, with a search box, a legend for the three type icons, paging, and a Delete action per row.
2. **Compose** at `/broker-notes/new`, opened by the button "Send a note". Pick a company and a broker, enter the target and recommendation, optionally a previous target and recommendation (recommendation change), optional attachments, optional "Also send by email". Creating a note is sending it. "Send" returns to the list; "Send and continue" resets the form for the next note.
3. **Delete** with a confirmation dialog. Deleting does not recall what was already delivered.

Behaviour copies myCMS (`docs/mycms-admin-spec-1.md` section 9 "Broker notes" and section 10 "Notes de broker"), in English. No detail screen (myCMS describes none).

## API research

No new libraries. Everything uses what admin foundation installed (React 19.3, MUI 9.5, React Router 8.4, msw 3.0.3, Vitest 5, Playwright 1.64). MUI icons come from `@mui/icons-material` 9.x, which admin foundation did not install: add `@mui/icons-material` at the same major as `@mui/material` (9.5.0). Multipart uploads use the browser `FormData`; msw 3 reads them with `await request.formData()` in a handler.

Gateway shapes are not documented beyond spec 1 section 9; the shapes below are this plan's contract, to confirm with Pradeep.

## Code survey

- `src/data/gatewayClient.ts`: `createGatewayClient({baseUrl, getToken, onAuthError})` with private helpers `send`, `json`, `empty`; `send` always sets `Content-Type: application/json` when a body is given, so multipart needs its own helper. `GatewayError {status, message, fieldErrors?}`. Types in `src/data/types.ts`.
- `src/mocks/fixtures.ts`: module-state `db` (`companies`, `users`) with `resetFixtures()` called before each test; companies `c1` LVMH, `c2` Danone, `c3` Kering, `c4` Accor, `c5` Diageo, `c6` Worldline (archived). `src/mocks/handlers.ts`: handlers with `*` path prefixes, helpers `notFound()`, `bad(message)`.
- `src/app/AppRoutes.tsx`: `broker-notes` route renders `<PlaceholderScreen title="Broker notes" />`; replace it.
- Screens use `ScreenTitle` (h1), `Panel` from `@/ds/components`, MUI `Alert`, `Dialog`. Playwright specs in `e2e/*.spec.ts` name each test `MTP-<ID>: ...`.
- `docs/api/engage-admin-api.yaml`: OpenAPI 3.1, `bearerAuth`, shared `components.parameters` and `components.responses.Unauthorized`.
- Overlap with the Flashes feature (planned for build before this one): both need a multipart helper and an attachment picker. This plan pins their names and signatures (decision 7) so either feature can create them and the other reuses them.

Testing seams (same as admin foundation): A, gateway client against the msw node server; B, screens with Testing Library inside theme, router, signed-in auth and msw; C, Playwright against `npm run dev` in mock mode on port 5174.

Coverage per behaviour: list, search, paging, type icons, delete, compose validation, recommendation change toggle, send, send and continue, attachments limits, server error: automated at B; list, search, delete, validation, toggle, send, send and continue, attachments: also at C. The server-error row is automated at B only (msw override returns 500; no mock trigger in the browser).

## Implementation approach / decisions

Owner decisions, 2026-10-12:

1. **Copy myCMS**, English copy only. Create is send. No edit.
2. **Delete is offered** (myCMS screen shows none, the gateway has one): Delete per row, dialog title "Delete broker note", body "Are you sure you want to delete?", bold sub-text "This action cannot be undone", buttons "Cancel" and "Yes".
3. **Attachments** optional, any file type, limits checked in the browser: an empty file is refused with "Attachment {file name} is empty.", a file over 10 MB (10 485 760 bytes) with "Attachment {file name} is larger than 10 MB.", a total over 15 MB (15 728 640 bytes) with "Attachments must total 15 MB or less." The refused file is not added.
4. **Currencies** exactly "€", "$", "£", "p", "SFr", default "€", sent as the symbol string.
5. **Mock reference data.** Recommendations (`GET /api-admin/referential/types/broker-note`), in this order: BUY, NEUTRAL, OUTPERFORM, OVERWEIGHT, HOLD, UNDERWEIGHT, SELL, EQUALWEIGHT. Brokers (`GET /api-admin/referential/broker`), in this order: Barclays, BofA, CIC Market Solutions, Citi, IDMidcaps, Oddo BHF, RBC Capital, Redburn Atlantic, Seaport Global, Zacks.
6. **Company picker** lists non-archived companies from `GET /api-admin/emitters-management/emitter`, sorted by name, shown as "{name} ({ric})".
7. **Shared pieces, pinned names.** `gatewayClient.ts` gets a private helper `form<T>(method: string, path: string, body: FormData): Promise<T>` that sets only the `Authorization` header (the browser sets the multipart boundary) and applies the same 401/403 and error handling as `send`. The attachment picker is `src/ds/components/AttachmentPicker.tsx`, exported from `src/ds/components/index.ts`: props `{files: File[], onChange: (files: File[]) => void, label: string}`, renders the section heading `label`, a button "Add an attachment" (hidden file input, `multiple`), one line per file with its name, size in KB and a "Remove" button, and the decision 3 errors in an error `Alert` under it. Whichever of Flashes or Broker notes is built first creates both; the other reuses them unchanged.
8. **`lastOfEmitter`** goes into the contract and the client (`getLastBrokerNote`) but the screens do not call it: myCMS's use of it is not known. Open item for Pradeep.

Pinned copy (translations of the myCMS strings):

- List: title "Broker notes"; search placeholder "Search broker notes"; button "Send a note"; legend line with the three icons labelled "Recommendation change" (`SwapVertIcon`), "Initiation" (`NewReleasesOutlinedIcon`), "Sector" (`CategoryOutlinedIcon`), all from `@mui/icons-material`, colour `textSecondary`; columns "Sent on", "Company", "Broker", "Type", "Target", "Recommendation", "Previous target", "Previous recommendation"; empty state "No broker notes found."; row action "Delete" (text button).
- Cells: Sent on = `createdAt` as dd/MM/yyyy HH:mm local time; Company = `emitter.name`; Type = one icon per true flag in the order recommendation change, initiation, sector, each with `aria-label` and `title` set to its legend label, empty when none; Target = "{currentObjective} {currency}"; Previous target = "{previousObjective} {currency}" and Previous recommendation = `previousRecommendation`, both empty when `recoChange` is false.
- Compose: title "Send a broker note"; fields "Company" (autocomplete, placeholder "Search companies", error "Please enter a company"), "Note title" (optional), "Broker" (autocomplete, placeholder "Search brokers", error "Please enter a broker"); heading "Note details": "Target" (text, placeholder "0.00", error "Target is required") with a currency select labelled "Currency", "Recommendation" (select, error "Type is required", copied from myCMS "Le type est requis"), checkboxes "Sector" and "Initiation"; heading "Recommendation change": a switch "Recommendation change" that reveals "Previous target" (placeholder "0.00", error "Target is required") and "Previous recommendation" (select, error "Type is required"); `AttachmentPicker` with label "Attachments"; checkbox "Also send by email"; buttons "Send" and "Send and continue". Errors show on submit. Target values are free text, required only (myCMS has no number check). Server failure: error `Alert` above the form "Unable to create a note right now. Please try again later." with the form kept.
- After "Send": navigate to `/broker-notes`. After "Send and continue": stay, reset every field to its default (currency "€", switches and checkboxes off, no files), and show a MUI `Snackbar` bottom-right "Broker note sent" for 4 seconds.

List mechanics: server-side search and paging. Query `GET /api-admin/broker-note?q={text}&page={n}&size=20` (omit `q` when empty), search sent 300 ms after the last keystroke and resets to page 0. MUI `TablePagination` with `rowsPerPage` 20, `rowsPerPageOptions={[]}`, `count = totalElements`.

Contract additions to `docs/api/engage-admin-api.yaml` (all `bearerAuth`, 401 `Unauthorized`, marked `x-confirm: Pradeep`):

- `BrokerNote` = `{id: string, emitter: {id: string, name: string, ric: string}, title: string | null, broker: string, currency: string, currentObjective: string, currentRecommendation: string, sectorNote: boolean, initiationNote: boolean, recoChange: boolean, previousObjective: string | null, previousRecommendation: string | null, sendByEmail: boolean, attachments: Attachment[], createdAt: date-time}`; `Attachment` = `{id: string, fileName: string, contentType: string, size: integer}`.
- `BrokerNoteRequest` = `{emitterId, title?, broker, currency, currentObjective, currentRecommendation, sectorNote, initiationNote, recoChange, previousObjective?, previousRecommendation?, sendByEmail}`.
- `POST /api-admin/broker-note`: `multipart/form-data`, part `note` (`application/json`, `BrokerNoteRequest`), zero or more parts `attachments` (binary) → 201 `BrokerNote` with header `Location: /api-admin/broker-note/{id}`; 400 `{message, fieldErrors?}`.
- `GET /api-admin/broker-note` query `q?`, `page` (default 0), `size` (default 20) → 200 `{content: BrokerNote[], totalElements: integer, totalPages: integer, number: integer, size: integer}`, `content` newest first.
- `GET /api-admin/broker-note/{id}` → 200 `BrokerNote`; 404.
- `GET /api-admin/broker-note/lastOfEmitter/{emitterId}` → 200 `BrokerNote`; 204 when the company has none.
- `DELETE /api-admin/broker-note/{id}` → 204; 404.
- `GET /api-admin/referential/broker` → 200 `string[]`.
- `GET /api-admin/referential/types/broker-note` → 200 `string[]`.

Mock behaviour: search is case-insensitive substring over `emitter.name`, `broker`, `title` and `currentRecommendation`; sort `createdAt` descending; page and size applied after filtering. Create reads `await request.formData()`, parses part `note`, looks up the company (400 `{message: "Unknown company"}` if missing), stores the note with `id: crypto.randomUUID()`, `createdAt: new Date().toISOString()`, attachment metadata from each `attachments` part (`id: crypto.randomUUID()`, `fileName: file.name`, `contentType: file.type || 'application/octet-stream'`, `size: file.size`). Delete of an unknown id returns 404. `resetFixtures()` also resets broker notes.

Mock fixtures (`db.brokerNotes`), all `sendByEmail: false`, no attachments unless stated:

| id | company | broker | title | currency | target | recommendation | flags | previous | createdAt |
|---|---|---|---|---|---|---|---|---|---|
| `bn1` | `c1` LVMH | Barclays | "Target price raised after Q3" | € | "720.00" | OVERWEIGHT | recoChange | "680.00", NEUTRAL | 2026-10-09T07:45:00Z |
| `bn2` | `c5` Diageo | Citi | "Initiating coverage" | p | "3100.00" | BUY | initiationNote | none | 2026-10-08T08:10:00Z |
| `bn3` | `c2` Danone | Oddo BHF | null | € | "64.00" | HOLD | sectorNote | none | 2026-10-07T09:30:00Z |
| `bn4` | `c3` Kering | BofA | "Downgrade on China demand" | € | "290.00" | UNDERWEIGHT | recoChange | "340.00", NEUTRAL | 2026-10-06T06:55:00Z |
| `bn5` | `c4` Accor | RBC Capital | "Hotels upcycle intact" | € | "48.00" | OUTPERFORM | none | none | 2026-10-05T07:00:00Z |

`bn5` has one attachment `{id: 'att-bn5', fileName: 'accor-rbc.pdf', contentType: 'application/pdf', size: 245760}`.

## Manual test plan (definition of done)

MTP-BRN-001 to MTP-BRN-009 (rows in `docs/manual-test-plan.md`; execution in `docs/mtp-results.md`). All automated: 001 to 008 by Playwright, 009 by a seam B test.

## Out of scope / open questions

Out of scope: editing a note, a note detail screen, broker list management (no myCMS screen), recommendation-type management, recall of delivered notes, push or email content (gateway side).

Open, none blocking:

- Confirm with Pradeep: every shape above, the paging envelope, and how `lastOfEmitter` is used.
- Whether myCMS checks the target is a number (spec 1 shows only "required").
