# Company tabs plan

- Slug: company-tabs
- MTP prefix: CTAB
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

The company detail page's Lists and Imports tabs, which currently show "Coming soon". Factset keeps showing "Coming soon".

1. **Lists.** Per company, named lists of related tickers ("peers"). Each list is a collapsible row showing its name and "{N} items" (or "1 item"). Expanding it shows its tickers. The admin can create a list (a title and at least one ticker, each checked against the RIC lookup), add a ticker, rename a list, delete a ticker and delete a whole list. Deletes ask for confirmation. Server messages, such as a duplicate list name, are shown verbatim.
2. **Imports.** Per company, upload one Excel file of one of four kinds. The admin picks the kind from a dropdown, picks a file, and clicks "Import a file". The result shows how many rows were imported out of how many, and every failed row with its messages, verbatim. A file the gateway rejects outright shows the gateway's message verbatim.

Behaviour recreates myCMS as described in `docs/mycms-admin-spec-1.md` sections 3, 6, 9 (Ticker lists, Per-company Excel import) and 10, and `docs/mycms-admin-spec-2.md` section 2. English copy only.

## API research

No new libraries. Uploads use the browser's `FormData` with `fetch` (no `Content-Type` header set by hand, so the browser adds the multipart boundary). msw 3 reads uploads in handlers with `await request.formData()`; the `file` entry is a `File` with a `name`. The repo already uses msw 3 (`http`, `HttpResponse`) and `CLAUDE.md` records that msw 3 names the unhandled-request option `onUnhandledFrame`.

Assumed (to confirm with Pradeep): every request and response shape below. The myCMS spec gives paths, status codes and messages but not full bodies, so the shapes are ours.

## Code survey

- `src/data/gatewayClient.ts`: `createGatewayClient` with private `send(method, path, body?)` that always JSON-encodes. Imports need a multipart variant: extend `send` to accept a `FormData` body (when the body is `FormData`, pass it through and do not set `Content-Type`). Errors already map to `GatewayError {status, message, fieldErrors}`; 401/403 call `onAuthError`.
- `src/data/types.ts`: shared request/response types. New types go here.
- `src/mocks/fixtures.ts`: module-state `db` with `resetFixtures()` (called from `src/test/setup.ts`); `pairs` holds the 20 known RICs; companies `c1` LVMH (`LVMH.PA`) to `c6` Worldline. New `db.tickerLists` seeded here and reset in `resetFixtures()`.
- `src/mocks/handlers.ts`: handlers with `*` path prefix; helpers `notFound()` and `bad(message)`.
- `src/screens/CompanyDetail/CompanyDetailScreen.tsx`: tabs array with Information, Lists, Users, Imports, Factset; route `companies/:id/:tab?`; Users renders `UsersTab`; the other non-Information tabs render a `Box` with "Coming soon". New `ListsTab.tsx` and `ImportsTab.tsx` beside `UsersTab.tsx`.
- `src/screens/CompanyDetail/UserFormDialog.tsx` and `UsersTab.tsx`: the dialog, error-alert and delete-confirmation patterns to copy.
- Tests that this feature breaks and must reconcile: `src/screens/CompanyDetail/CompanyDetailScreen.test.tsx` "shows Coming soon on the other tabs..." (loops Lists, Imports, Factset); `e2e/companies.spec.ts` "MTP-ADMF-017: Lists, Imports and Factset show Coming soon"; and row MTP-ADMF-017 in `docs/manual-test-plan.md`.

Seams: A, the gateway client against the msw node server (`src/data/gatewayClient.test.ts`). B, the tab components rendered with Testing Library in theme, router and signed-in auth, msw behind. C, Playwright against `npm run dev` in mock mode (port 5174).

Coverage decisions: every behaviour below is automated. Client calls at seam A; list display, create, add, rename, delete, validation and server-message display at seam B; each MTP row at seam C. The mock does not parse Excel, so import outcomes are driven by the file name (rule below) and are deterministic.

## Implementation approach / decisions

1. **Factset deferred** (owner, 2026-10-12): stays "Coming soon" until Pradeep shares the Factset payloads.
2. **Imports always replace** (owner, 2026-10-12): no choice offered; every upload sends `purge=true`.
3. **Contract additions** to `docs/api/engage-admin-api.yaml`, all marked `x-confirm-with: Pradeep`:
   - `GET /api-admin/tickers/by-emitter/{emitterId}?page=0&size=100` → 200 `{content: TickerList[], totalElements: number, totalPages: number, number: number, size: number}`. The client always asks for page 0, size 100.
   - `PUT /api-admin/tickers` body `{emitterId, name, tickers: string[]}` (RICs) → 201 `TickerList`; 400 `{message: "A list with name [{name}] already exists for the emitter."}`.
   - `PUT /api-admin/tickers/{listId}/ticker` body `{ric}` → 201 `Ticker`; 404.
   - `PUT /api-admin/tickers/{listId}` body `{name}` → 200 `TickerList`; 400 same duplicate message; 404.
   - `DELETE /api-admin/tickers/{id}` → 204; 404.
   - `DELETE /api-admin/tickers/ticker/{id}` → 204; 404.
   - `GET /api-admin/import/excel-types` → 200 `[{kind, label}]`, kind one of `stock`, `stock-lending`, `reco-tp`, `consensus`.
   - `POST /api-admin/emitter/{emitterId}/import/{kind}?purge=true`, multipart, one part `file` → 200 `{totalRows: number, okRows: number, rowErrors: {[row: string]: string[]}}`; 400 `{message}` with "Invalid Excel file", "Tab [Brute] not found in Excel file" or "Invalid type [{kind}]"; 404.
   - `TickerList` = `{id, emitterId, name, tickers: Ticker[]}`; `Ticker` = `{id, ric, name}`.
4. **Kind labels and mapping** (assumption, to confirm with Pradeep; recorded in the contract): "Short BlackApp (file 10)" → `stock`; "Consensus" → `consensus`; "Short Markit (file 9)" → `stock-lending`; "Reco TP" → `reco-tp`. The dropdown shows what the gateway returns, in its order.
5. **Mock fixtures.** Ticker lists: `l1` on `c1` "Luxury peers" with tickers `t1` HRMS.PA Hermes International, `t2` CDI.PA Christian Dior, `t3` PRTP.PA Kering; `l2` on `c1` "European consumer" with `t4` OREP.PA L'Oreal; `l3` on `c2` "Food peers" with `t5` NESN.S Nestle, `t6` ULVR.L Unilever. Other companies have none. New ids from `crypto.randomUUID()`. Ticker names come from `pairs`. Duplicate list names are compared case-insensitively within one company. Adding a RIC not in `pairs` returns 404 `{message: "No pair with RIC [{ric}]"}`.
6. **Mock import rule** (by uploaded file name, case-insensitive): contains `invalid` → 400 "Invalid Excel file"; contains `no-brute` → 400 "Tab [Brute] not found in Excel file"; contains `errors` → 200 `{totalRows: 150, okRows: 148, rowErrors: {"101": ["Field [Value] shouldn't be empty"], "117": ["Value [{company RIC}] was expected for field [RIC]."]}}`; anything else → 200 `{totalRows: 20, okRows: 20, rowErrors: {}}`. An unknown kind → 400 "Invalid type [{kind}]". The mock ignores `purge`.
7. **Copy, Lists tab.** Button "Create a list". Empty state "No lists yet". Each list row: name, "{N} items" (N = 1 gives "1 item", 0 gives "0 items"), and buttons "Add an item", "Rename", "Delete". Expanded list: one row per ticker, "{ric}" then "{name}", with a "Delete" button. Create dialog title "Create a list": field "Title" (error "Required"), a ticker field labelled "Ticker" with placeholder "Search for a peer" and an "Add" button that checks the RIC with the pairs lookup (404 shows "This RIC code does not exist"; a RIC already chosen shows "This ticker is already in the list"); chosen tickers show as removable chips "{ric}"; error "Add at least one ticker" when saving with none; buttons "Cancel", "Save". Add item dialog title "Add an item": same ticker field and errors, buttons "Cancel", "Save" (saves the one RIC). Rename dialog title "Rename a list": field "Title" prefilled, error "Required", buttons "Cancel", "Save". Delete list dialog title "Delete a list", body "Are you sure you want to delete {name}?" and bold "This action cannot be undone", buttons "Cancel", "Yes". Delete item dialog title "Delete an item", body "Are you sure you want to delete {ric}?" and the same bold line and buttons. Server `message` values show verbatim in an error alert at the top of the open dialog.
8. **Copy, Imports tab.** Select labelled "Type" with placeholder "Choose a type"; a file picker button "Choose a file" (accepts `.xlsx,.xls`) showing the chosen file name; button "Import a file", disabled until a type and a file are chosen and while uploading. Success: "{okRows} of {totalRows} rows imported" in a success alert when `rowErrors` is empty, otherwise a warning alert with the same line and below it a list headed "Rows with errors" with one entry per row, in ascending row order, "Row {n}: {message}" per message. Whole-file errors and other server errors: an error alert with the server message verbatim. Choosing a new file or type clears the previous result.

## Manual test plan (definition of done)

MTP-CTAB-001 to MTP-CTAB-008. Rows in `docs/manual-test-plan.md`; execution in `docs/mtp-results.md`. All automated with Playwright against mock mode.

## Out of scope / open questions

- Factset tab (deferred, owner decision 2026-10-12).
- Paging through more than 100 lists for one company.
- Confirm with Pradeep: every shape in decision 3; the kind mapping in decision 4; whether adding a ticker that is already in a list is rejected server-side (the screen blocks it client-side).
