# Admin foundation plan

- Slug: admin-foundation
- MTP prefix: ADMF
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-12

## What we're building

The first slice of Engage Admin, the web back office that replaces the myCMS admin system for the Corporate Market Services team. Front end only: every read and write goes to the Engage Gateway, which Pradeep builds. Until his admin endpoints exist the page talks to a stand-in inside the browser.

From the admin's point of view:

1. **Sign-in.** With Entra configured, a sign-in page with one button, "Sign in with Microsoft". After sign-in, someone without the Admin app role sees "You do not have access to Engage Admin." and a "Sign out" button. With no Entra configured (local development), the app opens straight away as "Local Admin" on mock data.
2. **Shell.** A left sidebar with six entries in this order: Reports, Flashes, Broker notes, Companies, Version, Monitoring. The signed-in person's name and a "Sign out" link at the bottom. The app opens on Companies. The five entries other than Companies show their title and "Coming soon".
3. **Companies.** A list with columns Company, RIC, Sector, Users, Status; a search box ("Search companies") matching name or RIC; a checkbox "Show archived companies" (off by default); a button "Add company". A three-step wizard to create a company. A detail page with tabs Information, Lists, Users, Imports, Factset and an Archive/Unarchive control; Lists, Imports and Factset show "Coming soon".
4. **Users.** Per company, in the Users tab: a table (Name, Position, Email, Phone, Terms accepted), a search box ("Search users"), "Add user", and Edit and Delete per row. Add and edit forms with the myCMS validation rules in English. Server messages shown verbatim.

The behaviour recreates myCMS exactly as the three specs describe it (`docs/mycms-admin-spec-1.md` sections 2, 9 and 10 for this feature). No redesign.

## API research

All confirmed on 2026-10-12 against npm and the vendors' documentation.

| Library | Version | Notes |
|---|---|---|
| react, react-dom | 19.3.0 | |
| typescript | 6.0.3 | Not 7: typescript-eslint 8.71 supports `>=4.8.4 <6.1.0` only |
| vite | 8.3.4 | `@vitejs/plugin-react` 6.1.2 requires vite ^8 |
| @mui/material, @emotion/react, @emotion/styled | 9.5.0, 11.x | MUI 9 peers `@mui/material-pigment-css` ^9.5.0; install it alongside |
| react-router | 8.4.0 | Requires react >=19.2.7; use the data-less `BrowserRouter` + `Routes` API |
| @azure/msal-browser | 5.25.0 | Standalone, no msal-react. `loginRedirect` then `handleRedirectPromise`; the app role is read from `account.idTokenClaims.roles` |
| msw | 3.0.3 | `setupWorker` from `msw/browser` for dev, `setupServer` from `msw/node` for Vitest, one `handlers` array shared |
| vitest | 5.0.3 | jsdom environment for component tests |
| @testing-library/react, jest-dom, user-event | current | |
| @playwright/test | 1.64.0 | Starts the dev server itself, like Engage-Web |
| eslint, typescript-eslint, prettier | 10.12, 8.71, 3.9 | Engage-Web's config copied and adjusted |

**Entra facts (confirmed, Microsoft Learn):** a token issued to a single-page app lists at most 6 groups before Entra replaces the list with an overage claim, so group membership cannot be read reliably in the browser. App roles arrive in the `roles` claim with no such limit. Hence the Admin app role decision below.

**Assumed (to confirm with Pradeep after the build):** the gateway's Entra app registration exposes an API scope and an app role named `Admin`, assigned to the same security groups that grant myCMS back-office access (`D365-RMM-MyCMSBackOffice-PRD-access` and `D365-IT-Cloud-DevOps-PRD` in production, per spec 2 section 5).

## Code survey

New repo, no code yet. Conventions come from the two sibling repos under `~/Projects/Xcode-Projects/Client`:

- **Engage-Web** (`ra-engage-web`): layout `src/ds`, `src/data`, `src/screens`, `src/app`; scripts `dev`, `build` (`tsc -b && vite build`), `typecheck`, `test`, `test:e2e`, `lint`, `format:check`, `verify`; a `.githooks` pre-commit via `prepare`; `src/test/setup.ts` and `renderWithTheme.tsx` helpers; a `LoginGate` in `src/app`. Copy the tooling config (eslint, prettier, tsconfig split, playwright config, vite config with the `@/` alias) and update for the newer majors.
- **Engage-Automation-Demo** (`engage-flow`): the design system to copy verbatim into `src/ds`: `theme/tokens.ts` (colours canvas `#EBEDF1`, panel `#FFFFFF`, rule `#D2D7DF`, textPrimary `#1C355E`, textSecondary `#706E6C`, textMuted `#949291`, chrome `#495D7E`, onChrome `#F8F9FA`, green `#34C759`, amber `#EDA100`, red `#FF383C`, strip `#F8F9FA`; font `'Source Sans 3', sans-serif`), `theme/fonts.ts` with the five Source Sans 3 OTF files, `theme/theme.ts` (MUI theme: primary chrome, radius 2, no shadows, buttons 28px high, 13px, weight 600, no uppercase), `components/Panel.tsx`. Its `data/signIn.ts` is the MSAL pattern to follow: Entra when `VITE_ENTRA_TENANT_ID`, `VITE_ENTRA_CLIENT_ID` and `VITE_API_SCOPE` are set, otherwise local.

**Testing seams and coverage decisions:**

- Seam A, the gateway client (`src/data/gatewayClient.ts`, a typed interface over `fetch` to the base address `VITE_GATEWAY_URL`). Tests run it against the msw node server with the shared handlers. Automated.
- Seam B, screens rendered with Testing Library inside the theme, router and a signed-in auth context, with msw behind the client. Automated for every list, form, dialog and validation behaviour.
- Seam C, Playwright against `npm run dev` in mock mode (no Entra settings, worker on). Automated for every MTP row from ADMF-003 to ADMF-021.
- The real Entra sign-in and the no-role screen (ADMF-001, ADMF-002) need a tenant and accounts: manual-MTP-only. The auth state machine behind them (claims with and without `Admin`) is unit tested with a fake MSAL account object. Automated at seam B.

Per behaviour: sign-in gate and role check, automated (unit) plus manual (live); mock auto sign-in, shell, sign-out, companies list, wizard, detail, archive, indices dialog, placeholders, users table, add, edit, delete: automated at seams B and C.

## Implementation approach / decisions

Decisions taken in the grill on 2026-10-12, all the owner's:

1. **Scope.** Feature 1 is scaffold, sign-in, shell, Companies (list, wizard, detail Information and archive) and Users. Later features: flashes, broker notes, reports, company Lists and Imports and Factset tabs, version, monitoring, hosting.
2. **Direct on dev.** No worktree, no PR. Ordered commits on `dev`, pushed as they land.
3. **Admin check.** Entra app role `Admin` on the gateway's app registration. The page reads `roles` from the ID token claims and shows the no-access screen when `Admin` is absent; the gateway also refuses such callers. In mock mode the role is always present. To confirm with Pradeep once built.
4. **Versions.** Latest stable throughout, except TypeScript 6.0.3 (see research).
5. **Stand-in.** Mock Service Worker, not a server process. One `src/mocks/handlers.ts` serves dev (`msw/browser`, started by `main.tsx` when `VITE_GATEWAY_URL` is unset) and tests (`msw/node` in `src/test/setup.ts`). Fixtures in `src/mocks/fixtures.ts`, held in module state so creates, edits, archives and deletes show up until reload. Fixture set: markets EPA ("Euronext Paris", EUR) and LSE ("London Stock Exchange", GBp); sectors `Luxury`, `Luxury/Fashion`, `Food`, `Food/Dairy`, `Hospitality`, `Beverages`, `Payments`, `Industrials`, `Industrials/Capital Goods`; indices `.FCHI` ("CAC 40", national), `.FTSE` ("FTSE 100", national), `.STOXX50E` ("Euro Stoxx 50", national), `.SXNP` ("Stoxx Europe 600 Industrials", sector), `.SXQP` ("Stoxx Europe 600 Personal & Household Goods", sector), `.SX3P` ("Stoxx Europe 600 Food & Beverage", sector); pairs lookup of twenty RICs including every company's own; companies LVMH (`LVMH.PA`, fr-FR), Danone (`DANO.PA`, fr-FR), Kering (`PRTP.PA`, fr-FR), Accor (`ACCP.PA`, fr-FR), Diageo (`DGE.L`, en-EN), Worldline (`WLN.PA`, fr-FR, archived); two or three users each with mixed roles, one with terms unaccepted, one with the read dates at `N/A`. Mock sign-in account: name "Local Admin", roles `["Admin"]`.
6. **Shell.** Sidebar entries and order: Reports (`/reports`), Flashes (`/flashes`), Broker notes (`/broker-notes`), Companies (`/companies`), Version (`/version`), Monitoring (`/monitoring`). Root redirects to `/companies`. Monitoring is a visible entry (myCMS commented it out; no decision was ever recorded). Placeholder screens show the entry title as a heading and the text "Coming soon".
7. **Design system.** The automation demo's `src/ds` copied as-is (tokens, fonts, theme, Panel). New components for this feature live in `src/ds/components` only when used twice; otherwise in the screen folder. Sidebar background `chrome`, text `onChrome`, selected entry `panel` background with `textPrimary` text. Content on `canvas`, tables and forms inside `Panel`.
8. **Hosting.** None in this feature. `npm run build` produces the static bundle; deployment is a later feature.
9. **Naming.** "Companies" and "company" in all copy. API field names stay as the gateway has them (`emitter`, `emitterId`, `collaborators`).
10. **Contract.** `docs/api/engage-admin-api.yaml`, OpenAPI 3.1, myCMS admin paths and payloads unchanged, `bearerAuth` security scheme, server URL `{gatewayUrl}`. Feature 1 documents exactly these fourteen operations, with request and response schemas and the error bodies below:
    - `GET /api-admin/emitters-management/emitter` → 200 array of `{id, name, ric, sectors: string[], associatedUsers: number, archived: boolean}`
    - `PUT /api-admin/emitters-management/emitter` body `{name, ric, marketCode, languageCode, sector, subSector?, national1IndiceRic?, sector1IndiceRic?, national2IndiceRic?, sector2IndiceRic?, pairs: [], collaborators: [{email, firstName, lastName, jobFunction, phone?}]}` → 201 company detail; 400 `{message: "An emitter with same RIC code already exists"}`
    - `GET /api-admin/emitters-management/emitter/{emitterId}` → 200 `{id, name, ric, archived, languageCode, market: {code, shortName, fullName, currency}, sector, subSector, national1Indice?, sector1Indice?, national2Indice?, sector2Indice? (each `{ric, name}`), collaborators: User[]}`; 404
    - `PUT /api-admin/emitters-management/emitter/{emitterId}/archive` → 204; 404
    - `PUT /api-admin/emitters-management/emitter/{emitterId}/unarchive` → 204; 404
    - `PUT /api-admin/emitters-management/emitter/indice/{emitterId}` body `{national_1_indice, sector_1_indice, national_2_indice, sector_2_indice}` (RIC strings or null) → 204; 404
    - `GET /api-admin/pairs-management/pairs/ric/{search}` → 200 `{ric, name}` or 404
    - `GET /api-admin/referential/market` → 200 array of `{code, shortName, fullName, currency}`
    - `GET /api-admin/referential/sectors` → 200 array of strings (sub-sectors as `"Parent/Child"`)
    - `GET /api-admin/referential/indices` → 200 array of `{ric, name, type}` with `type` in `national`, `sector`
    - `GET /api-admin/accounts-management/emitter/{emitterId}` → 200 User[]
    - `PUT /api-admin/accounts-management/account` body `{email, firstName, lastName, phone?, jobFunction, emitterId, roles: string[]}` → 201 with `Location`; 400 `{message: "Email {email} is already used."}` or `{message: "The creation email has not been sent. Cause :{cause}"}` or `{message, fieldErrors: [{objectName, field, code, message}]}`
    - `POST /api-admin/accounts-management/account/{accountId}` body as create without `emitterId` plus optional `newPassword`, `passwordChangeRequired` → 200 User; 400; 404
    - `DELETE /api-admin/accounts-management/account/delete/{accountId}` → 204; 400 `{message: "No account with UUID: {id}"}`
    - `GET /api-admin/accounts-management/roles` → 200 `["ROLE_EMITTER", "ROLE_EMITTER_LIMITED"]`
    - `User` = `{id, email, phone?, firstName, lastName, jobFunction, cgu?: date-time, deactivationDate?: date-time, roles: string[], passwordChangeRequired: boolean, lastFlashRead?: date-time, lastFlash?: date-time, lastDailyRead?: date-time, lastDaily?: date-time}`
    - Errors: 401 `{error: "unauthorized", message: "Authentication required"}`; 403 for a caller without the Admin role (new, gateway-side).
11. **Auth module** (`src/auth`). `AuthProvider` exposes `{status: 'loading' | 'signedOut' | 'noAccess' | 'signedIn', name, getToken, signIn, signOut}`. Entra mode when the three `VITE_ENTRA_*` settings are set: `PublicClientApplication` with `authority https://login.microsoftonline.com/{tenant}`, `redirectUri window.location.origin`, `loginRedirect({scopes: [VITE_API_SCOPE]})`, `handleRedirectPromise` on load, role check `idTokenClaims.roles includes 'Admin'`, `acquireTokenSilent` for the bearer token, `logoutRedirect` on sign-out. Mock mode otherwise: signed in at once as "Local Admin". The gateway client adds `Authorization: Bearer {token}` and maps 401 and 403 to the auth status.
12. **Copy, pinned.** Sign-in page: wordmark "Engage Admin", button "Sign in with Microsoft". No access: "You do not have access to Engage Admin.", button "Sign out". Companies list: columns Company, RIC, Sector, Users, Status (Active / Archived); search placeholder "Search companies"; checkbox "Show archived companies"; button "Add company". Wizard steps "1. Information", "2. Indices", "3. Users"; step 1 fields RIC, Name, Language (radio French / English, values `fr-FR` / `en-EN`, default French), Market, Sector, Sub-sector; errors "RIC is required", "This RIC code does not exist", "Name is required", "Market is required", "Sector is required"; step 2 fields Index 1 to Index 4, each excluding the others' choices, all optional; step 3 blocks "User {n}" with First name, Last name, Position, Email, Phone, errors "First name is required", "Last name is required", "Position is required", "Email is required", "Invalid email format", button "Add user" to add a block and "Remove" per block; navigation "Back", "Next", "Add". Detail: tabs Information, Lists, Users, Imports, Factset; header button "Archive" / "Unarchive"; banner "This company is archived"; Information labels RIC, Name, Language (French / English), Market (full name), Sector, Sub-sector; INDICES block with Index 1 to Index 4 showing "{ric} {name}" or "None", link "Edit"; dialog "Edit indices" with the four pickers, buttons "Cancel", "Save". Users tab: columns Name ("{first} {last}"), Position, Email, Phone, Terms accepted (dd/MM/yyyy or "No"); search placeholder "Search users"; button "Add user"; row actions "Edit", "Delete". User form (add and edit): First name, Last name, Position, Email, Phone, Role; errors "First name is required", "Last name is required", "Position is required", "Email is required", "Invalid email address", "Role is required"; Role options "Standard" (`ROLE_EMITTER`) and "Limited access" (`ROLE_EMITTER_LIMITED`), single select; edit form adds read-only "Last daily report read" and "Last flash read" as dd/MM/yyyy or "N/A"; buttons "Cancel", "Save". Delete dialog title "Delete user", body "Are you sure you want to delete {first name} {last name}?", buttons "No", "Yes". Server `message` values are shown verbatim in an error alert above the form; `fieldErrors` map to their fields. Placeholders: heading is the sidebar label, body "Coming soon".
13. **Validation rules, pinned.** Email: `^[^\s@]+@[^\s@]+\.[A-Za-z]{2,10}$`. Phone optional, free text. The company wizard's user blocks use the same email rule. Search is client-side, case-insensitive, substring, on name and RIC (companies) or first name, last name and email (users). Dates render as dd/MM/yyyy in the browser's local time.
14. **No password field** on the user edit form in feature 1. The update endpoint accepts `newPassword` but spec 1 could not confirm the myCMS screen shows it. Open item for Pradeep.
15. **Repo docs.** A `CLAUDE.md` in the repo root: stack, scripts, the `src` layout, "English only", "copy the DS from src/ds", "mock mode is the default", "direct commits on dev". README updated with the scripts table.

## Manual test plan (definition of done)

MTP-ADMF-001 to MTP-ADMF-024 (022 to 024 added 2026-10-12, see Increment). Rows in `docs/manual-test-plan.md`; execution in `docs/mtp-results.md`. ADMF-001 and ADMF-002 are manual (need Entra); the rest are covered by Playwright against mock mode.

## Out of scope / open questions

Out of scope: flashes, broker notes, reports, company Lists, Imports and Factset tabs, version, monitoring, hosting and deployment, French copy, the kapplet's new sign-in, any back end.

Open, none of which block the build:

- Confirm with Pradeep after the build: the `Admin` app role on the gateway's app registration, the API scope value, and whether the gateway accepts the fourteen operations as written in `docs/api/engage-admin-api.yaml`.
- Whether the myCMS user edit screen shows a password field (decision 14 omits it).
- The exact `Location` header format on user creation (the mock returns `/api-admin/accounts-management/account/{id}`).
- Confirm with Pradeep that the gateway accepts `phone: ""` on user edit (operation 13) as "clear the phone".

## Increment (2026-10-12): stand-in Microsoft sign-in

Gap: the owner has no Entra tenant, registration or accounts, so ADMF-001, 002 and the Entra half of 006 cannot be run. Decisions (owner, 2026-10-12):

1. **Fake inside the app**, not a local sign-in server. New setting `VITE_ENTRA_MOCK=1` replaces the MSAL `PublicClientApplication` with a fake object implementing the existing `MsalClient` type in `src/auth/entraAuth.ts` (`initialize`, `handleRedirectPromise`, `getActiveAccount`, `setActiveAccount`, `getAllAccounts`, `loginRedirect`, `logoutRedirect`, `acquireTokenSilent`). It takes precedence over the three real `VITE_ENTRA_*` settings. Data stays on the msw mock when `VITE_GATEWAY_URL` is unset.
2. **Real rows kept, deferred.** ADMF-001 and 002 stay for a real tenant, waiting on Pradeep, and do not block acceptance of this feature. New rows ADMF-022 to 024 cover the stand-in and are automated.

Pinned detail:
- Fake `loginRedirect` goes to `/mock-entra-sign-in` with `window.location.assign`. When the fake is on and the path is `/mock-entra-sign-in`, `App` renders the stand-in page instead of the auth gate. Page copy: heading "Stand-in Microsoft sign-in", text "Pick an account. This page stands in for Microsoft until an Entra tenant is set up.", buttons "Admin User" and "Standard User". Same theme, centred Panel on canvas.
- Accounts: Admin `{homeAccountId: 'mock-admin', localAccountId: 'mock-admin', environment: 'mock', tenantId: 'mock', username: 'admin.user@example.com', name: 'Admin User', idTokenClaims: {roles: ['Admin']}}`; Standard `{homeAccountId: 'mock-standard', localAccountId: 'mock-standard', environment: 'mock', tenantId: 'mock', username: 'standard.user@example.com', name: 'Standard User', idTokenClaims: {roles: []}}`.
- Picking an account writes its id to `sessionStorage` key `engage-admin.mock-entra.account` and sets key `engage-admin.mock-entra.redirect` to `1`, then `window.location.replace('/')`. `handleRedirectPromise` returns `{account}` and clears the redirect key when it is set, else `null`. `getActiveAccount` and `getAllAccounts` read the stored account (so reload keeps the session). `acquireTokenSilent` resolves `{accessToken: 'mock-entra-token'}`. `logoutRedirect` removes both keys and calls `browserLocation.replace('/')`.
- Script `dev:entra-mock`: `VITE_ENTRA_MOCK=1 vite --port 5175 --strictPort`. Playwright: a second `webServer` entry for it on port 5175, and a second project `entra-mock` (baseURL `http://localhost:5175`, `testMatch: 'entraMock.spec.ts'`); the existing `chromium` project ignores that file. Specs in `e2e/entraMock.spec.ts`.
- `.env.example` and README list `VITE_ENTRA_MOCK`. CLAUDE.md notes the stand-in mode.

Coverage: the fake client unit tested at seam B (account round trip through `sessionStorage`, redirect read once, sign-out clears) and through `AuthProvider` (Admin gives signedIn, Standard gives noAccess); ADMF-022 to 024 automated at seam C on port 5175.
