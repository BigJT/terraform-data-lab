# Gateway contract plan

- Slug: gateway-contract
- MTP prefix: GWC
- Isolation: direct
- Integration branch: dev
- Worktree: none (direct)
- Branch: dev (direct)
- Surveyed: 2026-10-13

## What we're building

Engage Admin adopts Pradeep's C# gateway contract, `docs/api/gateway-swagger.json` (OpenAPI 3.0.4, 62 paths, 54 schemas), exactly: paths, methods, field names, shapes and status codes. The page, its types, its client and its mock change to match; Pradeep changes nothing. Our own contract `docs/api/engage-admin-api.yaml` is deleted at the end and the swagger becomes the contract named in CLAUDE.md and README.

Nothing changes on screen except two additions the new contract makes possible:

1. **Company create warnings.** When some users in the add-company wizard could not be created, the new company page lists them.
2. **Flash recipients count.** The Flashes list's Recipients column shows a count ("1 company", "{n} companies") because the list response no longer carries names.

Every existing MTP row keeps passing.

## API research

Source: `docs/api/gateway-swagger.json`, saved by the owner 2026-10-13. Errors: 401 `{error, message}`, 403 `{message}`, 400 `{message, fieldErrors: [{objectName, field, code, message}]}`. Every create and delete returns **200**; the swagger lists no 404 responses. Full field-by-field comparison with the page today: see "Contract mapping" below (the binding list).

## Code survey

- `src/data/types.ts`: page types (`CompanySummary`, `CompanyDetail`, `User`, `ReportSummary`, `ReportDetail`, `MarketReportSummary`, `MarketReportDetail`, `Flash`, `BrokerNote`, `TickerList`, `AppVersion`, `DisconnectionStats`, `Factset` ...). All renamed fields below change here.
- `src/data/gatewayClient.ts`: one function per call (`listCompanies`, `createCompany`, `getCompany`, `updateCompanyIndices`, `lookupRic`, `listMarkets`, `listIndices`, `listCompanyUsers`, `createUser`, `updateUser`, `deleteUser`, `listTickerLists`, `createTickerList`, `addTicker`, `renameTickerList`, `getFactset`, `listReports`, `getReport`, `saveReportContent`, `attachReportChart`, `getMarketReport(language, id)`, `getMe`, `validateMarketReportContent`, `listFlashes`, broker note functions, version and monitoring functions). Helpers `json<T>`, `empty`, `form<T>`.
- `src/mocks/fixtures.ts`, `src/mocks/handlers.ts`: module-state mock; companies `c1` to `c6`, users `u1` to `u12`, reports, market reports, flashes (`f1` to `f5`, built from `emitterIds`), broker notes, ticker lists, factset, version, disconnections.
- `src/data/MeProvider.tsx` (`MeProvider`, `useMe`, retry), `src/screens/Reports/useReportLock.ts` (free when `lockedBy === null || lockedBy === me.name`), the GWA-T06 alert "Your account could not be loaded, so this report is read-only." with "Try again" on `ReportScreen` and `MarketReportScreen`.
- Routes: `reports/market/:language/:id` (GWA-T01) returns to `reports/market/:id`.
- The language-toggle feature is being built at the same time and replaces on-screen strings with translation calls (`t('...')`). Every task keeps any translation calls already present and adds new visible text through the same mechanism when `src/i18n/en.json` exists.
- **Will break:** seam A client tests (paths, bodies, field names), every screen test whose fixtures or msw overrides use old field names, e2e that assert status codes or old URLs (`/reports/market/{language}/{id}`), mock handler tests. Each task reconciles the ones in its area.

Seams: A (client against msw node server) for every changed call; B (Testing Library) for every screen that reads a renamed field; C (Playwright, mock mode) for GWC-001 and GWC-002 and all existing rows.

## Implementation approach / decisions

Owner decisions 2026-10-13: adopt the swagger exactly; mock follows the swagger exactly (mock ids such as `c1`, `u1`, `f1` may stay as they are); and the 16 gaps resolved as follows.

1. **Report and market report date** = the local date of `createdAt`. Used for the past-date read-only rule, the date line and the "Back to reports" link. Mock: `createdAt` = the report's day at 05:00 local.
2. **Company details on the report screen** come from `GET /api-admin/emitters-management/emitter/{emitterId}` (`EmitterDto`): Name `name`, RIC `ric`, Market `market.fullName`, Sector (part of `sector` before "/"), Language from `languageCode` ("French" / "English").
3. **Sub-sector**: `EmitterDto.sector` holds "Parent/Child" when there is a sub-sector. Sector shows the part before "/", Sub-sector the part after it, or "None" when there is no "/". Mock: LVMH `sector` "Luxury/Fashion", Danone "Food/Dairy", others the parent only.
4. **Company users** keep loading from `GET /api-admin/accounts-management/emitter/{emitterId}`.
5. **Flash list recipients**: "1 company" when `relatedCompanyCount` is 1, else "{n} companies".
6. **Flash and broker note create bodies** keep the current JSON (myCMS spec) in the `flash` / `note` part; to confirm.
7. **Not found** stays status 404 ("Company not found", "Report not found", "Flash not found"); to confirm.
8. **Unknown RIC** is a 404 from `GET /api-admin/pairs-management/pairs/ric/{search}`; to confirm.
9. **Version "none published"** = `version` null or "" (GET always 200); keep the existing copy "No version published yet".
10. **Report list path date** stays `dd-MM-yyyy`; to confirm.
11. **Market `validation/content`** sends `{content: <current content>}`.
12. **`IndiceDto.type`** accepted as any string; the index pickers do not use it.
13. **Lock ownership** uses `lockedByCaller`: free when `lockedBy === null || lockedByCaller`. Remove `getMe`, `MeProvider`, `useMe`, the mock `GET /api-admin/user/me` handler, the GWA-T06 alert and "Try again", and their tests.
14. **Company create failures**: after `PUT emitter`, navigate to `/companies/{emitter.id}/information` passing `failures` in router state; when non-empty the page shows a warning alert headed "Some users could not be created:" with one line per failure "{collaborator}: {message}". Mock: a collaborator whose email is already used by any user is not created and returns `{collaborator: <email>, message: "Email <email> is already used."}`; the rest are created. French (when translation files exist): "Certains utilisateurs n'ont pas pu être créés :" (new, recorded in `docs/i18n-review.md`).
15. **Monitoring extras** (`last24hDisconnections`, `topDisconnectedUsers`) are not shown; the mock fills them.
16. **Market language label** uses `languageName`. Mock: `fr-FR` "French", `en-EN` "English"; `languageId` `6f1c2a1e-0000-4000-8000-000000000001` (fr-FR) and `6f1c2a1e-0000-4000-8000-000000000002` (en-EN).

### Contract mapping (binding)

Shared: creates and deletes return 200; mocks return 200 (deletes with empty body) and tests no longer assert 201/204. `GET /api/attachment/{id}/content` unchanged.

Companies and users:
- `EmitterListItemDto {id, name, isArchived, ric, devise, sectors: [{name, createdAt, updated_at}], associatedAccountsCount}` replaces `CompanySummary {archived, associatedUsers, sectors: string[]}`. Sector column = `sectors.map(s => s.name).join(', ')`.
- `EmitterDto {id, name, ric, sector, isArchived, market: MarketDto, pairs, importedPairs, primaryIndice1..primaryIndice4: IndiceDto | null, otherIndices, languageCode, tickers}` replaces `CompanyDetail` (`archived` -> `isArchived`; `national1Indice` -> `primaryIndice1`, `sector1Indice` -> `primaryIndice2`, `national2Indice` -> `primaryIndice3`, `sector2Indice` -> `primaryIndice4`; no `subSector`; no `collaborators`).
- `IndiceDto {name, codeRIC, type, createdAt, updated_at}` (`ric` -> `codeRIC`). Index display "{codeRIC} {name}".
- `MarketDto {name, fullName, code, devise, createdAt, updated_at}` (`shortName` -> `name`, `currency` -> `devise`).
- `CreateEmitterRequest {ric, name, marketCode, sector, subSector, primaryIndiceRic1..4, otherIndicesRic: [], collaborators: CreateAccountRequest[], languageCode}`; no `pairs`. Wizard collaborators send `{email, firstName, lastName, phone?, jobFunction, roles: ["ROLE_EMITTER"]}` (no `emitterId`). `subSector` stays the full "Parent/Child" string.
- Response `CreateEmitterResultDto {emitter: EmitterDto, failures: [{collaborator, message}]}`, 200.
- `UpdateIndicesRequest {primaryIndiceRic1, primaryIndiceRic2, primaryIndiceRic3, primaryIndiceRic4}` (RIC or null) replaces `national_1_indice..sector_2_indice`; 200 empty.
- `RicQuote {ric, name, isin, currency}`.
- `AccountDto {id, email, phone, firstname, lastname, jobFunction, cgu, deactivationDate, emitter, authorities, passwordChangeRequired, lastFlashReadDate, lastFlashDate, lastDailyReadDate, lastDailyDate}` replaces `User` (`firstName` -> `firstname`, `lastName` -> `lastname`, `roles` -> `authorities`, `lastFlashRead` -> `lastFlashReadDate`, `lastFlash` -> `lastFlashDate`, `lastDailyRead` -> `lastDailyReadDate`, `lastDaily` -> `lastDailyDate`).
- `PUT /api-admin/accounts-management/account` body `CreateAccountRequest {email, firstName, lastName, phone, jobFunction, emitterId, roles}` (unchanged), returns 200 `AccountDto`, no `Location`.
- `POST /api-admin/accounts-management/account/{accountId}` body `UpdateAccountRequest {email, firstName, lastName, newPassword, phone, jobFunction, emitterId, passwordChangeRequired, roles}`: the page now also sends `emitterId` (the company id) and `passwordChangeRequired` (the user's current value).

Reports:
- `ReportSummaryDto {id, emitterId, companyName, ric, languageCode, writingStatus, validation: {writing, content, status}, sent, sentAt, lockedBy, lockedByCaller, marketReportId, createdAt, updatedAt}` replaces `ReportSummary` (`emitterName` -> `companyName`, `emitterRic` -> `ric`, `validationStatus` -> `validation.status`, `date` -> local date of `createdAt`).
- `ReportDetailDto {id, emitterId, companyName, ric, languageCode, writingStatus, validation, sent, sentAt, lockedBy, lockedByCaller, marketReportId, createdAt, updatedAt, sector, value, customContent1, customContent2, marketContent, graphPosition: AttachmentMeta | null}` replaces `ReportDetail` (`analysis` -> `value`, `sectorAnalysis` -> `sector`, `analysisValidation` -> `validation.writing`, `contentValidation` -> `validation.content`, `validationStatus` -> `validation.status`, nested `emitter` removed, `graphPosition {id, filename, type}` -> `{id, fileName, contentType, size}`).
- `PUT /api-admin/reports/{analysisId}/content` body `SaveReportContentRequest {sector, value, customContent1, customContent2}` (all four always sent).
- Writes (`writing_status`, `validation/analysis`, `validation/content`, `sent`, `lock`, `unlock`, `graph-position` POST and DELETE) return 200 `ReportDetailDto`. `validation/analysis` sets `validation.writing`.

Market reports:
- `GET /api-admin/reports/market/byId/{marketReportId}` (revert GWA-T01; client `getMarketReport(marketReportId)`; route `reports/market/:id`; links `/reports/market/{id}`).
- `MarketReportSummaryDto {id, languageId, languageCode, languageName, writingStatus, validation, sent, lockedBy, lockedByCaller, createdAt, updatedAt}`; `MarketReportDetailDto` adds `content`. No `sentAt` on market reports: sent shows "✓ Sent" without a time (keep the translation call if present).
- `PUT .../market/{id}/validation/content` body `{content}`.

Flashes:
- List `FlashSummaryDtoPagedResult {content: FlashSummaryDto[], totalElements, totalPages, number, size}`; `FlashSummaryDto {id, title, company, type, description, sendByEmail, attachmentCount, relatedCompanyCount, createdAt}`.
- Detail `FlashDetailDto {id, title, company, type, description, links, sendByEmail, attachments: AttachmentMeta[], relatedCompanies: [{id, name, ric}], createdAt}` (`value` -> `company`, `emitters` -> `relatedCompanies`; no `sendToAll`, `updatedAt`).
- Create: multipart part `flash` (JSON string, unchanged body `{title, value, description, type, links, emittersUUID, sendByEmail, sendToAll}`) and parts `attachments`; 200 `FlashDetailDto`. Delete 200.

Broker notes:
- `BrokerNoteSummaryDto {id, title, broker, company: {id, name, ric}, currency, currentObjective: number|null, currentRecommendation, previousObjective: number|null, previousRecommendation, recommendationChange, sectorNote, initiationNote, monitoringOfficer, attachmentCount, createdAt}`; `BrokerNoteDetailDto` replaces `attachmentCount` with `attachments` and adds `sendByMail`. Renames: `emitter` -> `company`, `recoChange` -> `recommendationChange`, `sendByEmail` -> `sendByMail` (detail only). Objectives display with two decimals.
- Create body unchanged in the `note` part; 200 `BrokerNoteDetailDto`. Delete 200.

Lists and imports:
- `GET /api-admin/tickers/by-emitter/{emitterId}?q=&page=&size=` returns `TickerListsPageDto {criteria, emitterId, resultPage: {content: TickerListDto[], totalElements, totalPages, number, size}}`.
- `TickerListDto {id, name, comments, tickers: [{id, ricCode, name}], createdAt, updatedAt}` (`ric` -> `ricCode`; no `emitterId`).
- `PUT /api-admin/tickers` body `{emitterId, name, comments: "", tickers: [{ric, name}]}` (name from the RIC lookup), 200 `TickerListDto`.
- `PUT /api-admin/tickers/{listId}/ticker` body `{ric, name}`, 200 `TickerListDto`.
- Rename `POST /api-admin/tickers/{listId}` body `{name, comments}` (keep the list's current comments), 200 `TickerListDto`.
- Deletes 200. Imports unchanged.

Factset: `FactsetPeerDto {id, factsetName, factsetId}`, `MultipleDto {id, key, label}`; requests unchanged; saves 200 empty. Mock ids: peers 1, 2; multiples `PE` 1, `EV_EBITDA` 2, `EV_SALES` 3, `PB` 4, `DIV_YIELD` 5, `FCF_YIELD` 6.

Version: `AppVersionDto {version, forceUpdate}` (no `createdAt`); GET always 200; publish `PublishVersionRequest {version, forceUpdate}` returns 200 `AppVersionDto`.

Monitoring: `DisconnectionStatsDto {days, from, to, totalDisconnections, last24hDisconnections, reasonBreakdown: [{reason, count}], platformBreakdown: [{platform, count}], topDisconnectedUsers: [{userEmail, disconnectionCount}]}` (`total` -> `totalDisconnections`, `byReason` -> `reasonBreakdown`, `byPlatform` -> `platformBreakdown`). Log `DisconnectionDto` unchanged.

## Manual test plan (definition of done)

MTP-GWC-001 and MTP-GWC-002 (rows in `docs/manual-test-plan.md`, execution in `docs/mtp-results.md`), automated in Playwright. All existing rows keep passing.

## Out of scope / open questions

Out of scope: the report side panel market data (its four endpoints are not in the swagger), anything Pradeep must change. Items to confirm with him are listed in `items-to-confirm-with-pradeep.md`.
