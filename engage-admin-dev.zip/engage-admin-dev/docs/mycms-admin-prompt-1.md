I need a complete behavioural specification of the **admin system** of this application:
the back-office web front end and the API behind it that the CMS team uses to run myCMS.
A separate team is rebuilding the admin system as a new web front end against a new back
end, possibly in a different language. They have **no access to this repo**. Follow-up
questions are possible but slow, so the output must be as self-contained and exhaustive
as you can make it. Write your findings to a single Markdown file,
`mycms-admin-spec-<repo name>.md`, following the structure below.

The goal is a **build specification**: a document someone could build a replacement from.
Phrase every section as "what the replacement must do", not as a tour of this code.

Ground rules:

- **No source code.** Do not quote lines of code, class names, or file paths. Describe
  logic in plain English. The replacement may not be in the same language.
- Describe every API as a swagger-style definition: method, path, authentication, request
  schema with a realistic example, success response schema with a realistic example,
  every error status and error body, and what each error means to the admin user.
- Quote **verbatim**: user-facing copy (labels, buttons, messages, emails), validation
  rules, error messages, enum values, field names, column headers, hard-coded values,
  limits and defaults.
- If something cannot be determined from this repo (it lives in another repo, a database
  job, a third-party service), say so under "Not determinable from this repo". **Never
  guess or infer behaviour you cannot see.**
- Cover every environment the repo configures (dev, UAT, prod) and note any behaviour
  that differs between them.
- Scope is **everything the admin can do**, not only the list below. For each feature,
  say whether it looks live, unused or dead (no UI reaching it, commented out, a TODO
  saying it is retired), so the rebuilding team can decide what to drop. Include admin
  jobs that live outside the admin UI: scheduled jobs, scripts, manual database fixes,
  email sends, anything the CMS team runs by hand.
- Before finishing, re-read the whole file against the checklist in section 14 and fill
  any gaps.

## 0. Context

- What is this repo: platform, language, framework, rough shape? Is the admin front end
  in this repo, a separate repo, or served by the back end? Name the other repos the
  rebuilding team would need to ask about.
- Who uses the admin system (the CMS team, internal R&Co staff, anyone else), how do
  they sign in (same login as client users, a separate admin login, a corporate single
  sign-on), and what makes a user an admin?
- Is there a staging or dry-run mode for any admin action?

## 1. Feature inventory

List every admin feature, one line each, with: name as the admin sees it, what it does,
live / unused / dead, and which section below covers it. The rebuilding team believes
the list includes at least these; confirm, correct and extend:

1. User administration: adding users one at a time with an assigned company
2. Target price and recommendation upload from the CMS team's spreadsheet
3. Stock, sector and market summary uploads for the end-of-day report
4. Composing and editing flash notes in a rich text editor
5. Send lists
6. Editing broker names
7. The connection (login) audit trail
8. The billing export
9. Unarchiving apps
10. Valuation import (`POST /api/import/valuation`)

## 2. Users and entitlements

The rebuilding team's current understanding, to confirm or correct with evidence: users
are added one at a time by the CMS team with an "assigned" company; there is one main
role plus a "limited access" role that is probably never used.

- Creating a user: every field, its validation and error copy, required versus
  optional, defaults. Is there bulk creation (CSV, paste) as well?
- How the initial credential reaches the user: generated password, emailed link, admin
  typed? Quote the email template verbatim. Does it expire, and what happens then?
- The entitlement model as rules: one company per user or many; by sector; by client
  firm; by content type. What exactly does "assigned company" control in the client app?
- Roles: every role, what each can and cannot do, and whether anyone is set up with
  each in the seed data or fixtures. What does "limited access" restrict?
- Editing a user: which fields can change after creation, and what happens to their
  existing sessions, tokens, push registrations and content on each change.
- Deactivating, suspending, deleting, archiving and unarchiving: the difference between
  each, what the user sees, whether it is reversible, what data is kept.
- Password reset by admin, unlocking a locked account, forcing a password change,
  resetting terms acceptance.
- Searching, filtering and sorting the user list; any export.
- The connection audit trail: what is recorded per login (time, platform, IP, device,
  app version), how long it is kept, how it is displayed and exported.

## 3. Target price and recommendation upload

Greg has sent the rebuilding team the spreadsheet the CMS team uses. Its title row is
"Intégration des changements de recommandations et d'objectifs de cours dans OWS -
Fichier CMS", its header row is:

`#`, `Ticker`, `Valeur`, `Secteur - Short`, `Secteur OWS`, `Broker - Short`, `Broker`,
`Reco New`, `Reco Last`, `Price New`, `Price Last`, `Devise`, `Secteur In-tact`

and it has a second lookup sheet of about a thousand rows with columns `Brokers short`,
`Brokers`, `Recommandation`, `Bloomberg Code`, `Valeur`, `Secteur OWS`, `Secteur short`,
`Bloomberg Code complet`, `Devise`, `Région`, `liste devises`. In the sample, some data
rows are shifted six columns to the left (they start at `Valeur`), tickers appear in
several formats (`7201JP`, `SHA0 GR`, `TSLA`, `DSYFP`), and prices mix `350.00` with `87`.

- Is this file uploaded to myCMS directly, or loaded into "OWS" with myCMS fed from OWS?
  What is OWS, and what is the data path from spreadsheet to the client app?
- The exact accepted file format: file types, sheet names or indexes, header row
  position, which columns are read and which are ignored, data types, number and date
  formats, currency codes, how the ticker is matched to a company (which field, exact
  or fuzzy, case, the `GBp` pence convention), how broker names are matched.
- Row handling: blank rows, duplicate rows, shifted rows as in the sample, unknown
  ticker, unknown broker, unknown recommendation value, missing price, price with the
  wrong decimal separator, trailing spaces. For each: reject the whole file, skip the
  row, warn, or accept?
- The full list of recognised recommendation values and any mapping between them (for
  example "OVERWEIGHT" to "Overweight", "- AUCUNE -" to none).
- Is there a preview or validation step before commit? What does the admin see on
  success and on each failure, verbatim?
- Re-upload rules: the same file twice, the same ticker twice in a day, a correction
  after publish. Does a new row replace, append or version the previous one?
- What the upload produces downstream: which records change, what the client app shows,
  whether a push or flash is generated, whether the end-of-day report picks it up.
- Any transformation applied (currency conversion, rounding, sector mapping from the
  lookup sheet) with the exact rule.

## 4. End-of-day report uploads: stock, sector and market summaries

- How each of the three summaries arrives: one upload or three, file or typed text,
  format (spreadsheet, Word, HTML, plain text), expected structure and headers.
- Validation, matching to companies and sectors, and what happens on each failure.
- Timing rules: cut-off times, time zone, what happens on a late or missing upload, how
  the report is generated and scheduled, whether the admin can regenerate or preview.
- Who receives the report and how (in-app, email, PDF), and how a correction after
  sending is handled.

## 5. Flash notes

The rebuilding team recalls a rich text editor screen where the admin adds text, links,
images and documents. The client app must render exactly what the new editor produces.

- The editor: which editor component, the allowed formatting (headings, bold, lists,
  tables, links, images, embedded documents, mentions of companies or tickers), and
  which are blocked.
- The stored format (HTML, Markdown, a JSON document model), its exact schema or allowed
  tag list, size limits, and how it is sanitised.
- Attachments and images: accepted types, size limits, where they are stored, how they
  are referenced in the body, how they are served to the client app and with what
  authentication.
- The full lifecycle: draft, scheduled, sent, edited after send, deleted after send,
  with what the client app shows at each state. Can a sent flash be recalled?
- Targeting: how recipients are chosen (send lists, companies, sectors, everyone),
  what happens on send to an empty list.
- Push: whether a send triggers a push, the push title and body rules, who is excluded,
  and whether the admin can send without push or push without a flash.
- Every field on the compose screen with validation and copy, verbatim.

## 6. Send lists

- What a send list is, how membership is defined (hand-picked users, derived from
  assigned company, derived from sector), and whether membership updates when a user's
  company changes.
- Create, edit, delete, and what happens to scheduled sends when a list is deleted.

## 7. Broker names and reference data

- Editing broker names: what is editable, whether a rename rewrites history or only
  future records, uniqueness rules.
- Every other reference table the admin maintains: companies, sectors, tickers,
  currencies, indices, peer groups. For each: fields, validation, where it is used.

## 8. Billing export, unarchiving and the rest

- The billing export: what it counts, the period, the output format with headers, who
  runs it and when.
- Unarchiving apps: what "app" means here, what archive does, and the reverse.
- Valuation import and any other endpoint or screen not covered above, to the same depth.

## 9. Admin API

For **every** endpoint the admin front end calls, a swagger-style definition as per the
ground rules. Group them by feature. Include authentication and authorisation rules
(which role may call which endpoint), pagination, rate limits, file upload mechanics
(multipart, size limit, timeout), and long-running job handling (polling, status
endpoints). Note any endpoint the admin front end calls that also serves the client app.

## 10. Screens

For each admin screen: purpose, who can reach it, navigation, every field with its
validation and error copy, every action with its outcome and confirmation dialog,
loading and failure states, and all user-facing copy verbatim. Include the list and
search screens, not only the forms.

## 11. Emails, notifications and scheduled jobs

Every email the admin system sends (welcome, password reset, flash, report), with the
template verbatim, the trigger, and the sender configuration. Every scheduled job, with
its schedule, time zone, what it does, and what happens when it fails.

## 12. Localisation

Which languages the admin UI and its emails support, and the full string table for the
admin system in every language present.

## 13. Foibles, workarounds and edge cases

Hunt deliberately for anything a rebuilding team would trip over: comments and TODOs
describing a workaround, special-case branches for a particular company, broker, ticker
or user, hard-coded values, date and time zone handling, duplicate and concurrency
rules, retry behaviour, environment-specific quirks, known bugs, and any manual step
the CMS team performs outside the UI. Say for each what the replacement should do.

Then two closing sections:

- **Not determinable from this repo**: everything you could not answer, and where it
  probably lives.
- **Questions the Engage team should ask next**: the gaps a second prompt should target.

## 14. Completeness checklist

End the file with this checklist, ticking each item or explaining why it could not be
answered from this repo:

- [ ] Every admin feature listed with live / unused / dead status
- [ ] User creation, entitlement model and every role documented as rules
- [ ] Initial credential delivery and every email template quoted verbatim
- [ ] Target price upload: accepted format, every row-handling rule, re-upload rules
- [ ] OWS relationship and the data path to the client app explained
- [ ] End-of-day summaries: format, timing, generation and delivery
- [ ] Flash editor stored format and allowed formatting specified exactly
- [ ] Flash lifecycle and push rules covered
- [ ] Every admin endpoint defined swagger-style with all errors
- [ ] Every screen covered with verbatim copy and validation
- [ ] Scheduled jobs and manual steps listed
- [ ] Foibles section written, with a recommendation per item
- [ ] No source code or file paths anywhere in the file
- [ ] "Not determinable from this repo" and "Questions to ask next" present
