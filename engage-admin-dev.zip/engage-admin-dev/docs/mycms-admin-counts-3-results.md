# Production counts, run by Pradeep 2026-10-09

Results of `mycms-admin-counts-3.sql` against the myCMS production database.

| Query | Result |
|---|---|
| 1. Reports in the last twelve months | 11,248 total; custom content 1 filled in 306; custom content 2 filled in 17 |
| 2. Accounts per role | ROLE_EMITTER 498; ROLE_EMITTER_LIMITED 5 |
| 3. Accounts with email starting cms1 or cms2 | 0 |
| 4. Recommendation values in the recommendation-change table | BUY 18, NEUTRAL 15, OUTPERFORM 8, OVERWEIGHT 7, HOLD 7, UNDERWEIGHT 3, SELL 3, EQUALWEIGHT 2 |
| 5. Broker names in the recommendation-change table with no match in the broker table | AlphaValue/Baader Europe, Barclays, BofA, CIC Market Solutions, Citi, IDMidcaps, Oddo BHF, RBC Capital, Redburn Atlantic, Seaport Global, Zacks |
