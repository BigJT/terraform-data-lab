-- Read-only counts against the myCMS production database (SQL Server).
-- Table and column names are guessed from the API field names in the specs;
-- correct them to the real schema before running.

-- 1. Per-company reports in the last twelve months: total, and how many have
--    a non-empty value in each custom content field.
SELECT
    COUNT(*) AS total_reports,
    SUM(CASE WHEN NULLIF(LTRIM(RTRIM(analysis_custom_content_1)), '') IS NOT NULL THEN 1 ELSE 0 END) AS custom_1_used,
    SUM(CASE WHEN NULLIF(LTRIM(RTRIM(analysis_custom_content_2)), '') IS NOT NULL THEN 1 ELSE 0 END) AS custom_2_used
FROM analysis
WHERE created_at >= DATEADD(month, -12, GETDATE());

-- 2. Accounts per role.
SELECT role, COUNT(*) AS accounts
FROM user_role
GROUP BY role;

-- 3. Accounts whose email starts with cms1 or cms2.
SELECT COUNT(*) AS cms_accounts
FROM [user]
WHERE email LIKE 'cms1%' OR email LIKE 'cms2%';

-- 4. Distinct recommendation values in the recommendation-change table, with counts.
SELECT reco_new AS recommendation, COUNT(*) AS rows_
FROM imported_broker_note
GROUP BY reco_new
ORDER BY rows_ DESC;

-- 5. Broker names in the recommendation-change table that match nothing in the broker table.
SELECT DISTINCT n.broker
FROM imported_broker_note n
LEFT JOIN broker b ON b.name = n.broker
WHERE b.name IS NULL;
