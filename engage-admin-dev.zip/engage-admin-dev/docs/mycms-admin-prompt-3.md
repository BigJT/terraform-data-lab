This is round three, a short one. Your two earlier files (`mycms-admin-spec-MyCMS-Plateform-AzureIaC.md` and `mycms-admin-spec-2.md`) have been read in full; do not repeat anything in them. Write your findings to `mycms-admin-spec-3.md`.

Same ground rules: **no source code, no class names, no file paths**; logic in plain English; copy quoted verbatim; "not determinable from this repo" rather than a guess.

## 1. The two custom content boxes on the per-company report

Round two found two extra free-text fields saved alongside the company and sector analysis, but did not check the admin front end for them. Look at the back-office report write screen specifically and state:

- Whether the screen shows editable controls bound to each of the two custom fields. If so, their labels, placeholders, position on the screen, and any rule about when they appear (always, per language, per company, behind a toggle).
- If the screen does not show them, whether anything else on the admin side writes them (another screen, the market report propagation, an import key).
- Whether the client-facing app bundle in this repo, if any, renders them, and under what heading.

Then the usual two closing sections: **Not determinable from this repo** and **Questions the Engage team should ask next**.

## 2. Completeness checklist

- [ ] Custom field controls on the report screen described, or their absence stated
- [ ] No source code or file paths
- [ ] Closing sections present
