This is round two. Your earlier specification of the myCMS admin system (the file
`mycms-admin-spec-MyCMS-Plateform-AzureIaC.md`) was excellent and has been read in full;
do not repeat anything it already covers. This round goes deeper on six areas it left
open. Write your findings to `mycms-admin-spec-2.md`, as an addendum organised by the
section numbers below.

Same ground rules as before: **no source code, no class names, no file paths**; logic in
plain English; APIs swagger-style; copy, field names, enum values, limits and defaults
quoted verbatim; say "not determinable from this repo" rather than guess; cover every
environment and note differences. Phrase everything as what the replacement must do.
Re-read against the checklist in section 6 before finishing.

Two facts learnt since round one, so you can treat them as given: the CMS team believe a
Kofax RPA robot ("kapplet") reads their spreadsheet and posts it to the generic import
endpoint, several times a day, each time with the whole sheet; and the client app shows
no history of recommendation changes, so the purge-then-insert behaviour is acceptable.

## 1. Generic import payloads, every key

For **each** of the keys the generic `POST /api/import` endpoint accepts (`agenda`,
`brokers`, `cumulated_volume`, `economic_statistics`, `indices`, `languages`, `markets`,
`most_active_brokers`, `recalculed_indices`, `sectors`, `traded_volumes`, `type_flash`,
`type_recommendation_broker`, `unissued_pairs`, `push_notifications`, `stock_lending`,
`stock`, `short_sellers`, `monitoring_block`, `reco_tp_brokers`, `consensus`,
`recommendation_change`, plus any you find that were not listed):

- The full row schema: every field name, type, required or optional, format (dates,
  numbers, currency, booleans), and a realistic example row.
- The default for the purge flag for that key, and what "purge" deletes: the whole
  table, or only rows matching something in the payload.
- How rows are matched to companies, tickers, brokers or sectors (which field, exact or
  normalised), and what happens to a row that matches nothing.
- Which client-facing endpoint or screen reads the resulting table, so the rebuilding
  team can see what each key feeds.
- Your best evidence for who loads it: the CMS team by hand or robot, a data feed, or a
  one-off seed. Say "cannot tell" where the repo gives no clue.
- Whether anything happens on import beyond the table write (a push, a cache clear, a
  recalculation).

The `push_notifications` key in particular: what does posting to it do? Does it send a
push, or only record one?

## 2. The other per-company Excel imports

Round one described only the `"Reco TP"` kind. For `stock`, `stock-lending` and
`consensus`: the required sheet name, header row handling, every column read with its
position, type and format, the RIC matching rule, every per-row and whole-file rejection
with its verbatim message, and what the resulting rows feed in the client app. State any
difference between the four kinds in how the purge flag behaves.

## 3. The report workflow in full

- Every value of the writing status, the validation states and the sent state, in order,
  with the exact transition rules: which button moves which state, which transitions are
  blocked, and whether any can go backwards.
- The complete list of content fields on the per-company report, including the two
  boxes round one could not name, with their field names in the save payload and any
  length limits. The same for the market report.
- What marking a report "sent" does, exhaustively: every table written, every flag set,
  any email, push, notification timestamp or client-visible change. If the only effect
  is a flag, say so plainly.
- Whether the write screen stays reachable after sending or after the date has passed,
  and whether the save endpoints still accept changes then (server-side enforcement
  versus front-end hiding).
- How a report is created for a company: by hand per company each day, in bulk, or on
  first open. What decides which companies appear in the day's list. What the date
  picker does for a past or future date.
- The lock in detail: what is stored, timeout if any, what "take over" does to the other
  admin's unsaved work, and whether a lock survives the admin closing the browser.
- Languages: how a report for a company whose language is English differs from French,
  and whether one company can have both.

## 4. What the client app reads

For each admin-written thing (flashes, broker notes, per-company and market reports,
the recommendation-change table, the per-company import tables, app version, archived
flag, the four notification timestamps, terms acceptance, "must change password"), name
the client-facing endpoint that reads it, swagger-style, with the response schema and
how the user's assigned company filters it. The rebuilding team must make sure the new
admin writes exactly what the client reads. Note any field the admin writes that no
client endpoint ever returns, and any field the client returns that no admin screen can
set.

Also: how a flash's unread count and a daily report's unread count are computed from the
four timestamps, and which client call advances each timestamp.

## 5. Environment-specific loose ends

- The full set of Azure AD group names or ids that grant back-office access in UAT and
  production, as far as the infrastructure configuration shows. State exactly which
  values are visible and which are supplied at deploy time from outside the repo.
- For the account-creation and password-reset emails: the template id per environment,
  the exact variable names passed to the template service, and the sender name and
  address per environment.
- The push payload for a flash, as the provider receives it: every key and value, for
  iOS and Android separately, including sound, badge, channel, colour and any data keys
  the client app uses to deep-link.
- The exact multipart part names, size limits and timeouts for every upload endpoint.
- The CSRF exemption on `/api-admin/**`: is there any other protection on those paths
  (same-site cookie, origin check), or is the session cookie alone sufficient?
- Network reachability, from the infrastructure definitions: for each environment, are
  `POST /api/import` and `GET /api/attachment/{id}/content` reachable from the public
  internet, or only from inside the corporate network or VPN? Name the control that
  decides it (access restrictions, private endpoint, API gateway, firewall) and state
  plainly if the infrastructure code shows no restriction at all.

Then two closing sections, as before: **Not determinable from this repo** and
**Questions the Engage team should ask next**.

## 6. Completeness checklist

- [ ] Every generic import key has a full row schema, purge default, matching rule and
      downstream reader
- [ ] `push_notifications` behaviour stated
- [ ] All three remaining Excel import kinds specified to the same depth as "Reco TP"
- [ ] Report state machine, content fields, "sent" effects and lock behaviour complete
- [ ] Every admin-written item mapped to the client endpoint that reads it
- [ ] Unread-count computation explained
- [ ] UAT and production admin group values stated or marked as supplied externally
- [ ] Email template ids, variables and senders per environment
- [ ] Push payload per platform
- [ ] Reachability of the two open endpoints stated per environment with the control named
- [ ] No source code or file paths anywhere in the file
- [ ] "Not determinable from this repo" and "Questions to ask next" present
