# myCMS Admin (Back-Office) — Build Specification Addendum 2

This is round two, an addendum to `mycms-admin-spec-MyCMS-Plateform-AzureIaC.md`. It does not repeat anything already covered there; it goes deeper on six areas that round one left open. Same ground rules: no source code, no class names, no file paths; logic described in plain English; APIs described swagger-style; user-facing copy, field names, enum values, limits and defaults quoted verbatim; "not determinable from this repo" used rather than guessing; every environment covered with differences noted. Everything is phrased as what the replacement must do.

**Two facts supplied for this round, taken as given:** the CMS team believe a Kofax RPA robot (a "kapplet") reads their spreadsheet and posts it to the generic import endpoint several times a day, each time with the whole sheet; and the client app shows no history of recommendation changes, so a purge-then-insert on every post is acceptable to them. Nothing in this repository can independently confirm the robot's existence or schedule — the evidence below is entirely about what the **endpoint itself** does when called, which is consistent with, but does not prove, the CMS team's belief.

---

## 1. Generic import payloads, every key

**How the dispatcher decides whether to purge.** The generic endpoint reads a JSON body with three top-level fields: `"key"` (which data type), `"data"` (an array of rows), and an optional `"purge"` field. If `"purge"` is present, its text value is parsed as a boolean and **overrides** the per-key default for that one request; if it is absent, the request falls back to a fixed default-purge setting that is baked in per key (shown in the table below). A request missing `"key"` or `"data"` fails with `"Missing JSON key [{0}]"` / French `"Clé JSON manquante [{0}]"`; an unrecognised `"key"` fails with `"Not supported data key [{0}]"` / French `"Clé de données non supportée [{0}]"`; a body that cannot be parsed into the target row shape fails with `"Provided JSON data are erroneous."` / French `"Les données JSON fournies sont erronées."`; a database failure during the write fails with `"An error occured while altering the database."` / French `"Une erreur est intervenue pendant la modification de la base de données."` The response on success is a bare 200 with no body — there is **no per-row success/failure report** on this path (unlike the per-company Excel importer), so a partially-bad payload either succeeds in full or the whole request is rejected.

**What "purge" actually deletes, in every case found:** whenever purge is honoured at all, it deletes **every row currently in that one data type's table**, with no scoping to companies, tickers, or anything else in the payload. There is no "delete only the rows that match what's in this payload" behaviour anywhere in this mechanism — it is always all-rows-for-that-type or nothing.

**General behaviour that holds for every key unless stated otherwise below:** rows are plain inserts; nothing in the generic import path cross-checks a row's ticker/RIC, broker name, sector name or market code against any other table before saving it. A row referencing a company, broker or sector that does not otherwise exist in the system is simply saved as-is — there is no rejection, no warning, and no linkage created to any other table purely by virtue of the string matching. Several keys are explicitly implemented as **append-only regardless of the purge flag actually requested** (noted per key below) — for those, asking for a purge in the request body is a silent no-op.

The 22 recognised keys, their per-row schema, their matching/purge behaviour, and (where determinable) who reads the resulting table and who most plausibly loads it:

### `brokers`
Schema: a broker is just a name (treated as the unique identifier for the row) plus system-maintained created/updated timestamps. Example: `{"name": "Example Securities"}`.
Purge default: **true** (full delete-then-insert of the whole broker list).
Matching: the name field is the row's own identity; there is no separate matching step — every post simply replaces the whole table with whatever names are in the payload.
Downstream reader: the broker-note compose screen's broker drop-down (admin side); no client-facing endpoint reading the standalone broker list was found.
Who loads it: not determinable from this repo; most plausibly a one-off/occasional reference-data refresh rather than the Kofax robot, since broker names change far less often than recommendations — but nothing in the repo distinguishes an automated caller from a manual one.
Side effects beyond the table write: none found.

### `sectors`
Schema: a sector/sub-sector name (the name string itself encodes the parent/child relationship as `"Parent/Child"`), plus timestamps. Example: `{"name": "Industrials/Capital Goods"}`.
Purge default: **true**.
Matching: name is the identity; full replace on every post.
Downstream reader: the company-creation wizard's sector/sub-sector drop-downs.
Who loads it: not determinable; a reference-data refresh.
Side effects: none found.

### `type_flash`
Schema: a flash-type name, plus timestamps. Example: `{"name": "Breaking News"}`.
Purge default: **true**.
Matching: name is the identity; full replace.
Downstream reader: the flash-compose screen's `"Type"` drop-down (both admin and, indirectly, the client app's flash display, which shows the type string).
Who loads it: not determinable; reference-data refresh, seeded initially from a bundled configuration file at first deployment.
Side effects: none found.

### `type_recommendation_broker`
Schema: a recommendation-type name, plus timestamps. Example: `{"name": "Overweight"}`.
Purge default: **true**.
Matching: name is the identity; full replace.
Downstream reader: the broker-note compose screen's recommendation drop-down.
Who loads it: not determinable; reference-data refresh, also seeded from a bundled configuration file initially.
Side effects: none found.

### `markets`
Schema: a market code (identity), short name, full name, and a currency/"devise" code, plus timestamps. Example: `{"id": "EPA", "name": "Euronext Paris", "fullname": "Euronext Paris", "devise": "EUR"}`.
Purge default: **false**, and this key is additionally implemented as **append-only even if purge is explicitly requested** — the import code explicitly declines to delete existing markets because companies hold a live reference to them, so a purge request is silently ignored for this key.
Matching: code is the identity for new rows; existing rows with the same code are not explicitly described as being overwritten by a second post with the same code (the import simply appends what it is given).
Downstream reader: the company-creation wizard's market drop-down.
Who loads it: not determinable; reference-data refresh.
Side effects: none found.

### `indices`
Schema: an index RIC code (identity), a name, and a type classification, plus timestamps. Example: `{"ric": ".FCHI", "name": "CAC 40", "type": "NATIONAL"}` (the exact set of valid type values is itself reference data and not enumerable from code alone).
Purge default: **false**, and append-only even if purge is requested, for the same reason as markets — companies hold live references to indices.
Matching: RIC is the identity.
Downstream reader: the company-creation/edit screens' four "primary index" drop-downs.
Who loads it: not determinable; reference-data refresh.
Side effects: none found.

### `languages`
Schema: a name and a value (the value being the short code, e.g. `"fr-FR"`), plus timestamps. Example: `{"name": "Français", "value": "fr-FR"}`.
Purge default: **false**.
Matching: **this is the one key confirmed to do a true merge rather than a blunt delete-or-append**: existing rows are read, keyed by name; incoming rows are keyed by name; the two maps are combined so that an incoming row overwrites an existing one with the same name, but any existing name **not** present in the incoming payload is kept rather than deleted. In other words, posting this key can only add or update languages, never remove one, regardless of the purge flag.
Downstream reader: the company-creation wizard's language choice, and indirectly every report's language-based routing (§3 of round one and §3 below).
Who loads it: not determinable; this table almost certainly changes rarely (new languages are a very infrequent event), so a one-off seed is the most plausible explanation.
Side effects: none found.

### `unissued_pairs`
Schema: a Bloomberg code, a name, a rate/"stock" value, a RIC code, daily and year-to-date performance strings, and a list name, plus timestamps. Example: `{"bbg_code_pair": "XYZ GY", "pair": "XYZ Peer", "stock": "12.34", "ric_code": "XYZ.DE", "performance_daily": "+1.2%", "performance_yearly": "+8.4%", "list_name": "Sector Peers"}`.
Purge default: **true** (full delete-then-insert of the whole table on every post).
Matching: no key-based matching; the whole table is replaced wholesale when purged.
Downstream reader: not determinable with confidence; the name "unissued pairs" and the "list_name" field suggest this feeds some form of peer/ticker list display, but no specific controller reading this exact table was confirmed. **Not determinable from this repo.**
Who loads it: not determinable.
Side effects: none found.

### `recommendation_change`
Schema: ticker, a company/value name, a sector, broker short name, broker full name, new recommendation, previous recommendation, new price, previous price, and currency — all plain strings — plus timestamps. Example (matches the CMS team's spreadsheet shape almost column-for-column):
```json
{"ticker": "ACME.PA", "value": "Acme Corp", "sector": "Industrials", "broker_short": "EXS", "broker": "Example Securities", "reco_new": "Overweight", "reco_last": "Neutral", "price_new": "45.00", "price_last": "40.00", "currency": "EUR"}
```
Purge default: **true** — full delete-then-insert of the entire table (every company, every broker) on every post. This matches the "no history is kept or shown" fact supplied for this round: a purge-then-insert design is only harmless because nothing downstream expects yesterday's rows to still be there.
Matching: **none at all** — there is no validation that the ticker corresponds to any known company, that the broker name corresponds to any row in the broker reference table, or that the sector corresponds to a known sector. A row with a completely unknown ticker, broker or sector is saved exactly as submitted; nothing rejects or flags it.
Downstream reader: a client-facing endpoint that groups this table's rows by the company/value field and serves them to the signed-in user's own company's ticker only (plain string match against the ticker field — not a foreign key), rendering the broker/recommendation/target-price comparison the CMS team's spreadsheet is meant to drive.
Who loads it: this is the key the CMS team believes the Kofax "kapplet" posts, several times a day, with the whole sheet each time — the purge-then-insert default and the complete absence of row-level matching are exactly what a "replace everything, every time" robot would need, so this is consistent with (though not independently provable from) that belief.
Side effects beyond the table write: none found — posting this key does **not** trigger a flash, a push, or any recalculation; it is a silent data refresh that the client app then reads on its own next request.

### `stock`
Schema: a free-text company/issuer name, a Bloomberg code, a RIC code, a date, and a value, plus timestamps. Example: `{"issuer": "Acme Corp", "bbg_code": "ACME FP", "ric_code": "ACME.PA", "date": "09/10/2026", "value": "1.23"}`.
Purge default: **false**, and the posting logic is append-only regardless of the flag.
Matching: **none** — unlike the per-company Excel upload of the same data (round one, and §2 below), the generic JSON path does **not** check the RIC against any specific company; any RIC string, including one for a company that does not exist, is accepted and saved as-is.
Downstream reader: a client endpoint that returns this company's own stock-data history, filtered by matching the signed-in user's company's RIC against the RIC field in this table (last roughly one year of rows).
Who loads it: not determinable with the same confidence as the recommendation table, since it has no direct relationship to the CMS spreadsheet described; could plausibly be a separate automated feed or a manual seed. **Not determinable.**
Side effects: none found.

### `stock_lending`
Schema: free-text issuer name, Bloomberg code, RIC code, a descriptive name, a date, and a value, plus timestamps. Example: `{"issuer": "Acme Corp", "bbg_code": "ACME FP", "ric_code": "ACME.PA", "name": "Lending desk", "date": "09/10/2026", "value": "0.45"}`.
Purge default: **false**; append-only in behaviour.
Matching: none — same lack of RIC validation as `stock`.
Downstream reader: a client endpoint returning the company's own stock-lending history, filtered by RIC match (last roughly one year).
Who loads it: not determinable.
Side effects: none found.

### `consensus`
Schema: emitter RIC code, ticker name, a "VA" (valuation-provider) ticker, an is-parent boolean, a line-item name/id/type, a line-item sort order, and a numeric "VA CID" classification id, plus timestamps. Example: `{"emitter_ric_code": "ACME.PA", "ticker_name": "Acme Corp", "va_ticker": "ACME-US", "is_parent": true, "line_item_name": "Revenue", "line_item_id": "REV", "line_item_order": 1, "line_item_type": "Income Statement", "va_cid": 100021}`.
Purge default: **true** (full table replace).
Matching: none — no check that the RIC corresponds to a real company.
Downstream reader: a client-facing consensus endpoint, filtered by the signed-in user's company's RIC.
Who loads it: not determinable; likely a market-data-provider feed given the "VA"/valuation-provider-shaped fields, but nothing in this repo proves that.
Side effects: none found.

### `short_sellers`
Schema: free-text issuer name, Bloomberg code, RIC code, a funds name, a percentage-position string, and a free-text comment, plus timestamps. Example: `{"issuer": "Acme Corp", "bbg_code": "ACME FP", "ric_code": "ACME.PA", "funds": "Example Fund LP", "pct_position": "1.25%", "comment": "Disclosed threshold crossing"}`.
Purge default: **true** (full table replace).
Matching: none.
Downstream reader: a client endpoint returning the company's own short-seller disclosures, filtered by RIC.
Who loads it: not determinable; shape strongly suggests an external regulatory/market-data feed rather than the CMS team's own spreadsheet.
Side effects: none found.

### `monitoring_block`
Schema: a ticker, a time string, a size string, a price string, a place/venue string, a platform full name, and a RIC code, plus timestamps. Example: `{"ticker": "ACME", "time": "14:32:10", "size": "50000", "price": "45.12", "place": "XPAR", "platform_full_name": "Euronext Paris", "ric_code": "ACME.PA"}`.
Purge default: **false**, and the service never deletes anything at all regardless of what the purge flag says — every post simply appends more rows, forever.
Matching: none.
Downstream reader: not determinable from the code examined; plausibly feeds a trade-monitoring/surveillance screen, but no confirmed controller was found reading it. **Not determinable from this repo.**
Who loads it: not determinable.
Side effects: none found.

### `reco_tp_brokers`
Schema: a ticker, a broker name, a recommendation string, a target-price string, a date string, and a RIC code, plus timestamps. Example: `{"ticker": "ACME", "broker": "Example Securities", "reco": "Overweight", "target_price": "45.00", "date": "09/10/2026", "ric_code": "ACME.PA"}`.
Purge default: **true**, but — notably — the posting logic never actually deletes anything; it always appends. This means asking for a purge on this key has **no effect**: the default being `true` is misleading, because the underlying behaviour is identical whether purge is requested or not.
Matching: none.
Downstream reader: queried internally by RIC, but no client-facing controller reading it directly was confirmed. **Not determinable from this repo** which screen, if any, surfaces it to end users.
Who loads it: not determinable.
Side effects: none found.

### `economic_statistics`
Schema: a zone, a country, a free-text "object"/description, a period string, and actual/expected/previous/released value strings, plus timestamps. Example: `{"zone": "Europe", "pays": "France", "objet": "Indice des prix à la consommation", "period": "September 2026", "actual": "1.1%", "expected": "1.0%", "previous": "0.9%", "released": "true"}`.
Purge default: **false** (full delete-then-insert **when** purge is requested; the default leaves existing rows in place and simply adds the new ones on top).
Matching: none; no de-duplication by zone/country/period.
Downstream reader: a dedicated admin "economic statistics" endpoint, read by the report-writing screens to help compose end-of-day market commentary (§4 of round one).
Who loads it: not determinable; shape strongly suggests an external economic-data feed.
Side effects: none found.

### `cumulated_volume`
Schema: free-text issuer name, Bloomberg code, RIC code, a date/hour value, a volume, a cumulated-volume figure, an average-cumulated-volume figure, and a ratio, plus timestamps.
Purge default: **true** (full table replace).
Matching: none.
Downstream reader: a client endpoint returning aggregated cumulated-volume figures grouped by ticker.
Who loads it: not determinable; likely a market-data feed.
Side effects: none found.

### `recalculed_indices`
Schema: free-text issuer name, Bloomberg code, RIC code, a recalculated-index name, a "cours"/price string, a daily-performance string, and a year-to-date-performance string, plus timestamps.
Purge default: **true**.
Matching: none.
Downstream reader: read via a dedicated service with onward mapping to a DTO; the specific screen/endpoint that finally serves it to end users was not confirmed with certainty. **Not fully determinable from this repo.**
Who loads it: not determinable; shape suggests a market-data feed.
Side effects: none found.

### `agenda`
Schema: free-text issuer/emitter name, Bloomberg code, RIC code, a pair string, a free-text "object" field, and a date (`dd/MM/yyyy`), plus timestamps.
Purge default: **false**.
Matching: none.
Downstream reader: a dedicated admin/agenda endpoint queried by RIC code and date range — most plausibly feeds a corporate-calendar/events display, though the exact client screen was not confirmed. **Partially not determinable.**
Who loads it: not determinable; shape suggests an external corporate-events feed.
Side effects: none found.

### `most_active_brokers`
Schema: a composite-keyed row — broker name, a company RIC code, a share volume, a free-text comment, and the row's own creation timestamp (all three of name, RIC and creation time together form the row's identity), plus a shared "import batch id" value that is freshly generated and stamped onto every row in the same request.
Purge default: **false**; behaviour is append-only, grouped under a fresh import-batch id each time, rather than a delete/replace — so the table accumulates one batch of rows per post, with no automatic cleanup of older batches.
Matching: none beyond the composite key described.
Downstream reader: queried internally for "most recent batch for this company" style lookups; no confirmed client-facing endpoint. **Not determinable from this repo** whether end users ever see this directly.
Who loads it: not determinable; shape suggests a recurring market-data feed given the batching behaviour.
Side effects: none found.

### `traded_volumes`
Schema: a composite-keyed row — a platform/venue name, a RIC code, and the row's own creation timestamp form the identity — plus a Bloomberg code, an issuer name, a daily volume figure, and daily/yearly repartition strings, plus a shared import-batch id per post, using snake-case JSON property names throughout (e.g. `platform`, `ric_code`, `bbg_code`, `issuer`, `daily_volume`, `daily_repartition`, `yearly_repartition`).
Purge default: **false**; same append-with-batch-id behaviour as `most_active_brokers`.
Matching: composite key as described; no cross-check against known venues/RICs.
Downstream reader: queried internally for "most recent batch for this RIC"; no confirmed client-facing endpoint found. **Not determinable.**
Who loads it: not determinable; likely a recurring market-data feed.
Side effects: none found.

### `push_notifications`
Schema: **this key is not a stored table at all** — the shape accepted is a RIC code, a push title, and a push body/content, matched transiently against a company. Example: `{"ric": "ACME.PA", "title": "Acme Corp update", "content": "Please see the latest commentary."}`.
Purge default: **false** (the concept of purging is meaningless here since nothing is persisted).
Matching: the RIC is resolved against the company reference table; **a row whose RIC does not resolve to any known company is silently dropped and nothing happens for it** — no error, no partial failure reported.
**What posting to this key does — confirmed definitively: it sends a real push notification immediately, to every user of the matched company who has a push token recorded, in the same request.** It is not merely recorded for later sending and it is not a dry-run/log-only mechanism. For every matched company, the system looks up all of that company's users, computes each user's current unread-flash-plus-unread-daily-report count (the same computation described in §4 below) to use as the push badge number, and dispatches one push per user with that title/content, through the same push-sending path used for flash sends. There is **no persisted record of this notification anywhere** — if the call fails partway through (e.g. the push provider is unreachable), there is no row left behind to retry or audit; it is pure fire-and-forget.
Downstream reader: none — nothing reads this back; it is one-way.
Who loads it: not determinable from the repo; given it unconditionally sends a real push the moment it is called, this is a sensitive capability to have reachable without any authentication (see also §5's reachability findings for whether this is network-exposed in each environment).

---

## 2. The other per-company Excel imports

All four kinds (`stock`, `stock-lending`, `reco-tp`, `consensus`) share one engine: the uploaded workbook must contain a sheet named exactly **`"Brute"`**; row 1 is always treated as a header and skipped; data starts at row 2; every kind validates its RIC/ticker column against the **one company** the upload was made for (an exact, case-sensitive string match — no normalisation of whitespace or case) and rejects a non-matching row individually rather than failing the whole file. The whole-file errors are identical for all four kinds: `"Invalid Excel file"` / French `"Le fichier Excel est invalide."` if the file cannot be read as an Excel workbook at all, and `"Tab [{0}] not found in Excel file"` / French `"L'onglet [{0}] n'a pas été trouvé dans le fichier Excel."` if the `"Brute"` sheet is missing (`{0}` is filled with `"Brute"`). The per-row errors, also identical in wording across all four kinds, are: `"Field [{0}] shouldn't be empty"` / French `"Le champ [{0}] ne doit pas être vide"` for a blank required cell; `"Invalid value [{1}] for field [{0}]"` / French `"Valeur [{1}] invalide pour le champ [{0}]"` for a cell that fails to parse as the expected date or number; and `"Value [{1}] was expected for field [{0}]."` / French `"Valeur [{1}] était attendu pour le champ [{0}]."` when the RIC/ticker column does not match the company the upload was made for. In every case `{0}` is filled with the column's header text as read from row 1 of the actual uploaded file, and `{1}` with the offending or expected value. A row that fails any check is skipped; the rest of the file still processes, and the response reports the total row count, how many succeeded, and a map of row number to error messages for every row that failed — there is no preview step; valid rows commit immediately.

**Purge behaviour is identical for all four kinds**: a query parameter on the upload (default **true**) controls whether this one company's existing rows of this one import kind are deleted before the new rows are inserted; turning it off appends instead, with no de-duplication, so re-uploading the same file twice with purge off duplicates every row. Unlike the generic JSON mechanism's full-table purge, this purge is **scoped to the one company** being uploaded for — other companies' rows of the same kind are untouched.

### `stock`
Columns read, by position, after the header row: column 1 (0-indexed "0") — company/issuer name, free text, not validated; column 2 ("1") — Bloomberg code, free text, not validated; column 3 ("2") — RIC code, **required**, must equal this company's own RIC exactly; column 4 ("3") — a date, **required**, expected in `dd/MM/yyyy` form; column 5 ("4") — a numeric value, **required**, stored after being formatted as a percentage string. Client-facing consumer: an endpoint returning this company's own stock-value history (filtered by RIC, roughly the last year of data).

### `stock-lending`
Columns read: column 1 — issuer name, free text, not validated; column 2 — Bloomberg code, free text, not validated; column 3 — RIC code, **required**, must equal this company's RIC exactly; column 4 — a descriptive name, free text, not validated; column 5 — a date, **required**, `dd/MM/yyyy`; column 6 — a numeric value, **required**, stored as a percentage string. Client-facing consumer: an endpoint returning this company's own stock-lending history (filtered by RIC, roughly the last year).

### `consensus`
Columns read: column 1 — issuer name, ignored entirely (not even read into the row); column 2 — RIC code, **required**, must equal this company's RIC exactly; column 3 — an is-parent flag, **required**, accepted either as a true boolean cell or as a 0/1 numeric fallback; column 4 — a "VA" (valuation-provider) ticker, **required**, must be non-empty; column 5 — a ticker display name, free text, not validated; column 6 — a line-item name, free text, not validated; column 7 — a line-item id, free text, not validated; column 8 — a line-item sort order, **required**, numeric; column 9 — a line-item type/category, free text, not validated; column 10 — a numeric "VA CID" classification id, **required**. Client-facing consumer: a consensus endpoint, filtered by the signed-in user's company's RIC, returning the full consensus line-item list for that company.

### `reco-tp` (covered at a lighter level in round one; restated here for completeness against the same depth)
Columns read: column 1 — RIC code, **required**, must equal this company's RIC exactly; column 2 — a free-text value, **required**, non-empty. This is deliberately the simplest of the four — just a ticker check and one value — unlike the richer three above. No client-facing endpoint reading this specific table was confirmed; it is distinct from the generic `recommendation_change` key's table described in §1.

---

## 3. The report workflow in full

**Status values, in their declared order, reused for four separate fields:** `"todo"`, `"doing"`, `"done"` — in that declaration order, though the natural lifecycle order is `"todo"` → `"doing"` → `"done"`. The same three-value set is reused for: the writing status, the per-section "analysis" validation status, the per-section "content" validation status, and a derived overall validation status.

**State transition rules, exactly as implemented (there are no guards anywhere in this workflow):**
- A brand-new report is created with writing status `"todo"` and both validation statuses `"todo"`.
- The "I've finished writing, please review" action sets writing status to `"done"` and **both** validation statuses to `"doing"` in the same action (there is no separate "start review" step).
- The "approve the analysis section" action sets the analysis-validation status to `"done"`; if the content-section validation is **already** `"done"` at that moment, the overall validation status is also set to `"done"`; otherwise the overall status is left as it was.
- The "approve the content section" action is the mirror image: sets content-validation to `"done"`; if analysis-validation is already `"done"`, the overall status also becomes `"done"`.
- **Nothing prevents calling "mark sent" before either validation section is approved.** There is no check anywhere in this workflow that the overall validation status is `"done"` before the send action is accepted — the system will happily let an admin send a report that has never been reviewed.
- **The sent flag cannot be reversed by any endpoint found** — once set, there is no "unsend"/"recall"/"revert to draft" action anywhere in this workflow.
- **No illegal-transition exception exists anywhere in this workflow** — every transition above is a plain, unconditional field assignment; none of them throw, log a warning, or refuse based on the current state.

**Full content field list, per-company ("Valeurs") report**, each capped at roughly 30,000 characters: a main company-level analysis box; a sector-level analysis box; and **two further, otherwise-unlabelled custom content boxes**, saved and retrieved alongside the first two in the same single "save content" action — nothing in the code names what these two extra boxes are "for" beyond being free-form additional text areas; their purpose in the actual admin screen (if they are even exposed in the UI at all, versus being vestigial/reserved) is **not determinable from this repo** and should be confirmed with the CMS team directly. Also present: an optional attached "graph position" image/file, attached and detached through two separate dedicated actions rather than through the main content save.

**Full content field list, market report:** a **single** content box (also roughly 30,000-character capacity) — there are no sector/custom boxes for the market report; it is one block of text per language per day.

**What "mark sent" does, exhaustively, for a per-company report:**
1. Sets the sent flag to true and stamps a "sent at" timestamp to the current server time.
2. Immediately attempts to push-notify every user of that one company who has a push token recorded. The push title is the fixed literal string **"Your daily report is available"**; the push body is the fixed literal string **"Click to open"**; there is no per-report customisation of the push text. The push badge for each recipient is their current combined unread-flash-plus-unread-daily-report count (§4). The deep-link action embedded in the push points at the path **`"daily-report"`** off the configured front-end URL.
3. Separately, bumps a "new daily report available" timestamp for every user of that company (this is the timestamp later compared against to compute each user's unread-report count — see §4).
There is **no email** sent on report-send (unlike flashes and broker notes, which have an explicit "also send by email" option) — sending a report is push-only. Marking a market report's validation/content as approved has an **additional** side effect not present on the per-company report: it propagates/re-applies that market report's content into every per-company report sharing the same language and day, so that company-level reports stay in sync with the approved market text for their language.

**Write protection after sending or after the date has passed: there is none, anywhere, enforced by the server.** The content-save action accepts and commits new text to a report regardless of whether its sent flag is already true, and regardless of whether its date is in the past. There is no guard, no exception, and no silent no-op — the save simply succeeds. Any "you can't edit a sent/past report" behaviour the admin screen appears to enforce is a **front-end-only** restriction (hiding or disabling the edit controls); a direct call to the save endpoint, by anyone with a valid admin session, can still alter a sent or back-dated report's content at any time.

**How a report is created for a company:** there is **no scheduled/batch job** that creates the day's reports in advance. Reports are created **lazily**: the very first time the admin's report-list screen is opened for a given day, the system looks at every company and, for any company that does not yet have a report row for that day, synthesises and saves a brand-new empty one on the spot (writing status `"todo"`, both validation statuses `"todo"`, sent flag false) before returning the list. There is also a separate, explicit "create an empty report for this one company" action an admin can call directly, which behaves the same way (returns the existing report for today if one already exists, otherwise creates one) and is otherwise optional/redundant with the lazy-creation behaviour.

**Which companies appear in a given day's list — a real, confirmed difference depending on how the screen is opened:**
- Opening the report screen for **today specifically, with no date chosen**, includes **every company, including archived ones** — nothing filters archived companies out of this particular code path.
- Opening the report screen for **any specific date (including today, once a date has been explicitly picked)** filters the company list down to **non-archived companies only**.
This is a genuine, confirmed inconsistency in the current system (not a guess) — the rebuilding team should decide deliberately whether to keep, unify, or deliberately diverge from this behaviour, since right now the plain "today" view and the "pick a date" view can show a different set of companies even when the date happens to be the same day.

**What the date picker does for a past or future date:** picking a past date re-runs the same lazy "find or create for that day" logic described above, scoped to that date's midnight-to-midnight window, so picking a past date for which no report ever existed will **create a brand-new empty one, backdated to that day, right now** — there is no read-only "historical view" distinct from the live editable report. Picking a future date behaves identically (the system does not reject dates in the future); nothing was found that treats "future" specially.

**The lock, in full detail.** The only thing stored is a single text field holding the name of whoever currently "has" the report open — there is **no timestamp recorded for when the lock was taken**, and therefore no possible timeout/expiry logic (none was found; there is no background job or scheduled check anywhere that clears stale locks). "Taking over" a report that shows as locked by someone else is implemented as a plain overwrite: the new admin's name simply replaces the old one in that one field, with no conflict error, no confirmation required server-side (the confirmation dialog the admin sees is a front-end courtesy, not an enforced rule), and — critically — **nothing happens to the previous holder's unsaved, in-browser edits**; if they had unsaved changes open in their own browser and then save after being "taken over", their save still succeeds and silently overwrites whatever the new holder had saved in the meantime (last write wins, with no versioning or conflict detection at all). The lock is **not released automatically** on logout, browser close, or any kind of session expiry — it persists in the database until a human explicitly clears it (via the dedicated "unlock" action) or another admin overwrites it by locking it themselves.

**Languages.** A company's content language is a fixed attribute of the company itself (not of the report) — there is no field on the report that lets one company's report exist in two languages on the same day; each company is locked to a single configured language, and its daily report always links to **the one** market report that matches that language for that same day. The market report itself is keyed purely by **language and day**, not by company at all — meaning every company sharing a language on the same day shares the exact same underlying market-report row. There is no mechanism anywhere in this workflow for a single company to receive both an English and a French report on the same day; if the CMS team needs that, it does not exist today and must be designed fresh.

---

## 4. What the client app reads

The client app authenticates with a bearer token and always scopes what it returns to the signed-in user's **one** assigned company, almost always by comparing that company's id or RIC code against a field on the data being read — described per item below.

### Flashes
**GET `/api/flash`** — returns flashes addressed to the caller's company. **Important correction to how this is often described**: despite being documented as "get all flash since 5 days", the actual window implemented is **the last 30 days**, not 5 — a genuine naming/behaviour mismatch in the current system worth deciding on deliberately rather than copying blindly. List results have their description text truncated to the first **120 characters**; the full, untruncated description is only available via the single-item fetch.
**GET `/api/flash/{id}`** — one flash, full description, full attachment list.
Side effect of calling the list endpoint: the caller's "last flash read" timestamp is bumped to the current time, regardless of how many (if any) flashes were actually returned.
Fields written by the admin but never returned to this client API: the "send also by email" flag (it only ever controls whether a duplicate email goes out at creation time; the client has no way to know after the fact whether a given flash was also emailed).

### Broker notes
**GET `/api/broker-note`** — paginated list scoped to the caller's own company (a plain one-to-one match between the note and the company, not a set-based "related companies" relationship like flashes have). Returned fields include the broker name, attachments, creation date, the sector/initiation/recommendation-change flags, currency, current objective and recommendation, and — only when the recommendation-change flag is true — the previous objective and recommendation. The admin-only "also send by email" flag is written at creation time but is **not** present in this response.

### Reports
**GET** (the per-company daily-report read endpoint) — returns, for the caller's own company, either the report matching a specific requested date, or (when no date is given) the single most recent report for that company that has its sent flag set to true, ordered by last-updated. **Only sent reports are ever returned to the client** — this is the publication gate: drafting/validating a report is entirely invisible to end users until the "mark sent" action is called. Calling this endpoint for "most recent, no date given" bumps the caller's "last daily report read" timestamp. Fields returned include the company-level and sector-level analysis text, the two custom content boxes, the linked market content, the writing status, and the attached graph image if present; the per-section validation statuses and the lock-holder field are **admin-only information, not returned to the client** at all.

### The recommendation-change table
A client endpoint groups this table's rows by the company/value field and serves the subset whose ticker matches the caller's own company's RIC (a plain string match, not a foreign key) — this is how the CMS spreadsheet data the Kofax robot is believed to post ultimately reaches the mobile/desktop app's recommendation-comparison display.

### The per-company Excel-import tables
Each of `stock`, `stock-lending`, `consensus`, and the reco-tp pair-value table has its own dedicated client read endpoint, in every case filtered by matching the caller's own company's RIC against the ticker/RIC field stored on each row (see §2 for the exact endpoint paths already listed there).

### App version
**GET `/api/app-version/{version}`** — given the caller's currently-installed version string, returns the latest published version and whether an update should be forced; this is **global**, with no per-company scoping at all — every company's users see the same published version.

### The archived flag
Archiving a company is a **stop-new-content** switch, not a hide-existing-content switch: once a company is archived, new flashes created with "send to everyone" no longer reach it, and (per §3) it drops out of the "pick a date" report list — but nothing found revokes a client user's ability to keep reading whatever flashes, broker notes and already-sent reports already exist for that company, nor does anything in the client-facing login/session logic check the archived flag to block a user from signing in at all. Whether the archived flag itself is ever directly exposed in a client response (e.g. so the app could show "this company is now archived" to the user) could not be confirmed either way — **not determinable from this repo**.

### The four notification timestamps
Two are "last created" timestamps, bumped by **admin actions**: one is bumped for every user of every targeted company the moment a flash is created, and the other is bumped for every user of a company the moment its report is marked sent. The other two are "last read" timestamps, bumped by **the user's own client calls**: one by calling the flash-list endpoint, the other by calling the report-read endpoint (either the "give me the most recent sent report" form, or — confirmed separately — a related "get today's report" lookup also bumps it). All four are returned on the client's own "who am I" self-info call.

**Unread-count computation, exact logic:** a flash is "unread" if its creation time is after the user's last-flash-read timestamp (treating a user who has never read anything as having a last-read timestamp at the start of computer time, i.e. everything ever created counts as unread); the same comparison, against the last-daily-read timestamp, counts unread **sent** reports. The combined total (unread flashes **plus** unread reports) is used **only** as the numeric badge value attached to outgoing push notifications — there is **no client-facing endpoint that returns this count directly**; a client app wanting to show an unread badge without waiting for a push would have to compute it itself from the four timestamps plus its own list of flashes/reports, or simply mirror whatever number arrived in the last push payload.

### Terms-of-service (CGU) acceptance
A dedicated client action sets the acceptance date to the current time; the "who am I" self-info call returns that date (or its absence). There is **no admin-side way to set or clear this field** — it is entirely self-service from the client, which also means there is no admin "re-request terms acceptance" capability (consistent with round one's finding that no reset/un-accept action exists anywhere).

### "Must change password"
Set to true by the admin at account creation (and, implicitly, available to be set again through the general account-update action — see round one). Returned on the "who am I" self-info call. Cleared only by the user successfully completing the client's own "change my password" action — nothing else clears it, and (as already noted in round one) nothing server-side actually blocks the user from using the app while the flag is still true; it is purely informational for the client's own UI to act on.

**Fields the client reads that the admin screens can never set directly:** every one of the four notification timestamps is maintained entirely by system actions (admin-triggered or client-triggered events), never by a direct admin "set this user's timestamps" control; the terms-acceptance date, as above, is client-only. **Fields the admin writes that no client endpoint ever returns:** the "send also by email" flags on both flashes and broker notes, and every per-section validation status plus the lock-holder field on reports.

---

## 5. Environment-specific loose ends

Three Terraform-defined environments exist in this repository: one named for production, one named for sandbox, and one — confusingly — simply named **"dev"**, whose own access-control configuration literally grants entry to a security group named for UAT (see below). **There is no Terraform folder or configuration literally named "uat" anywhere in this repository.** The rebuilding team should treat this as a strong signal that what the CMS team calls "UAT" is hosted using this "dev"-named configuration, and should confirm that directly rather than assuming a separate UAT environment exists.

### Azure AD back-office access groups

| Environment | Exact allow-list value found | Notes |
|---|---|---|
| "dev" (believed to double as UAT) | `D365-RMM-MyCMSBackOffice-UAT-access,6eb518d5-421e-4edc-b8b8-9f440f347c13,D365-IT-Cloud-DevOps-PRD,8677070c-ce9d-49cb-8d29-9ecb45776959` | The first entry's own name literally contains "UAT" |
| Production | `D365-RMM-MyCMSBackOffice-PRD-access,86b71d0c-00e5-4f6e-86bf-2e7c2449ffe7,D365-IT-Cloud-DevOps-PRD,8677070c-ce9d-49cb-8d29-9ecb45776959` | |
| Sandbox | `Panoptes_MONITORING_OFFICER` (single value, under a differently-named configuration key than the other two environments) | Narrower/older-looking configuration, possibly left over from before the other two environments were introduced |
| Local/containerised development | `Panoptes_MONITORING_OFFICER,Panoptes_MONITORING_OFFICER_ADMIN,cb656e47-1334-47bb-81fc-ff5ddd90714d,586d6d6d-7fa3-492e-9947-db2344dee8f0` (and a near-duplicate value for a container-specific profile, with the same two group names but neither GUID) | Matches what round one already reported for "development" |

All of these values are plain strings committed directly in the infrastructure configuration — **none of them are secret references** (unlike the push credentials below); they are genuinely the full, real values, not placeholders resolved elsewhere, as far as this repository shows.

### Account-creation and password-reset emails, per environment

| Environment | Account-creation template id | Password-reset template id | Sender email | Sender name |
|---|---|---|---|---|
| "dev"/believed-UAT | `1659303` | `1659301` | `rothschildandcocms@rothschildandco.com` | `"Corporate Market Services"` (from the application's own configuration, not the infrastructure definition) |
| Production | `1659303` | `1659301` | `rothschildandcocms@rothschildandco.com` | `"Corporate Market Services"` |
| Sandbox | `1659303` | `1659301` | `no-reply@rmm-cms.rothschildandco.com` (**different from the other two environments**) | not found in the infrastructure definition for this environment |
| Local/containerised development | `1380921` (account creation) / `1382679` (password reset) — **both different from every cloud environment** | — | `rothschildandcocms@rothschildandco.com` | `"Corporate Market Services"` |

The variables passed into the template service for account creation are the recipient's name, their newly generated plain-text password, and the configured front-end website address; for password reset, the recipient's name and a reset link built from the front-end address plus a reset-password path plus the one-time key (all matching round one's findings, confirmed again here per environment). The actual visual HTML of either template lives only inside the third-party email-template service and remains **not determinable from this repo**.

### Push payload, exact shape, per platform

Confirmed directly from the push-sending logic (same shape for both a flash push and a daily-report push; only the title/body/summary/deep-link-target strings differ, shown per-case below):

**iOS payload fields:** a "thread id" set to the fixed literal **`"PANOPTES_DIFFUSION_CHANNEL"`** (used by iOS to group notifications); an alert title; an alert body; a "summary argument" set to the fixed literal **`"RMM"`** with a summary-argument-count of 1; a sound block naming the sound file **`"strike-call"`**, marked critical, at volume **0.5**; and a badge set to the numeric value of the recipient's combined unread count (§4).

**Android payload fields:** a title; an alert/body; a summary string; a fixed icon resource name **`"ic_notification"`**; a fixed icon colour **`"#022D5F"`**; and a notification channel set to the same fixed literal **`"PANOPTES_DIFFUSION_CHANNEL"`** used as the iOS thread id.

**Deep-link data:** every push carries an "open" action pointing at a short path string, resolved against the configured front-end URL for the web fallback. For a **flash** push: title = `"{company name} - {flash type}"`; summary = the fixed literal **`"Nouveau flash disponible"`**; body = the flash's own title text; deep-link path = **`"flashs"`**. For a **daily report** push: title = the fixed literal **`"Your daily report is available"`** (English, with no French equivalent found anywhere for this specific string); summary = an **empty string** (Android shows no summary line at all for report pushes); body = the fixed literal **`"Click to open"`**; deep-link path = **`"daily-report"`**. Every token on a company is sent both an iOS-style and an Android-style payload in the same request (the system does not track which platform a given token belongs to — it addresses the token as both an iOS channel and an Android channel simultaneously, and whichever one the token actually belongs to is the one that fires).

**Push provider credentials, per environment:** every environment examined (the "dev"/believed-UAT environment, production, and sandbox) configures a distinct Urban Airship application key and a distinct application master secret, both stored as **plain-text literal values directly inside the committed infrastructure configuration** — not as a Key Vault reference, not as a pipeline secret variable. **This is a real secrets-in-source-control exposure** (the literal secret values are not reproduced in this document for that reason) and should be flagged to the CMS/platform team as something to rotate and move to a proper secret store, independent of anything else in this rebuild.

### Multipart part names, size limits and timeouts

Confirmed, and identical across every environment (these are Spring Boot application-level settings, not per-environment infrastructure settings): maximum **10 MB per uploaded file part**, maximum **15 MB for the whole multipart request**; a general asynchronous request timeout of **15 seconds**; and a server-side session idle timeout of **12 hours**. Exact multipart part names, confirmed directly in the relevant upload actions: flash creation uses a part named **`"flash"`** (the JSON body, as a string) plus an optional part named **`"attachments"`** (one or more files); broker-note creation uses a part named **`"note"`** (JSON string) plus the same optional **`"attachments"`** part; the per-company Excel import uses a single part named **`"file"`**.

### CSRF exemption and what protects `/api-admin/**` instead

CSRF token checking is explicitly turned off for every path under `/api-admin/**`, confirmed directly in the security configuration. What is left protecting those paths is: (a) the session cookie itself, which is marked HttpOnly (not readable from JavaScript) but whose "SameSite" attribute is **not explicitly configured anywhere found** — meaning it falls back to the web framework's own default behaviour rather than an explicit, deliberate choice; and (b) the CORS allow-list (see round one and below), which restricts which **browser-origin** pages are allowed to make credentialed cross-origin calls at all, though CORS is not a substitute for CSRF against non-browser callers. In short: for `/api-admin/**`, the session cookie plus the CORS origin allow-list are the only protections against a forged cross-site request — there is no additional origin-header check, no double-submit token, and no other CSRF-equivalent mechanism specifically layered onto the admin path group.

CORS allow-lists differ by environment (confirming and extending round one): the "dev"/believed-UAT environment allows a short list of local development origins; production allows a longer, explicit list of roughly a dozen named HTTPS origins (the back-office domain, the main client-facing domain, at least one UAT-named domain, and the mobile app's custom URL scheme) plus credentialed requests. Nothing path-specific singles out `/api-admin/**` for different CORS treatment than any other path.

### Network reachability of the two open endpoints, per environment

This materially changes how severe the unauthenticated generic-import and attachment-content endpoints described in round one really are, **and the answer is different in every environment**:

| Environment | Public internet access to the web app at all | Controls found |
|---|---|---|
| "dev"/believed-UAT | **Disabled.** The web app is explicitly configured with public network access turned off, a default-deny IP restriction policy, virtual-network integration into a private subnet, and a private endpoint. | VNet integration + private endpoint + default-deny access restriction, all explicit in the infrastructure definition |
| Production | **Disabled**, with the identical combination of controls as the "dev" environment described above. | Same combination: no public access, default-deny, VNet integration, private endpoint |
| Sandbox | **Not restricted.** The equivalent public-access and default-deny settings exist in the configuration file but are **commented out**, meaning the web app falls back to the platform default of open public access with no IP restriction at all. No virtual-network integration or private endpoint is configured for this environment. | None — this environment is openly reachable from the internet as far as the infrastructure code shows |

No API gateway, Web Application Firewall, or CDN/edge-routing resource of any kind was found anywhere in the infrastructure definitions for any environment, and nothing anywhere singles out `/api/import` or `/api/attachment/{id}/content` for special treatment at the network layer — whatever network reachability a given environment has, those two paths share it exactly like every other path on the same web app.

**Net effect, stated plainly:** in the "dev"/believed-UAT and production environments, the fact that `POST /api/import` and `GET /api/attachment/{id}/content` require no application-level login is significantly mitigated by the environments themselves not being reachable from the public internet at all — only something already inside the corporate network/VNet can reach them. In the sandbox environment, however, the same two endpoints are reachable from the open internet by anyone, with no login and no network-level barrier at all. Given the Kofax robot is described as posting "several times a day", confirming **which environment it actually targets** is one of the most important open questions for this rebuild (see below) — if it targets anything resembling the sandbox configuration, or any future environment built the same way as sandbox, the exposure is real and not just theoretical.

---

## Not determinable from this repo

- Whether the Kofax "kapplet" genuinely exists, what it runs on, its real schedule, and which of the three environments it actually calls — nothing in this repository can confirm or deny any of this; everything in §1 about it is inference from what the endpoint's behaviour is consistent with, not proof.
- The two unlabelled custom content boxes on the per-company report — their intended purpose, and even whether the current admin screen exposes editable controls for them at all, could not be confirmed from the areas of the front end reviewed.
- The downstream consumer (if any) of several generic-import keys: `unissued_pairs`, `monitoring_block`, `reco_tp_brokers`, and the exact current client-facing status of `most_active_brokers`, `traded_volumes`, `recalculed_indices` and `agenda` beyond "queried internally by some key field" — no confirmed admin or client screen was found for these.
- Whether the client app itself ever reads or displays the company "archived" flag directly, as opposed to simply losing eligibility for new content as described in §4.
- The exact SameSite cookie behaviour actually in force for the admin session cookie, since no explicit value is configured — this depends on the web framework's own version-specific default, which is outside this repository's control.
- Whether there is a UAT environment genuinely distinct from the "dev" Terraform configuration described above, hosted somewhere this repository does not show (e.g. provisioned by hand, or by a pipeline using variables not present in this repo).
- The real values behind the push-notification secret credentials — deliberately not reproduced here even though they are visible in the repository, for the reasons given in §5.

## Questions the Engage team should ask next

1. Which environment does the Kofax robot actually call — the "dev"/UAT-named one, production, or something not represented in this repository at all? Given the sandbox environment is openly reachable from the internet with no login, confirming the robot never targets anything built like sandbox is important.
2. Is there, in fact, a genuinely separate UAT environment outside this repository, or does "UAT" really mean the Terraform configuration folder named "dev" here?
3. What are the two unlabelled custom content fields on the per-company daily report actually used for today, and does the current admin screen even expose them as editable boxes, or are they vestigial?
4. Given reports can be marked "sent" without either validation step having been completed, and can still be edited afterwards with no server-side objection, is that leniency intentional (a safety valve for correcting mistakes) or an oversight the rebuild should close with real enforcement?
5. Is it acceptable that opening the plain "today" report list shows archived companies while picking any explicit date (including today) hides them — or should this inconsistency be fixed one way or the other in the rebuild?
6. Should the rebuild's report-locking mechanism gain real enforcement (expiry, conflict detection, warning the previous holder) now that it is clear today's lock is purely cosmetic?
7. Who, today, is responsible for rotating the push-notification provider credentials that are currently committed in plain text in the infrastructure configuration, and can that be fixed as a quick, independent win alongside this rebuild?
8. Does the CMS team want the replacement to keep the "last write wins" behaviour on concurrent report edits, or introduce real conflict detection?
9. For the generic-import keys with no confirmed downstream reader (`unissued_pairs`, `monitoring_block`, `reco_tp_brokers`, and others noted above) — are these still in active use at all, or safe to drop from the rebuild's scope entirely?

---

## 6. Completeness checklist

- [x] Every generic import key has a full row schema, purge default, matching rule and downstream reader — §1 (two keys' downstream readers explicitly marked not determinable, as instructed, rather than guessed)
- [x] `push_notifications` behaviour stated — §1 (confirmed: sends a real push immediately; nothing persisted)
- [x] All three remaining Excel import kinds specified to the same depth as "Reco TP" — §2
- [x] Report state machine, content fields, "sent" effects and lock behaviour complete — §3
- [x] Every admin-written item mapped to the client endpoint that reads it — §4
- [x] Unread-count computation explained — §4
- [x] UAT and production admin group values stated or marked as supplied externally — §5 (and the absence of a genuine separate UAT environment flagged explicitly)
- [x] Email template ids, variables and senders per environment — §5
- [x] Push payload per platform — §5
- [x] Reachability of the two open endpoints stated per environment with the control named — §5
- [x] No source code or file paths anywhere in this file
- [x] "Not determinable from this repo" and "Questions to ask next" present — above
