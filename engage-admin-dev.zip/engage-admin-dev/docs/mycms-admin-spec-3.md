# myCMS Admin (Back-Office) — Build Specification Addendum 3

Round three, a short follow-up to `mycms-admin-spec-MyCMS-Plateform-AzureIaC.md` and `mycms-admin-spec-2.md`. It does not repeat them, except where it **corrects** a statement in round two (section 1.6). Same ground rules: no source code, no class names, no file paths; plain English; user-facing copy quoted verbatim; "not determinable from this repo" instead of guessing.

---

## 1. The two custom content boxes on the per-company report

### 1.1 Short answer

**Yes — the back-office report write screen shows two editable boxes bound to the two custom fields.** Round two flagged these as possibly vestigial; that was wrong for the screen. They are live, editable, auto-saved and sent to the client API. What remains unknown is their business purpose (see "Not determinable").

### 1.2 Where they sit and what they are called

The screen is titled **"Rédiger un rapport"**. Its left (about 70% wide) column stacks the following blocks, top to bottom, in this fixed order:

1. **"VALEUR"** — the company analysis.
2. **"SECTEUR"** — the sector analysis.
3. **"CUSTOM CONTENT 1"** — first custom box.
4. **"CUSTOM CONTENT 2"** — second custom box.
5. **"POSITION COURTES"** — the optional short-positions graph attachment.
6. **"MARCHÉ"** — the read-only market report for the company's language (language name, a "Consulter" link to the market report's own screen, then the market text).
7. A horizontal separator.

The right column shows company information and market help data, unrelated to the custom boxes.

The two custom headings are written exactly as above: **upper-case, in English, with a number** — unlike the other headings, which are French. They look like developer placeholder labels that were never given business names or translated.

### 1.3 When they appear

**Always.** There is no toggle, no per-company flag, no per-language rule and no feature switch. Every company's report screen, in French or English, today or past, sent or unsent, shows both boxes. Nothing found hides, renames or conditionally enables them.

### 1.4 How they behave (differences from "VALEUR" and "SECTEUR")

- **Placeholder:** none. "VALEUR" and "SECTEUR" display the hint **"Renseignez votre analyse ici"** when empty; the two custom boxes display no hint. No other label, helper text or character counter is attached to them.
- **A different editor.** "VALEUR" and "SECTEUR" use a French-language editor whose toolbar offers only **bold** and **italic**. The two custom boxes use a **different rich-text editor product** with a fuller toolbar (formatting, lists, links, tables, images and so on). Its toolbar deliberately removes these buttons: brush, file, fullsize, copyformat, eraser, the overflow ("dots") menu and the separator. Further behaviour of the custom editor:
  - it asks for confirmation before pasting HTML and before pasting Word content;
  - images are embedded **inline as encoded data inside the text** (no upload to a file store);
  - an extra toolbar button, internally named "insertDate" but in fact a **paste-from-clipboard** button: it reads the clipboard as plain text and inserts it, converting line breaks to line-break tags.
- **When a keystroke counts as a change.** "VALEUR" and "SECTEUR" report each change immediately. The custom boxes report their text **only when the editor loses focus** (blur). Consequently the 3-second auto-save below fires only after the author clicks out of a custom box.
- **Read-only rendering.** When the report is locked (see 1.5) each box shows its stored HTML as-is. It is not sanitised before display, in the same way as the other boxes. The replacement should treat this as a stored-markup risk.
- **Storage.** Each box maps to a text column. The data model describes a limit of roughly 30,000 characters. The database migration that created the two columns declares them as **unbounded text**, so the 30,000 figure cited in round two is not enforced by the database. Inline images (see above) can inflate the text well beyond what authors perceive as "length". Server-side behaviour when text exceeds the intended limit is **not determinable**; no validation was found.

### 1.5 Save, lock and send behaviour as the screen actually implements it

This adds screen-level detail to round two's section 3:

- **Auto-save:** 3 seconds after the last change in any of the four text boxes, if the report is **not sent**, the screen saves all four texts in one call. Empty boxes do not by themselves trigger an auto-save (the change test requires the box to be non-empty), so blanking a box does not auto-save, but the blank is written the next time any save fires.
- **Save-everything:** every save sends **all four texts at once**. The server overwrites all four with whatever it receives. If a caller omits the two custom fields, **both are cleared to empty**. The replacement's save call must either always send all four fields or be rebuilt as per-field updates.
- **Fully-locked (read-only) state.** The screen goes read-only when the report is **sent** or when its last-updated date is **not today**. When read-only, all four boxes and the short-positions control are disabled.
- **Unlocking a sent report.** A sent report shows **"Envoyé à"** followed by the send time (HH:mm) and a **"Modifier"** button which re-enables all editors. The bottom button then reads **"Sauvegarde"** instead of "Envoyer"; it saves the four texts again, confirmed through the same modal as sending. It does **not** re-send the push or flag the report as sent a second time. Auto-save stays off for sent reports; saves are explicit only.
- **Past-date reports that were never sent** are read-only with **no** "Modifier" button. The screen offers no route to edit them. The server still accepts a direct save (round two), so the restriction exists only in this screen.
- **Send confirmation modal**, titled **"Envoyer le rapport"**. If the writing status is not "done" it first says: **"Le contenu et la rédaction du rapport n’ont pas étés validés."** and then **"Êtes-vous certain de vouloir envoyer le rapport à {company name} ?"** (the typo "étés" is in the original). Otherwise only the second line is shown. Buttons: **"Annuler"** and **"Oui"**. Note that the soft warning keys on the writing status alone, not on the two validation statuses.
- **Lock modal**, titled **"CONTENU EN COURS DE RÉDACTION"**: **"Le rapport est en cours de rédaction par {name}"**, then **"Désirez-vous dévérouiller l’accès à ce rapport ?"** (typo "dévérouiller" in the original), with **"Annuler"** (keep the report locked and read-only for this author) and **"Oui"** (take over). Other action-bar labels: **"Demander la validation"**, **"Valider le contenu"** / **"Contenu validé"**, **"Valider la rédaction"** / **"Rédaction validée"**, **"Envoyer"**, **"Sauvegarde"**, **"Modifier"**.
- **Lock timing on this screen** (refines round two): opening an unlocked, unsent report **automatically takes the lock** for the signed-in user. Leaving the screen, and closing the tab, makes a **best-effort attempt to release** it (only for unsent reports the author has not left read-only). If the browser dies, the network drops or the tab is killed, the release is lost and the lock persists as round two described. The lock is therefore not "never released on browser close" as round two wrote; it is "released on a clean exit, stranded on an unclean one".

### 1.6 Corrections to round two arising from this check

1. **What the client receives.** Round two said the per-section validation statuses and the lock-holder were "admin-only … not returned to the client at all". **That was wrong.** The client's "analysis of the day" call returns the **same full report shape as the admin screen**: company text, sector text, both custom texts, the linked market text, the writing status, the three validation statuses, the sent flag and sent time, the lock-holder's name, the last-updated time, the company and language and market identifiers, and the graph attachment's metadata. So both custom texts **are** delivered to the client, and the lock-holder's name (an admin's sign-in name, which looks like an email address) is exposed to every client user whose company has a sent report. The replacement should decide deliberately whether to keep this. A second client call, which fetches one report by id, returns only the id, one content text and the type; **it does not carry the custom texts** (nor the sector text, as far as the shape shows).
2. **What market approval does.** Round two said approving a market report "propagates/re-applies that market report's content into every per-company report". More precisely: approving a market report only **re-saves the link** between that market report and the same-day company reports already linked to it. **No text is copied** and **neither custom field is touched**. Company reports read the market text through that link when displayed, so edits to market text appear live. The only changes that matter for the replacement are: the link is set at the time a company's report is opened/locked/fetched for the day, and any company report created before the market report existed that day is linked only when one of those calls next happens.

### 1.7 What else writes the two fields

**Nothing.** The two texts are written only by the single content-save action on the report (the same call that writes "VALEUR" and "SECTEUR"), and the empty-report creation path leaves them unset. Checked and ruled out:

- **No other admin screen** shows or sets them (the reports list, the market report screen and the company screens do not mention them).
- **No import key** (JSON or Excel) touches the report table at all.
- **Market-report propagation** does not write them (1.6).
- **No scheduled job, seed or bulk-update** was found. The sample seed script bundled with the front end inserts reports without these columns.
- The **API documentation collection** (Postman) predates the fields and does not list them.

### 1.8 Does the client app bundle in this repo render them?

**Not determinable — there is no client app bundle in this repo.** The one front end here is the admin back-office (package name suggests an "emetteur" front). The repo contains no mobile or client-facing screens. What the repo does prove:

- the client API **delivers** both texts (1.6, item 1);
- under the field names **"analysis_custom_content_1"** and **"analysis_custom_content_2"**, described in the API documentation as **"Analysis Custom content 1"** and **"Analysis Custom content 2"**;
- there is **no heading text for them anywhere in the repo's client-facing data or copy** — no translations, no label keys, nothing.

Whether the shipped client app displays them at all, and under what heading, must come from the client app's own source or a device inspection.

### 1.9 History

The two columns were added by a database migration dated **21 September 2023**, generated automatically (no hand-written description). The repository's version history was flattened (the earliest commit touching these names is a bulk update of June 2025), so **who asked for them and why cannot be recovered here**.

---

## Not determinable from this repo

- The **business purpose** of "CUSTOM CONTENT 1" and "CUSTOM CONTENT 2", the intended real labels, whether they are meant for specific companies or languages, and whether authors actually fill them in today. (The screen shows them to everyone, always, so usage can only be answered from production data: count reports with non-empty values.)
- **Whether and under what heading the shipped client app renders them**; no client source is in the repo.
- Why they use a **different editor** from "VALEUR"/"SECTEUR" (richer toolbar, inline images, clipboard-paste button) — design intent, or a later bolt-on.
- **Server behaviour with oversized text** (over the intended 30,000 characters, especially with inline images): no validation was found; failure mode unknown.
- Whether exposing the **lock-holder's name** and **validation statuses** to client users is intended.
- Whether the **soft "not validated" warning** on sending is considered an adequate control.

## Questions the Engage team should ask next

1. How many reports in production have non-empty "CUSTOM CONTENT 1" / "CUSTOM CONTENT 2", over what period, and for which companies/languages? (This settles whether to rebuild, merge into the main text, or drop.)
2. What do these boxes mean to the CMS authors? Should they be given real French and English labels, and should they be optional per company?
3. Does the client app show them, under what heading, and in what order relative to company, sector and market text?
4. Is the richer editor (images, tables, links, paste-from-clipboard) required for these two boxes, or should the replacement use one editor for all four?
5. Should the client API stop returning the lock-holder's name and the validation statuses?
6. Should sending a report require both validations to be done, and should the confirmation text typos ("étés", "dévérouiller") be fixed?
7. Should past-date unsent reports ever be editable, given the screen cannot edit them but the server can?
8. Should the replacement's save keep "send all four texts, overwrite all" semantics, or move to per-field updates so an omitted field cannot blank another?

---

## 2. Completeness checklist

- [x] Custom field controls on the report screen described, or their absence stated — 1.2 to 1.5 (present, labels "CUSTOM CONTENT 1" / "CUSTOM CONTENT 2", position, always shown, no placeholder)
- [x] No source code or file paths
- [x] Closing sections present — "Not determinable from this repo" and "Questions the Engage team should ask next"
