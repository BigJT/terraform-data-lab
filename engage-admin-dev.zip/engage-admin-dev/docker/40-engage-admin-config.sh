#!/bin/sh
# Runs when the container starts (nginx's /docker-entrypoint.d). Writes config.js from the
# container's environment so one image serves every environment. Unset or empty variables
# are left out, and the app then falls back to its built-in defaults.
CONFIG_FILE="${CONFIG_FILE:-/usr/share/nginx/html/engage-admin/config.js}"

pairs=""

# add <key> <value>: appends "key": "value" with backslashes and quotes escaped.
add() {
  [ -n "$2" ] || return 0
  escaped=$(printf '%s' "$2" | tr -d '\r\n' | sed 's/\\/\\\\/g; s/"/\\"/g')
  pair="\"$1\": \"$escaped\""
  if [ -n "$pairs" ]; then pairs="$pairs, $pair"; else pairs="$pair"; fi
}

add gatewayUrl "$GATEWAY_URL"
add entraTenantId "$ENTRA_TENANT_ID"
add entraClientId "$ENTRA_CLIENT_ID"
add apiScope "$API_SCOPE"
add entraMock "$ENTRA_MOCK"

printf 'window.__ENGAGE_ADMIN_CONFIG__ = {%s}\n' "$pairs" > "$CONFIG_FILE"
exit 0
